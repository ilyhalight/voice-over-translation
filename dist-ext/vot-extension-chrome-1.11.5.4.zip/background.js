var e = {
	log: (...e) => {
		console.log("%c[VOT DEBUG]", "background: #3700ffff; color: #fff; padding: 5px;", ...e);
	},
	warn: (...e) => {
		console.warn("%c[VOT DEBUG]", "background: #e1ff00ff; color: #fff; padding: 5px;", ...e);
	},
	error: (...e) => {
		console.error("%c[VOT DEBUG]", "background: #F2452D; color: #fff; padding: 5px;", ...e);
	}
}, t = globalThis.browser, n = globalThis.chrome, r = t ?? n ?? null, i = !!t && r === t, a = typeof t?.runtime?.getBrowserInfo == "function", o = a;
function s() {
	let e = n?.runtime?.lastError ?? r?.runtime?.lastError;
	return e?.message ? String(e.message) : null;
}
async function c(e, t = [], n = {}) {
	if (typeof e != "function") throw TypeError("WebExtension API is not available");
	let r = n.mapCbArgs, a = n.rejectOnLastError !== !1;
	return i ? await e(...t) : await new Promise((n, i) => {
		try {
			e(...t, (...e) => {
				let t = a ? s() : null;
				t ? i(Error(t)) : n(r ? r(...e) : e[0]);
			});
		} catch (e) {
			i(e);
		}
	});
}
async function l(e) {
	let i = a ? void 0 : n?.storage?.local;
	if (i && typeof i.get == "function") return await new Promise((t, n) => {
		try {
			i.get(e, (e) => {
				let r = s();
				if (r) {
					n(Error(r));
					return;
				}
				t(e);
			});
		} catch (e) {
			n(e);
		}
	});
	let o = t?.storage?.local ?? r?.storage?.local;
	return await c(o?.get?.bind(o), [e]);
}
async function u(e) {
	let i = a ? void 0 : n?.storage?.local;
	if (i && typeof i.set == "function") {
		await new Promise((t, n) => {
			try {
				i.set(e, () => {
					let e = s();
					if (e) {
						n(Error(e));
						return;
					}
					t();
				});
			} catch (e) {
				n(e);
			}
		});
		return;
	}
	let o = t?.storage?.local ?? r?.storage?.local;
	await c(o?.set?.bind(o), [e], { mapCbArgs: () => void 0 });
}
async function d(e) {
	let i = a ? void 0 : n?.storage?.local;
	if (i && typeof i.remove == "function") {
		await new Promise((t, n) => {
			try {
				i.remove(e, () => {
					let e = s();
					if (e) {
						n(Error(e));
						return;
					}
					t();
				});
			} catch (e) {
				n(e);
			}
		});
		return;
	}
	let o = t?.storage?.local ?? r?.storage?.local;
	await c(o?.remove?.bind(o), [e], { mapCbArgs: () => void 0 });
}
async function f(e, t) {
	let n = r?.notifications, i = n?.create;
	!n || typeof i != "function" || await c(i.bind(n), [e, t], { mapCbArgs: () => void 0 });
}
async function p(e) {
	let t = r?.notifications, n = t?.clear;
	!t || typeof n != "function" || await c(n.bind(t), [e], {
		mapCbArgs: () => void 0,
		rejectOnLastError: !1
	});
}
async function m(e, t) {
	let n = r?.windows, i = n?.update;
	!n || typeof i != "function" || await c(i.bind(n), [e, t], {
		mapCbArgs: () => void 0,
		rejectOnLastError: !1
	});
}
async function h(e, t) {
	let n = r?.tabs, i = n?.update;
	!n || typeof i != "function" || await c(i.bind(n), [e, t], {
		mapCbArgs: () => void 0,
		rejectOnLastError: !1
	});
}
//#endregion
//#region src/extension/backgroundNotifications.ts
function g(e) {
	if (e instanceof Error) return e.message;
	if (e && typeof e == "object") try {
		return JSON.stringify(e);
	} catch {
		return Object.prototype.toString.call(e);
	}
	try {
		return String(e);
	} catch {
		return "Unknown error";
	}
}
function _(e, t) {
	if (typeof e == "function") try {
		e(t);
	} catch {}
}
function v(e) {
	return !e || typeof e != "object" ? !1 : e.type === "gm_notification";
}
function y(e) {
	let t = e && typeof e == "object" ? e : {}, n = Number(t.timeout ?? 0);
	return {
		title: t.title == null ? "" : String(t.title),
		text: t.text == null ? "" : String(t.text),
		silent: !!t.silent,
		timeout: Number.isFinite(n) && n > 0 ? n : 0
	};
}
function b(e) {
	let t = e.tab?.id, n = e.tab?.windowId;
	return `vot:${typeof t == "number" ? t : -1}:${typeof n == "number" ? n : -1}:${typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}:${Math.random().toString(36).slice(2)}`}`;
}
function x(e) {
	let t = typeof r?.runtime?.getBrowserInfo == "function", n = {
		type: "basic",
		iconUrl: r?.runtime?.getURL ? r.runtime.getURL("icons/icon-128.png") : "icons/icon-128.png",
		title: e.title || "VOT",
		message: e.text
	};
	return t || (n.silent = e.silent), n;
}
function S() {
	r?.runtime?.onMessage?.addListener?.((t, n, r) => {
		if (!v(t)) return;
		let i = y(t.details), a = b(n), o = x(i);
		return (async () => {
			try {
				await f(a, o), i.timeout > 0 && setTimeout(() => {
					p(a);
				}, i.timeout), _(r, { ok: !0 });
			} catch (t) {
				e.error("[VOT EXT][background] Failed to create notification", t), _(r, {
					ok: !1,
					error: g(t)
				});
			}
		})(), !0;
	}), r?.notifications?.onClicked?.addListener?.((e) => {
		if (!e.startsWith("vot:")) return;
		let t = e.split(":");
		if (t.length < 3) return;
		let n = Number(t[1]), r = Number(t[2]);
		Number.isFinite(r) && r >= 0 && m(r, { focused: !0 }), Number.isFinite(n) && n >= 0 && h(n, { active: !0 });
	});
}
//#endregion
//#region src/extension/backgroundStorage.ts
function C(e) {
	return !e || typeof e != "object" ? !1 : e.type === "gm_storage";
}
function w(e) {
	switch (typeof e) {
		case "string": return e;
		case "number":
		case "boolean":
		case "bigint": return String(e);
		default: return "";
	}
}
function T(e) {
	if (e instanceof Error) return e.message;
	if (e && typeof e == "object") try {
		return JSON.stringify(e);
	} catch {
		return Object.prototype.toString.call(e);
	}
	try {
		return String(e);
	} catch {
		return "Unknown error";
	}
}
function E(e, t) {
	if (typeof e == "function") try {
		e(t);
	} catch {}
}
async function D(e, t) {
	switch (e) {
		case "gm_getValue": {
			let e = w(t?.key), n = t?.def, r = await l(e);
			return Object.hasOwn(r, e) ? r[e] : n;
		}
		case "gm_setValue": return await u({ [w(t?.key)]: t?.value }), !0;
		case "gm_deleteValue": return await d(w(t?.key)), !0;
		case "gm_listValues": {
			let e = await l(null);
			return Object.keys(e ?? {});
		}
		case "gm_getValues": return await l(t?.defaults ?? {});
		default: throw Error(`Unknown storage action: ${e}`);
	}
}
function ee() {
	r?.runtime?.onMessage?.addListener?.((e, t, n) => {
		if (C(e)) return (async () => {
			try {
				E(n, {
					ok: !0,
					result: await D(String(e.action ?? ""), e.payload)
				});
			} catch (e) {
				E(n, {
					ok: !1,
					error: T(e)
				});
			}
		})(), !0;
	});
}
//#endregion
//#region src/extension/bodySerialization.ts
var O = typeof Uint8Array.prototype.toBase64 == "function" ? Uint8Array.prototype.toBase64 : null, k = Uint8Array.fromBase64, te = /[-_]/;
function ne(e) {
	let t = String(e).replaceAll(/\s+/g, ""), n = t.length % 4;
	if (n === 1) throw TypeError("Invalid base64 input.");
	return n === 0 ? t : t + "=".repeat(4 - n);
}
function re(e) {
	let t = "";
	for (let n of e) t += String.fromCharCode(n);
	return t;
}
function A(e) {
	if (typeof O == "function") return O.call(e);
	let t = globalThis.btoa;
	if (typeof t != "function") throw TypeError("Base64 encoder is not available in this environment.");
	return t(re(e));
}
function ie(e) {
	return A(new Uint8Array(e));
}
function j(e) {
	let t = ne(e), n = t.replaceAll("-", "+").replaceAll("_", "/");
	if (typeof k == "function") {
		let e = te.test(t);
		return k(e ? n : t, e ? { alphabet: "base64" } : void 0);
	}
	let r = globalThis.atob;
	if (typeof r != "function") throw TypeError("Base64 decoder is not available in this environment.");
	let i = r(n), a = new Uint8Array(i.length);
	for (let e = 0; e < i.length; e += 1) a[e] = i.charCodeAt(e);
	return a;
}
var M = 1e7, ae = 12, oe = 2;
function N(e) {
	return typeof e == "object" && !!e;
}
function se(e) {
	return P(e) === "[object Object]";
}
function P(e) {
	try {
		return Object.prototype.toString.call(e);
	} catch {
		return null;
	}
}
function F(e) {
	return P(e) === "[object ArrayBuffer]";
}
function ce(e) {
	try {
		let t = e?.constructor?.name;
		return typeof t == "string" ? t : null;
	} catch {
		return null;
	}
}
function I(e, t) {
	try {
		let n = e?.[t];
		return typeof n == "string" ? n : null;
	} catch {
		return null;
	}
}
function L(e) {
	if (P(e) === "[object Blob]") return !0;
	if (!e || typeof e != "object") return !1;
	try {
		let t = e, n = typeof t.arrayBuffer == "function", r = typeof t.slice == "function", i = typeof t.size == "number", a = typeof t.type == "string";
		return (n || r) && i && a;
	} catch {
		return !1;
	}
}
function le(e) {
	try {
		return JSON.stringify(e);
	} catch {
		return null;
	}
}
function R(e) {
	if (typeof e != "number" || !Number.isFinite(e)) return null;
	let t = Math.trunc(e);
	return t < 0 || t > M ? null : t;
}
function z(e) {
	return typeof e != "number" || !Number.isFinite(e) ? null : Math.trunc(e) & 255;
}
function ue(e) {
	let t = e.length;
	if (t > M) return null;
	let n = new Uint8Array(t);
	for (let r = 0; r < t; r += 1) {
		let t = z(e[r]);
		if (t === null) return null;
		n[r] = t;
	}
	return n;
}
function de(e) {
	return new Uint8Array(e.buffer, e.byteOffset, e.byteLength);
}
function fe(e) {
	return de(e).slice();
}
function pe(e) {
	if (e === "") return null;
	let t = Number(e);
	return !Number.isFinite(t) || !Number.isInteger(t) || t < 0 ? null : t;
}
function B(e) {
	if (!N(e)) return !1;
	let t = e;
	return t.__votExtBody === !0 && typeof t.b64 == "string";
}
function V(e, t = 0) {
	if (t > oe || !N(e)) return null;
	let n = e;
	if (F(e)) return new Uint8Array(e);
	try {
		if (ArrayBuffer.isView(e)) return fe(e);
	} catch {}
	return Array.isArray(e) ? ue(e) : me(n) || he(n) || ge(n, e, t) || _e(n) || (se(e) ? ve(n) : null);
}
function me(e) {
	let t = [
		e.type === "Buffer" && Array.isArray(e.data) ? e.data : null,
		Array.isArray(e.data) ? e.data : null,
		Array.isArray(e.bytes) ? e.bytes : null
	];
	for (let e of t) {
		if (!e) continue;
		let t = ue(e);
		if (t) return t;
	}
	return null;
}
function he(e) {
	let t = [e.b64, e.base64];
	for (let e of t) if (typeof e == "string") try {
		return j(e);
	} catch {}
	return null;
}
function ge(e, t, n) {
	let r = R(e.byteLength), i = R(e.byteOffset ?? 0);
	if (r === null || i === null) return null;
	let a = e.buffer;
	if (F(a)) try {
		return new Uint8Array(a, i, r).slice();
	} catch {}
	if (!a || a === t) return null;
	let o = V(a, n + 1);
	if (!o || i > o.byteLength) return null;
	let s = Math.min(o.byteLength, i + r);
	return o.slice(i, s);
}
function _e(e) {
	let t = R(e.length);
	if (t === null) return null;
	let n = e, r = new Uint8Array(t);
	for (let e = 0; e < t; e += 1) {
		let t = z(n[e]);
		if (t === null) return null;
		r[e] = t;
	}
	return r;
}
function ve(e) {
	let t = Object.keys(e);
	if (!t.length) return null;
	let n = Array(t.length), r = -1;
	for (let e = 0; e < t.length; e += 1) {
		let i = pe(t[e]);
		if (i === null || i > M) return null;
		n[e] = i, i > r && (r = i);
	}
	let i = new Uint8Array(r + 1);
	for (let r = 0; r < t.length; r += 1) {
		let a = z(e[t[r]]);
		if (a === null) return null;
		i[n[r]] = a;
	}
	return i;
}
function H(e) {
	return V(e);
}
function U(e) {
	let t = e === null ? "null" : typeof e, n = P(e), r = ce(e), i = ye(e, t, n, r);
	if (i) return i;
	let a = be(e, t, n, r);
	if (a) return a;
	let o = xe(e, t, n, r);
	if (o) return o;
	let s = H(e);
	if (s) return {
		kind: "coerced-bytes",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: s.byteLength
	};
	if (N(e)) {
		let i = Object.keys(e);
		return {
			kind: "object",
			jsType: t,
			tag: n,
			ctor: r,
			keyCount: i.length,
			keys: i.slice(0, ae)
		};
	}
	return {
		kind: "primitive",
		jsType: t,
		tag: n,
		ctor: r
	};
}
function ye(e, t, n, r) {
	return e == null ? {
		kind: "empty",
		jsType: t,
		tag: n,
		ctor: r
	} : typeof e == "string" ? {
		kind: "string",
		jsType: t,
		tag: n,
		ctor: r,
		textLength: e.length
	} : null;
}
function be(e, t, n, r) {
	return B(e) ? {
		kind: `serialized:${typeof e.kind == "string" && e.kind ? e.kind : "bytes"}`,
		jsType: t,
		tag: n,
		ctor: r,
		base64Length: e.b64.length,
		mime: I(e, "mime")
	} : null;
}
function xe(e, t, n, r) {
	if (F(e)) return {
		kind: "ArrayBuffer",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: e.byteLength
	};
	try {
		if (ArrayBuffer.isView(e)) return {
			kind: r ? `TypedArray:${r}` : "TypedArray",
			jsType: t,
			tag: n,
			ctor: r,
			byteLength: e.byteLength
		};
	} catch {}
	return L(e) ? {
		kind: "BlobLike",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: typeof e.size == "number" ? Number(e.size) : -1,
		mime: I(e, "type")
	} : null;
}
function Se(e) {
	if (e == null) return;
	if (typeof e == "string" || F(e)) return e;
	try {
		if (ArrayBuffer.isView(e)) return de(e);
	} catch {}
	if (L(e)) return e;
	if (B(e)) return Ce(e);
	let t = H(e);
	if (t) return t;
	if (N(e)) {
		let t = le(e);
		if (typeof t == "string") return t;
	}
	return String(e);
}
function Ce(e) {
	let t = j(e.b64);
	if ((typeof e.kind == "string" && e.kind ? e.kind : "bytes") !== "blob") return t;
	let n = e.mime, r = t.buffer;
	return typeof n == "string" && n ? new Blob([r], { type: n }) : new Blob([r]);
}
//#endregion
//#region src/extension/yandexHeaders.ts
var we = "api.browser.yandex.ru", Te = new Set([
	"sec-ch-ua",
	"sec-ch-ua-mobile",
	"sec-ch-ua-platform",
	"sec-ch-ua-full-version-list"
]), W = [
	"sec-ch-ua-full-version",
	"sec-ch-ua-platform-version",
	"sec-ch-ua-arch",
	"sec-ch-ua-bitness",
	"sec-ch-ua-model",
	"sec-ch-ua-wow64"
], Ee = new Set(W);
function De(e) {
	return String(e || "") === we;
}
function G(e) {
	return String(e || "").trim();
}
function Oe(e) {
	let t = G(e).toLowerCase();
	return t ? !!(t === "origin" || t === "referer" || Ee.has(t) || t.startsWith("sec-ch-ua") && !Te.has(t)) : !1;
}
function ke(e) {
	let t = {};
	for (let [n, r] of Object.entries(e || {})) {
		let e = G(n);
		e && (Oe(e) || (t[e] = String(r)));
	}
	return t;
}
//#endregion
//#region src/extension/background.ts
var Ae = 512 * 1024, je = /application\/(?:x-)?protobuf|application\/octet-stream/, Me = /^(?=.*[+/=_-])[A-Za-z0-9+/=_-]+$/, K = 9001, q = 9002, J = 9003, Y = /* @__PURE__ */ new Map(), X = Promise.resolve();
function Z() {
	return !!r?.declarativeNetRequest?.updateSessionRules;
}
function Ne(e) {
	let t = r?.declarativeNetRequest?.updateSessionRules;
	if (typeof t != "function") return Promise.resolve();
	try {
		let n = t({
			addRules: e.addRules || [],
			removeRuleIds: e.removeRuleIds || []
		});
		if (n && typeof n.then == "function") return n;
	} catch {}
	return new Promise((n, r) => {
		try {
			t({
				addRules: e.addRules || [],
				removeRuleIds: e.removeRuleIds || []
			}, () => {
				let e = s();
				e ? r(Error(e)) : n();
			});
		} catch (e) {
			r(e);
		}
	});
}
function Pe(e) {
	let t = G(e).toLowerCase();
	if (!t) return !1;
	switch (t[0]) {
		case "s": return t.startsWith("sec-");
		case "p": return t.startsWith("proxy-");
		case "u": return t === "user-agent";
		case "o": return t === "origin";
		case "r": return t === "referer";
		default: return !1;
	}
}
function Q(e) {
	let t = e.map((e) => [`${G(String(e.header)).toLowerCase()}:${String(e.operation)}`, String("value" in e ? e.value : "")]).sort((e, t) => e[0].localeCompare(t[0]));
	return JSON.stringify(t);
}
function $(e, t, n) {
	return t === Y.get(e) ? Promise.resolve() : (X = X.catch(() => void 0).then(async () => {
		t !== Y.get(e) && (await Ne({
			removeRuleIds: [e],
			addRules: [n]
		}), Y.set(e, t));
	}), X);
}
async function Fe(e, t) {
	if (!Z()) return;
	let n = "";
	try {
		n = new URL(e).hostname;
	} catch {
		return;
	}
	if (!De(n)) return;
	let r = [
		{
			header: "Origin",
			operation: "remove"
		},
		{
			header: "Referer",
			operation: "remove"
		},
		...W.map((e) => ({
			header: e,
			operation: "remove"
		}))
	], i = ke(t);
	for (let [e, t] of Object.entries(i)) r.push({
		header: G(e),
		operation: "set",
		value: String(t)
	});
	await $(K, Q(r), {
		id: K,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders: r
		},
		condition: {
			urlFilter: "|https://api.browser.yandex.ru/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
function Ie(e) {
	try {
		let t = new URL(e);
		return t.protocol === "https:" && t.hostname === "www.youtube.com" && t.pathname.startsWith("/youtubei/");
	} catch {
		return !1;
	}
}
function Le(e) {
	try {
		let t = new URL(e), n = t.hostname.toLowerCase();
		return t.protocol === "https:" && (n === "googlevideo.com" || n.endsWith(".googlevideo.com"));
	} catch {
		return !1;
	}
}
async function Re(e) {
	if (!Z() || !Ie(e)) return;
	let t = [
		{
			header: "Origin",
			operation: "remove"
		},
		{
			header: "x-client-data",
			operation: "remove"
		},
		{
			header: "x-goog-visitor-id",
			operation: "remove"
		}
	];
	await $(q, JSON.stringify({
		v: 2,
		headers: Q(t)
	}), {
		id: q,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders: t
		},
		condition: {
			urlFilter: "|https://www.youtube.com/youtubei/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
async function ze(e) {
	if (!Z() || !Le(e)) return;
	let t = [{
		header: "x-client-data",
		operation: "remove"
	}];
	await $(J, JSON.stringify({
		v: 1,
		headers: Q(t)
	}), {
		id: J,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders: t
		},
		condition: {
			urlFilter: "||googlevideo.com/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
function Be(e) {
	if (e instanceof Error) return e.message;
	if (e && typeof e == "object") try {
		return JSON.stringify(e);
	} catch {
		return Object.prototype.toString.call(e);
	}
	try {
		return String(e);
	} catch {
		return "Unknown error";
	}
}
function Ve(e) {
	return Array.from(e.entries()).map(([e, t]) => `${e}: ${t}`).join("\r\n");
}
function He(e) {
	let t = {};
	if (!e) return t;
	for (let [n, r] of Object.entries(e)) r !== void 0 && (typeof r == "string" || typeof r == "number" || typeof r == "boolean") && (t[String(n)] = String(r));
	return t;
}
function Ue(e, t) {
	return {
		finalUrl: e,
		readyState: 4,
		status: 0,
		statusText: "",
		responseHeaders: "",
		response: null,
		responseText: "",
		error: t
	};
}
function We(e) {
	let t = new Uint8Array(e.byteLength);
	return t.set(e), t.buffer;
}
function Ge(e) {
	return o ? { chunk: We(e) } : { chunkB64: A(e) };
}
function Ke(e) {
	return o ? { response: e } : e.byteLength <= 0 ? {} : { responseB64: ie(e) };
}
function qe(e, t) {
	let n = t.toLowerCase();
	for (let [t, r] of Object.entries(e)) if (String(t).toLowerCase() === n) return String(r);
}
function Je(e) {
	return je.test(String(e ?? "").toLowerCase());
}
function Ye(e) {
	let t = String(e ?? "");
	if (!Me.test(t)) return null;
	let n = t.replaceAll("-", "+").replaceAll("_", "/"), r = n.length % 4;
	if (r === 1) return null;
	let i = r === 0 ? n : `${n}${"=".repeat(4 - r)}`;
	try {
		return j(i);
	} catch {
		return null;
	}
}
function Xe(e) {
	let t = String(e || ""), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; e += 1) n[e] = (t.codePointAt(e) ?? 0) & 255;
	return n;
}
function Ze(e) {
	return /^\[object [^\]]+\]$/.test(String(e || "").trim());
}
var Qe = 0;
r?.runtime?.onConnect?.addListener?.((t) => {
	if (!t || typeof t != "object") return;
	let n = t;
	if (n.name !== "vot_gm_xhr" || typeof n.onDisconnect?.addListener != "function" || typeof n.onMessage?.addListener != "function" || typeof n.postMessage != "function") return;
	let r = (e) => {
		n.postMessage?.(e);
	};
	Qe += 1;
	let i = Qe, a = null, o = null, s = !1, c = !1, l = () => {
		o !== null && (clearTimeout(o), o = null);
	};
	n.onDisconnect.addListener(() => {
		l(), e.warn("[VOT EXT][background][xhr] port disconnected", { xhrSessionId: i }), u();
	});
	let u = () => {
		try {
			a?.abort();
		} catch {}
	}, d = () => {
		s = !0, e.warn("[VOT EXT][background][xhr] abort requested", { xhrSessionId: i }), u();
	}, f = (e) => {
		let t = He(e.headers), n = {}, r = {};
		for (let [e, i] of Object.entries(t)) Pe(e) ? r[e] = i : n[e] = i;
		return {
			allHeaders: t,
			headers: n,
			forbiddenHeaders: r
		};
	}, p = (e) => {
		let t = {
			finalUrl: e,
			readyState: 4,
			status: 0,
			statusText: "",
			responseHeaders: "",
			response: null,
			responseText: "",
			error: "Aborted"
		};
		try {
			r({
				type: "abort",
				state: "terminal",
				error: t
			});
		} catch {}
	}, m = (e) => e.anonymous || e.withCredentials === !1 ? "omit" : "include", h = (e) => {
		if (e.nocache) return "no-store";
		if (e.revalidate) return "no-cache";
	}, g = (t, n, r, a) => {
		if (n === "GET") return;
		let o = Se(t.data), s, c = () => (s === void 0 && (s = H(t.data)), s), l = qe(r, "content-type"), u = Je(l);
		if (e.log("[VOT EXT][background][xhr] body decoded", {
			xhrSessionId: i,
			url: a,
			method: n,
			contentType: l ?? null,
			isProtobufRequest: u,
			sourceBody: U(t.data),
			decodedBody: U(o)
		}), u && o == null) {
			let t = c();
			t && (o = t, e.warn("[VOT EXT][background][xhr] protobuf body recovered from raw payload", {
				xhrSessionId: i,
				url: a,
				method: n,
				recoveredBody: U(o)
			}));
		}
		if (typeof o == "string" && u) {
			if (Ze(o)) {
				let r = c();
				r && (o = r, e.warn("[VOT EXT][background][xhr] recovered protobuf body from object-like string fallback", {
					xhrSessionId: i,
					url: a,
					method: n,
					sourceBody: U(t.data),
					recoveredBody: U(r)
				}));
			}
			if (typeof o == "string") {
				let t = Ye(o);
				o = t ?? Xe(o), e.log("[VOT EXT][background][xhr] protobuf string converted to bytes", {
					xhrSessionId: i,
					url: a,
					method: n,
					strategy: t ? "base64" : "latin1",
					convertedBody: U(o)
				});
			}
		}
		return o;
	}, _ = (e) => {
		let t = {
			method: e.method,
			headers: e.headers,
			redirect: e.redirect,
			credentials: e.credentials,
			signal: a?.signal
		};
		return e.body !== void 0 && (t.body = e.body), e.cache !== void 0 && (t.cache = e.cache), t;
	}, v = async (t) => {
		let { url: n, method: a, responseType: o, res: s } = t;
		e.log("[VOT EXT][background][xhr] fetch response received", {
			xhrSessionId: i,
			url: s.url || n,
			method: a,
			status: s.status,
			statusText: s.statusText,
			responseType: o,
			contentType: s.headers.get("content-type") || null,
			contentLength: s.headers.get("content-length") || null
		});
		let c = Ve(s.headers), u = s.url || n, d = s.headers.get("content-type") || "", f = (e) => ({
			finalUrl: u,
			readyState: e,
			status: s.status,
			statusText: s.statusText,
			responseHeaders: c
		}), p = o === "arraybuffer" || o === "blob" || o === "stream", m, h, g;
		if (p) {
			let e = Number(s.headers.get("content-length") || 0);
			if (s.body && (!Number.isFinite(e) || e > Ae)) {
				let t = 0, n = Number.isFinite(e) ? e : 0, i = s.body.getReader();
				for (;;) {
					let { done: e, value: a } = await i.read();
					if (e) break;
					a && (t += a.byteLength, r({
						type: "progress",
						state: "in_flight",
						progress: {
							...f(3),
							loaded: t,
							total: n,
							lengthComputable: n > 0,
							...Ge(a)
						}
					}));
				}
			} else {
				let e = Ke(await s.arrayBuffer());
				m = e.response, g = e.responseB64;
			}
		} else if (o === "json") {
			h = await s.text();
			try {
				m = JSON.parse(h);
			} catch {
				m = null;
			}
		} else h = await s.text(), m = h;
		l(), e.log("[VOT EXT][background][xhr] terminal", {
			xhrSessionId: i,
			state: "terminal",
			kind: "load",
			url: u,
			status: s.status,
			responseType: o,
			responseBody: U(m),
			responseTextLength: h?.length ?? 0,
			responseB64Length: g?.length ?? 0
		}), r({
			type: "load",
			state: "terminal",
			response: {
				...f(4),
				responseType: o,
				...d ? { contentType: d } : {},
				...g ? { responseB64: g } : {},
				response: m,
				...typeof h == "string" ? { responseText: h } : {}
			}
		});
	}, y = (t, n, a, o) => {
		if (l(), s || c || o instanceof DOMException && o.name === "AbortError") {
			let o = c ? "timeout" : "abort", s = Ue(t, o === "timeout" ? "Timeout" : "Aborted");
			try {
				r({
					type: o,
					state: "terminal",
					error: s
				});
			} catch {}
			e.warn("[VOT EXT][background][xhr] terminal", {
				xhrSessionId: i,
				state: "terminal",
				kind: o,
				url: t,
				method: n,
				responseType: a
			});
			return;
		}
		let u = Ue(t, Be(o));
		r({
			type: "error",
			state: "terminal",
			error: u
		}), e.error("[VOT EXT][background][xhr] terminal", {
			xhrSessionId: i,
			state: "terminal",
			kind: "error",
			url: t,
			method: n,
			responseType: a,
			error: u.error
		});
	}, b = async (t) => {
		let n = s && a === null;
		s = !1;
		let { details: r } = t, l = r.url, d = (r.method || "GET").toUpperCase(), { allHeaders: b, headers: x, forbiddenHeaders: S } = f(r), C = Number(r.timeout || 0), w = String(r.responseType || "text").toLowerCase();
		if (e.log("[VOT EXT][background][xhr] start", {
			xhrSessionId: i,
			state: "in_flight",
			url: l,
			method: d,
			responseType: w,
			timeoutMs: C,
			headerCount: Object.keys(b).length,
			headerNames: Object.keys(b),
			forbiddenHeaderNames: Object.keys(S),
			body: U(r.data)
		}), n) {
			p(l);
			return;
		}
		c = !1, a = new AbortController(), C > 0 && (o = setTimeout(() => {
			c = !0, u();
		}, C));
		let T = m(r), E = h(r), D = r.redirect === "error" || r.redirect === "manual" ? r.redirect : "follow";
		try {
			try {
				await ze(l), await Re(l), await Fe(l, S);
			} catch (e) {
				console.warn("[VOT Extension] Failed to apply DNR header rules; requests may break:", e);
			}
			let t = g(r, d, b, l);
			e.log("[VOT EXT][background][xhr] fetch dispatch", {
				xhrSessionId: i,
				url: l,
				method: d,
				credentials: T,
				redirect: D,
				cache: E ?? "default",
				body: U(t)
			});
			let n = _({
				method: d,
				headers: x,
				redirect: D,
				credentials: T,
				body: t,
				cache: E
			});
			await v({
				url: l,
				method: d,
				responseType: w,
				res: await fetch(l, n)
			});
		} catch (e) {
			y(l, d, w, e);
		}
	};
	n.onMessage.addListener(async (e) => {
		if (!(!e || typeof e != "object")) {
			if (e.type === "abort") {
				d();
				return;
			}
			e.type === "start" && await b(e);
		}
	});
}), ee(), S();
//#endregion
