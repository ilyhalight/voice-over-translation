//#region src/utils/debug.ts
var e = () => {}, t = {
	log: e,
	warn: e,
	error: e
}, n = globalThis.browser, r = globalThis.chrome, i = n ?? r ?? null, a = !!n && i === n, o = typeof n?.runtime?.getBrowserInfo == "function", s = o;
function c() {
	let e = r?.runtime?.lastError ?? i?.runtime?.lastError;
	return e?.message ? String(e.message) : null;
}
async function l(e, t = [], n = {}) {
	if (typeof e != "function") throw TypeError("WebExtension API is not available");
	let r = n.mapCbArgs, i = n.rejectOnLastError !== !1;
	return a ? await e(...t) : await new Promise((n, a) => {
		try {
			e(...t, (...e) => {
				let t = i ? c() : null;
				t ? a(Error(t)) : n(r ? r(...e) : e[0]);
			});
		} catch (e) {
			a(e);
		}
	});
}
async function u(e) {
	let t = o ? void 0 : r?.storage?.local;
	if (t && typeof t.get == "function") return await new Promise((n, r) => {
		try {
			t.get(e, (e) => {
				let t = c();
				if (t) {
					r(Error(t));
					return;
				}
				n(e);
			});
		} catch (e) {
			r(e);
		}
	});
	let a = n?.storage?.local ?? i?.storage?.local;
	return await l(a?.get?.bind(a), [e]);
}
async function d(e) {
	let t = o ? void 0 : r?.storage?.local;
	if (t && typeof t.set == "function") {
		await new Promise((n, r) => {
			try {
				t.set(e, () => {
					let e = c();
					if (e) {
						r(Error(e));
						return;
					}
					n();
				});
			} catch (e) {
				r(e);
			}
		});
		return;
	}
	let a = n?.storage?.local ?? i?.storage?.local;
	await l(a?.set?.bind(a), [e], { mapCbArgs: () => void 0 });
}
async function f(e) {
	let t = o ? void 0 : r?.storage?.local;
	if (t && typeof t.remove == "function") {
		await new Promise((n, r) => {
			try {
				t.remove(e, () => {
					let e = c();
					if (e) {
						r(Error(e));
						return;
					}
					n();
				});
			} catch (e) {
				r(e);
			}
		});
		return;
	}
	let a = n?.storage?.local ?? i?.storage?.local;
	await l(a?.remove?.bind(a), [e], { mapCbArgs: () => void 0 });
}
async function p(e, t) {
	let n = i?.notifications, r = n?.create;
	!n || typeof r != "function" || await l(r.bind(n), [e, t], { mapCbArgs: () => void 0 });
}
async function m(e) {
	let t = i?.notifications, n = t?.clear;
	!t || typeof n != "function" || await l(n.bind(t), [e], {
		mapCbArgs: () => void 0,
		rejectOnLastError: !1
	});
}
async function h(e, t) {
	let n = i?.windows, r = n?.update;
	!n || typeof r != "function" || await l(r.bind(n), [e, t], {
		mapCbArgs: () => void 0,
		rejectOnLastError: !1
	});
}
async function g(e, t) {
	let n = i?.tabs, r = n?.update;
	!n || typeof r != "function" || await l(r.bind(n), [e, t], {
		mapCbArgs: () => void 0,
		rejectOnLastError: !1
	});
}
//#endregion
//#region src/extension/backgroundNotifications.ts
function ee(e) {
	if (e instanceof Error) return e.message;
	if (e && typeof e == "object") try {
		return JSON.stringify(e);
	} catch {
		return Object.prototype.toString.call(e);
	}
	try {
		return String(e);
	} catch {
		return "Unknown error";
	}
}
function _(e, t) {
	if (typeof e == "function") try {
		e(t);
	} catch {}
}
function te(e) {
	return !e || typeof e != "object" ? !1 : e.type === "gm_notification";
}
function v(e) {
	let t = e && typeof e == "object" ? e : {}, n = Number(t.timeout ?? 0);
	return {
		title: t.title == null ? "" : String(t.title),
		text: t.text == null ? "" : String(t.text),
		silent: !!t.silent,
		timeout: Number.isFinite(n) && n > 0 ? n : 0
	};
}
function y(e) {
	let t = e.tab?.id, n = e.tab?.windowId;
	return `vot:${typeof t == "number" ? t : -1}:${typeof n == "number" ? n : -1}:${typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}:${Math.random().toString(36).slice(2)}`}`;
}
function b(e) {
	let t = typeof i?.runtime?.getBrowserInfo == "function", n = {
		type: "basic",
		iconUrl: i?.runtime?.getURL ? i.runtime.getURL("icons/icon-128.png") : "icons/icon-128.png",
		title: e.title || "VOT",
		message: e.text
	};
	return t || (n.silent = e.silent), n;
}
function x() {
	i?.runtime?.onMessage?.addListener?.((e, n, r) => {
		if (!te(e)) return;
		let i = v(e.details), a = y(n), o = b(i);
		return (async () => {
			try {
				await p(a, o), i.timeout > 0 && setTimeout(() => {
					m(a);
				}, i.timeout), _(r, { ok: !0 });
			} catch (e) {
				t.error("[VOT EXT][background] Failed to create notification", e), _(r, {
					ok: !1,
					error: ee(e)
				});
			}
		})(), !0;
	}), i?.notifications?.onClicked?.addListener?.((e) => {
		if (!e.startsWith("vot:")) return;
		let t = e.split(":");
		if (t.length < 3) return;
		let n = Number(t[1]), r = Number(t[2]);
		Number.isFinite(r) && r >= 0 && h(r, { focused: !0 }), Number.isFinite(n) && n >= 0 && g(n, { active: !0 });
	});
}
//#endregion
//#region src/extension/backgroundStorage.ts
function S(e) {
	return !e || typeof e != "object" ? !1 : e.type === "gm_storage";
}
function C(e) {
	switch (typeof e) {
		case "string": return e;
		case "number":
		case "boolean":
		case "bigint": return String(e);
		default: return "";
	}
}
function w(e) {
	if (e instanceof Error) return e.message;
	if (e && typeof e == "object") try {
		return JSON.stringify(e);
	} catch {
		return Object.prototype.toString.call(e);
	}
	try {
		return String(e);
	} catch {
		return "Unknown error";
	}
}
function T(e, t) {
	if (typeof e == "function") try {
		e(t);
	} catch {}
}
async function ne(e, t) {
	switch (e) {
		case "gm_getValue": {
			let e = C(t?.key), n = t?.def, r = await u(e);
			return Object.hasOwn(r, e) ? r[e] : n;
		}
		case "gm_setValue": return await d({ [C(t?.key)]: t?.value }), !0;
		case "gm_deleteValue": return await f(C(t?.key)), !0;
		case "gm_listValues": {
			let e = await u(null);
			return Object.keys(e ?? {});
		}
		case "gm_getValues": return await u(t?.defaults ?? {});
		default: throw Error(`Unknown storage action: ${e}`);
	}
}
function re() {
	i?.runtime?.onMessage?.addListener?.((e, t, n) => {
		if (S(e)) return (async () => {
			try {
				T(n, {
					ok: !0,
					result: await ne(String(e.action ?? ""), e.payload)
				});
			} catch (e) {
				T(n, {
					ok: !1,
					error: w(e)
				});
			}
		})(), !0;
	});
}
//#endregion
//#region src/extension/bodySerialization.ts
var E = typeof Uint8Array.prototype.toBase64 == "function" ? Uint8Array.prototype.toBase64 : null, D = Uint8Array.fromBase64, ie = /[-_]/;
function ae(e) {
	let t = String(e).replaceAll(/\s+/g, ""), n = t.length % 4;
	if (n === 1) throw TypeError("Invalid base64 input.");
	return n === 0 ? t : t + "=".repeat(4 - n);
}
function oe(e) {
	let t = "";
	for (let n of e) t += String.fromCharCode(n);
	return t;
}
function O(e) {
	if (typeof E == "function") return E.call(e);
	let t = globalThis.btoa;
	if (typeof t != "function") throw TypeError("Base64 encoder is not available in this environment.");
	return t(oe(e));
}
function se(e) {
	return O(new Uint8Array(e));
}
function k(e) {
	let t = ae(e), n = t.replaceAll("-", "+").replaceAll("_", "/");
	if (typeof D == "function") {
		let e = ie.test(t);
		return D(e ? n : t, e ? { alphabet: "base64" } : void 0);
	}
	let r = globalThis.atob;
	if (typeof r != "function") throw TypeError("Base64 decoder is not available in this environment.");
	let i = r(n), a = new Uint8Array(i.length);
	for (let e = 0; e < i.length; e += 1) a[e] = i.charCodeAt(e);
	return a;
}
var A = 1e7, ce = 12, le = 2;
function j(e) {
	return typeof e == "object" && !!e;
}
function ue(e) {
	return M(e) === "[object Object]";
}
function M(e) {
	try {
		return Object.prototype.toString.call(e);
	} catch {
		return null;
	}
}
function N(e) {
	return M(e) === "[object ArrayBuffer]";
}
function de(e) {
	try {
		let t = e?.constructor?.name;
		return typeof t == "string" ? t : null;
	} catch {
		return null;
	}
}
function P(e, t) {
	try {
		let n = e?.[t];
		return typeof n == "string" ? n : null;
	} catch {
		return null;
	}
}
function F(e) {
	if (M(e) === "[object Blob]") return !0;
	if (!e || typeof e != "object") return !1;
	try {
		let t = e, n = typeof t.arrayBuffer == "function", r = typeof t.slice == "function", i = typeof t.size == "number", a = typeof t.type == "string";
		return (n || r) && i && a;
	} catch {
		return !1;
	}
}
function fe(e) {
	try {
		return JSON.stringify(e);
	} catch {
		return null;
	}
}
function I(e) {
	if (typeof e != "number" || !Number.isFinite(e)) return null;
	let t = Math.trunc(e);
	return t < 0 || t > A ? null : t;
}
function L(e) {
	return typeof e != "number" || !Number.isFinite(e) ? null : Math.trunc(e) & 255;
}
function R(e) {
	let t = e.length;
	if (t > A) return null;
	let n = new Uint8Array(t);
	for (let r = 0; r < t; r += 1) {
		let t = L(e[r]);
		if (t === null) return null;
		n[r] = t;
	}
	return n;
}
function z(e) {
	return new Uint8Array(e.buffer, e.byteOffset, e.byteLength);
}
function pe(e) {
	return z(e).slice();
}
function me(e) {
	if (e === "") return null;
	let t = Number(e);
	return !Number.isFinite(t) || !Number.isInteger(t) || t < 0 ? null : t;
}
function B(e) {
	if (!j(e)) return !1;
	let t = e;
	return t.__votExtBody === !0 && typeof t.b64 == "string";
}
function V(e, t = 0) {
	if (t > le || !j(e)) return null;
	let n = e;
	if (N(e)) return new Uint8Array(e);
	try {
		if (ArrayBuffer.isView(e)) return pe(e);
	} catch {}
	return Array.isArray(e) ? R(e) : he(n) || ge(n) || _e(n, e, t) || ve(n) || (ue(e) ? ye(n) : null);
}
function he(e) {
	let t = [
		e.type === "Buffer" && Array.isArray(e.data) ? e.data : null,
		Array.isArray(e.data) ? e.data : null,
		Array.isArray(e.bytes) ? e.bytes : null
	];
	for (let e of t) {
		if (!e) continue;
		let t = R(e);
		if (t) return t;
	}
	return null;
}
function ge(e) {
	let t = [e.b64, e.base64];
	for (let e of t) if (typeof e == "string") try {
		return k(e);
	} catch {}
	return null;
}
function _e(e, t, n) {
	let r = I(e.byteLength), i = I(e.byteOffset ?? 0);
	if (r === null || i === null) return null;
	let a = e.buffer;
	if (N(a)) try {
		return new Uint8Array(a, i, r).slice();
	} catch {}
	if (!a || a === t) return null;
	let o = V(a, n + 1);
	if (!o || i > o.byteLength) return null;
	let s = Math.min(o.byteLength, i + r);
	return o.slice(i, s);
}
function ve(e) {
	let t = I(e.length);
	if (t === null) return null;
	let n = e, r = new Uint8Array(t);
	for (let e = 0; e < t; e += 1) {
		let t = L(n[e]);
		if (t === null) return null;
		r[e] = t;
	}
	return r;
}
function ye(e) {
	let t = Object.keys(e);
	if (!t.length) return null;
	let n = Array(t.length), r = -1;
	for (let e = 0; e < t.length; e += 1) {
		let i = me(t[e]);
		if (i === null || i > A) return null;
		n[e] = i, i > r && (r = i);
	}
	let i = new Uint8Array(r + 1);
	for (let r = 0; r < t.length; r += 1) {
		let a = L(e[t[r]]);
		if (a === null) return null;
		i[n[r]] = a;
	}
	return i;
}
function H(e) {
	return V(e);
}
function U(e) {
	let t = e === null ? "null" : typeof e, n = M(e), r = de(e), i = be(e, t, n, r);
	if (i) return i;
	let a = xe(e, t, n, r);
	if (a) return a;
	let o = Se(e, t, n, r);
	if (o) return o;
	let s = H(e);
	if (s) return {
		kind: "coerced-bytes",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: s.byteLength
	};
	if (j(e)) {
		let i = Object.keys(e);
		return {
			kind: "object",
			jsType: t,
			tag: n,
			ctor: r,
			keyCount: i.length,
			keys: i.slice(0, ce)
		};
	}
	return {
		kind: "primitive",
		jsType: t,
		tag: n,
		ctor: r
	};
}
function be(e, t, n, r) {
	return e == null ? {
		kind: "empty",
		jsType: t,
		tag: n,
		ctor: r
	} : typeof e == "string" ? {
		kind: "string",
		jsType: t,
		tag: n,
		ctor: r,
		textLength: e.length
	} : null;
}
function xe(e, t, n, r) {
	return B(e) ? {
		kind: `serialized:${typeof e.kind == "string" && e.kind ? e.kind : "bytes"}`,
		jsType: t,
		tag: n,
		ctor: r,
		base64Length: e.b64.length,
		mime: P(e, "mime")
	} : null;
}
function Se(e, t, n, r) {
	if (N(e)) return {
		kind: "ArrayBuffer",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: e.byteLength
	};
	try {
		if (ArrayBuffer.isView(e)) return {
			kind: r ? `TypedArray:${r}` : "TypedArray",
			jsType: t,
			tag: n,
			ctor: r,
			byteLength: e.byteLength
		};
	} catch {}
	return F(e) ? {
		kind: "BlobLike",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: typeof e.size == "number" ? Number(e.size) : -1,
		mime: P(e, "type")
	} : null;
}
function Ce(e) {
	if (e == null) return;
	if (typeof e == "string" || N(e)) return e;
	try {
		if (ArrayBuffer.isView(e)) return z(e);
	} catch {}
	if (F(e)) return e;
	if (B(e)) return we(e);
	let t = H(e);
	if (t) return t;
	if (j(e)) {
		let t = fe(e);
		if (typeof t == "string") return t;
	}
	return String(e);
}
function we(e) {
	let t = k(e.b64);
	if ((typeof e.kind == "string" && e.kind ? e.kind : "bytes") !== "blob") return t;
	let n = e.mime, r = t.buffer;
	return typeof n == "string" && n ? new Blob([r], { type: n }) : new Blob([r]);
}
//#endregion
//#region src/extension/yandexHeaders.ts
var Te = "api.browser.yandex.ru", Ee = new Set([
	"sec-ch-ua",
	"sec-ch-ua-mobile",
	"sec-ch-ua-platform",
	"sec-ch-ua-full-version-list"
]), W = [
	"sec-ch-ua-full-version",
	"sec-ch-ua-platform-version",
	"sec-ch-ua-arch",
	"sec-ch-ua-bitness",
	"sec-ch-ua-model",
	"sec-ch-ua-wow64"
], De = new Set(W);
function Oe(e) {
	return String(e || "") === Te;
}
function G(e) {
	return String(e || "").trim();
}
function ke(e) {
	let t = G(e).toLowerCase();
	return t ? !!(t === "origin" || t === "referer" || De.has(t) || t.startsWith("sec-ch-ua") && !Ee.has(t)) : !1;
}
function Ae(e) {
	let t = {};
	for (let [n, r] of Object.entries(e || {})) {
		let e = G(n);
		e && (ke(e) || (t[e] = String(r)));
	}
	return t;
}
//#endregion
//#region src/extension/background.ts
var je = 512 * 1024, Me = /application\/(?:x-)?protobuf|application\/octet-stream/, Ne = /^(?=.*[+/=_-])[A-Za-z0-9+/=_-]+$/, K = 9001, q = 9002, Pe = 9003, J = /* @__PURE__ */ new Map(), Y = Promise.resolve();
function X() {
	return !!i?.declarativeNetRequest?.updateSessionRules;
}
function Fe(e) {
	let t = i?.declarativeNetRequest?.updateSessionRules;
	if (typeof t != "function") return Promise.resolve();
	try {
		let n = t({
			addRules: e.addRules || [],
			removeRuleIds: e.removeRuleIds || []
		});
		if (n && typeof n.then == "function") return n;
	} catch {}
	return new Promise((n, r) => {
		try {
			t({
				addRules: e.addRules || [],
				removeRuleIds: e.removeRuleIds || []
			}, () => {
				let e = c();
				e ? r(Error(e)) : n();
			});
		} catch (e) {
			r(e);
		}
	});
}
function Ie(e) {
	let t = G(e).toLowerCase();
	if (!t) return !1;
	switch (t[0]) {
		case "s": return t.startsWith("sec-");
		case "p": return t.startsWith("proxy-");
		case "u": return t === "user-agent";
		case "o": return t === "origin";
		case "r": return t === "referer";
		default: return !1;
	}
}
function Z(e) {
	let t = e.map((e) => [`${G(String(e.header)).toLowerCase()}:${String(e.operation)}`, String("value" in e ? e.value : "")]).sort((e, t) => e[0].localeCompare(t[0]));
	return JSON.stringify(t);
}
function Q(e, t, n) {
	return t === J.get(e) ? Promise.resolve() : (Y = Y.catch(() => void 0).then(async () => {
		t !== J.get(e) && (await Fe({
			removeRuleIds: [e],
			addRules: [n]
		}), J.set(e, t));
	}), Y);
}
async function Le(e, t) {
	if (!X()) return;
	let n = "";
	try {
		n = new URL(e).hostname;
	} catch {
		return;
	}
	if (!Oe(n)) return;
	let r = [
		{
			header: "Origin",
			operation: "remove"
		},
		{
			header: "Referer",
			operation: "remove"
		},
		...W.map((e) => ({
			header: e,
			operation: "remove"
		}))
	], i = Ae(t);
	for (let [e, t] of Object.entries(i)) r.push({
		header: G(e),
		operation: "set",
		value: String(t)
	});
	await Q(K, Z(r), {
		id: K,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders: r
		},
		condition: {
			urlFilter: "|https://api.browser.yandex.ru/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
function Re(e) {
	try {
		let t = new URL(e);
		return t.protocol === "https:" && t.hostname === "www.youtube.com" && t.pathname.startsWith("/youtubei/");
	} catch {
		return !1;
	}
}
function ze(e) {
	try {
		let t = new URL(e), n = t.hostname.toLowerCase();
		return t.protocol === "https:" && (n === "googlevideo.com" || n.endsWith(".googlevideo.com"));
	} catch {
		return !1;
	}
}
async function Be(e) {
	if (!X() || !Re(e)) return;
	let t = [
		{
			header: "Origin",
			operation: "remove"
		},
		{
			header: "x-client-data",
			operation: "remove"
		},
		{
			header: "x-goog-visitor-id",
			operation: "remove"
		}
	];
	await Q(q, JSON.stringify({
		v: 2,
		headers: Z(t)
	}), {
		id: q,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders: t
		},
		condition: {
			urlFilter: "|https://www.youtube.com/youtubei/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
async function Ve(e) {
	if (!X() || !ze(e)) return;
	let t = [{
		header: "x-client-data",
		operation: "remove"
	}];
	await Q(Pe, JSON.stringify({
		v: 1,
		headers: Z(t)
	}), {
		id: Pe,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders: t
		},
		condition: {
			urlFilter: "||googlevideo.com/",
			resourceTypes: ["xmlhttprequest"],
			tabIds: [-1]
		}
	});
}
function He(e) {
	if (e instanceof Error) return e.message;
	if (e && typeof e == "object") try {
		return JSON.stringify(e);
	} catch {
		return Object.prototype.toString.call(e);
	}
	try {
		return String(e);
	} catch {
		return "Unknown error";
	}
}
function Ue(e) {
	return Array.from(e.entries()).map(([e, t]) => `${e}: ${t}`).join("\r\n");
}
function We(e) {
	let t = {};
	if (!e) return t;
	for (let [n, r] of Object.entries(e)) r !== void 0 && (typeof r == "string" || typeof r == "number" || typeof r == "boolean") && (t[String(n)] = String(r));
	return t;
}
function Ge(e, t) {
	return {
		finalUrl: e,
		readyState: 4,
		status: 0,
		statusText: "",
		responseHeaders: "",
		response: null,
		responseText: "",
		error: t
	};
}
function Ke(e) {
	let t = new Uint8Array(e.byteLength);
	return t.set(e), t.buffer;
}
function qe(e) {
	return s ? { chunk: Ke(e) } : { chunkB64: O(e) };
}
function Je(e) {
	return s ? { response: e } : e.byteLength <= 0 ? {} : { responseB64: se(e) };
}
function Ye(e, t) {
	let n = t.toLowerCase();
	for (let [t, r] of Object.entries(e)) if (String(t).toLowerCase() === n) return String(r);
}
function Xe(e) {
	return Me.test(String(e ?? "").toLowerCase());
}
function Ze(e) {
	let t = String(e ?? "");
	if (!Ne.test(t)) return null;
	let n = t.replaceAll("-", "+").replaceAll("_", "/"), r = n.length % 4;
	if (r === 1) return null;
	let i = r === 0 ? n : `${n}${"=".repeat(4 - r)}`;
	try {
		return k(i);
	} catch {
		return null;
	}
}
function Qe(e) {
	let t = String(e || ""), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; e += 1) n[e] = (t.codePointAt(e) ?? 0) & 255;
	return n;
}
function $e(e) {
	return /^\[object [^\]]+\]$/.test(String(e || "").trim());
}
var $ = 0;
i?.runtime?.onConnect?.addListener?.((e) => {
	if (!e || typeof e != "object") return;
	let n = e;
	if (n.name !== "vot_gm_xhr" || typeof n.onDisconnect?.addListener != "function" || typeof n.onMessage?.addListener != "function" || typeof n.postMessage != "function") return;
	let r = (e) => {
		n.postMessage?.(e);
	};
	$ += 1;
	let i = $, a = null, o = null, s = !1, c = !1, l = () => {
		o !== null && (clearTimeout(o), o = null);
	};
	n.onDisconnect.addListener(() => {
		l(), t.warn("[VOT EXT][background][xhr] port disconnected", { xhrSessionId: i }), u();
	});
	let u = () => {
		try {
			a?.abort();
		} catch {}
	}, d = () => {
		s = !0, t.warn("[VOT EXT][background][xhr] abort requested", { xhrSessionId: i }), u();
	}, f = (e) => {
		let t = We(e.headers), n = {}, r = {};
		for (let [e, i] of Object.entries(t)) Ie(e) ? r[e] = i : n[e] = i;
		return {
			allHeaders: t,
			headers: n,
			forbiddenHeaders: r
		};
	}, p = (e) => {
		let t = {
			finalUrl: e,
			readyState: 4,
			status: 0,
			statusText: "",
			responseHeaders: "",
			response: null,
			responseText: "",
			error: "Aborted"
		};
		try {
			r({
				type: "abort",
				state: "terminal",
				error: t
			});
		} catch {}
	}, m = (e) => e.anonymous || e.withCredentials === !1 ? "omit" : "include", h = (e) => {
		if (e.nocache) return "no-store";
		if (e.revalidate) return "no-cache";
	}, g = (e, n, r, a) => {
		if (n === "GET") return;
		let o = Ce(e.data), s, c = () => (s === void 0 && (s = H(e.data)), s), l = Ye(r, "content-type"), u = Xe(l);
		if (t.log("[VOT EXT][background][xhr] body decoded", {
			xhrSessionId: i,
			url: a,
			method: n,
			contentType: l ?? null,
			isProtobufRequest: u,
			sourceBody: U(e.data),
			decodedBody: U(o)
		}), u && o == null) {
			let e = c();
			e && (o = e, t.warn("[VOT EXT][background][xhr] protobuf body recovered from raw payload", {
				xhrSessionId: i,
				url: a,
				method: n,
				recoveredBody: U(o)
			}));
		}
		if (typeof o == "string" && u) {
			if ($e(o)) {
				let r = c();
				r && (o = r, t.warn("[VOT EXT][background][xhr] recovered protobuf body from object-like string fallback", {
					xhrSessionId: i,
					url: a,
					method: n,
					sourceBody: U(e.data),
					recoveredBody: U(r)
				}));
			}
			if (typeof o == "string") {
				let e = Ze(o);
				o = e ?? Qe(o), t.log("[VOT EXT][background][xhr] protobuf string converted to bytes", {
					xhrSessionId: i,
					url: a,
					method: n,
					strategy: e ? "base64" : "latin1",
					convertedBody: U(o)
				});
			}
		}
		return o;
	}, ee = (e) => {
		let t = {
			method: e.method,
			headers: e.headers,
			redirect: e.redirect,
			credentials: e.credentials,
			signal: a?.signal
		};
		return e.body !== void 0 && (t.body = e.body), e.cache !== void 0 && (t.cache = e.cache), t;
	}, _ = async (e) => {
		let { url: n, method: a, responseType: o, res: s } = e;
		t.log("[VOT EXT][background][xhr] fetch response received", {
			xhrSessionId: i,
			url: s.url || n,
			method: a,
			status: s.status,
			statusText: s.statusText,
			responseType: o,
			contentType: s.headers.get("content-type") || null,
			contentLength: s.headers.get("content-length") || null
		});
		let c = Ue(s.headers), u = s.url || n, d = s.headers.get("content-type") || "", f = (e) => ({
			finalUrl: u,
			readyState: e,
			status: s.status,
			statusText: s.statusText,
			responseHeaders: c
		}), p = o === "arraybuffer" || o === "blob" || o === "stream", m, h, g;
		if (p) {
			let e = Number(s.headers.get("content-length") || 0);
			if (s.body && (!Number.isFinite(e) || e > je)) {
				let t = 0, n = Number.isFinite(e) ? e : 0, i = s.body.getReader();
				for (;;) {
					let { done: e, value: a } = await i.read();
					if (e) break;
					a && (t += a.byteLength, r({
						type: "progress",
						state: "in_flight",
						progress: {
							...f(3),
							loaded: t,
							total: n,
							lengthComputable: n > 0,
							...qe(a)
						}
					}));
				}
			} else {
				let e = Je(await s.arrayBuffer());
				m = e.response, g = e.responseB64;
			}
		} else if (o === "json") {
			h = await s.text();
			try {
				m = JSON.parse(h);
			} catch {
				m = null;
			}
		} else h = await s.text(), m = h;
		l(), t.log("[VOT EXT][background][xhr] terminal", {
			xhrSessionId: i,
			state: "terminal",
			kind: "load",
			url: u,
			status: s.status,
			responseType: o,
			responseBody: U(m),
			responseTextLength: h?.length ?? 0,
			responseB64Length: g?.length ?? 0
		}), r({
			type: "load",
			state: "terminal",
			response: {
				...f(4),
				responseType: o,
				...d ? { contentType: d } : {},
				...g ? { responseB64: g } : {},
				response: m,
				...typeof h == "string" ? { responseText: h } : {}
			}
		});
	}, te = (e, n, a, o) => {
		if (l(), s || c || o instanceof DOMException && o.name === "AbortError") {
			let o = c ? "timeout" : "abort", s = Ge(e, o === "timeout" ? "Timeout" : "Aborted");
			try {
				r({
					type: o,
					state: "terminal",
					error: s
				});
			} catch {}
			t.warn("[VOT EXT][background][xhr] terminal", {
				xhrSessionId: i,
				state: "terminal",
				kind: o,
				url: e,
				method: n,
				responseType: a
			});
			return;
		}
		let u = Ge(e, He(o));
		r({
			type: "error",
			state: "terminal",
			error: u
		}), t.error("[VOT EXT][background][xhr] terminal", {
			xhrSessionId: i,
			state: "terminal",
			kind: "error",
			url: e,
			method: n,
			responseType: a,
			error: u.error
		});
	}, v = async (e) => {
		let n = s && a === null;
		s = !1;
		let { details: r } = e, l = r.url, d = (r.method || "GET").toUpperCase(), { allHeaders: v, headers: y, forbiddenHeaders: b } = f(r), x = Number(r.timeout || 0), S = String(r.responseType || "text").toLowerCase();
		if (t.log("[VOT EXT][background][xhr] start", {
			xhrSessionId: i,
			state: "in_flight",
			url: l,
			method: d,
			responseType: S,
			timeoutMs: x,
			headerCount: Object.keys(v).length,
			headerNames: Object.keys(v),
			forbiddenHeaderNames: Object.keys(b),
			body: U(r.data)
		}), n) {
			p(l);
			return;
		}
		c = !1, a = new AbortController(), x > 0 && (o = setTimeout(() => {
			c = !0, u();
		}, x));
		let C = m(r), w = h(r), T = r.redirect === "error" || r.redirect === "manual" ? r.redirect : "follow";
		try {
			try {
				await Ve(l), await Be(l), await Le(l, b);
			} catch (e) {
				console.warn("[VOT Extension] Failed to apply DNR header rules; requests may break:", e);
			}
			let e = g(r, d, v, l);
			t.log("[VOT EXT][background][xhr] fetch dispatch", {
				xhrSessionId: i,
				url: l,
				method: d,
				credentials: C,
				redirect: T,
				cache: w ?? "default",
				body: U(e)
			});
			let n = ee({
				method: d,
				headers: y,
				redirect: T,
				credentials: C,
				body: e,
				cache: w
			});
			await _({
				url: l,
				method: d,
				responseType: S,
				res: await fetch(l, n)
			});
		} catch (e) {
			te(l, d, S, e);
		}
	};
	n.onMessage.addListener(async (e) => {
		if (!(!e || typeof e != "object")) {
			if (e.type === "abort") {
				d();
				return;
			}
			e.type === "start" && await v(e);
		}
	});
}), re(), x();
//#endregion
