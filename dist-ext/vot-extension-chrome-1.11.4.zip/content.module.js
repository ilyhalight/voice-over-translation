//#region \0rolldown/runtime.js
var e = Object.create, t = Object.defineProperty, n = Object.getOwnPropertyDescriptor, r = Object.getOwnPropertyNames, i = Object.getPrototypeOf, a = Object.prototype.hasOwnProperty, o = (e, t) => () => (t || e((t = { exports: {} }).exports, t), t.exports), s = (e, i, o, s) => {
	if (i && typeof i == "object" || typeof i == "function") for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
		get: ((e) => i[e]).bind(null, d),
		enumerable: !(s = n(i, d)) || s.enumerable
	});
	return e;
}, c = (n, r, a) => (a = n == null ? {} : e(i(n)), s(r || !n || !n.__esModule ? t(a, "default", {
	value: n,
	enumerable: !0
}) : a, n)), l = {
	host: "api.browser.yandex.ru",
	hostVOT: "vot.toil.cc/v1",
	hostWorker: "vot-worker.toil.cc",
	mediaProxy: "media-proxy.toil.cc",
	userAgent: " Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 YaBrowser/26.3.1.981 Yowser/2.5 Safari/537.36",
	componentVersion: "26.3.1.981",
	hmac: "bt8xH3VOlb4mqf0nqAibnDOoiPlXsisf",
	defaultDuration: 310,
	minChunkSize: 5295308,
	loggerLevel: 1,
	version: "2.4.16"
};
//#endregion
//#region node_modules/@bufbuild/protobuf/dist/esm/wire/varint.js
function u() {
	let e = 0, t = 0;
	for (let n = 0; n < 28; n += 7) {
		let r = this.buf[this.pos++];
		if (e |= (r & 127) << n, !(r & 128)) return this.assertBounds(), [e, t];
	}
	let n = this.buf[this.pos++];
	if (e |= (n & 15) << 28, t = (n & 112) >> 4, !(n & 128)) return this.assertBounds(), [e, t];
	for (let n = 3; n <= 31; n += 7) {
		let r = this.buf[this.pos++];
		if (t |= (r & 127) << n, !(r & 128)) return this.assertBounds(), [e, t];
	}
	throw Error("invalid varint");
}
function d(e, t, n) {
	for (let r = 0; r < 28; r += 7) {
		let i = e >>> r, a = !(!(i >>> 7) && t == 0), o = (a ? i | 128 : i) & 255;
		if (n.push(o), !a) return;
	}
	let r = e >>> 28 & 15 | (t & 7) << 4, i = !!(t >> 3);
	if (n.push((i ? r | 128 : r) & 255), i) {
		for (let e = 3; e < 31; e += 7) {
			let r = t >>> e, i = !!(r >>> 7), a = (i ? r | 128 : r) & 255;
			if (n.push(a), !i) return;
		}
		n.push(t >>> 31 & 1);
	}
}
var f = 4294967296;
function p(e) {
	let t = e[0] === "-";
	t && (e = e.slice(1));
	let n = 1e6, r = 0, i = 0;
	function a(t, a) {
		let o = Number(e.slice(t, a));
		i *= n, r = r * n + o, r >= f && (i += r / f | 0, r %= f);
	}
	return a(-24, -18), a(-18, -12), a(-12, -6), a(-6), t ? v(r, i) : _(r, i);
}
function m(e, t) {
	let n = _(e, t), r = n.hi & 2147483648;
	r && (n = v(n.lo, n.hi));
	let i = h(n.lo, n.hi);
	return r ? "-" + i : i;
}
function h(e, t) {
	if ({lo: e, hi: t} = g(e, t), t <= 2097151) return String(f * t + e);
	let n = e & 16777215, r = (e >>> 24 | t << 8) & 16777215, i = t >> 16 & 65535, a = n + r * 6777216 + i * 6710656, o = r + i * 8147497, s = i * 2, c = 1e7;
	return a >= c && (o += Math.floor(a / c), a %= c), o >= c && (s += Math.floor(o / c), o %= c), s.toString() + ee(o) + ee(a);
}
function g(e, t) {
	return {
		lo: e >>> 0,
		hi: t >>> 0
	};
}
function _(e, t) {
	return {
		lo: e | 0,
		hi: t | 0
	};
}
function v(e, t) {
	return t = ~t, e ? e = ~e + 1 : t += 1, _(e, t);
}
var ee = (e) => {
	let t = String(e);
	return "0000000".slice(t.length) + t;
};
function te(e, t) {
	if (e >= 0) {
		for (; e > 127;) t.push(e & 127 | 128), e >>>= 7;
		t.push(e);
	} else {
		for (let n = 0; n < 9; n++) t.push(e & 127 | 128), e >>= 7;
		t.push(1);
	}
}
function ne() {
	let e = this.buf[this.pos++], t = e & 127;
	if (!(e & 128) || (e = this.buf[this.pos++], t |= (e & 127) << 7, !(e & 128)) || (e = this.buf[this.pos++], t |= (e & 127) << 14, !(e & 128)) || (e = this.buf[this.pos++], t |= (e & 127) << 21, !(e & 128))) return this.assertBounds(), t;
	e = this.buf[this.pos++], t |= (e & 15) << 28;
	for (let t = 5; e & 128 && t < 10; t++) e = this.buf[this.pos++];
	if (e & 128) throw Error("invalid varint");
	return this.assertBounds(), t >>> 0;
}
//#endregion
//#region node_modules/@bufbuild/protobuf/dist/esm/proto-int64.js
var y = /* @__PURE__ */ re();
function re() {
	let e = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
	if (typeof BigInt == "function" && typeof e.getBigInt64 == "function" && typeof e.getBigUint64 == "function" && typeof e.setBigInt64 == "function" && typeof e.setBigUint64 == "function" && (typeof process != "object" || typeof process.env != "object" || process.env.BUF_BIGINT_DISABLE !== "1")) {
		let t = BigInt("-9223372036854775808"), n = BigInt("9223372036854775807"), r = BigInt("0"), i = BigInt("18446744073709551615");
		return {
			zero: BigInt(0),
			supported: !0,
			parse(e) {
				let r = typeof e == "bigint" ? e : BigInt(e);
				if (r > n || r < t) throw Error(`invalid int64: ${e}`);
				return r;
			},
			uParse(e) {
				let t = typeof e == "bigint" ? e : BigInt(e);
				if (t > i || t < r) throw Error(`invalid uint64: ${e}`);
				return t;
			},
			enc(t) {
				return e.setBigInt64(0, this.parse(t), !0), {
					lo: e.getInt32(0, !0),
					hi: e.getInt32(4, !0)
				};
			},
			uEnc(t) {
				return e.setBigInt64(0, this.uParse(t), !0), {
					lo: e.getInt32(0, !0),
					hi: e.getInt32(4, !0)
				};
			},
			dec(t, n) {
				return e.setInt32(0, t, !0), e.setInt32(4, n, !0), e.getBigInt64(0, !0);
			},
			uDec(t, n) {
				return e.setInt32(0, t, !0), e.setInt32(4, n, !0), e.getBigUint64(0, !0);
			}
		};
	}
	return {
		zero: "0",
		supported: !1,
		parse(e) {
			return typeof e != "string" && (e = e.toString()), ie(e), e;
		},
		uParse(e) {
			return typeof e != "string" && (e = e.toString()), ae(e), e;
		},
		enc(e) {
			return typeof e != "string" && (e = e.toString()), ie(e), p(e);
		},
		uEnc(e) {
			return typeof e != "string" && (e = e.toString()), ae(e), p(e);
		},
		dec(e, t) {
			return m(e, t);
		},
		uDec(e, t) {
			return h(e, t);
		}
	};
}
function ie(e) {
	if (!/^-?[0-9]+$/.test(e)) throw Error("invalid int64: " + e);
}
function ae(e) {
	if (!/^[0-9]+$/.test(e)) throw Error("invalid uint64: " + e);
}
//#endregion
//#region node_modules/@bufbuild/protobuf/dist/esm/wire/text-encoding.js
var oe = Symbol.for("@bufbuild/protobuf/text-encoding");
function se() {
	if (globalThis[oe] == null) {
		let e = new globalThis.TextEncoder(), t = new globalThis.TextDecoder();
		globalThis[oe] = {
			encodeUtf8(t) {
				return e.encode(t);
			},
			decodeUtf8(e) {
				return t.decode(e);
			},
			checkUtf8(e) {
				try {
					return !0;
				} catch {
					return !1;
				}
			}
		};
	}
	return globalThis[oe];
}
//#endregion
//#region node_modules/@bufbuild/protobuf/dist/esm/wire/binary-encoding.js
var ce;
(function(e) {
	e[e.Varint = 0] = "Varint", e[e.Bit64 = 1] = "Bit64", e[e.LengthDelimited = 2] = "LengthDelimited", e[e.StartGroup = 3] = "StartGroup", e[e.EndGroup = 4] = "EndGroup", e[e.Bit32 = 5] = "Bit32";
})(ce ||= {});
var b = class {
	constructor(e = se().encodeUtf8) {
		this.encodeUtf8 = e, this.stack = [], this.chunks = [], this.buf = [];
	}
	finish() {
		this.buf.length && (this.chunks.push(new Uint8Array(this.buf)), this.buf = []);
		let e = 0;
		for (let t = 0; t < this.chunks.length; t++) e += this.chunks[t].length;
		let t = new Uint8Array(e), n = 0;
		for (let e = 0; e < this.chunks.length; e++) t.set(this.chunks[e], n), n += this.chunks[e].length;
		return this.chunks = [], t;
	}
	fork() {
		return this.stack.push({
			chunks: this.chunks,
			buf: this.buf
		}), this.chunks = [], this.buf = [], this;
	}
	join() {
		let e = this.finish(), t = this.stack.pop();
		if (!t) throw Error("invalid state, fork stack empty");
		return this.chunks = t.chunks, this.buf = t.buf, this.uint32(e.byteLength), this.raw(e);
	}
	tag(e, t) {
		return this.uint32((e << 3 | t) >>> 0);
	}
	raw(e) {
		return this.buf.length && (this.chunks.push(new Uint8Array(this.buf)), this.buf = []), this.chunks.push(e), this;
	}
	uint32(e) {
		for (ue(e); e > 127;) this.buf.push(e & 127 | 128), e >>>= 7;
		return this.buf.push(e), this;
	}
	int32(e) {
		return le(e), te(e, this.buf), this;
	}
	bool(e) {
		return this.buf.push(e ? 1 : 0), this;
	}
	bytes(e) {
		return this.uint32(e.byteLength), this.raw(e);
	}
	string(e) {
		let t = this.encodeUtf8(e);
		return this.uint32(t.byteLength), this.raw(t);
	}
	float(e) {
		de(e);
		let t = new Uint8Array(4);
		return new DataView(t.buffer).setFloat32(0, e, !0), this.raw(t);
	}
	double(e) {
		let t = new Uint8Array(8);
		return new DataView(t.buffer).setFloat64(0, e, !0), this.raw(t);
	}
	fixed32(e) {
		ue(e);
		let t = new Uint8Array(4);
		return new DataView(t.buffer).setUint32(0, e, !0), this.raw(t);
	}
	sfixed32(e) {
		le(e);
		let t = new Uint8Array(4);
		return new DataView(t.buffer).setInt32(0, e, !0), this.raw(t);
	}
	sint32(e) {
		return le(e), e = (e << 1 ^ e >> 31) >>> 0, te(e, this.buf), this;
	}
	sfixed64(e) {
		let t = new Uint8Array(8), n = new DataView(t.buffer), r = y.enc(e);
		return n.setInt32(0, r.lo, !0), n.setInt32(4, r.hi, !0), this.raw(t);
	}
	fixed64(e) {
		let t = new Uint8Array(8), n = new DataView(t.buffer), r = y.uEnc(e);
		return n.setInt32(0, r.lo, !0), n.setInt32(4, r.hi, !0), this.raw(t);
	}
	int64(e) {
		let t = y.enc(e);
		return d(t.lo, t.hi, this.buf), this;
	}
	sint64(e) {
		let t = y.enc(e), n = t.hi >> 31;
		return d(t.lo << 1 ^ n, (t.hi << 1 | t.lo >>> 31) ^ n, this.buf), this;
	}
	uint64(e) {
		let t = y.uEnc(e);
		return d(t.lo, t.hi, this.buf), this;
	}
}, x = class {
	constructor(e, t = se().decodeUtf8) {
		this.decodeUtf8 = t, this.varint64 = u, this.uint32 = ne, this.buf = e, this.len = e.length, this.pos = 0, this.view = new DataView(e.buffer, e.byteOffset, e.byteLength);
	}
	tag() {
		let e = this.uint32(), t = e >>> 3, n = e & 7;
		if (t <= 0 || n < 0 || n > 5) throw Error("illegal tag: field no " + t + " wire type " + n);
		return [t, n];
	}
	skip(e, t) {
		let n = this.pos;
		switch (e) {
			case ce.Varint:
				for (; this.buf[this.pos++] & 128;);
				break;
			case ce.Bit64: this.pos += 4;
			case ce.Bit32:
				this.pos += 4;
				break;
			case ce.LengthDelimited:
				let n = this.uint32();
				this.pos += n;
				break;
			case ce.StartGroup:
				for (;;) {
					let [e, n] = this.tag();
					if (n === ce.EndGroup) {
						if (t !== void 0 && e !== t) throw Error("invalid end group tag");
						break;
					}
					this.skip(n, e);
				}
				break;
			default: throw Error("cant skip wire type " + e);
		}
		return this.assertBounds(), this.buf.subarray(n, this.pos);
	}
	assertBounds() {
		if (this.pos > this.len) throw RangeError("premature EOF");
	}
	int32() {
		return this.uint32() | 0;
	}
	sint32() {
		let e = this.uint32();
		return e >>> 1 ^ -(e & 1);
	}
	int64() {
		return y.dec(...this.varint64());
	}
	uint64() {
		return y.uDec(...this.varint64());
	}
	sint64() {
		let [e, t] = this.varint64(), n = -(e & 1);
		return e = (e >>> 1 | (t & 1) << 31) ^ n, t = t >>> 1 ^ n, y.dec(e, t);
	}
	bool() {
		let [e, t] = this.varint64();
		return e !== 0 || t !== 0;
	}
	fixed32() {
		return this.view.getUint32((this.pos += 4) - 4, !0);
	}
	sfixed32() {
		return this.view.getInt32((this.pos += 4) - 4, !0);
	}
	fixed64() {
		return y.uDec(this.sfixed32(), this.sfixed32());
	}
	sfixed64() {
		return y.dec(this.sfixed32(), this.sfixed32());
	}
	float() {
		return this.view.getFloat32((this.pos += 4) - 4, !0);
	}
	double() {
		return this.view.getFloat64((this.pos += 8) - 8, !0);
	}
	bytes() {
		let e = this.uint32(), t = this.pos;
		return this.pos += e, this.assertBounds(), this.buf.subarray(t, t + e);
	}
	string() {
		return this.decodeUtf8(this.bytes());
	}
};
function le(e) {
	if (typeof e == "string") e = Number(e);
	else if (typeof e != "number") throw Error("invalid int32: " + typeof e);
	if (!Number.isInteger(e) || e > 2147483647 || e < -2147483648) throw Error("invalid int32: " + e);
}
function ue(e) {
	if (typeof e == "string") e = Number(e);
	else if (typeof e != "number") throw Error("invalid uint32: " + typeof e);
	if (!Number.isInteger(e) || e > 4294967295 || e < 0) throw Error("invalid uint32: " + e);
}
function de(e) {
	if (typeof e == "string") {
		let t = e;
		if (e = Number(e), isNaN(e) && t !== "NaN") throw Error("invalid float32: " + t);
	} else if (typeof e != "number") throw Error("invalid float32: " + typeof e);
	if (Number.isFinite(e) && (e > 34028234663852886e22 || e < -34028234663852886e22)) throw Error("invalid float32: " + e);
}
//#endregion
//#region node_modules/@vot.js/shared/dist/protos/yandex.js
var S;
(function(e) {
	e[e.NO_CONNECTION = 0] = "NO_CONNECTION", e[e.TRANSLATING = 10] = "TRANSLATING", e[e.STREAMING = 20] = "STREAMING", e[e.UNRECOGNIZED = -1] = "UNRECOGNIZED";
})(S ||= {});
function fe(e) {
	switch (e) {
		case 0:
		case "NO_CONNECTION": return S.NO_CONNECTION;
		case 10:
		case "TRANSLATING": return S.TRANSLATING;
		case 20:
		case "STREAMING": return S.STREAMING;
		default: return S.UNRECOGNIZED;
	}
}
function pe(e) {
	switch (e) {
		case S.NO_CONNECTION: return "NO_CONNECTION";
		case S.TRANSLATING: return "TRANSLATING";
		case S.STREAMING: return "STREAMING";
		case S.UNRECOGNIZED:
		default: return "UNRECOGNIZED";
	}
}
function me() {
	return {
		target: "",
		targetUrl: ""
	};
}
var he = {
	encode(e, t = new b()) {
		return e.target !== "" && t.uint32(10).string(e.target), e.targetUrl !== "" && t.uint32(18).string(e.targetUrl), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = me();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 10) break;
					i.target = n.string();
					continue;
				case 2:
					if (e !== 18) break;
					i.targetUrl = n.string();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			target: w(e.target) ? globalThis.String(e.target) : "",
			targetUrl: w(e.targetUrl) ? globalThis.String(e.targetUrl) : ""
		};
	},
	toJSON(e) {
		let t = {};
		return e.target !== "" && (t.target = e.target), e.targetUrl !== "" && (t.targetUrl = e.targetUrl), t;
	},
	create(e) {
		return he.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = me();
		return t.target = e.target ?? "", t.targetUrl = e.targetUrl ?? "", t;
	}
};
function ge() {
	return {
		url: "",
		deviceId: void 0,
		firstRequest: !1,
		duration: 0,
		unknown0: 0,
		language: "",
		forceSourceLang: !1,
		unknown1: 0,
		translationHelp: [],
		wasStream: !1,
		responseLanguage: "",
		unknown2: 0,
		unknown3: 0,
		bypassCache: !1,
		useLivelyVoice: !1,
		videoTitle: ""
	};
}
var _e = {
	encode(e, t = new b()) {
		e.url !== "" && t.uint32(26).string(e.url), e.deviceId !== void 0 && t.uint32(34).string(e.deviceId), e.firstRequest !== !1 && t.uint32(40).bool(e.firstRequest), e.duration !== 0 && t.uint32(49).double(e.duration), e.unknown0 !== 0 && t.uint32(56).int32(e.unknown0), e.language !== "" && t.uint32(66).string(e.language), e.forceSourceLang !== !1 && t.uint32(72).bool(e.forceSourceLang), e.unknown1 !== 0 && t.uint32(80).int32(e.unknown1);
		for (let n of e.translationHelp) he.encode(n, t.uint32(90).fork()).join();
		return e.wasStream !== !1 && t.uint32(104).bool(e.wasStream), e.responseLanguage !== "" && t.uint32(114).string(e.responseLanguage), e.unknown2 !== 0 && t.uint32(120).int32(e.unknown2), e.unknown3 !== 0 && t.uint32(128).int32(e.unknown3), e.bypassCache !== !1 && t.uint32(136).bool(e.bypassCache), e.useLivelyVoice !== !1 && t.uint32(144).bool(e.useLivelyVoice), e.videoTitle !== "" && t.uint32(154).string(e.videoTitle), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = ge();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 3:
					if (e !== 26) break;
					i.url = n.string();
					continue;
				case 4:
					if (e !== 34) break;
					i.deviceId = n.string();
					continue;
				case 5:
					if (e !== 40) break;
					i.firstRequest = n.bool();
					continue;
				case 6:
					if (e !== 49) break;
					i.duration = n.double();
					continue;
				case 7:
					if (e !== 56) break;
					i.unknown0 = n.int32();
					continue;
				case 8:
					if (e !== 66) break;
					i.language = n.string();
					continue;
				case 9:
					if (e !== 72) break;
					i.forceSourceLang = n.bool();
					continue;
				case 10:
					if (e !== 80) break;
					i.unknown1 = n.int32();
					continue;
				case 11:
					if (e !== 90) break;
					i.translationHelp.push(he.decode(n, n.uint32()));
					continue;
				case 13:
					if (e !== 104) break;
					i.wasStream = n.bool();
					continue;
				case 14:
					if (e !== 114) break;
					i.responseLanguage = n.string();
					continue;
				case 15:
					if (e !== 120) break;
					i.unknown2 = n.int32();
					continue;
				case 16:
					if (e !== 128) break;
					i.unknown3 = n.int32();
					continue;
				case 17:
					if (e !== 136) break;
					i.bypassCache = n.bool();
					continue;
				case 18:
					if (e !== 144) break;
					i.useLivelyVoice = n.bool();
					continue;
				case 19:
					if (e !== 154) break;
					i.videoTitle = n.string();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			url: w(e.url) ? globalThis.String(e.url) : "",
			deviceId: w(e.deviceId) ? globalThis.String(e.deviceId) : void 0,
			firstRequest: w(e.firstRequest) ? globalThis.Boolean(e.firstRequest) : !1,
			duration: w(e.duration) ? globalThis.Number(e.duration) : 0,
			unknown0: w(e.unknown0) ? globalThis.Number(e.unknown0) : 0,
			language: w(e.language) ? globalThis.String(e.language) : "",
			forceSourceLang: w(e.forceSourceLang) ? globalThis.Boolean(e.forceSourceLang) : !1,
			unknown1: w(e.unknown1) ? globalThis.Number(e.unknown1) : 0,
			translationHelp: globalThis.Array.isArray(e?.translationHelp) ? e.translationHelp.map((e) => he.fromJSON(e)) : [],
			wasStream: w(e.wasStream) ? globalThis.Boolean(e.wasStream) : !1,
			responseLanguage: w(e.responseLanguage) ? globalThis.String(e.responseLanguage) : "",
			unknown2: w(e.unknown2) ? globalThis.Number(e.unknown2) : 0,
			unknown3: w(e.unknown3) ? globalThis.Number(e.unknown3) : 0,
			bypassCache: w(e.bypassCache) ? globalThis.Boolean(e.bypassCache) : !1,
			useLivelyVoice: w(e.useLivelyVoice) ? globalThis.Boolean(e.useLivelyVoice) : !1,
			videoTitle: w(e.videoTitle) ? globalThis.String(e.videoTitle) : ""
		};
	},
	toJSON(e) {
		let t = {};
		return e.url !== "" && (t.url = e.url), e.deviceId !== void 0 && (t.deviceId = e.deviceId), e.firstRequest !== !1 && (t.firstRequest = e.firstRequest), e.duration !== 0 && (t.duration = e.duration), e.unknown0 !== 0 && (t.unknown0 = Math.round(e.unknown0)), e.language !== "" && (t.language = e.language), e.forceSourceLang !== !1 && (t.forceSourceLang = e.forceSourceLang), e.unknown1 !== 0 && (t.unknown1 = Math.round(e.unknown1)), e.translationHelp?.length && (t.translationHelp = e.translationHelp.map((e) => he.toJSON(e))), e.wasStream !== !1 && (t.wasStream = e.wasStream), e.responseLanguage !== "" && (t.responseLanguage = e.responseLanguage), e.unknown2 !== 0 && (t.unknown2 = Math.round(e.unknown2)), e.unknown3 !== 0 && (t.unknown3 = Math.round(e.unknown3)), e.bypassCache !== !1 && (t.bypassCache = e.bypassCache), e.useLivelyVoice !== !1 && (t.useLivelyVoice = e.useLivelyVoice), e.videoTitle !== "" && (t.videoTitle = e.videoTitle), t;
	},
	create(e) {
		return _e.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = ge();
		return t.url = e.url ?? "", t.deviceId = e.deviceId ?? void 0, t.firstRequest = e.firstRequest ?? !1, t.duration = e.duration ?? 0, t.unknown0 = e.unknown0 ?? 0, t.language = e.language ?? "", t.forceSourceLang = e.forceSourceLang ?? !1, t.unknown1 = e.unknown1 ?? 0, t.translationHelp = e.translationHelp?.map((e) => he.fromPartial(e)) || [], t.wasStream = e.wasStream ?? !1, t.responseLanguage = e.responseLanguage ?? "", t.unknown2 = e.unknown2 ?? 0, t.unknown3 = e.unknown3 ?? 0, t.bypassCache = e.bypassCache ?? !1, t.useLivelyVoice = e.useLivelyVoice ?? !1, t.videoTitle = e.videoTitle ?? "", t;
	}
};
function ve() {
	return {
		url: void 0,
		duration: void 0,
		status: 0,
		remainingTime: void 0,
		unknown0: void 0,
		translationId: "",
		language: void 0,
		message: void 0,
		isLivelyVoice: !1,
		unknown2: void 0,
		shouldRetry: void 0,
		unknown3: void 0
	};
}
var ye = {
	encode(e, t = new b()) {
		return e.url !== void 0 && t.uint32(10).string(e.url), e.duration !== void 0 && t.uint32(17).double(e.duration), e.status !== 0 && t.uint32(32).int32(e.status), e.remainingTime !== void 0 && t.uint32(40).int32(e.remainingTime), e.unknown0 !== void 0 && t.uint32(48).int32(e.unknown0), e.translationId !== "" && t.uint32(58).string(e.translationId), e.language !== void 0 && t.uint32(66).string(e.language), e.message !== void 0 && t.uint32(74).string(e.message), e.isLivelyVoice !== !1 && t.uint32(80).bool(e.isLivelyVoice), e.unknown2 !== void 0 && t.uint32(88).int32(e.unknown2), e.shouldRetry !== void 0 && t.uint32(96).int32(e.shouldRetry), e.unknown3 !== void 0 && t.uint32(104).int32(e.unknown3), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = ve();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 10) break;
					i.url = n.string();
					continue;
				case 2:
					if (e !== 17) break;
					i.duration = n.double();
					continue;
				case 4:
					if (e !== 32) break;
					i.status = n.int32();
					continue;
				case 5:
					if (e !== 40) break;
					i.remainingTime = n.int32();
					continue;
				case 6:
					if (e !== 48) break;
					i.unknown0 = n.int32();
					continue;
				case 7:
					if (e !== 58) break;
					i.translationId = n.string();
					continue;
				case 8:
					if (e !== 66) break;
					i.language = n.string();
					continue;
				case 9:
					if (e !== 74) break;
					i.message = n.string();
					continue;
				case 10:
					if (e !== 80) break;
					i.isLivelyVoice = n.bool();
					continue;
				case 11:
					if (e !== 88) break;
					i.unknown2 = n.int32();
					continue;
				case 12:
					if (e !== 96) break;
					i.shouldRetry = n.int32();
					continue;
				case 13:
					if (e !== 104) break;
					i.unknown3 = n.int32();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			url: w(e.url) ? globalThis.String(e.url) : void 0,
			duration: w(e.duration) ? globalThis.Number(e.duration) : void 0,
			status: w(e.status) ? globalThis.Number(e.status) : 0,
			remainingTime: w(e.remainingTime) ? globalThis.Number(e.remainingTime) : void 0,
			unknown0: w(e.unknown0) ? globalThis.Number(e.unknown0) : void 0,
			translationId: w(e.translationId) ? globalThis.String(e.translationId) : "",
			language: w(e.language) ? globalThis.String(e.language) : void 0,
			message: w(e.message) ? globalThis.String(e.message) : void 0,
			isLivelyVoice: w(e.isLivelyVoice) ? globalThis.Boolean(e.isLivelyVoice) : !1,
			unknown2: w(e.unknown2) ? globalThis.Number(e.unknown2) : void 0,
			shouldRetry: w(e.shouldRetry) ? globalThis.Number(e.shouldRetry) : void 0,
			unknown3: w(e.unknown3) ? globalThis.Number(e.unknown3) : void 0
		};
	},
	toJSON(e) {
		let t = {};
		return e.url !== void 0 && (t.url = e.url), e.duration !== void 0 && (t.duration = e.duration), e.status !== 0 && (t.status = Math.round(e.status)), e.remainingTime !== void 0 && (t.remainingTime = Math.round(e.remainingTime)), e.unknown0 !== void 0 && (t.unknown0 = Math.round(e.unknown0)), e.translationId !== "" && (t.translationId = e.translationId), e.language !== void 0 && (t.language = e.language), e.message !== void 0 && (t.message = e.message), e.isLivelyVoice !== !1 && (t.isLivelyVoice = e.isLivelyVoice), e.unknown2 !== void 0 && (t.unknown2 = Math.round(e.unknown2)), e.shouldRetry !== void 0 && (t.shouldRetry = Math.round(e.shouldRetry)), e.unknown3 !== void 0 && (t.unknown3 = Math.round(e.unknown3)), t;
	},
	create(e) {
		return ye.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = ve();
		return t.url = e.url ?? void 0, t.duration = e.duration ?? void 0, t.status = e.status ?? 0, t.remainingTime = e.remainingTime ?? void 0, t.unknown0 = e.unknown0 ?? void 0, t.translationId = e.translationId ?? "", t.language = e.language ?? void 0, t.message = e.message ?? void 0, t.isLivelyVoice = e.isLivelyVoice ?? !1, t.unknown2 = e.unknown2 ?? void 0, t.shouldRetry = e.shouldRetry ?? void 0, t.unknown3 = e.unknown3 ?? void 0, t;
	}
};
function be() {
	return {
		status: 0,
		remainingTime: void 0,
		message: void 0,
		unknown0: void 0
	};
}
var C = {
	encode(e, t = new b()) {
		return e.status !== 0 && t.uint32(8).int32(e.status), e.remainingTime !== void 0 && t.uint32(16).int32(e.remainingTime), e.message !== void 0 && t.uint32(26).string(e.message), e.unknown0 !== void 0 && t.uint32(32).int32(e.unknown0), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = be();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 8) break;
					i.status = n.int32();
					continue;
				case 2:
					if (e !== 16) break;
					i.remainingTime = n.int32();
					continue;
				case 3:
					if (e !== 26) break;
					i.message = n.string();
					continue;
				case 4:
					if (e !== 32) break;
					i.unknown0 = n.int32();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			status: w(e.status) ? globalThis.Number(e.status) : 0,
			remainingTime: w(e.remainingTime) ? globalThis.Number(e.remainingTime) : void 0,
			message: w(e.message) ? globalThis.String(e.message) : void 0,
			unknown0: w(e.unknown0) ? globalThis.Number(e.unknown0) : void 0
		};
	},
	toJSON(e) {
		let t = {};
		return e.status !== 0 && (t.status = Math.round(e.status)), e.remainingTime !== void 0 && (t.remainingTime = Math.round(e.remainingTime)), e.message !== void 0 && (t.message = e.message), e.unknown0 !== void 0 && (t.unknown0 = Math.round(e.unknown0)), t;
	},
	create(e) {
		return C.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = be();
		return t.status = e.status ?? 0, t.remainingTime = e.remainingTime ?? void 0, t.message = e.message ?? void 0, t.unknown0 = e.unknown0 ?? void 0, t;
	}
};
function xe() {
	return {
		url: "",
		duration: 0,
		language: "",
		responseLanguage: ""
	};
}
var Se = {
	encode(e, t = new b()) {
		return e.url !== "" && t.uint32(10).string(e.url), e.duration !== 0 && t.uint32(17).double(e.duration), e.language !== "" && t.uint32(26).string(e.language), e.responseLanguage !== "" && t.uint32(34).string(e.responseLanguage), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = xe();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 10) break;
					i.url = n.string();
					continue;
				case 2:
					if (e !== 17) break;
					i.duration = n.double();
					continue;
				case 3:
					if (e !== 26) break;
					i.language = n.string();
					continue;
				case 4:
					if (e !== 34) break;
					i.responseLanguage = n.string();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			url: w(e.url) ? globalThis.String(e.url) : "",
			duration: w(e.duration) ? globalThis.Number(e.duration) : 0,
			language: w(e.language) ? globalThis.String(e.language) : "",
			responseLanguage: w(e.responseLanguage) ? globalThis.String(e.responseLanguage) : ""
		};
	},
	toJSON(e) {
		let t = {};
		return e.url !== "" && (t.url = e.url), e.duration !== 0 && (t.duration = e.duration), e.language !== "" && (t.language = e.language), e.responseLanguage !== "" && (t.responseLanguage = e.responseLanguage), t;
	},
	create(e) {
		return Se.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = xe();
		return t.url = e.url ?? "", t.duration = e.duration ?? 0, t.language = e.language ?? "", t.responseLanguage = e.responseLanguage ?? "", t;
	}
};
function Ce() {
	return {
		default: void 0,
		cloning: void 0
	};
}
var we = {
	encode(e, t = new b()) {
		return e.default !== void 0 && C.encode(e.default, t.uint32(10).fork()).join(), e.cloning !== void 0 && C.encode(e.cloning, t.uint32(18).fork()).join(), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = Ce();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 10) break;
					i.default = C.decode(n, n.uint32());
					continue;
				case 2:
					if (e !== 18) break;
					i.cloning = C.decode(n, n.uint32());
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			default: w(e.default) ? C.fromJSON(e.default) : void 0,
			cloning: w(e.cloning) ? C.fromJSON(e.cloning) : void 0
		};
	},
	toJSON(e) {
		let t = {};
		return e.default !== void 0 && (t.default = C.toJSON(e.default)), e.cloning !== void 0 && (t.cloning = C.toJSON(e.cloning)), t;
	},
	create(e) {
		return we.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = Ce();
		return t.default = e.default !== void 0 && e.default !== null ? C.fromPartial(e.default) : void 0, t.cloning = e.cloning !== void 0 && e.cloning !== null ? C.fromPartial(e.cloning) : void 0, t;
	}
};
function Te() {
	return {
		audioFile: new Uint8Array(),
		fileId: ""
	};
}
var Ee = {
	encode(e, t = new b()) {
		return e.audioFile.length !== 0 && t.uint32(18).bytes(e.audioFile), e.fileId !== "" && t.uint32(10).string(e.fileId), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = Te();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 2:
					if (e !== 18) break;
					i.audioFile = n.bytes();
					continue;
				case 1:
					if (e !== 10) break;
					i.fileId = n.string();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			audioFile: w(e.audioFile) ? $e(e.audioFile) : new Uint8Array(),
			fileId: w(e.fileId) ? globalThis.String(e.fileId) : ""
		};
	},
	toJSON(e) {
		let t = {};
		return e.audioFile.length !== 0 && (t.audioFile = et(e.audioFile)), e.fileId !== "" && (t.fileId = e.fileId), t;
	},
	create(e) {
		return Ee.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = Te();
		return t.audioFile = e.audioFile ?? new Uint8Array(), t.fileId = e.fileId ?? "", t;
	}
};
function De() {
	return {
		audioFile: new Uint8Array(),
		chunkId: 0
	};
}
var Oe = {
	encode(e, t = new b()) {
		return e.audioFile.length !== 0 && t.uint32(18).bytes(e.audioFile), e.chunkId !== 0 && t.uint32(8).int32(e.chunkId), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = De();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 2:
					if (e !== 18) break;
					i.audioFile = n.bytes();
					continue;
				case 1:
					if (e !== 8) break;
					i.chunkId = n.int32();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			audioFile: w(e.audioFile) ? $e(e.audioFile) : new Uint8Array(),
			chunkId: w(e.chunkId) ? globalThis.Number(e.chunkId) : 0
		};
	},
	toJSON(e) {
		let t = {};
		return e.audioFile.length !== 0 && (t.audioFile = et(e.audioFile)), e.chunkId !== 0 && (t.chunkId = Math.round(e.chunkId)), t;
	},
	create(e) {
		return Oe.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = De();
		return t.audioFile = e.audioFile ?? new Uint8Array(), t.chunkId = e.chunkId ?? 0, t;
	}
};
function ke() {
	return {
		audioBuffer: void 0,
		audioPartsLength: 0,
		fileId: "",
		version: 0
	};
}
var Ae = {
	encode(e, t = new b()) {
		return e.audioBuffer !== void 0 && Oe.encode(e.audioBuffer, t.uint32(10).fork()).join(), e.audioPartsLength !== 0 && t.uint32(16).int32(e.audioPartsLength), e.fileId !== "" && t.uint32(26).string(e.fileId), e.version !== 0 && t.uint32(32).int32(e.version), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = ke();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 10) break;
					i.audioBuffer = Oe.decode(n, n.uint32());
					continue;
				case 2:
					if (e !== 16) break;
					i.audioPartsLength = n.int32();
					continue;
				case 3:
					if (e !== 26) break;
					i.fileId = n.string();
					continue;
				case 4:
					if (e !== 32) break;
					i.version = n.int32();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			audioBuffer: w(e.audioBuffer) ? Oe.fromJSON(e.audioBuffer) : void 0,
			audioPartsLength: w(e.audioPartsLength) ? globalThis.Number(e.audioPartsLength) : 0,
			fileId: w(e.fileId) ? globalThis.String(e.fileId) : "",
			version: w(e.version) ? globalThis.Number(e.version) : 0
		};
	},
	toJSON(e) {
		let t = {};
		return e.audioBuffer !== void 0 && (t.audioBuffer = Oe.toJSON(e.audioBuffer)), e.audioPartsLength !== 0 && (t.audioPartsLength = Math.round(e.audioPartsLength)), e.fileId !== "" && (t.fileId = e.fileId), e.version !== 0 && (t.version = Math.round(e.version)), t;
	},
	create(e) {
		return Ae.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = ke();
		return t.audioBuffer = e.audioBuffer !== void 0 && e.audioBuffer !== null ? Oe.fromPartial(e.audioBuffer) : void 0, t.audioPartsLength = e.audioPartsLength ?? 0, t.fileId = e.fileId ?? "", t.version = e.version ?? 0, t;
	}
};
function je() {
	return {
		translationId: "",
		url: "",
		partialAudioInfo: void 0,
		audioInfo: void 0
	};
}
var Me = {
	encode(e, t = new b()) {
		return e.translationId !== "" && t.uint32(10).string(e.translationId), e.url !== "" && t.uint32(18).string(e.url), e.partialAudioInfo !== void 0 && Ae.encode(e.partialAudioInfo, t.uint32(34).fork()).join(), e.audioInfo !== void 0 && Ee.encode(e.audioInfo, t.uint32(50).fork()).join(), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = je();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 10) break;
					i.translationId = n.string();
					continue;
				case 2:
					if (e !== 18) break;
					i.url = n.string();
					continue;
				case 4:
					if (e !== 34) break;
					i.partialAudioInfo = Ae.decode(n, n.uint32());
					continue;
				case 6:
					if (e !== 50) break;
					i.audioInfo = Ee.decode(n, n.uint32());
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			translationId: w(e.translationId) ? globalThis.String(e.translationId) : "",
			url: w(e.url) ? globalThis.String(e.url) : "",
			partialAudioInfo: w(e.partialAudioInfo) ? Ae.fromJSON(e.partialAudioInfo) : void 0,
			audioInfo: w(e.audioInfo) ? Ee.fromJSON(e.audioInfo) : void 0
		};
	},
	toJSON(e) {
		let t = {};
		return e.translationId !== "" && (t.translationId = e.translationId), e.url !== "" && (t.url = e.url), e.partialAudioInfo !== void 0 && (t.partialAudioInfo = Ae.toJSON(e.partialAudioInfo)), e.audioInfo !== void 0 && (t.audioInfo = Ee.toJSON(e.audioInfo)), t;
	},
	create(e) {
		return Me.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = je();
		return t.translationId = e.translationId ?? "", t.url = e.url ?? "", t.partialAudioInfo = e.partialAudioInfo !== void 0 && e.partialAudioInfo !== null ? Ae.fromPartial(e.partialAudioInfo) : void 0, t.audioInfo = e.audioInfo !== void 0 && e.audioInfo !== null ? Ee.fromPartial(e.audioInfo) : void 0, t;
	}
};
function Ne() {
	return {
		status: 0,
		remainingChunks: []
	};
}
var Pe = {
	encode(e, t = new b()) {
		e.status !== 0 && t.uint32(8).int32(e.status);
		for (let n of e.remainingChunks) t.uint32(18).string(n);
		return t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = Ne();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 8) break;
					i.status = n.int32();
					continue;
				case 2:
					if (e !== 18) break;
					i.remainingChunks.push(n.string());
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			status: w(e.status) ? globalThis.Number(e.status) : 0,
			remainingChunks: globalThis.Array.isArray(e?.remainingChunks) ? e.remainingChunks.map((e) => globalThis.String(e)) : []
		};
	},
	toJSON(e) {
		let t = {};
		return e.status !== 0 && (t.status = Math.round(e.status)), e.remainingChunks?.length && (t.remainingChunks = e.remainingChunks), t;
	},
	create(e) {
		return Pe.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = Ne();
		return t.status = e.status ?? 0, t.remainingChunks = e.remainingChunks?.map((e) => e) || [], t;
	}
};
function Fe() {
	return {
		language: "",
		url: "",
		unknown0: 0,
		translatedLanguage: "",
		translatedUrl: "",
		unknown1: 0,
		unknown2: 0
	};
}
var Ie = {
	encode(e, t = new b()) {
		return e.language !== "" && t.uint32(10).string(e.language), e.url !== "" && t.uint32(18).string(e.url), e.unknown0 !== 0 && t.uint32(24).int32(e.unknown0), e.translatedLanguage !== "" && t.uint32(34).string(e.translatedLanguage), e.translatedUrl !== "" && t.uint32(42).string(e.translatedUrl), e.unknown1 !== 0 && t.uint32(48).int32(e.unknown1), e.unknown2 !== 0 && t.uint32(56).int32(e.unknown2), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = Fe();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 10) break;
					i.language = n.string();
					continue;
				case 2:
					if (e !== 18) break;
					i.url = n.string();
					continue;
				case 3:
					if (e !== 24) break;
					i.unknown0 = n.int32();
					continue;
				case 4:
					if (e !== 34) break;
					i.translatedLanguage = n.string();
					continue;
				case 5:
					if (e !== 42) break;
					i.translatedUrl = n.string();
					continue;
				case 6:
					if (e !== 48) break;
					i.unknown1 = n.int32();
					continue;
				case 7:
					if (e !== 56) break;
					i.unknown2 = n.int32();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			language: w(e.language) ? globalThis.String(e.language) : "",
			url: w(e.url) ? globalThis.String(e.url) : "",
			unknown0: w(e.unknown0) ? globalThis.Number(e.unknown0) : 0,
			translatedLanguage: w(e.translatedLanguage) ? globalThis.String(e.translatedLanguage) : "",
			translatedUrl: w(e.translatedUrl) ? globalThis.String(e.translatedUrl) : "",
			unknown1: w(e.unknown1) ? globalThis.Number(e.unknown1) : 0,
			unknown2: w(e.unknown2) ? globalThis.Number(e.unknown2) : 0
		};
	},
	toJSON(e) {
		let t = {};
		return e.language !== "" && (t.language = e.language), e.url !== "" && (t.url = e.url), e.unknown0 !== 0 && (t.unknown0 = Math.round(e.unknown0)), e.translatedLanguage !== "" && (t.translatedLanguage = e.translatedLanguage), e.translatedUrl !== "" && (t.translatedUrl = e.translatedUrl), e.unknown1 !== 0 && (t.unknown1 = Math.round(e.unknown1)), e.unknown2 !== 0 && (t.unknown2 = Math.round(e.unknown2)), t;
	},
	create(e) {
		return Ie.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = Fe();
		return t.language = e.language ?? "", t.url = e.url ?? "", t.unknown0 = e.unknown0 ?? 0, t.translatedLanguage = e.translatedLanguage ?? "", t.translatedUrl = e.translatedUrl ?? "", t.unknown1 = e.unknown1 ?? 0, t.unknown2 = e.unknown2 ?? 0, t;
	}
};
function Le() {
	return {
		url: "",
		language: ""
	};
}
var Re = {
	encode(e, t = new b()) {
		return e.url !== "" && t.uint32(10).string(e.url), e.language !== "" && t.uint32(18).string(e.language), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = Le();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 10) break;
					i.url = n.string();
					continue;
				case 2:
					if (e !== 18) break;
					i.language = n.string();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			url: w(e.url) ? globalThis.String(e.url) : "",
			language: w(e.language) ? globalThis.String(e.language) : ""
		};
	},
	toJSON(e) {
		let t = {};
		return e.url !== "" && (t.url = e.url), e.language !== "" && (t.language = e.language), t;
	},
	create(e) {
		return Re.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = Le();
		return t.url = e.url ?? "", t.language = e.language ?? "", t;
	}
};
function ze() {
	return {
		waiting: !1,
		subtitles: []
	};
}
var Be = {
	encode(e, t = new b()) {
		e.waiting !== !1 && t.uint32(8).bool(e.waiting);
		for (let n of e.subtitles) Ie.encode(n, t.uint32(18).fork()).join();
		return t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = ze();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 8) break;
					i.waiting = n.bool();
					continue;
				case 2:
					if (e !== 18) break;
					i.subtitles.push(Ie.decode(n, n.uint32()));
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			waiting: w(e.waiting) ? globalThis.Boolean(e.waiting) : !1,
			subtitles: globalThis.Array.isArray(e?.subtitles) ? e.subtitles.map((e) => Ie.fromJSON(e)) : []
		};
	},
	toJSON(e) {
		let t = {};
		return e.waiting !== !1 && (t.waiting = e.waiting), e.subtitles?.length && (t.subtitles = e.subtitles.map((e) => Ie.toJSON(e))), t;
	},
	create(e) {
		return Be.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = ze();
		return t.waiting = e.waiting ?? !1, t.subtitles = e.subtitles?.map((e) => Ie.fromPartial(e)) || [], t;
	}
};
function Ve() {
	return {
		url: "",
		timestamp: ""
	};
}
var He = {
	encode(e, t = new b()) {
		return e.url !== "" && t.uint32(10).string(e.url), e.timestamp !== "" && t.uint32(18).string(e.timestamp), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = Ve();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 10) break;
					i.url = n.string();
					continue;
				case 2:
					if (e !== 18) break;
					i.timestamp = n.string();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			url: w(e.url) ? globalThis.String(e.url) : "",
			timestamp: w(e.timestamp) ? globalThis.String(e.timestamp) : ""
		};
	},
	toJSON(e) {
		let t = {};
		return e.url !== "" && (t.url = e.url), e.timestamp !== "" && (t.timestamp = e.timestamp), t;
	},
	create(e) {
		return He.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = Ve();
		return t.url = e.url ?? "", t.timestamp = e.timestamp ?? "", t;
	}
};
function Ue() {
	return {
		url: "",
		language: "",
		responseLanguage: "",
		unknown0: 0,
		unknown1: 0
	};
}
var We = {
	encode(e, t = new b()) {
		return e.url !== "" && t.uint32(10).string(e.url), e.language !== "" && t.uint32(18).string(e.language), e.responseLanguage !== "" && t.uint32(26).string(e.responseLanguage), e.unknown0 !== 0 && t.uint32(40).int32(e.unknown0), e.unknown1 !== 0 && t.uint32(48).int32(e.unknown1), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = Ue();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 10) break;
					i.url = n.string();
					continue;
				case 2:
					if (e !== 18) break;
					i.language = n.string();
					continue;
				case 3:
					if (e !== 26) break;
					i.responseLanguage = n.string();
					continue;
				case 5:
					if (e !== 40) break;
					i.unknown0 = n.int32();
					continue;
				case 6:
					if (e !== 48) break;
					i.unknown1 = n.int32();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			url: w(e.url) ? globalThis.String(e.url) : "",
			language: w(e.language) ? globalThis.String(e.language) : "",
			responseLanguage: w(e.responseLanguage) ? globalThis.String(e.responseLanguage) : "",
			unknown0: w(e.unknown0) ? globalThis.Number(e.unknown0) : 0,
			unknown1: w(e.unknown1) ? globalThis.Number(e.unknown1) : 0
		};
	},
	toJSON(e) {
		let t = {};
		return e.url !== "" && (t.url = e.url), e.language !== "" && (t.language = e.language), e.responseLanguage !== "" && (t.responseLanguage = e.responseLanguage), e.unknown0 !== 0 && (t.unknown0 = Math.round(e.unknown0)), e.unknown1 !== 0 && (t.unknown1 = Math.round(e.unknown1)), t;
	},
	create(e) {
		return We.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = Ue();
		return t.url = e.url ?? "", t.language = e.language ?? "", t.responseLanguage = e.responseLanguage ?? "", t.unknown0 = e.unknown0 ?? 0, t.unknown1 = e.unknown1 ?? 0, t;
	}
};
function Ge() {
	return {
		interval: 0,
		translatedInfo: void 0,
		pingId: void 0
	};
}
var Ke = {
	encode(e, t = new b()) {
		return e.interval !== 0 && t.uint32(8).int32(e.interval), e.translatedInfo !== void 0 && He.encode(e.translatedInfo, t.uint32(18).fork()).join(), e.pingId !== void 0 && t.uint32(24).int32(e.pingId), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = Ge();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 8) break;
					i.interval = n.int32();
					continue;
				case 2:
					if (e !== 18) break;
					i.translatedInfo = He.decode(n, n.uint32());
					continue;
				case 3:
					if (e !== 24) break;
					i.pingId = n.int32();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			interval: w(e.interval) ? fe(e.interval) : 0,
			translatedInfo: w(e.translatedInfo) ? He.fromJSON(e.translatedInfo) : void 0,
			pingId: w(e.pingId) ? globalThis.Number(e.pingId) : void 0
		};
	},
	toJSON(e) {
		let t = {};
		return e.interval !== 0 && (t.interval = pe(e.interval)), e.translatedInfo !== void 0 && (t.translatedInfo = He.toJSON(e.translatedInfo)), e.pingId !== void 0 && (t.pingId = Math.round(e.pingId)), t;
	},
	create(e) {
		return Ke.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = Ge();
		return t.interval = e.interval ?? 0, t.translatedInfo = e.translatedInfo !== void 0 && e.translatedInfo !== null ? He.fromPartial(e.translatedInfo) : void 0, t.pingId = e.pingId ?? void 0, t;
	}
};
function qe() {
	return { pingId: 0 };
}
var Je = {
	encode(e, t = new b()) {
		return e.pingId !== 0 && t.uint32(8).int32(e.pingId), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = qe();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 8) break;
					i.pingId = n.int32();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return { pingId: w(e.pingId) ? globalThis.Number(e.pingId) : 0 };
	},
	toJSON(e) {
		let t = {};
		return e.pingId !== 0 && (t.pingId = Math.round(e.pingId)), t;
	},
	create(e) {
		return Je.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = qe();
		return t.pingId = e.pingId ?? 0, t;
	}
};
function Ye() {
	return {
		uuid: "",
		module: ""
	};
}
var Xe = {
	encode(e, t = new b()) {
		return e.uuid !== "" && t.uint32(10).string(e.uuid), e.module !== "" && t.uint32(18).string(e.module), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = Ye();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 10) break;
					i.uuid = n.string();
					continue;
				case 2:
					if (e !== 18) break;
					i.module = n.string();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			uuid: w(e.uuid) ? globalThis.String(e.uuid) : "",
			module: w(e.module) ? globalThis.String(e.module) : ""
		};
	},
	toJSON(e) {
		let t = {};
		return e.uuid !== "" && (t.uuid = e.uuid), e.module !== "" && (t.module = e.module), t;
	},
	create(e) {
		return Xe.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = Ye();
		return t.uuid = e.uuid ?? "", t.module = e.module ?? "", t;
	}
};
function Ze() {
	return {
		secretKey: "",
		expires: 0
	};
}
var Qe = {
	encode(e, t = new b()) {
		return e.secretKey !== "" && t.uint32(10).string(e.secretKey), e.expires !== 0 && t.uint32(16).int32(e.expires), t;
	},
	decode(e, t) {
		let n = e instanceof x ? e : new x(e), r = t === void 0 ? n.len : n.pos + t, i = Ze();
		for (; n.pos < r;) {
			let e = n.uint32();
			switch (e >>> 3) {
				case 1:
					if (e !== 10) break;
					i.secretKey = n.string();
					continue;
				case 2:
					if (e !== 16) break;
					i.expires = n.int32();
					continue;
			}
			if ((e & 7) == 4 || e === 0) break;
			n.skip(e & 7);
		}
		return i;
	},
	fromJSON(e) {
		return {
			secretKey: w(e.secretKey) ? globalThis.String(e.secretKey) : "",
			expires: w(e.expires) ? globalThis.Number(e.expires) : 0
		};
	},
	toJSON(e) {
		let t = {};
		return e.secretKey !== "" && (t.secretKey = e.secretKey), e.expires !== 0 && (t.expires = Math.round(e.expires)), t;
	},
	create(e) {
		return Qe.fromPartial(e ?? {});
	},
	fromPartial(e) {
		let t = Ze();
		return t.secretKey = e.secretKey ?? "", t.expires = e.expires ?? 0, t;
	}
};
function $e(e) {
	if (globalThis.Buffer) return Uint8Array.from(globalThis.Buffer.from(e, "base64"));
	{
		let t = globalThis.atob(e), n = new Uint8Array(t.length);
		for (let e = 0; e < t.length; ++e) n[e] = t.charCodeAt(e);
		return n;
	}
}
function et(e) {
	if (globalThis.Buffer) return globalThis.Buffer.from(e).toString("base64");
	{
		let t = [];
		return e.forEach((e) => {
			t.push(globalThis.String.fromCharCode(e));
		}), globalThis.btoa(t.join(""));
	}
}
function w(e) {
	return e != null;
}
//#endregion
//#region node_modules/@vot.js/shared/dist/types/logger.js
var tt;
(function(e) {
	e[e.DEBUG = 0] = "DEBUG", e[e.INFO = 1] = "INFO", e[e.WARN = 2] = "WARN", e[e.ERROR = 3] = "ERROR", e[e.SILENCE = 4] = "SILENCE";
})(tt ||= {});
//#endregion
//#region node_modules/@vot.js/shared/dist/utils/logger.js
var nt = `[vot.js v${l.version}]`;
function rt(e) {
	return l.loggerLevel <= e;
}
function it(...e) {
	rt(tt.DEBUG) && console.log(nt, ...e);
}
function at(...e) {
	rt(tt.INFO) && console.info(nt, ...e);
}
function ot(...e) {
	rt(tt.WARN) && console.warn(nt, ...e);
}
function st(...e) {
	rt(tt.ERROR) && console.error(nt, ...e);
}
var T = {
	canLog: rt,
	log: it,
	info: at,
	warn: ot,
	error: st
}, { componentVersion: ct } = l;
async function lt() {
	return typeof window < "u" && window.crypto ? window.crypto : await import("./nodeCrypto-BsZVy84y.js");
}
var ut = new TextEncoder();
async function dt(e, t, n) {
	let r = await lt(), i = await r.subtle.importKey("raw", ut.encode(t), {
		name: "HMAC",
		hash: { name: e }
	}, !1, ["sign", "verify"]);
	return await r.subtle.sign("HMAC", i, n);
}
async function ft(e) {
	let t = await dt("SHA-256", l.hmac, e);
	return new Uint8Array(t).reduce((e, t) => e + t.toString(16).padStart(2, "0"), "");
}
async function pt(e, t, n, r) {
	let { secretKey: i, uuid: a } = t, o = `${a}:${r}:${ct}`, s = await ft(ut.encode(o));
	if (e === "Ya-Summary") return {
		[`X-${e}-Sk`]: i,
		[`X-${e}-Token`]: `${s}:${o}`
	};
	if (!n) throw TypeError(`Body is required for sec type ${e}`);
	let c = await ft(n);
	return {
		[`${e}-Signature`]: c,
		[`Sec-${e}-Sk`]: i,
		[`Sec-${e}-Token`]: `${s}:${o}`
	};
}
function mt() {
	let e = "";
	for (let t = 0; t < 32; t++) {
		let t = Math.floor(Math.random() * 16);
		e += "0123456789ABCDEF"[t];
	}
	return e;
}
async function ht(e, t) {
	try {
		let n = await dt("SHA-1", e, ut.encode(t));
		return btoa(String.fromCharCode(...new Uint8Array(n)));
	} catch (e) {
		return T.error(e), !1;
	}
}
var gt = {
	"sec-ch-ua": `"Chromium";v="146", "YaBrowser";v="${ct.slice(0, 5)}", "Not?A_Brand";v="26", "Yowser";v="2.5"`,
	"sec-ch-ua-full-version-list": `"Chromium";v="146.0.7680.154", "YaBrowser";v="${ct}", "Not?A_Brand";v="26.0.0.0", "Yowser";v="2.5"`,
	"Sec-Fetch-Mode": "no-cors"
}, _t = {
	afr: "af",
	aka: "ak",
	alb: "sq",
	amh: "am",
	ara: "ar",
	arm: "hy",
	asm: "as",
	aym: "ay",
	aze: "az",
	baq: "eu",
	bel: "be",
	ben: "bn",
	bos: "bs",
	bul: "bg",
	bur: "my",
	cat: "ca",
	chi: "zh",
	cos: "co",
	cze: "cs",
	dan: "da",
	div: "dv",
	dut: "nl",
	eng: "en",
	epo: "eo",
	est: "et",
	ewe: "ee",
	fin: "fi",
	fre: "fr",
	fry: "fy",
	geo: "ka",
	ger: "de",
	gla: "gd",
	gle: "ga",
	glg: "gl",
	gre: "el",
	grn: "gn",
	guj: "gu",
	hat: "ht",
	hau: "ha",
	hin: "hi",
	hrv: "hr",
	hun: "hu",
	ibo: "ig",
	ice: "is",
	ind: "id",
	ita: "it",
	jav: "jv",
	jpn: "ja",
	kan: "kn",
	kaz: "kk",
	khm: "km",
	kin: "rw",
	kir: "ky",
	kor: "ko",
	kur: "ku",
	lao: "lo",
	lat: "la",
	lav: "lv",
	lin: "ln",
	lit: "lt",
	ltz: "lb",
	lug: "lg",
	mac: "mk",
	mal: "ml",
	mao: "mi",
	mar: "mr",
	may: "ms",
	mlg: "mg",
	mlt: "mt",
	mon: "mn",
	nep: "ne",
	nor: "no",
	nya: "ny",
	ori: "or",
	orm: "om",
	pan: "pa",
	per: "fa",
	pol: "pl",
	por: "pt",
	pus: "ps",
	que: "qu",
	rum: "ro",
	rus: "ru",
	san: "sa",
	sin: "si",
	slo: "sk",
	slv: "sl",
	smo: "sm",
	sna: "sn",
	snd: "sd",
	som: "so",
	sot: "st",
	spa: "es",
	srp: "sr",
	sun: "su",
	swa: "sw",
	swe: "sv",
	tam: "ta",
	tat: "tt",
	tel: "te",
	tgk: "tg",
	tha: "th",
	tir: "ti",
	tso: "ts",
	tuk: "tk",
	tur: "tr",
	uig: "ug",
	ukr: "uk",
	urd: "ur",
	uzb: "uz",
	vie: "vi",
	wel: "cy",
	xho: "xh",
	yid: "yi",
	yor: "yo",
	zul: "zu"
};
async function vt(e, t = { headers: { "User-Agent": l.userAgent } }) {
	let { timeout: n = 3e3, signal: r, ...i } = t;
	if (!r && (!n || n <= 0)) return await fetch(e, i);
	let a = new AbortController(), o = (e) => {
		a.signal.aborted || a.abort(e);
	};
	r && (r.aborted ? o(r.reason) : r.addEventListener("abort", () => o(r.reason), { once: !0 }));
	let s;
	n && n > 0 && (s = setTimeout(() => o(/* @__PURE__ */ Error("Fetch timeout")), n));
	try {
		return await fetch(e, {
			...i,
			signal: a.signal
		});
	} finally {
		s && clearTimeout(s);
	}
}
function bt() {
	return Math.floor(Date.now() / 1e3);
}
function E(e) {
	return e.length === 3 ? _t[e] : e.toLowerCase().split(/[_;-]/)[0].trim();
}
function D(e, t = "mp4") {
	let n = `https://${l.mediaProxy}/v1/proxy/video.${t}?format=base64&force=true`;
	return e instanceof URL ? `${n}&url=${btoa(e.href)}&origin=${e.origin}&referer=${e.origin}` : `${n}&url=${btoa(e)}`;
}
function xt(e, t) {
	let n = e.replace(/^\/+/, ""), r = new URL("https://vk.com/video");
	r.searchParams.set("z", n);
	for (let e of ["list", "access_key"]) {
		let n = t.searchParams.get(e);
		n && r.searchParams.set(e, n);
	}
	return r.toString();
}
//#endregion
//#region node_modules/@vot.js/core/dist/protobuf.js
function St(e, t, n, r, i, { forceSourceLang: a = !1, wasStream: o = !1, videoTitle: s = "", bypassCache: c = !1, useLivelyVoice: l = !1, firstRequest: u = !0 } = {}) {
	return _e.encode({
		url: e,
		firstRequest: u,
		duration: t,
		unknown0: 1,
		language: n,
		forceSourceLang: a,
		unknown1: 0,
		translationHelp: i ?? [],
		responseLanguage: r,
		wasStream: o,
		unknown2: 1,
		unknown3: 2,
		bypassCache: c,
		useLivelyVoice: l,
		videoTitle: s
	}).finish();
}
function Ct(e) {
	return ye.decode(new Uint8Array(e));
}
function wt(e, t, n, r) {
	return Se.encode({
		url: e,
		duration: t,
		language: n,
		responseLanguage: r
	}).finish();
}
function Tt(e) {
	return we.decode(new Uint8Array(e));
}
function Et(e) {
	return "chunkId" in e;
}
function Dt(e, t, n, r) {
	return r && Et(n) ? Me.encode({
		url: e,
		translationId: t,
		partialAudioInfo: {
			...r,
			audioBuffer: n
		}
	}).finish() : Me.encode({
		url: e,
		translationId: t,
		audioInfo: n
	}).finish();
}
function Ot(e) {
	return Pe.decode(new Uint8Array(e));
}
function kt(e, t) {
	return Re.encode({
		url: e,
		language: t
	}).finish();
}
function At(e) {
	return Be.decode(new Uint8Array(e));
}
function jt(e) {
	return Je.encode({ pingId: e }).finish();
}
function Mt(e, t, n) {
	return We.encode({
		url: e,
		language: t,
		responseLanguage: n,
		unknown0: 1,
		unknown1: 0
	}).finish();
}
function Nt(e) {
	return Ke.decode(new Uint8Array(e));
}
var O = {
	encodeTranslationRequest: St,
	decodeTranslationResponse: Ct,
	encodeTranslationCacheRequest: wt,
	decodeTranslationCacheResponse: Tt,
	isPartialAudioBuffer: Et,
	encodeTranslationAudioRequest: Dt,
	decodeTranslationAudioResponse: Ot,
	encodeSubtitlesRequest: kt,
	decodeSubtitlesResponse: At,
	encodeStreamPingRequest: jt,
	encodeStreamRequest: Mt,
	decodeStreamResponse: Nt
};
function Pt(e, t) {
	return Xe.encode({
		uuid: e,
		module: t
	}).finish();
}
function Ft(e) {
	return Qe.decode(new Uint8Array(e));
}
var It = {
	encodeSessionRequest: Pt,
	decodeSessionResponse: Ft
}, Lt;
(function(e) {
	e[e.FAILED = 0] = "FAILED", e[e.FINISHED = 1] = "FINISHED", e[e.WAITING = 2] = "WAITING", e[e.LONG_WAITING = 3] = "LONG_WAITING", e[e.PART_CONTENT = 5] = "PART_CONTENT", e[e.AUDIO_REQUESTED = 6] = "AUDIO_REQUESTED", e[e.SESSION_REQUIRED = 7] = "SESSION_REQUIRED";
})(Lt ||= {});
var Rt;
(function(e) {
	e.WEB_API_VIDEO_SRC_FROM_IFRAME = "web_api_video_src_from_iframe", e.WEB_API_VIDEO_SRC = "web_api_video_src", e.WEB_API_GET_ALL_GENERATING_URLS_DATA_FROM_IFRAME = "web_api_get_all_generating_urls_data_from_iframe", e.WEB_API_GET_ALL_GENERATING_URLS_DATA_FROM_IFRAME_TMP_EXP = "web_api_get_all_generating_urls_data_from_iframe_tmp_exp", e.WEB_API_REPLACED_FETCH_INSIDE_IFRAME = "web_api_replaced_fetch_inside_iframe", e.ANDROID_API = "android_api", e.WEB_API_SLOW = "web_api_slow", e.WEB_API_STEAL_SIG_AND_N = "web_api_steal_sig_and_n", e.WEB_API_COMBINED = "web_api_get_all_generating_urls_data_from_iframe,web_api_steal_sig_and_n";
})(Rt ||= {});
//#endregion
//#region node_modules/@vot.js/core/dist/types/service.js
var k;
(function(e) {
	e.custom = "custom", e.directlink = "custom", e.youtube = "youtube", e.preservetube = "preservetube", e.piped = "piped", e.invidious = "invidious", e.niconico = "niconico", e.vk = "vk", e.nine_gag = "nine_gag", e.gag = "nine_gag", e.twitch = "twitch", e.proxitok = "proxitok", e.tiktok = "tiktok", e.vimeo = "vimeo", e.xvideos = "xvideos", e.xhamster = "xhamster", e.spankbang = "spankbang", e.rule34video = "rule34video", e.picarto = "picarto", e.olympicsreplay = "olympics_replay", e.pornhub = "pornhub", e.twitter = "twitter", e.x = "twitter", e.rumble = "rumble", e.facebook = "facebook", e.rutube = "rutube", e.coub = "coub", e.bilibili = "bilibili", e.mail_ru = "mailru", e.mailru = "mailru", e.bitchute = "bitchute", e.eporner = "eporner", e.peertube = "peertube", e.dailymotion = "dailymotion", e.trovo = "trovo", e.yandexdisk = "yandexdisk", e.ok_ru = "okru", e.okru = "okru", e.googledrive = "googledrive", e.bannedvideo = "bannedvideo", e.weverse = "weverse", e.weibo = "weibo", e.newgrounds = "newgrounds", e.egghead = "egghead", e.youku = "youku", e.archive = "archive", e.kodik = "kodik", e.patreon = "patreon", e.reddit = "reddit", e.kick = "kick", e.apple_developer = "apple_developer", e.appledeveloper = "apple_developer", e.epicgames = "epicgames", e.odysee = "odysee", e.coursehunterLike = "coursehunterLike", e.sap = "sap", e.watchpornto = "watchpornto", e.jove = "jove", e.linkedin = "linkedin", e.incestflix = "incestflix", e.porntn = "porntn", e.dzen = "dzen", e.bunnystream = "bunnystream", e.cloudflarestream = "cloudflarestream", e.loom = "loom", e.rtnews = "rtnews", e.bitview = "bitview", e.thisvid = "thisvid", e.ign = "ign", e.zdf = "zdf", e.bunkr = "bunkr", e.imdb = "imdb", e.telegram = "telegram";
})(k ||= {});
//#endregion
//#region node_modules/@vot.js/core/dist/utils/vot.js
function zt(e, t, n) {
	return e === k.patreon ? {
		service: "mux",
		videoId: new URL(n).pathname.slice(1)
	} : {
		service: e,
		videoId: t
	};
}
//#endregion
//#region node_modules/@vot.js/core/dist/client.js
var A = class extends Error {
	data;
	constructor(e, t = void 0) {
		super(e), this.data = t, this.name = "VOTJSError";
	}
}, Bt = class {
	host;
	schema;
	fetch;
	fetchOpts;
	sessions = {};
	userAgent = l.userAgent;
	headers = {
		"User-Agent": this.userAgent,
		Accept: "application/x-protobuf",
		"Accept-Language": "en",
		"Content-Type": "application/x-protobuf",
		Pragma: "no-cache",
		"Cache-Control": "no-cache"
	};
	hostSchemaRe = /(http(s)?):\/\//;
	constructor({ host: e = l.host, fetchFn: t = vt, fetchOpts: n = {}, headers: r = {} } = {}) {
		let i = this.hostSchemaRe.exec(e)?.[1];
		this.host = i ? e.replace(`${i}://`, "") : e, this.schema = i ?? "https", this.fetch = t, this.fetchOpts = n, this.headers = {
			...this.headers,
			...r
		};
	}
	async request(e, t, n = {}, r = "POST") {
		let i = this.getOpts(new Blob([t]), n, r);
		try {
			let t = await this.fetch(`${this.schema}://${this.host}${e}`, i), n = await t.arrayBuffer();
			return {
				success: t.status === 200,
				data: n
			};
		} catch (e) {
			return {
				success: !1,
				data: e?.message
			};
		}
	}
	async requestJSON(e, t = null, n = {}, r = "POST") {
		let i = this.getOpts(t, {
			"Content-Type": "application/json",
			...n
		}, r);
		try {
			let t = await this.fetch(`${this.schema}://${this.host}${e}`, i), n = await t.json();
			return {
				success: t.status === 200,
				data: n
			};
		} catch (e) {
			return {
				success: !1,
				data: e?.message
			};
		}
	}
	getOpts(e, t = {}, n = "POST") {
		return {
			method: n,
			headers: {
				...this.headers,
				...t
			},
			body: e,
			...this.fetchOpts
		};
	}
	async getSession(e) {
		let t = bt(), n = this.sessions[e];
		if (n && n.timestamp + n.expires > t) return n;
		let { secretKey: r, expires: i, uuid: a } = await this.createSession(e);
		return this.sessions[e] = {
			secretKey: r,
			expires: i,
			timestamp: t,
			uuid: a
		}, this.sessions[e];
	}
	async createSession(e) {
		let t = mt(), n = It.encodeSessionRequest(t, e), r = await this.request("/session/create", n, { "Vtrans-Signature": await ft(n) });
		if (!r.success) throw new A("Failed to request create session", r);
		return {
			...It.decodeSessionResponse(r.data),
			uuid: t
		};
	}
}, Vt = class extends Bt {
	hostVOT;
	schemaVOT;
	apiToken;
	requestLang;
	responseLang;
	paths = {
		videoTranslation: "/video-translation/translate",
		videoTranslationFailAudio: "/video-translation/fail-audio-js",
		videoTranslationAudio: "/video-translation/audio",
		videoTranslationCache: "/video-translation/cache",
		videoSubtitles: "/video-subtitles/get-subtitles",
		streamPing: "/stream-translation/ping-stream",
		streamTranslation: "/stream-translation/translate-stream"
	};
	isCustomLink(e) {
		return !!(/\.(m3u8|m4(a|v)|mpd)/.exec(e) ?? /^https:\/\/cdn\.qstv\.on\.epicgames\.com/.exec(e));
	}
	headersVOT = {
		"User-Agent": `vot.js/${l.version}`,
		"Content-Type": "application/json",
		Pragma: "no-cache",
		"Cache-Control": "no-cache"
	};
	constructor({ host: e, hostVOT: t = l.hostVOT, fetchFn: n, fetchOpts: r, requestLang: i = "en", responseLang: a = "ru", apiToken: o, headers: s } = {}) {
		super({
			host: e,
			fetchFn: n,
			fetchOpts: r,
			headers: s
		});
		let c = this.hostSchemaRe.exec(t)?.[1];
		this.hostVOT = c ? t.replace(`${c}://`, "") : t, this.schemaVOT = c ?? "https", this.requestLang = i, this.responseLang = a, this.apiToken = o;
	}
	get apiTokenHeader() {
		return this.apiToken ? { Authorization: `OAuth ${this.apiToken}` } : {};
	}
	async requestVOT(e, t, n = {}) {
		let r = this.getOpts(JSON.stringify(t), {
			...this.headersVOT,
			...n
		});
		try {
			let t = await this.fetch(`${this.schemaVOT}://${this.hostVOT}${e}`, r), n = await t.json();
			return {
				success: t.status === 200,
				data: n
			};
		} catch (e) {
			return {
				success: !1,
				data: e?.message
			};
		}
	}
	async translateVideoYAImpl({ videoData: e, requestLang: t = this.requestLang, responseLang: n = this.responseLang, translationHelp: r = null, headers: i = {}, extraOpts: a = {}, shouldSendFailedAudio: o = !0 }) {
		let { url: s, duration: c = l.defaultDuration } = e, u = await this.getSession("video-translation"), d = O.encodeTranslationRequest(s, c, t, n, r, a), f = this.paths.videoTranslation, p = await pt("Vtrans", u, d, f), m = a.useLivelyVoice ? this.apiTokenHeader : {}, h = await this.request(f, d, {
			...p,
			...m,
			...i
		});
		if (!h.success) throw new A("Failed to request video translation", h);
		let g = O.decodeTranslationResponse(h.data);
		T.log("translateVideo", g);
		let { status: _, translationId: v } = g;
		switch (_) {
			case Lt.FAILED: throw new A("Yandex couldn't translate video", g);
			case Lt.FINISHED:
			case Lt.PART_CONTENT:
				if (!g.url) throw new A("Audio link wasn't received from Yandex response", g);
				return {
					translationId: v,
					translated: !0,
					url: g.url,
					status: _,
					remainingTime: g.remainingTime ?? -1
				};
			case Lt.WAITING:
			case Lt.LONG_WAITING: return {
				translationId: v,
				translated: !1,
				status: _,
				remainingTime: g.remainingTime ?? -1
			};
			case Lt.AUDIO_REQUESTED: return s.startsWith("https://youtu.be/") && o ? (await this.requestVtransFailAudio(s), await this.requestVtransAudio(s, g.translationId, {
				audioFile: new Uint8Array(),
				fileId: Rt.WEB_API_GET_ALL_GENERATING_URLS_DATA_FROM_IFRAME
			}), await this.translateVideoYAImpl({
				videoData: e,
				requestLang: t,
				responseLang: n,
				translationHelp: r,
				headers: i,
				shouldSendFailedAudio: !1
			})) : {
				translationId: v,
				translated: !1,
				status: _,
				remainingTime: g.remainingTime ?? -1
			};
			case Lt.SESSION_REQUIRED: throw new A("Yandex auth required to translate video. See docs for more info", g);
			default: throw T.error("Unknown response", g), new A("Unknown response from Yandex", g);
		}
	}
	async translateVideoVOTImpl({ url: e, videoId: t, service: n, requestLang: r = this.requestLang, responseLang: i = this.responseLang, headers: a = {}, provider: o = "yandex" }) {
		let s = zt(n, t, e), c = await this.requestVOT(this.paths.videoTranslation, {
			provider: o,
			service: s.service,
			video_id: s.videoId,
			from_lang: r,
			to_lang: i,
			raw_video: e
		}, { ...a });
		if (!c.success) throw new A("Failed to request video translation", c);
		let l = c.data;
		switch (l.status) {
			case "failed": throw new A("Yandex couldn't translate video", l);
			case "success":
				if (!l.translated_url) throw new A("Audio link wasn't received from VOT response", l);
				return {
					translationId: String(l.id),
					translated: !0,
					url: l.translated_url,
					status: 1,
					remainingTime: -1
				};
			case "waiting": return {
				translationId: "",
				translated: !1,
				remainingTime: l.remaining_time,
				status: 2,
				message: l.message
			};
		}
	}
	async requestVtransFailAudio(e) {
		let t = await this.requestJSON(this.paths.videoTranslationFailAudio, JSON.stringify({ video_url: e }), void 0, "PUT");
		if (!t.data || typeof t.data == "string" || t.data.status !== 1) throw new A("Failed to request to fake video translation fail audio js", t);
		return t;
	}
	async requestVtransAudio(e, t, n, r, i = {}) {
		let a = await this.getSession("video-translation"), o;
		if (O.isPartialAudioBuffer(n)) {
			if (!r) throw new A("Partial audio metadata is required for partial audio buffer", n);
			o = O.encodeTranslationAudioRequest(e, t, n, r);
		} else o = O.encodeTranslationAudioRequest(e, t, n, void 0);
		let s = this.paths.videoTranslationAudio, c = await pt("Vtrans", a, o, s), l = await this.request(s, o, {
			...c,
			...i
		}, "PUT");
		if (!l.success) throw new A("Failed to request video translation audio", l);
		return O.decodeTranslationAudioResponse(l.data);
	}
	async translateVideoCache({ videoData: e, requestLang: t = this.requestLang, responseLang: n = this.responseLang, headers: r = {} }) {
		let { url: i, duration: a = l.defaultDuration } = e, o = await this.getSession("video-translation"), s = O.encodeTranslationCacheRequest(i, a, t, n), c = this.paths.videoTranslationCache, u = await pt("Vtrans", o, s, c), d = await this.request(c, s, {
			...u,
			...r
		}, "POST");
		if (!d.success) throw new A("Failed to request video translation cache", d);
		return O.decodeTranslationCacheResponse(d.data);
	}
	async translateVideo({ videoData: e, requestLang: t = this.requestLang, responseLang: n = this.responseLang, translationHelp: r = null, headers: i = {}, extraOpts: a = {}, shouldSendFailedAudio: o = !0 }) {
		let { url: s, videoId: c, host: l } = e;
		return this.isCustomLink(s) ? await this.translateVideoVOTImpl({
			url: s,
			videoId: c,
			service: l,
			requestLang: t,
			responseLang: n,
			headers: i,
			provider: a.useLivelyVoice ? "yandex_lively" : "yandex"
		}) : await this.translateVideoYAImpl({
			videoData: e,
			requestLang: t,
			responseLang: n,
			translationHelp: r,
			headers: i,
			extraOpts: a,
			shouldSendFailedAudio: o
		});
	}
	async getSubtitlesYAImpl({ videoData: e, requestLang: t = this.requestLang, headers: n = {} }) {
		let { url: r } = e, i = await this.getSession("video-translation"), a = O.encodeSubtitlesRequest(r, t), o = this.paths.videoSubtitles, s = await pt("Vsubs", i, a, o), c = await this.request(o, a, {
			...s,
			...n
		});
		if (!c.success) throw new A("Failed to request video subtitles", c);
		let l = O.decodeSubtitlesResponse(c.data), u = l.subtitles.map((e) => {
			let { language: t, url: n, translatedLanguage: r, translatedUrl: i } = e;
			return {
				language: t,
				url: n,
				translatedLanguage: r,
				translatedUrl: i
			};
		});
		return {
			waiting: l.waiting,
			subtitles: u
		};
	}
	async getSubtitlesVOTImpl({ url: e, videoId: t, service: n, headers: r = {} }) {
		let i = zt(n, t, e), a = await this.requestVOT(this.paths.videoSubtitles, {
			provider: "yandex",
			service: i.service,
			video_id: i.videoId
		}, r);
		if (!a.success) throw new A("Failed to request video subtitles", a);
		let o = a.data;
		return {
			waiting: !1,
			subtitles: o.reduce((e, t) => {
				if (!t.lang_from) return e;
				let n = o.find((e) => e.lang === t.lang_from);
				return n && e.push({
					language: n.lang,
					url: n.subtitle_url,
					translatedLanguage: t.lang,
					translatedUrl: t.subtitle_url
				}), e;
			}, [])
		};
	}
	async getSubtitles({ videoData: e, requestLang: t = this.requestLang, headers: n = {} }) {
		let { url: r, videoId: i, host: a } = e;
		return this.isCustomLink(r) ? await this.getSubtitlesVOTImpl({
			url: r,
			videoId: i,
			service: a,
			headers: n
		}) : await this.getSubtitlesYAImpl({
			videoData: e,
			requestLang: t,
			headers: n
		});
	}
	async pingStream({ pingId: e, headers: t = {} }) {
		let n = await this.getSession("video-translation"), r = O.encodeStreamPingRequest(e), i = this.paths.streamPing, a = await pt("Vtrans", n, r, i), o = await this.request(i, r, {
			...a,
			...t
		});
		if (!o.success) throw new A("Failed to request stream ping", o);
		return !0;
	}
	async translateStream({ videoData: e, requestLang: t = this.requestLang, responseLang: n = this.responseLang, headers: r = {} }) {
		let { url: i } = e;
		if (this.isCustomLink(i)) throw new A("Unsupported video URL for getting stream translation");
		let a = await this.getSession("video-translation"), o = O.encodeStreamRequest(i, t, n), s = this.paths.streamTranslation, c = await pt("Vtrans", a, o, s), l = await this.request(s, o, {
			...c,
			...r
		});
		if (!l.success) throw new A("Failed to request stream translation", l);
		let u = O.decodeStreamResponse(l.data), d = u.interval;
		switch (d) {
			case S.NO_CONNECTION:
			case S.TRANSLATING: return {
				translated: !1,
				interval: d,
				message: d === S.NO_CONNECTION ? "streamNoConnectionToServer" : "translationTakeFewMinutes"
			};
			case S.STREAMING:
				if (u.pingId === void 0) throw new A("Stream ping id wasn't received from Yandex response", u);
				return {
					translated: !0,
					interval: d,
					pingId: u.pingId,
					result: u.translatedInfo
				};
			default: throw T.error("Unknown response", u), new A("Unknown response from Yandex", u);
		}
	}
}, Ht = class extends Vt {
	constructor(e = {}) {
		e.host = e.host ?? l.hostWorker, super(e);
	}
	async request(e, t, n = {}, r = "POST") {
		let i = this.getOpts(JSON.stringify({
			headers: {
				...this.headers,
				...n
			},
			body: Array.from(t)
		}), { "Content-Type": "application/json" }, r);
		try {
			let t = await this.fetch(`${this.schema}://${this.host}${e}`, i), n = await t.arrayBuffer();
			return {
				success: t.status === 200,
				data: n
			};
		} catch (e) {
			return {
				success: !1,
				data: e?.message
			};
		}
	}
	async requestJSON(e, t = null, n = {}, r = "POST") {
		let i = this.getOpts(JSON.stringify({
			headers: {
				...this.headers,
				"Content-Type": "application/json",
				Accept: "application/json",
				...n
			},
			body: t
		}), {
			Accept: "application/json",
			"Content-Type": "application/json"
		}, r);
		try {
			let t = await this.fetch(`${this.schema}://${this.host}${e}`, i), n = await t.json();
			return {
				success: t.status === 200,
				data: n
			};
		} catch (e) {
			return {
				success: !1,
				data: e?.message
			};
		}
	}
}, Ut = class extends Vt {
	constructor(e) {
		super(e), this.headers = {
			...gt,
			...this.headers
		};
	}
}, Wt = class extends Ht {
	constructor(e) {
		super(e), this.headers = {
			...gt,
			...this.headers
		};
	}
}, Gt = class extends Error {
	constructor(e) {
		super(e), this.name = "VideoDataError";
	}
}, Kt = /(file:\/\/(\/)?|(http(s)?:\/\/)(127\.0\.0\.1|localhost|192\.168\.(\d){1,3}\.(\d){1,3}))/, qt = [
	"yewtu.be",
	"inv.nadeko.net",
	"invidious.nerdvpn.de",
	"invidious.protokolla.fi",
	"invidious.materialio.us",
	"iv.melmac.space"
], Jt = [
	"piped.video",
	"piped.kavin.rocks",
	"piped.private.coffee"
], Yt = [
	"proxitok.pabloferreiro.es",
	"proxitok.pussthecat.org",
	"tok.habedieeh.re",
	"proxitok.esmailelbob.xyz",
	"proxitok.privacydev.net",
	"tok.artemislena.eu",
	"tok.adminforge.de",
	"tt.vern.cc",
	"cringe.whatever.social",
	"proxitok.lunar.icu",
	"proxitok.privacy.com.de"
], Xt = [
	"peertube.tmp.rcp.tf",
	"dalek.zone",
	"video.sadmin.io",
	"videos.viorsan.com",
	"peertube.1312.media",
	"tube.shanti.cafe",
	"bee-tube.fr",
	"video.blender.org",
	"beetoons.tv",
	"makertube.net",
	"peertube.tv",
	"framatube.org",
	"tilvids.com",
	"diode.zone",
	"fedimovie.com",
	"video.hardlimit.com",
	"share.tube",
	"peervideo.club"
], Zt = ["coursehunter.net", "coursetrain.net"], j;
(function(e) {
	e.udemy = "udemy", e.coursera = "coursera", e.douyin = "douyin", e.artstation = "artstation", e.kickstarter = "kickstarter", e.datacamp = "datacamp", e.oraclelearn = "oraclelearn", e.deeplearningai = "deeplearningai", e.netacad = "netacad", e.mediafile = "mediafile";
})(j ||= {}), {
	...k,
	...j
};
//#endregion
//#region node_modules/@vot.js/ext/dist/data/sites.js
var M = {
	bilibiliPlayer: ".bpx-player-video-wrap, div.player-mobile-box.player-mobile-autoplay",
	flowplayer: ".fp-player, div.flowplayer",
	idPlayer: "#player",
	jwPlayer: ".jwplayer, .jw-media",
	player: ".player",
	shakaPlayer: ".shaka-video-container, [id^=\"shaka-video-container-\"]",
	videoJsUniversal: "[id^='vjs_video_']:not([id*='_html5_api']):not(video), video-js:not([id*='_html5_api']), .video-js:not(video):not([id*='_html5_api']), .vjs-player:not([id*='_html5_api']), [data-vjs-player]:not([id*='_html5_api'])",
	vkVideoPlayer: ".videoplayer_media, vk-video-player"
}, Qt = [
	{
		additionalData: "mobile",
		host: k.youtube,
		url: "https://youtu.be/",
		match: /^m.youtube.com$/,
		selector: ".player-container",
		needExtraData: !0
	},
	{
		host: k.youtube,
		url: "https://youtu.be/",
		match: (e) => /^(www.)?youtube(-nocookie|kids)?.com$/.test(e.hostname) && e.pathname.startsWith("/tv"),
		selector: "#container",
		needExtraData: !0
	},
	{
		host: k.youtube,
		url: "https://youtu.be/",
		match: /^(www.)?youtube(-nocookie|kids)?.com$/,
		selector: ".html5-video-container:not(#inline-player *)",
		needExtraData: !0
	},
	{
		host: k.invidious,
		url: "https://youtu.be/",
		match: qt,
		selector: M.idPlayer,
		needBypassCSP: !0
	},
	{
		host: k.piped,
		url: "https://youtu.be/",
		match: Jt,
		selector: M.shakaPlayer,
		needBypassCSP: !0
	},
	{
		host: k.preservetube,
		url: "https://preservetube.com/",
		match: /^preservetube\.com$/,
		selector: "div.video-wrapper",
		needExtraData: !0
	},
	{
		host: k.zdf,
		url: "https://www.zdf.de/play/",
		match: [/^zdf.de$/, /^(www.)?zdf.de$/],
		selector: "div.zdfplayer-app.zdfplayer-desktop, div.zdfplayer-app"
	},
	{
		host: k.niconico,
		url: "https://www.nicovideo.jp/watch/",
		match: [/^(www\.|sp\.)?nicovideo\.jp$/, /^nico\.ms$/],
		selector: "[class*=\"grid-area_[player]\"] > div"
	},
	{
		additionalData: "mobile",
		host: k.vk,
		url: "https://vk.com/video?z=",
		match: [/^m.vk.(com|ru)$/, /^m.vkvideo.ru$/],
		selector: M.vkVideoPlayer,
		shadowRoot: !0,
		needExtraData: !0
	},
	{
		additionalData: "clips",
		host: k.vk,
		url: "https://vk.com/video?z=",
		match: /^(www.|m.)?vk.(com|ru)$/,
		selector: "div[data-testid=\"clipcontainer-video\"]",
		needExtraData: !0
	},
	{
		host: k.vk,
		url: "https://vk.com/video?z=",
		match: [/^(www\.|m\.)?vk\.(com|ru)$/, /^(.*\.)?vkvideo\.ru$/],
		selector: M.vkVideoPlayer,
		needExtraData: !0
	},
	{
		host: k.nine_gag,
		url: "https://9gag.com/gag/",
		match: /^9gag.com$/,
		selector: ".video-post",
		needExtraData: !0
	},
	{
		host: k.twitch,
		url: "https://twitch.tv/",
		match: [
			/^m.twitch.tv$/,
			/^(www.)?twitch.tv$/,
			/^clips.twitch.tv$/,
			/^player.twitch.tv$/
		],
		needExtraData: !0,
		selector: ".video-ref, main > div > section > div > div > div"
	},
	{
		host: k.proxitok,
		url: "https://www.tiktok.com/",
		match: Yt,
		selector: ".column.has-text-centered"
	},
	{
		host: k.tiktok,
		url: "https://www.tiktok.com/",
		match: /^(www.)?tiktok.com$/,
		selector: null
	},
	{
		host: j.douyin,
		url: "https://www.douyin.com/",
		match: /^(www.)?douyin.com/,
		selector: ".xg-video-container",
		needExtraData: !0,
		needBypassCSP: !0
	},
	{
		host: k.vimeo,
		url: "https://vimeo.com/",
		match: /^(www\.|m\.)?vimeo.com$/,
		needExtraData: !0,
		selector: M.player
	},
	{
		host: k.vimeo,
		url: "https://player.vimeo.com/",
		match: /^player.vimeo.com$/,
		additionalData: "embed",
		needExtraData: !0,
		needBypassCSP: !0,
		selector: M.player
	},
	{
		host: k.xvideos,
		url: "https://www.xvideos.com/",
		match: [
			/^(www.)?xvideos(-ar)?.com$/,
			/^(www.)?xvideos(\d\d\d).com$/,
			/^(www.)?xv-ru.com$/
		],
		selector: "#hlsplayer",
		needBypassCSP: !0
	},
	{
		host: k.xhamster,
		url: "https://xhamster.com/",
		match: (e) => /^(?:[^.]+\.)?(?:xhamster\.(?:com|desi)|xhamster\d+\.(?:com|desi)|xhvid\.com)$/.test(e.host) && /\/(?:videos\/[^/]+-[\dA-Za-z]+)\/?$/.test(e.pathname),
		selector: "#player-container"
	},
	{
		host: k.spankbang,
		url: "https://spankbang.com/",
		match: (e) => /^(?:[^.]+\.)?spankbang\.com$/.test(e.host) && /\/(?:[\da-z]+\/(?:video|play|embed)(?:\/[^/]+)?|[\da-z]+-[\da-z]+\/playlist\/[^/?#&]+)\/?$/i.test(e.pathname),
		selector: "#main_video_player"
	},
	{
		host: k.rule34video,
		url: "https://rule34video.com/video/",
		match: (e) => /^(www\.)?rule34video\.com$/.test(e.host) && /\/videos?\/\d+/.test(e.pathname),
		selector: M.flowplayer
	},
	{
		host: k.picarto,
		url: "https://picarto.tv/",
		match: (e) => /^(www\.)?picarto\.tv$/.test(e.host) && /^(?:\/[^/]+\/(?:profile\/)?videos\/[^/?#&]+|\/videopopout\/[^/?#&]+|\/[^/#?]+\/?)$/.test(e.pathname),
		selector: "[class*=\"VideosTab__PlayerWrapper\"]"
	},
	{
		host: k.olympicsreplay,
		url: "https://olympics.com/",
		match: (e) => /^(www\.)?olympics\.com$/.test(e.host) && /^\/[a-z]{2}\/(?:[a-z0-9-]+\/)?(?:replay|videos?|original-series\/episode)\/[\w-]+\/?$/i.test(e.pathname),
		selector: M.videoJsUniversal
	},
	{
		host: k.pornhub,
		url: "https://rt.pornhub.com/view_video.php?viewkey=",
		match: /^[a-z]+.pornhub.(com|org)$/,
		selector: ".mainPlayerDiv > .video-element-wrapper-js > div",
		eventSelector: ".mgp_eventCatcher"
	},
	{
		additionalData: "embed",
		host: k.pornhub,
		url: "https://rt.pornhub.com/view_video.php?viewkey=",
		match: (e) => /^[a-z]+.pornhub.(com|org)$/.exec(e.host) && e.pathname.startsWith("/embed/"),
		selector: M.idPlayer
	},
	{
		host: k.twitter,
		url: "https://twitter.com/i/status/",
		match: /^(twitter|x).com$/,
		selector: "div[data-testid=\"videoComponent\"]",
		needBypassCSP: !0
	},
	{
		host: k.rumble,
		url: "https://rumble.com/",
		match: /^rumble.com$/,
		selector: "[id^=\"vid_\"] > div"
	},
	{
		host: k.facebook,
		url: "https://facebook.com/",
		match: (e) => e.host.includes("facebook.com") && e.pathname.includes("/videos/"),
		selector: "div[role=\"main\"] div[data-pagelet$=\"video\" i]",
		needBypassCSP: !0
	},
	{
		additionalData: "reels",
		host: k.facebook,
		url: "https://facebook.com/",
		match: (e) => e.host.includes("facebook.com") && e.pathname.includes("/reel/"),
		selector: "div[role=\"main\"]",
		needBypassCSP: !0
	},
	{
		host: k.rutube,
		url: "https://rutube.ru/video/",
		match: /^rutube.ru$/,
		selector: "div[class*=\"videoWrapper\"]"
	},
	{
		additionalData: "embed",
		host: k.rutube,
		url: "https://rutube.ru/video/",
		match: /^rutube.ru$/,
		selector: "#app > div > div"
	},
	{
		host: k.bilibili,
		url: "https://www.bilibili.com/",
		match: /^(www|m|player).bilibili.com$/,
		selector: M.bilibiliPlayer
	},
	{
		host: k.bilibili,
		url: "https://www.bilibili.tv/",
		match: /^(?:www\.|m\.)?bilibili\.tv$/,
		selector: M.bilibiliPlayer
	},
	{
		additionalData: "old",
		host: k.bilibili,
		url: "https://www.bilibili.com/",
		match: /^(www|m).bilibili.com$/,
		selector: null
	},
	{
		host: k.mailru,
		url: "https://my.mail.ru/",
		match: /^my.mail.ru$/,
		selector: "#b-video-wrapper"
	},
	{
		host: k.bitchute,
		url: "https://www.bitchute.com/video/",
		match: /^(www.)?bitchute.com$/,
		selector: M.videoJsUniversal
	},
	{
		host: k.eporner,
		url: "https://www.eporner.com/",
		match: /^(www.)?eporner.com$/,
		selector: M.videoJsUniversal
	},
	{
		host: k.peertube,
		url: "stub",
		match: Xt,
		selector: M.videoJsUniversal
	},
	{
		host: k.dailymotion,
		url: "https://www.dailymotion.com/video/",
		match: /^((www\.|player\.)?dailymotion\.com|geo(\d+)?\.dailymotion\.com|dai\.ly)$/,
		selector: M.player
	},
	{
		host: k.trovo,
		url: "https://trovo.live/s/",
		match: /^trovo.live$/,
		selector: ".player-video"
	},
	{
		host: k.yandexdisk,
		url: "https://yadi.sk/",
		match: /^disk.yandex.(ru|kz|com(\.(am|ge|tr))?|by|az|co\.il|ee|lt|lv|md|net|tj|tm|uz)$/,
		selector: ".video-player__player > div:nth-child(1)",
		eventSelector: ".video-player__player",
		needBypassCSP: !0,
		needExtraData: !0
	},
	{
		host: k.okru,
		url: "https://ok.ru/video/",
		match: /^ok.ru$/,
		selector: M.vkVideoPlayer,
		shadowRoot: !0
	},
	{
		host: k.googledrive,
		url: "https://drive.google.com/file/d/",
		match: /^youtube.googleapis.com$/,
		selector: ".html5-video-container"
	},
	{
		host: k.bannedvideo,
		url: "https://madmaxworld.tv/watch?id=",
		match: /^(www.)?banned.video|madmaxworld.tv$/,
		selector: M.videoJsUniversal,
		needExtraData: !0
	},
	{
		host: k.weverse,
		url: "https://weverse.io/",
		match: /^weverse.io$/,
		selector: ".webplayer-internal-source-wrapper",
		needExtraData: !0
	},
	{
		host: k.weibo,
		url: "https://weibo.com/",
		match: (e) => /^(?:www\.)?weibo\.com$/.test(e.host) && /^\/(?:\d+\/[A-Za-z0-9]+|0\/[A-Za-z0-9]+|tv\/show\/\d+:(?:[\da-f]{32}|\d{16,}))\/?$/.test(e.pathname) || /^video\.weibo\.com$/.test(e.host) && /^\/show\/?$/.test(e.pathname) && /^\d+:(?:[\da-f]{32}|\d{16,})$/i.test(e.searchParams.get("fid") ?? "") || /^(?:www\.)?weibo\.com$/.test(e.host) && /^\/newlogin\/?$/.test(e.pathname) && (e.searchParams.has("url") || /^[A-Za-z0-9]+$/.test(e.searchParams.get("layerid") ?? "")),
		selector: M.videoJsUniversal || "#playVideo"
	},
	{
		host: k.newgrounds,
		url: "https://www.newgrounds.com/",
		match: /^(www.)?newgrounds.com$/,
		selector: ".ng-video-player"
	},
	{
		host: k.egghead,
		url: "https://egghead.io/",
		match: /^egghead.io$/,
		selector: ".cueplayer-react-video-holder"
	},
	{
		host: k.youku,
		url: "https://v.youku.com/",
		match: /^v.youku.com$/,
		selector: "#ykPlayer"
	},
	{
		host: k.archive,
		url: "https://archive.org/details/",
		match: /^archive.org$/,
		selector: M.jwPlayer
	},
	{
		host: k.kodik,
		url: "stub",
		match: /^kodik.(info|biz|cc)$/,
		selector: M.flowplayer,
		needExtraData: !0
	},
	{
		host: k.patreon,
		url: "stub",
		match: /^(www.)?patreon.com$/,
		selector: "div[data-tag=\"post-card\"] div[elevation=\"subtle\"] > div > div > div > div",
		needExtraData: !0
	},
	{
		additionalData: "old",
		host: k.reddit,
		url: "stub",
		match: /^old.reddit.com$/,
		selector: ".reddit-video-player-root",
		needExtraData: !0,
		needBypassCSP: !0
	},
	{
		host: k.reddit,
		url: "stub",
		match: /^(www.|new.)?reddit.com$/,
		selector: "div[slot=post-media-container]",
		shadowRoot: !0,
		needExtraData: !0,
		needBypassCSP: !0
	},
	{
		host: k.kick,
		url: "https://kick.com/",
		match: /^kick.com$/,
		selector: "#injected-embedded-channel-player-video > div",
		needExtraData: !0
	},
	{
		host: k.appledeveloper,
		url: "https://developer.apple.com/",
		match: /^developer.apple.com$/,
		selector: ".developer-video-player",
		needExtraData: !0,
		needBypassCSP: !0
	},
	{
		host: k.epicgames,
		url: "https://dev.epicgames.com/community/learning/",
		match: /^dev.epicgames.com$/,
		selector: M.videoJsUniversal,
		needExtraData: !0
	},
	{
		host: k.odysee,
		url: "stub",
		match: /^odysee.com$/,
		selector: M.videoJsUniversal,
		needExtraData: !0
	},
	{
		host: k.coursehunterLike,
		url: "stub",
		match: Zt,
		selector: null,
		needExtraData: !0
	},
	{
		host: k.sap,
		url: "https://learning.sap.com/courses/",
		match: /^learning.sap.com$/,
		selector: ".playkit-container",
		eventSelector: ".playkit-player",
		needExtraData: !0,
		needBypassCSP: !0
	},
	{
		host: j.udemy,
		url: "https://www.udemy.com/",
		match: /udemy.com$/,
		selector: M.shakaPlayer,
		needExtraData: !0
	},
	{
		host: j.datacamp,
		url: "https://www.datacamp.com/courses/",
		match: (e) => /^(?:campus\.|projector\.)?datacamp\.com$/.test(e.hostname),
		selector: M.videoJsUniversal,
		needExtraData: !0
	},
	{
		host: j.coursera,
		url: "https://www.coursera.org/",
		match: /coursera.org$/,
		selector: M.videoJsUniversal,
		needExtraData: !0
	},
	{
		host: k.watchpornto,
		url: "https://watchporn.to/",
		match: /^watchporn.to$/,
		selector: M.flowplayer
	},
	{
		host: k.jove,
		url: "https://jove.com/",
		match: /^(?:app|www)\.jove\.com$/,
		selector: M.flowplayer
	},
	{
		host: k.linkedin,
		url: "https://www.linkedin.com/learning/",
		match: /^(www.)?linkedin.com$/,
		selector: M.videoJsUniversal,
		needExtraData: !0,
		needBypassCSP: !0
	},
	{
		host: k.incestflix,
		url: "https://www.incestflix.net/watch/",
		match: /^(www.)?incestflix.(net|to|com)$/,
		selector: "#incflix-stream",
		needExtraData: !0
	},
	{
		host: k.porntn,
		url: "https://porntn.com/videos/",
		match: /^porntn.com$/,
		selector: M.flowplayer,
		needExtraData: !0
	},
	{
		host: k.dzen,
		url: "https://dzen.ru/video/watch/",
		match: /^dzen.ru$/,
		selector: "[class*=\"player__playerWrap\"] > div"
	},
	{
		host: k.bunnystream,
		url: "stub",
		match: [
			/^video\.bunnycdn\.com$/,
			/^iframe\.mediadelivery\.net$/,
			/^(?:[^.]+\.)*b-cdn\.net$/
		],
		selector: null
	},
	{
		host: k.cloudflarestream,
		url: "stub",
		match: /^(watch|embed|iframe|customer-[^.]+).cloudflarestream.com$/,
		selector: null
	},
	{
		host: k.loom,
		url: "https://www.loom.com/share/",
		match: /^(www.)?loom.com$/,
		selector: ".VideoLayersContainer",
		needExtraData: !0,
		needBypassCSP: !0
	},
	{
		host: j.artstation,
		url: "https://www.artstation.com/learning/",
		match: /^(www.)?artstation.com$/,
		selector: M.videoJsUniversal,
		needExtraData: !0
	},
	{
		host: k.rtnews,
		url: "https://www.rt.com/",
		match: /^(www.)?rt.com$/,
		selector: M.jwPlayer,
		needExtraData: !0
	},
	{
		host: k.bitview,
		url: "https://www.bitview.net/watch?v=",
		match: /^(www.)?bitview.net$/,
		selector: ".vlScreen",
		needExtraData: !0
	},
	{
		host: j.kickstarter,
		url: "https://www.kickstarter.com/",
		match: /^(www.)?kickstarter.com/,
		selector: ".ksr-video-player",
		needExtraData: !0
	},
	{
		host: k.thisvid,
		url: "https://thisvid.com/",
		match: /^(www.)?thisvid.com$/,
		selector: M.flowplayer
	},
	{
		additionalData: "regional",
		host: k.ign,
		url: "https://de.ign.com/",
		match: /^(\w{2}.)?ign.com$/,
		needExtraData: !0,
		selector: ".video-container"
	},
	{
		host: k.ign,
		url: "https://www.ign.com/",
		match: /^(www.)?ign.com$/,
		selector: M.player,
		needExtraData: !0
	},
	{
		host: k.bunkr,
		url: "https://bunkr.site/",
		match: /^bunkr\.(site|black|cat|media|red|site|ws|org|s[kiu]|c[ir]|fi|p[hks]|ru|la|is|to|a[cx])$/,
		needExtraData: !0,
		selector: ".plyr__video-wrapper"
	},
	{
		host: k.imdb,
		url: "https://www.imdb.com/video/",
		match: /^(www\.)?imdb\.com$/,
		selector: M.jwPlayer
	},
	{
		host: k.telegram,
		url: "https://t.me/",
		match: (e) => /^web\.telegram\.org$/.test(e.hostname) && e.pathname.startsWith("/k"),
		selector: ".ckin__player"
	},
	{
		host: j.oraclelearn,
		url: "https://mylearn.oracle.com/ou/course/",
		match: /^mylearn\.oracle\.com/,
		selector: M.videoJsUniversal,
		needExtraData: !0,
		needBypassCSP: !0
	},
	{
		host: j.deeplearningai,
		url: "https://learn.deeplearning.ai/courses/",
		match: /^learn(-dev|-staging)?\.deeplearning\.ai/,
		selector: ".lesson-video-player",
		needExtraData: !0
	},
	{
		host: j.netacad,
		url: "https://www.netacad.com/",
		match: /^(www\.)?netacad\.com/,
		selector: M.videoJsUniversal,
		needExtraData: !0
	},
	{
		host: j.mediafile,
		url: "https://mediafile.cc/",
		match: /^(www\.)?mediafile\.cc$/,
		selector: "div#playerContainer",
		needExtraData: !0
	},
	{
		host: k.custom,
		url: "stub",
		match: (e) => /([^.]+)\.(mp4|webm)/.test(e.pathname),
		rawResult: !0
	}
], N = class extends Error {
	constructor(e) {
		super(e), this.name = "VideoHelperError";
	}
}, P = class {
	API_ORIGIN = window.location.origin;
	fetch;
	extraInfo;
	referer;
	origin;
	service;
	video;
	language;
	constructor({ fetchFn: e = vt, extraInfo: t = !0, referer: n = document.referrer ?? `${window.location.origin}/`, origin: r = window.location.origin, service: i, video: a, language: o = "en" } = {}) {
		this.fetch = e, this.extraInfo = t, this.referer = n, this.origin = /^(http(s)?):\/\//.test(String(r)) ? r : window.location.origin, this.service = i, this.video = a, this.language = o;
	}
	getVideoData(e) {
		return Promise.resolve(void 0);
	}
	getVideoId(e) {
		return Promise.resolve(void 0);
	}
	returnBaseData(e) {
		if (this.service) return {
			url: this.service.url + e,
			videoId: e,
			host: this.service.host,
			duration: void 0
		};
	}
}, $t = class extends P {
	API_ORIGIN = "https://developer.apple.com";
	async getVideoData(e) {
		try {
			let e = document.querySelector("meta[property='og:video']")?.content;
			if (!e) throw new N("Failed to find content url");
			return { url: e };
		} catch (t) {
			T.error(`Failed to get apple developer video data by video ID: ${e}`, t.message);
			return;
		}
	}
	async getVideoId(e) {
		return /videos\/play\/([^/]+)\/([\d]+)/.exec(e.pathname)?.[0];
	}
}, en = class extends P {
	async getVideoId(e) {
		return /(details|embed)\/([^/]+)/.exec(e.pathname)?.[2];
	}
}, tn = class extends P {
	API_ORIGIN = "https://www.artstation.com/api/v2/learning";
	getCSRFToken() {
		return document.querySelector("meta[name=\"public-csrf-token\"]")?.content;
	}
	async getCourseInfo(e) {
		try {
			let t = this.getCSRFToken();
			return await (await this.fetch(`${this.API_ORIGIN}/courses/${e}/autoplay.json`, {
				method: "POST",
				headers: t ? { "PUBLIC-CSRF-TOKEN": t } : {}
			})).json();
		} catch (t) {
			return T.error(`Failed to get artstation course info by courseId: ${e}.`, t.message), !1;
		}
	}
	async getVideoUrl(e) {
		try {
			return (await (await this.fetch(`${this.API_ORIGIN}/quicksilver/video_url.json?chapter_id=${e}`)).json()).url.replace("qsep://", "https://");
		} catch (t) {
			return T.error(`Failed to get artstation video url by chapterId: ${e}.`, t.message), !1;
		}
	}
	async getVideoData(e) {
		let [, t, , , n] = e.split("/"), r = await this.getCourseInfo(t);
		if (!r) return;
		let i = r.chapters.find((e) => e.hash_id === n);
		if (!i) return;
		let a = await this.getVideoUrl(i.id);
		if (!a) return;
		let { title: o, duration: s, subtitles: c } = i;
		return {
			url: a,
			title: o,
			duration: s,
			subtitles: c.filter((e) => e.format === "vtt").map((e) => ({
				language: E(e.locale),
				source: "artstation",
				format: "vtt",
				url: e.file_url
			}))
		};
	}
	async getVideoId(e) {
		return /courses\/(\w{3,5})\/([^/]+)\/chapters\/(\w{3,5})/.exec(e.pathname)?.[0];
	}
}, nn = class extends P {
	API_ORIGIN = "https://api.banned.video";
	async getVideoInfo(e) {
		try {
			return await (await this.fetch(`${this.API_ORIGIN}/graphql`, {
				method: "POST",
				body: JSON.stringify({
					operationName: "GetVideo",
					query: "query GetVideo($id: String!) {\n            getVideo(id: $id) {\n              title\n              description: summary\n              duration: videoDuration\n              videoUrl: directUrl\n              isStream: live\n            }\n          }",
					variables: { id: e }
				}),
				headers: {
					"User-Agent": "bannedVideoFrontEnd",
					"apollographql-client-name": "banned-web",
					"apollographql-client-version": "1.3",
					"content-type": "application/json"
				}
			})).json();
		} catch (t) {
			return console.error(`Failed to get bannedvideo video info by videoId: ${e}.`, t.message), !1;
		}
	}
	async getVideoData(e) {
		let t = await this.getVideoInfo(e);
		if (!t) return;
		let { videoUrl: n, duration: r, isStream: i, description: a, title: o } = t.data.getVideo;
		return {
			url: n,
			duration: r,
			isStream: i,
			title: o,
			description: a
		};
	}
	async getVideoId(e) {
		return e.searchParams.get("id") ?? void 0;
	}
}, rn = class extends P {
	async getVideoId(e) {
		let t = /bangumi\/play\/([^/]+)/.exec(e.pathname)?.[0];
		if (t) return t;
		let n = e.searchParams.get("bvid");
		if (n) return `video/${n}`;
		let r = /^\/(?:[a-z]{2}\/)?((?:play\/\d+(?:\/\d+)?|video\/\d+))\/?$/i.exec(e.pathname)?.[1];
		if (r) return r;
		let i = /video\/([^/]+)/.exec(e.pathname)?.[0];
		return i && e.searchParams.get("p") !== null && (i += `/?p=${e.searchParams.get("p")}`), i;
	}
}, an = class extends P {
	async getVideoId(e) {
		return /(video|embed)\/([^/]+)/.exec(e.pathname)?.[2];
	}
}, on = class extends P {
	async getVideoData(e) {
		try {
			let e = document.querySelector(".vlScreen > video")?.src;
			if (!e) throw new N("Failed to find video URL");
			return { url: e };
		} catch (t) {
			T.error(`Failed to get Bitview data by videoId: ${e}`, t.message);
			return;
		}
	}
	async getVideoId(e) {
		return e.searchParams.get("v");
	}
}, sn = class extends P {
	async getVideoData(e) {
		let t = document.querySelector("#player > source[type=\"video/mp4\"]")?.src;
		if (t) return { url: t };
	}
	async getVideoId(e) {
		return /\/f\/([^/]+)/.exec(e.pathname)?.[1];
	}
}, cn = class extends P {
	async getVideoId(e) {
		return e.pathname + e.search;
	}
}, ln = class extends P {
	async getVideoId(e) {
		return e.pathname + e.search;
	}
}, un = class extends P {
	API_ORIGIN = this.origin ?? "https://coursehunter.net";
	async getCourseId() {
		let e = window.course_id;
		return e === void 0 ? document.querySelector("input[name=\"course_id\"]")?.value : String(e);
	}
	async getLessonsData(e) {
		let t = window.lessons;
		if (t?.length) return t;
		try {
			return await (await this.fetch(`${this.API_ORIGIN}/api/v1/course/${e}/lessons`)).json();
		} catch (t) {
			T.error(`Failed to get CoursehunterLike lessons data by courseId: ${e}, because ${t.message}`);
			return;
		}
	}
	getLessondId(e) {
		let t = e.split("?lesson=")?.[1];
		return t || (t = document.querySelector(".lessons-item_active")?.dataset?.index, t) ? +t : 1;
	}
	async getVideoData(e) {
		let t = await this.getCourseId();
		if (!t) return;
		let n = await this.getLessonsData(t);
		if (!n) return;
		let r = this.getLessondId(e), { file: i, duration: a, title: o } = n?.[r - 1];
		if (i) return {
			url: D(i),
			duration: a,
			title: o
		};
	}
	async getVideoId(e) {
		let t = /course\/([^/]+)/.exec(e.pathname)?.[0];
		return t ? t + e.search : void 0;
	}
}, dn = [
	"auto",
	"ru",
	"en",
	"zh",
	"ko",
	"lt",
	"lv",
	"ar",
	"fr",
	"it",
	"es",
	"de",
	"ja"
], fn = [
	"ru",
	"en",
	"kk"
], pn = class e extends P {
	SUBTITLE_SOURCE = "videojs";
	SUBTITLE_FORMAT = "vtt";
	static getPlayer() {
		let e = window.videojs, t = document.querySelector("video.vjs-tech[id], video[id$='_html5_api']"), n = t?.id?.endsWith("_html5_api") ? t.id.slice(0, -10) : void 0;
		if (e?.getPlayer) {
			if (n) {
				let t = e.getPlayer(n);
				if (t) return t;
			}
			if (t) {
				let n = e.getPlayer(t);
				if (n) return n;
			}
		}
		let r = (typeof e?.getPlayers == "function" ? e.getPlayers() : e?.players) ?? {};
		for (let e of Object.values(r)) {
			let r = e, i = (typeof r.el == "function" ? r.el() : null)?.querySelector?.("video.vjs-tech, video") ?? null;
			if (i && t && i === t || n && typeof r.id == "function" && r.id() === n) return e;
		}
	}
	getVideoDataByPlayer(t) {
		try {
			let n = e.getPlayer(), r = document.querySelector("video.vjs-tech, video[id$='_html5_api'], video[src]");
			if (!n && !r) throw Error(`Video player/video element not found, videoId ${t}`);
			let i = n?.duration?.() ?? r?.duration, a;
			if (n) {
				let e = typeof n.currentSources == "function" ? n.currentSources() : n.getCache?.()?.sources;
				a = (Array.isArray(e) ? e.find((e) => e?.type === "video/mp4" || e?.type === "video/webm" || e?.src) : void 0)?.src;
			}
			if (a ??= r?.currentSrc || r?.src || r?.getAttribute?.("src") || void 0, !a) throw Error(`Failed to find video url for videoID ${t}`);
			let o = (r ? Array.from(r.querySelectorAll("track[src]")) : []).filter((e) => e.kind !== "metadata").flatMap((e) => {
				let t = e.getAttribute("src");
				if (!t) return [];
				let n = new URL(t, window.location.href).toString();
				return [{
					language: E(e.srclang || ""),
					source: this.SUBTITLE_SOURCE,
					format: this.SUBTITLE_FORMAT,
					url: n
				}];
			});
			return {
				url: a,
				duration: i,
				subtitles: o
			};
		} catch (e) {
			T.error("Failed to get videojs video data", e.message);
			return;
		}
	}
}, mn = class e extends pn {
	API_ORIGIN = "https://www.coursera.org/api";
	SUBTITLE_SOURCE = "coursera";
	async getCourseData(e) {
		try {
			return (await (await this.fetch(`${this.API_ORIGIN}/onDemandCourses.v1/${e}`)).json())?.elements?.[0];
		} catch (t) {
			T.error(`Failed to get course data by courseId: ${e}`, t.message);
			return;
		}
	}
	static getPlayer() {
		return pn.getPlayer();
	}
	async getVideoData(t) {
		let n = this.getVideoDataByPlayer(t);
		if (!n) return;
		let { options_: r } = e.getPlayer() ?? {};
		!n.subtitles?.length && r && (n.subtitles = r.tracks.map((e) => ({
			url: e.src,
			language: E(e.srclang),
			source: this.SUBTITLE_SOURCE,
			format: this.SUBTITLE_FORMAT
		})));
		let i = r?.courseId;
		if (!i) return n;
		let a = "en", o = await this.getCourseData(i);
		if (o) {
			let { primaryLanguageCodes: [e] } = o;
			a = e ? E(e) : "en";
		}
		dn.includes(a) || (a = "en");
		let s = (n.subtitles.find((e) => e.language === a) ?? n.subtitles?.[0])?.url;
		s || T.warn("Failed to find any subtitle file");
		let { url: c, duration: l } = n, u = s ? [{
			target: "subtitles_file_url",
			targetUrl: s
		}, {
			target: "video_file_url",
			targetUrl: c
		}] : null;
		return {
			...s ? {
				url: this.service?.url + t,
				translationHelp: u
			} : {
				url: c,
				translationHelp: u
			},
			detectedLanguage: a,
			duration: l
		};
	}
	async getVideoId(e) {
		return (/learn\/([^/]+)\/lecture\/([^/]+)/.exec(e.pathname) ?? /lecture\/([^/]+)\/([^/]+)/.exec(e.pathname))?.[0];
	}
}, hn = class extends P {
	getVideoIdFromUrl(e) {
		let t = e.searchParams.get("video");
		if (t) return t;
	}
	resolveVideoIdViaPostMessage() {
		return new Promise((e) => {
			let t = "https://www.dailymotion.com", n = setTimeout(() => {
				window.removeEventListener("message", r), e(void 0);
			}, 3e3), r = (i) => {
				i.origin === t && typeof i.data == "string" && i.data.startsWith("getVideoId:") && (clearTimeout(n), window.removeEventListener("message", r), e(i.data.replace("getVideoId:", "")));
			};
			window.addEventListener("message", r), window.top?.postMessage("getVideoId:", t);
		});
	}
	async getVideoId(e) {
		return window.self === window.top ? this.getVideoIdFromUrl(e) : await this.resolveVideoIdViaPostMessage();
	}
}, gn = class extends pn {
	SUBTITLE_SOURCE = "datacamp";
	getVideoDataFromInput() {
		try {
			let e = document.getElementById("videoData");
			return !e || !(e instanceof HTMLInputElement) && !(e instanceof HTMLTextAreaElement) || !e.value ? null : JSON.parse(e.value);
		} catch (e) {
			return T.error("Failed to parse DataCamp videoData input", e instanceof Error ? e.message : String(e)), null;
		}
	}
	async getVideoData(e) {
		let t = this.getVideoDataByPlayer(e);
		if (!t) return;
		let n = this.getVideoDataFromInput(), r = n?.video_url ?? n?.plain_video_mp4_link ?? n?.plain_video_hls_link ?? n?.video_mp4_link ?? n?.video_hls_link ?? t.url;
		if (r) return {
			url: e,
			video_url: r,
			translationHelp: [{
				target: "video_file_url",
				targetUrl: r
			}]
		};
	}
	async getVideoId(e) {
		return e.href;
	}
}, _n = class extends P {
	async getVideoData(e) {
		if (!this.video) return;
		let t = this.video.querySelector("source[type=\"application/x-mpegurl\"]")?.src;
		if (t) return { url: t };
	}
	async getVideoId(e) {
		return /courses\/(([^/]+)\/lesson\/([^/]+)\/([^/]+))/.exec(e.pathname)?.[1];
	}
}, vn = class e extends P {
	static getPlayer() {
		if (!(typeof player > "u")) return player;
	}
	async getVideoData(t) {
		let n = e.getPlayer();
		if (!n) return;
		let { config: { url: r, duration: i, lang: a, isLive: o } } = n;
		if (!r) return;
		let s = r.find((e) => e.src.includes("www.douyin.com/aweme/v1/play/"));
		if (s) return {
			url: D(s.src),
			duration: i,
			isStream: o,
			...dn.includes(a) ? { detectedLanguage: a } : {}
		};
	}
	async getVideoId(t) {
		return /video\/([\d]+)/.exec(t.pathname)?.[0] || e.getPlayer()?.config.vid;
	}
}, yn = class extends P {
	async getVideoId(e) {
		return /video\/watch\/([^/]+)/.exec(e.pathname)?.[1];
	}
}, bn = class extends P {
	async getVideoId(e) {
		return e.pathname.slice(1);
	}
}, xn = class extends P {
	API_ORIGIN = "https://dev.epicgames.com/community/api/learning";
	async getPostInfo(e) {
		try {
			return await (await this.fetch(`${this.API_ORIGIN}/post.json?hash_id=${e}`)).json();
		} catch (t) {
			return T.error(`Failed to get epicgames post info by videoId: ${e}.`, t.message), !1;
		}
	}
	getVideoBlock() {
		let e = /videoUrl\s?=\s"([^"]+)"?/, t = Array.from(document.body.querySelectorAll("script")).find((t) => e.exec(t.innerHTML));
		if (!t) return;
		let n = t.innerHTML.trim(), r = e.exec(n)?.[1]?.replace("qsep://", "https://");
		if (!r) return;
		let i = /sources\s?=\s(\[([^\]]+)\])?/.exec(n)?.[1];
		if (!i) return {
			playlistUrl: r,
			subtitles: []
		};
		try {
			return i = `${i.replace(/src:(\s)+?(videoUrl)/g, "src:\"removed\"").substring(0, i.lastIndexOf("},"))}]`.split("\n").map((e) => e.replace(/([^\s]+):\s?(?!.*\1)/, "\"$1\":")).join("\n"), {
				playlistUrl: r,
				subtitles: JSON.parse(i).filter((e) => e.type === "captions")
			};
		} catch {
			return {
				playlistUrl: r,
				subtitles: []
			};
		}
	}
	async getVideoData(e) {
		let t = e.split(":")?.[1], n = await this.getPostInfo(t);
		if (!n) return;
		let r = this.getVideoBlock();
		if (!r) return;
		let { playlistUrl: i, subtitles: a } = r, { title: o, description: s } = n;
		return {
			url: i,
			title: o,
			description: s,
			subtitles: a.map((e) => ({
				language: E(e.srclang),
				source: "epicgames",
				format: "vtt",
				url: e.src
			}))
		};
	}
	async getVideoId(e) {
		return new Promise((e) => {
			let t = "https://dev.epicgames.com", n = btoa(window.location.href);
			window.addEventListener("message", (n) => {
				if (n.origin === t && typeof n.data == "string" && n.data.startsWith("getVideoId:")) return e(n.data.replace("getVideoId:", ""));
			}), window.top?.postMessage(`getVideoId:${n}`, t);
		});
	}
}, Sn = class extends P {
	async getVideoId(e) {
		return /video-([^/]+)\/([^/]+)/.exec(e.pathname)?.[0];
	}
}, Cn = class extends P {
	async getVideoId(e) {
		return e.pathname.slice(1);
	}
}, wn = class extends P {
	getPlayerData() {
		return document.querySelector("#movie_player")?.getVideoData?.() ?? void 0;
	}
	async getVideoId(e) {
		return this.getPlayerData()?.video_id;
	}
}, Tn = class extends P {
	getVideoDataBySource(e) {
		let t = document.querySelector(".icms.video > source[type=\"video/mp4\"][data-quality=\"360\"]")?.src;
		return t ? { url: D(t) } : this.returnBaseData(e);
	}
	getVideoDataByNext(e) {
		try {
			let e = document.getElementById("__NEXT_DATA__")?.textContent;
			if (!e) throw new Gt("Not found __NEXT_DATA__ content");
			let { props: { pageProps: { page: { description: t, title: n, video: { videoMetadata: { duration: r }, assets: i } } } } } = JSON.parse(e), a = i.find((e) => e.height === 360 && e.url.includes(".mp4"))?.url;
			if (!a) throw new Gt("Not found video URL in assets");
			return {
				url: D(a),
				duration: r,
				title: n,
				description: t
			};
		} catch (t) {
			return T.warn(`Failed to get ign video data by video ID: ${e}, because ${t.message}. Using clear link instead...`), this.returnBaseData(e);
		}
	}
	async getVideoData(e) {
		return document.getElementById("__NEXT_DATA__") ? this.getVideoDataByNext(e) : this.getVideoDataBySource(e);
	}
	async getVideoId(e) {
		return /([^/]+)\/([\d]+)\/video\/([^/]+)/.exec(e.pathname)?.[0] ?? /\/videos\/([^/]+)/.exec(e.pathname)?.[0];
	}
}, En = class extends P {
	async getVideoId(e) {
		return /video\/([^/]+)/.exec(e.pathname)?.[1];
	}
}, Dn = class extends P {
	async getVideoData(e) {
		try {
			let e = document.querySelector("#incflix-stream source:first-of-type");
			if (!e) throw new N("Failed to find source element");
			let t = e.getAttribute("src");
			if (!t) throw new N("Failed to find source link");
			let n = new URL(t.startsWith("//") ? `https:${t}` : t);
			return n.searchParams.append("media-proxy", "video.mp4"), { url: D(n) };
		} catch (t) {
			T.error(`Failed to get Incestflix data by videoId: ${e}`, t.message);
			return;
		}
	}
	async getVideoId(e) {
		return /\/watch\/([^/]+)/.exec(e.pathname)?.[1];
	}
}, On = class extends P {
	async getVideoId(e) {
		let t = /^\/(?:[a-z]{2}\/)?v\/(?<id>\d+)\/(?<slug>[^/?#]+)\/?$/i.exec(e.pathname)?.groups;
		if (!t) return;
		let { id: n, slug: r } = t;
		return `v/${n}/${r}`;
	}
}, kn = class extends P {
	API_ORIGIN = "https://kick.com/api";
	async getClipInfo(e) {
		try {
			let { clip_url: t, duration: n, title: r } = (await (await this.fetch(`${this.API_ORIGIN}/v2/clips/${e}`)).json()).clip;
			return {
				url: t,
				duration: n,
				title: r
			};
		} catch (t) {
			T.error(`Failed to get kick clip info by clipId: ${e}.`, t.message);
			return;
		}
	}
	async getVideoInfo(e) {
		try {
			let { source: t, livestream: n } = await (await this.fetch(`${this.API_ORIGIN}/v1/video/${e}`)).json(), { session_title: r, duration: i } = n;
			return {
				url: t,
				duration: Math.round(i / 1e3),
				title: r
			};
		} catch (t) {
			T.error(`Failed to get kick video info by videoId: ${e}.`, t.message);
			return;
		}
	}
	async getVideoData(e) {
		return e.startsWith("videos") ? await this.getVideoInfo(e.replace("videos/", "")) : await this.getClipInfo(e.replace("clips/", ""));
	}
	async getVideoId(e) {
		return /([^/]+)\/((videos|clips)\/([^/]+))/.exec(e.pathname)?.[2];
	}
}, An = class extends P {
	async getVideoData(e) {
		try {
			let e = document.querySelector(".ksr-video-player > video"), t = e?.querySelector("source[type^='video/mp4']")?.src;
			if (!t) throw new N("Failed to find video URL");
			let n = e?.querySelectorAll("track") ?? [];
			return {
				url: t,
				subtitles: Array.from(n).reduce((e, t) => {
					let n = t.getAttribute("srclang"), r = t.getAttribute("src");
					return !n || !r || e.push({
						language: E(n),
						url: r,
						format: "vtt",
						source: "kickstarter"
					}), e;
				}, [])
			};
		} catch (t) {
			T.error(`Failed to get Kickstarter data by videoId: ${e}`, t.message);
			return;
		}
	}
	async getVideoId(e) {
		return e.pathname.slice(1);
	}
}, jn = class extends P {
	API_ORIGIN = window.location.origin;
	getSecureData(e) {
		try {
			let [t, n, r] = e.split("/").filter((e) => e), i = Array.from(document.getElementsByTagName("script")), a = i.filter((e) => e.innerHTML.includes(`videoId = "${n}"`) || e.innerHTML.includes(`serialId = Number(${n})`));
			if (!a.length) throw new N("Failed to find secure script");
			let o = a[0]?.textContent?.trim();
			if (!o) throw new N("Secure script content is empty");
			let s = /'{[^']+}'/.exec(o)?.[0];
			if (!s) throw new N("Secure json wasn't found in secure script");
			let c = JSON.parse(s.replaceAll("'", ""));
			if (t !== "serial") return {
				videoType: t,
				videoId: n,
				hash: r,
				...c
			};
			let l = i.find((e) => e.innerHTML.includes("var videoInfo = {}"))?.textContent?.trim();
			if (!l) throw new N("Failed to find videoInfo content");
			let u = /videoInfo\.type\s+?=\s+?'([^']+)'/.exec(l)?.[1], d = /videoInfo\.id\s+?=\s+?'([^']+)'/.exec(l)?.[1], f = /videoInfo\.hash\s+?=\s+?'([^']+)'/.exec(l)?.[1];
			if (!u || !d || !f) throw new N("Failed to parse videoInfo content");
			return {
				videoType: u,
				videoId: d,
				hash: f,
				...c
			};
		} catch (t) {
			return T.error(`Failed to get kodik secure data by videoPath: ${e}.`, t.message), !1;
		}
	}
	async getFtor(e) {
		let { videoType: t, videoId: n, hash: r, d: i, d_sign: a, pd: o, pd_sign: s, ref: c, ref_sign: u } = e;
		try {
			return await (await this.fetch(`${this.API_ORIGIN}/ftor`, {
				method: "POST",
				headers: {
					"User-Agent": l.userAgent,
					Origin: this.API_ORIGIN,
					Referer: `${this.API_ORIGIN}/${t}/${n}/${r}/360p`
				},
				body: new URLSearchParams({
					d: i,
					d_sign: a,
					pd: o,
					pd_sign: s,
					ref: decodeURIComponent(c),
					ref_sign: u,
					bad_user: "false",
					cdn_is_working: "true",
					info: "{}",
					type: t,
					hash: r,
					id: n
				})
			})).json();
		} catch (e) {
			return T.error(`Failed to get kodik video data (type: ${t}, id: ${n}, hash: ${r})`, e.message), !1;
		}
	}
	decryptUrl(e) {
		return `https:${atob(e.replace(/[a-zA-Z]/g, (e) => {
			let t = e.charCodeAt(0) + 18, n = e <= "Z" ? 90 : 122;
			return String.fromCharCode(n >= t ? t : t - 26);
		}))}`;
	}
	async getVideoData(e) {
		let t = this.getSecureData(e);
		if (!t) return;
		let n = await this.getFtor(t);
		if (!n) return;
		let r = Object.entries(n.links[n.default.toString()]).find(([, e]) => e.type === "application/x-mpegURL")?.[1];
		if (r) return { url: r.src.startsWith("//") ? `https:${r.src}` : this.decryptUrl(r.src) };
	}
	async getVideoId(e) {
		return /\/(uv|video|seria|episode|season|serial)\/([^/]+)\/([^/]+)\/([\d]+)p/.exec(e.pathname)?.[0];
	}
}, Mn = class extends pn {
	SUBTITLE_SOURCE = "linkedin";
	async getVideoData(e) {
		let t = this.getVideoDataByPlayer(e);
		if (!t) return;
		let { url: n, duration: r, subtitles: i } = t;
		return {
			url: D(new URL(n)),
			duration: r,
			subtitles: i
		};
	}
	async getVideoId(e) {
		return /\/learning\/(([^/]+)\/([^/]+))/.exec(e.pathname)?.[1];
	}
}, Nn;
(function(e) {
	e.Channel = "Channel", e.Video = "Video";
})(Nn ||= {});
//#endregion
//#region node_modules/@vot.js/ext/dist/helpers/loom.js
var Pn = class extends P {
	getClientVersion() {
		if (!(typeof SENTRY_RELEASE > "u")) return SENTRY_RELEASE.id;
	}
	async getVideoData(e) {
		try {
			let t = this.getClientVersion();
			if (!t) throw new N("Failed to get client version");
			let n = await this.fetch("https://www.loom.com/graphql", {
				headers: {
					"User-Agent": l.userAgent,
					"content-type": "application/json",
					"x-loom-request-source": `loom_web_${t}`,
					"apollographql-client-name": "web",
					"apollographql-client-version": t,
					"Alt-Used": "www.loom.com"
				},
				body: `{"operationName":"FetchCaptions","variables":{"videoId":"${e}"},"query":"query FetchCaptions($videoId: ID!, $password: String) {\\n  fetchVideoTranscript(videoId: $videoId, password: $password) {\\n    ... on VideoTranscriptDetails {\\n      id\\n      captions_source_url\\n      language\\n      __typename\\n    }\\n    ... on GenericError {\\n      message\\n      __typename\\n    }\\n    __typename\\n  }\\n}"}`,
				method: "POST"
			});
			if (n.status !== 200) throw new N("Failed to get data from graphql");
			let r = (await n.json()).data.fetchVideoTranscript;
			if (r.__typename === "GenericError") throw new N(r.message);
			return {
				url: this.service?.url + e,
				subtitles: [{
					format: "vtt",
					language: E(r.language),
					source: "loom",
					url: r.captions_source_url
				}]
			};
		} catch (t) {
			return T.error(`Failed to get Loom video data, because: ${t.message}`), this.returnBaseData(e);
		}
	}
	async getVideoId(e) {
		return /(embed|share)\/([^/]+)?/.exec(e.pathname)?.[2];
	}
}, Fn = class extends P {
	API_ORIGIN = "https://my.mail.ru";
	async getVideoMeta(e) {
		try {
			return await (await this.fetch(`${this.API_ORIGIN}/+/video/meta/${e}?xemail=&ajax_call=1&func_name=&mna=&mnb=&ext=1&_=${Date.now()}`)).json();
		} catch (e) {
			T.error("Failed to get mail.ru video data", e.message);
			return;
		}
	}
	async getVideoId(e) {
		let t = e.pathname;
		if (/\/(v|mail|bk|inbox)\//.exec(t)) return t.slice(1);
		let n = /video\/embed\/([^/]+)/.exec(t)?.[1];
		if (!n) return;
		let r = await this.getVideoMeta(n);
		if (r) return r.meta.url.replace("//my.mail.ru/", "");
	}
}, In = class extends P {
	DEFAULT_SITE_ORIGIN = "https://mediafile.cc";
	SITE_ORIGIN = this.service?.url?.slice(0, -1) ?? this.DEFAULT_SITE_ORIGIN;
	getVideoSrc() {
		let e = this.video instanceof HTMLVideoElement ? this.video : document.querySelector("video");
		return e?.src || e?.currentSrc || e?.querySelector("source[src]")?.src || void 0;
	}
	async getVideoData(e) {
		let t = this.getVideoSrc();
		if (t) return {
			url: `${this.SITE_ORIGIN}/${e}`,
			video_url: t,
			translationHelp: [{
				target: "video_file_url",
				targetUrl: t
			}]
		};
	}
	async getVideoId(e) {
		return e.pathname.replace(/^\/+/, "") || void 0;
	}
}, Ln = class extends pn {
	SUBTITLE_SOURCE = "netacad";
	async getVideoData(e) {
		let t = this.getVideoDataByPlayer(e);
		if (!t) return;
		let { url: n, duration: r, subtitles: i } = t;
		return {
			url: D(new URL(n)),
			duration: r,
			subtitles: i
		};
	}
	async getVideoId(e) {
		return e.pathname + e.search;
	}
}, Rn = class extends P {
	async getVideoId(e) {
		return /([^/]+)\/(view)\/([^/]+)/.exec(e.pathname)?.[0];
	}
}, zn = class extends P {
	async getVideoId(e) {
		return e.hostname === "nico.ms" ? e.pathname.replace(/^\//, "").split("/")[0] || void 0 : /\/watch\/([^/?#]+)/.exec(e.pathname)?.[1];
	}
}, Bn = class extends P {
	async getVideoData(e) {
		let t = this.returnBaseData(e);
		if (!t) return t;
		try {
			if (!this.video) throw Error("Video element not found");
			let e = this.video.querySelector("source[type^=\"video/mp4\"], source[type^=\"video/webm\"]")?.src;
			if (!e || !/^https?:\/\//.test(e)) throw Error("Video source not found");
			return {
				...t,
				translationHelp: [{
					target: "video_file_url",
					targetUrl: e
				}]
			};
		} catch {
			return t;
		}
	}
	async getVideoId(e) {
		return /gag\/([^/]+)/.exec(e.pathname)?.[1];
	}
}, Vn = class extends P {
	API_ORIGIN = "https://odysee.com";
	async getVideoData(e) {
		try {
			let t = await (await this.fetch(`${this.API_ORIGIN}/${e}`)).text(), n = /"contentUrl":(\s)?"([^"]+)"/.exec(t)?.[2];
			if (!n) throw new N("Odysee url doesn't parsed");
			return { url: n };
		} catch (t) {
			T.error(`Failed to get odysee video data by video ID: ${e}`, t.message);
			return;
		}
	}
	async getVideoId(e) {
		return e.pathname.slice(1);
	}
}, Hn = class extends P {
	async getVideoId(e) {
		return /\/video\/(\d+)/.exec(e.pathname)?.[1];
	}
}, Un = class extends P {
	async getVideoId(e) {
		return /\/([a-z]{2}\/(?:[a-z0-9-]+\/)?(?:replay|videos?|original-series\/episode)\/[\w-]+)\/?$/i.exec(e.pathname)?.[1];
	}
}, Wn = class extends pn {
	SUBTITLE_SOURCE = "oraclelearn";
	async getVideoData(e) {
		let t = this.getVideoDataByPlayer(e);
		if (!t) return;
		let { url: n, duration: r, subtitles: i } = t, a = this.returnBaseData(e), o = D(new URL(n));
		return a ? {
			url: a.url,
			duration: r,
			subtitles: i,
			translationHelp: [{
				target: "video_file_url",
				targetUrl: o
			}]
		} : {
			url: o,
			duration: r,
			subtitles: i
		};
	}
	async getVideoId(e) {
		return /\/ou\/course\/(([^/]+)\/(\d+)\/(\d+))/.exec(e.pathname)?.[1];
	}
}, Gn = class extends P {
	API_ORIGIN = "https://www.patreon.com/api";
	async getPosts(e) {
		try {
			return await (await this.fetch(`${this.API_ORIGIN}/posts/${e}?json-api-use-default-includes=false`)).json();
		} catch (t) {
			return T.error(`Failed to get patreon posts by postId: ${e}.`, t.message), !1;
		}
	}
	async getVideoData(e) {
		let t = await this.getPosts(e);
		if (!t) return;
		let n = t.data.attributes.post_file.url;
		if (n) return { url: n };
	}
	async getVideoId(e) {
		let t = /posts\/([^/]+)/.exec(e.pathname)?.[1];
		if (t) return t.replace(/[^\d.]/g, "");
	}
}, Kn = class extends P {
	async getVideoId(e) {
		let t = e.pathname.replace(/\/+$/, ""), n = /\/videos\/watch\/([^/]+)/.exec(t)?.[1];
		if (n) return `/videos/watch/${n}`;
		let r = /\/w\/([^/]+)/.exec(t)?.[1];
		if (r) return `/videos/watch/${r}`;
	}
}, qn = class extends P {
	async getVideoId(e) {
		return /\/((?:videopopout|[^/]+(?:\/profile)?\/videos)\/[^/?#&/]+)\/?$/.exec(e.pathname)?.[1] ?? /^\/([^/#?]+)\/?$/.exec(e.pathname)?.[1];
	}
}, Jn = class extends P {
	async getVideoId(e) {
		return e.searchParams.get("viewkey") ?? /embed\/([^/]+)/.exec(e.pathname)?.[1];
	}
}, Yn = class extends P {
	async getVideoData(e) {
		try {
			if (typeof flashvars > "u") return;
			let { rnd: e, video_url: t, video_title: n } = flashvars;
			if (!t || !e) throw new N("Failed to find video source or rnd");
			let r = new URL(t);
			r.searchParams.append("rnd", e), T.log("PornTN get_file link", r.href);
			let i = await this.fetch(r.href, { method: "head" }), a = new URL(i.url);
			return T.log("PornTN cdn link", a.href), {
				url: D(a),
				title: n
			};
		} catch (t) {
			T.error(`Failed to get PornTN data by videoId: ${e}`, t.message);
			return;
		}
	}
	async getVideoId(e) {
		return /\/videos\/(([^/]+)\/([^/]+))/.exec(e.pathname)?.[1];
	}
}, Xn = class extends P {
	async getVideoData(e) {
		try {
			if (!e) throw new N("Failed to find PreserveTube video ID");
			return { url: `https://s3.archive.party/preservetube/${e}.mp4` };
		} catch (t) {
			T.error(`Failed to get PreserveTube data by videoId: ${e}`, t.message);
			return;
		}
	}
	async getVideoId(e) {
		return e.searchParams.get("v") ?? void 0;
	}
}, Zn = class extends P {
	API_ORIGIN = "https://www.reddit.com";
	async getContentUrl(e) {
		if (this.service?.additionalData !== "old") {
			let e = document.querySelector("shreddit-player-2, shreddit-player");
			return (e?.getAttribute("src") ?? e?.querySelector("source[type=\"application/vnd.apple.mpegURL\"]")?.getAttribute("src"))?.replaceAll("&amp;", "&");
		}
		return document.querySelector("[data-hls-url]")?.dataset.hlsUrl?.replaceAll("&amp;", "&");
	}
	async getVideoData(e) {
		try {
			let t = await this.getContentUrl(e);
			if (!t) throw new N("Failed to find content url");
			return { url: decodeURIComponent(t) };
		} catch (t) {
			T.error(`Failed to get reddit video data by video ID: ${e}`, t.message);
			return;
		}
	}
	async getVideoId(e) {
		return /\/r\/(([^/]+)\/([^/]+)\/([^/]+)\/([^/]+))/.exec(e.pathname)?.[1];
	}
}, Qn = class extends P {
	async getVideoData(e) {
		let t = document.querySelector(".jw-video, .media__video_noscript");
		if (!t) return;
		let n = t.getAttribute("src");
		if (n) return n.endsWith(".MP4") && (n = D(n)), {
			videoId: e,
			url: n
		};
	}
	async getVideoId(e) {
		return e.pathname.slice(1);
	}
}, $n = class extends P {
	async getVideoId(e) {
		let t = /\/videos?\/(\d+)(?:\/(.+))?\/?$/.exec(e.pathname);
		if (!t) return;
		let [, n, r] = t;
		return r ? `${n}/${r.replace(/\/+$/, "")}/` : n;
	}
}, er = class extends P {
	async getVideoId(e) {
		return e.pathname.slice(1);
	}
}, tr = class extends P {
	async getVideoId(e) {
		return /(?:video|embed)\/([^/]+)/.exec(e.pathname)?.[1];
	}
}, nr = class extends P {
	API_ORIGIN = "https://learning.sap.com/";
	async requestKaltura(e, t, n) {
		try {
			return await (await this.fetch(`https://${e}/api_v3/service/multirequest`, {
				method: "POST",
				body: JSON.stringify({
					1: {
						service: "session",
						action: "startWidgetSession",
						widgetId: `_${t}`
					},
					2: {
						service: "baseEntry",
						action: "list",
						ks: "{1:result:ks}",
						filter: { redirectFromEntryId: n },
						responseProfile: {
							type: 1,
							fields: "id,referenceId,name,description,dataUrl,duration,flavorParamsIds,type,dvrStatus,externalSourceType,createdAt,updatedAt,endDate,plays,views,downloadUrl,creatorId"
						}
					},
					3: {
						service: "baseEntry",
						action: "getPlaybackContext",
						entryId: "{2:result:objects:0:id}",
						ks: "{1:result:ks}",
						contextDataParams: {
							objectType: "KalturaContextDataParams",
							flavorTags: "all"
						}
					},
					apiVersion: "3.3.0",
					format: 1,
					ks: "",
					clientTag: "html5:v3.17.22",
					partnerId: t
				}),
				headers: { "Content-Type": "application/json" }
			})).json();
		} catch (e) {
			T.error("Failed to request kaltura data", e.message);
			return;
		}
	}
	async getKalturaData(e) {
		try {
			let t = document.querySelector("script[data-nscript=\"beforeInteractive\"]");
			if (!t) throw new N("Failed to find script element");
			let n = /https:\/\/([^"]+)\/p\/([^"]+)\/embedPlaykitJs\/uiconf_id\/([^"]+)/.exec(t?.src);
			if (!n) throw new N(`Failed to get sap data for videoId: ${e}`);
			let [, r, i] = n, a = document.querySelector("#shadow")?.firstChild?.getAttribute("id");
			if (!a) {
				let e = document.querySelector("#__NEXT_DATA__");
				if (!e) throw new N("Failed to find next data element");
				a = /"sourceId":\s?"([^"]+)"/.exec(e.innerText)?.[1];
			}
			if (!r || Number.isNaN(+i) || !a) throw new N(`One of the necessary parameters for getting a link to a sap video in wasn't found for ${e}. Params: kalturaDomain = ${r}, partnerId = ${i}, entryId = ${a}`);
			return await this.requestKaltura(r, i, a);
		} catch (e) {
			T.error("Failed to get kaltura data", e.message);
			return;
		}
	}
	async getVideoData(e) {
		let t = await this.getKalturaData(e);
		if (!t) return;
		let [, n, r] = t, { duration: i } = n.objects[0], a = r.sources.find((e) => e.format === "url" && e.protocols === "http,https" && e.url.includes(".mp4"))?.url;
		if (a) return {
			url: a,
			subtitles: r.playbackCaptions.map((e) => ({
				language: E(e.languageCode),
				source: "sap",
				format: "vtt",
				url: e.webVttUrl,
				isAutoGenerated: e.label.includes("auto-generated")
			})),
			duration: i
		};
	}
	async getVideoId(e) {
		return /((courses|learning-journeys)\/([^/]+)(\/[^/]+)?)/.exec(e.pathname)?.[1];
	}
}, rr = class extends P {
	async getVideoId(e) {
		return /\/([\da-z]+\/(?:video|play|embed)(?:\/[^/]+)?)\/?$/i.exec(e.pathname)?.[1] ?? /\/([\da-z]+-[\da-z]+\/playlist\/[^/]+)\/?$/i.exec(e.pathname)?.[1];
	}
}, ir = class e extends P {
	static getMediaViewer() {
		if (!(typeof appMediaViewer > "u")) return appMediaViewer;
	}
	async getVideoId(t) {
		let n = e.getMediaViewer();
		if (!n || n.live) return;
		let r = n.target.message;
		if (r.peer_id._ !== "peerChannel") return;
		let i = r.media;
		if (i._ !== "messageMediaDocument" || i.document.type !== "video") return;
		let a = r.mid & 4294967295;
		return `${await n.managers.appPeersManager.getPeerUsername(r.peerId)}/${a}`;
	}
}, ar = class extends P {
	async getVideoId(e) {
		return /(videos|embed)\/[^/]+/.exec(e.pathname)?.[0];
	}
}, or = class extends P {
	async getVideoId(e) {
		return /([^/]+)\/video\/([^/]+)/.exec(e.pathname)?.[0];
	}
}, sr = class extends P {
	async getVideoId(e) {
		let t = e.searchParams.get("vid"), n = /([^/]+)\/([\d]+)/.exec(e.pathname)?.[0];
		if (!(!t || !n)) return `${n}?vid=${t}`;
	}
}, cr = class extends P {
	API_ORIGIN = "https://clips.twitch.tv";
	async getClipLink(e, t) {
		let n = document.querySelector("script[type='application/ld+json']"), r = e.slice(1);
		if (n) {
			let e = JSON.parse(n.innerText)["@graph"].find((e) => e["@type"] === "VideoObject")?.creator.url;
			if (!e) throw new N("Failed to find channel link");
			return `${e.replace("https://www.twitch.tv/", "")}/clip/${r}`;
		}
		let i = r === "embed", a = document.querySelector(i ? ".tw-link[data-test-selector='stream-info-card-component__stream-avatar-link']" : ".clips-player a:not([class])");
		if (a) return `${a.href.replace("https://www.twitch.tv/", "")}/clip/${i ? t : r}`;
	}
	async getVideoData(e) {
		let t = document.querySelector("[data-a-target=\"stream-title\"], [data-test-selector=\"stream-info-card-component__subtitle\"]")?.innerText, n = !!document.querySelector("[data-a-target=\"animated-channel-viewers-count\"], .channel-status-info--live, .top-bar--pointer-enabled .tw-channel-status-text-indicator");
		return {
			url: this.service?.url + e,
			isStream: n,
			title: t
		};
	}
	async getVideoId(e) {
		let t = e.pathname;
		if (/^m\.twitch\.tv$/.test(t)) return /videos\/([^/]+)/.exec(e.href)?.[0] ?? t.slice(1);
		if (/^player\.twitch\.tv$/.test(e.hostname)) return `videos/${e.searchParams.get("video")}`;
		let n = /([^/]+)\/(?:clip)\/([^/]+)/.exec(t);
		if (n) return n[0];
		if (/^clips\.twitch\.tv$/.test(e.hostname)) return await this.getClipLink(t, e.searchParams.get("clip"));
		let r = /(?:videos)\/([^/]+)/.exec(t);
		if (r) return r[0];
		let i = document.querySelector(".home-offline-hero .tw-link");
		if (i?.href) {
			let e = new URL(i.href);
			return /(?:videos)\/([^/]+)/.exec(e.pathname)?.[0];
		}
		return document.querySelector(".persistent-player") ? t : void 0;
	}
}, lr = class extends P {
	async getVideoId(e) {
		let t = /status\/([^/]+)/.exec(e.pathname)?.[1];
		if (t) return t;
		let n = (this.video?.closest("[data-testid=\"tweet\"]"))?.querySelector("a[role=\"link\"][aria-label]")?.href;
		return n ? /status\/([^/]+)/.exec(n)?.[1] : void 0;
	}
};
//#endregion
//#region node_modules/@vot.js/ext/dist/helpers/udemy.js
function ur(e) {
	return typeof e == "object" && !!e;
}
function dr(e) {
	return typeof e == "object" && !!e;
}
function fr(e) {
	if (Array.isArray(e)) return e.filter(dr);
	if (typeof e != "object" || !e) return [];
	let t = e;
	return (Array.isArray(t.Video) ? t.Video : Array.isArray(t.video) ? t.video : []).filter(dr);
}
function pr(e) {
	if (!ur(e)) return [];
	let t = [];
	for (let [n, r] of Object.entries(e)) !ur(r) || typeof r.url != "string" || t.push({
		src: r.url,
		type: typeof r.type == "string" ? r.type : void 0,
		label: typeof r.height == "number" || typeof r.height == "string" ? r.height : n
	});
	return t;
}
function mr(e) {
	if (typeof e == "number" && Number.isFinite(e)) return e;
	let t = String(e ?? "").match(/(\d{3,4})/);
	return Number(t?.[1] ?? 0);
}
function hr(e) {
	if (typeof e.file == "string") return e.file;
	if (typeof e.src == "string") return e.src;
}
function gr(e, t) {
	return e.includes("mpegurl") || /\.m3u8(?:$|[?#])/i.test(t);
}
function _r(e, t) {
	return e.includes("dash") || /\.mpd(?:$|[?#])/i.test(t);
}
var vr = class extends P {
	API_ORIGIN = `${window.location.origin}/api-2.0`;
	getModuleData() {
		let e = (document.querySelector(".ud-app-loader[data-module-id='course-taking']") ?? document.querySelector("[data-module-id='course-taking']"))?.dataset?.moduleArgs;
		if (e) try {
			return JSON.parse(e);
		} catch {
			return;
		}
	}
	getLectureId(e) {
		let t = /(?:\/learn\/(?:v4\/t\/)?lecture\/|#\/?lecture\/)(\d+)/i, n = /\/lecture\/view\/\?/i, r = window.location.href, i = n.test(r) ? new URL(r).searchParams : void 0, a = i ? (() => {
			for (let [e, t] of i) {
				let n = e.toLowerCase();
				if (n === "lectureid" || n === "lecture_id") return t;
			}
		})() : void 0;
		return t.exec(r)?.[1] ?? a ?? (e ? t.exec(`/${e}`)?.[1] : void 0);
	}
	getCourseId(e) {
		let t = e, n = this.normalizeId(t?.courseId ?? t?.course_id ?? t?.course?.id);
		if (n) return n;
		let r = this.normalizeId(document.querySelector("[data-course-id]")?.getAttribute("data-course-id"));
		if (r) return r;
		let i = document.documentElement?.innerHTML ?? "";
		return /data-course-id=["'](\d+)/i.exec(i)?.[1] ?? /&quot;courseId&quot;\s*:\s*(\d+)/i.exec(i)?.[1] ?? /"courseId"\s*:\s*(\d+)/i.exec(i)?.[1];
	}
	normalizeId(e) {
		if (typeof e == "number" && Number.isFinite(e)) return String(e);
		if (typeof e == "string") return /^\d+$/.test(e) ? e : void 0;
	}
	parseJson(e) {
		try {
			return JSON.parse(e);
		} catch {
			let t = e.replaceAll("&quot;", "\"").replaceAll("&#34;", "\"").replaceAll("&apos;", "'").replaceAll("&#39;", "'");
			try {
				return JSON.parse(t);
			} catch {
				return;
			}
		}
	}
	getViewHtmlCandidates(e) {
		if (typeof e != "string" || !e.trim()) return [];
		let t = new DOMParser().parseFromString(e, "text/html"), n = [];
		for (let e of Array.from(t.querySelectorAll("source"))) {
			let t = e.getAttribute("src");
			t && n.push({
				src: t,
				type: e.getAttribute("type") ?? void 0,
				label: e.getAttribute("data-res") ?? void 0
			});
		}
		for (let e of Array.from(t.querySelectorAll("[videojs-setup-data]"))) {
			let t = e.getAttribute("videojs-setup-data");
			if (!t) continue;
			let r = this.parseJson(t);
			r && n.push(...fr(r.sources));
		}
		return n;
	}
	isErrorData(e) {
		return Object.hasOwn(e, "error") || Object.hasOwn(e, "detail") && !Object.hasOwn(e, "_class");
	}
	async getLectureData(e, t) {
		try {
			let n = await (await this.fetch(`${this.API_ORIGIN}/users/me/subscribed-courses/${e}/lectures/${t}/?` + new URLSearchParams({
				"fields[lecture]": "title,description,view_html,asset,download_url,is_free,last_watched_second",
				"fields[asset]": "asset_type,length,stream_url,media_sources,stream_urls,download_urls,external_url,captions,data,thumbnail_sprite,slides,slide_urls,course_is_drmed,media_license_token"
			}).toString())).json();
			if (this.isErrorData(n)) throw new N(n.detail ?? "unknown error");
			return n;
		} catch (n) {
			T.error(`Failed to get lecture data by courseId: ${e} and lectureId: ${t}`, n.message);
			return;
		}
	}
	async getCourseLang(e) {
		try {
			let t = await (await this.fetch(`${this.API_ORIGIN}/users/me/subscribed-courses/${e}?` + new URLSearchParams({ "fields[course]": "locale" }).toString())).json();
			if (!this.isErrorData(t)) return t;
			let n = await (await this.fetch(`${this.API_ORIGIN}/courses/${e}/?` + new URLSearchParams({ "fields[course]": "locale" }).toString())).json();
			if (this.isErrorData(n)) throw new N(n.detail ?? "unknown error");
			return n;
		} catch (t) {
			T.error(`Failed to get course lang by courseId: ${e}`, t.message);
			return;
		}
	}
	findVideoUrl(e, t, n, r, i, a, o) {
		let s = [], c = Array.isArray(e) ? e : [];
		for (let e of c) s.push({
			src: e.src,
			type: e.type,
			label: e.label
		});
		s.push(...fr(t)), s.push(...fr(n)), s.push(...pr(a)), typeof o == "string" && s.push(...this.getViewHtmlCandidates(o)), typeof r == "string" && s.push({ src: r }), typeof i == "string" && s.push({ src: i });
		let l = this.video?.currentSrc || this.video?.src;
		typeof l == "string" && l && s.push({ src: l });
		let u = /* @__PURE__ */ new Map();
		for (let e of s) {
			let t = hr(e);
			if (!t || /^javascript:/i.test(t)) continue;
			let n = mr(e.label ?? e.quality ?? e.height), r = String(e.type ?? "").toLowerCase(), i = u.get(t);
			(!i || n > i.quality) && u.set(t, {
				url: t,
				type: r,
				quality: n,
				isYouTubeWatch: /:\/\/(?:www\.)?youtube\.com\/watch\?/i.test(t)
			});
		}
		let d = Array.from(u.values());
		if (!d.length) return;
		let f = d.filter((e) => e.type.includes("mp4") || /\.mp4(?:$|[?#])/i.test(e.url));
		return f.length ? (f.sort((e, t) => t.quality - e.quality), f[0]?.url) : d.find((e) => gr(e.type, e.url))?.url || d.find((e) => _r(e.type, e.url))?.url || d.find((e) => !e.isYouTubeWatch)?.url || d[0]?.url;
	}
	getCaptionLocale(e) {
		let t = typeof e.locale_id == "string" ? e.locale_id : typeof e.locale?.locale == "string" ? e.locale.locale : void 0;
		return t ? E(t) : void 0;
	}
	findSubtitleUrl(e, t) {
		if (!Array.isArray(e)) return;
		let n = e.filter((e) => ur(e) && (typeof e.url == "string" || typeof e.download_url == "string")), r = n.find((e) => this.getCaptionLocale(e) === t) ?? n.find((e) => this.getCaptionLocale(e) === "en") ?? n[0];
		return r?.url ?? r?.download_url;
	}
	async getVideoData(e) {
		let t = this.getModuleData(), n = this.getCourseId(t), r = this.getLectureId(e);
		if (T.log(`[Udemy] courseId: ${n}, lectureId: ${r}`), !r || !n) return;
		let i = await this.getLectureData(n, r);
		if (!i) return;
		let { title: a, description: o, asset: s, view_html: c } = i, { length: l, media_sources: u, captions: d } = s, f = s, p = f.stream_urls, m = f.download_urls, h = this.findVideoUrl(u, p, m, f.stream_url ?? f.streamUrl, f.external_url, f.data?.outputs, c);
		if (!h) {
			T.log("Failed to find video file in asset sources", s);
			return;
		}
		let g = "en", _ = (await this.getCourseLang(n))?.locale?.locale;
		typeof _ == "string" && (g = E(_)), dn.includes(g) || (g = "en");
		let v = this.findSubtitleUrl(d, g);
		return v || T.log("Failed to find subtitle file in captions", d), {
			...v ? {
				url: this.service?.url + e,
				translationHelp: [{
					target: "subtitles_file_url",
					targetUrl: v
				}, {
					target: "video_file_url",
					targetUrl: h
				}],
				detectedLanguage: g
			} : {
				url: h,
				translationHelp: null
			},
			duration: l,
			title: a,
			description: o
		};
	}
	async getVideoId(e) {
		return e.pathname.slice(1);
	}
}, yr = class extends P {
	API_KEY = "";
	DEFAULT_SITE_ORIGIN = "https://vimeo.com";
	SITE_ORIGIN = this.service?.url?.slice(0, -1) ?? this.DEFAULT_SITE_ORIGIN;
	isErrorData(e) {
		return Object.hasOwn(e, "error");
	}
	isPrivatePlayer() {
		return this.referer && !this.referer.includes("vimeo.com") && this.origin.endsWith("player.vimeo.com");
	}
	toPublicUrl(e) {
		let [t, n] = e.split(":", 2);
		return n ? `${this.DEFAULT_SITE_ORIGIN}/${t}/${n}` : `${this.DEFAULT_SITE_ORIGIN}/${t}`;
	}
	returnPublicBaseData(e) {
		let t = this.returnBaseData(e);
		if (t) return {
			...t,
			url: this.toPublicUrl(e)
		};
	}
	normalizePublicVideoUrl(e, t) {
		try {
			let n = new URL(e);
			if (n.hostname === "player.vimeo.com") return this.toPublicUrl(t);
			if (n.hostname.endsWith("vimeo.com")) {
				let e = /^\/(\d+):([a-z0-9]+)$/i.exec(n.pathname);
				if (e) return `${this.DEFAULT_SITE_ORIGIN}/${e[1]}/${e[2]}`;
			}
		} catch {}
		return e;
	}
	async getViewerData() {
		try {
			let e = await (await this.fetch("https://vimeo.com/_next/viewer")).json(), { apiUrl: t, jwt: n } = e;
			return this.API_ORIGIN = `https://${t}`, this.API_KEY = `jwt ${n}`, e;
		} catch (e) {
			return T.error("Failed to get default viewer data.", e.message), !1;
		}
	}
	async getVideoInfo(e) {
		try {
			let t = new URLSearchParams({ fields: "name,link,description,duration" }).toString(), n = await (await this.fetch(`${this.API_ORIGIN}/videos/${e}?${t}`, { headers: { Authorization: this.API_KEY } })).json();
			if (this.isErrorData(n)) throw Error(n.developer_message ?? n.error);
			return n;
		} catch (t) {
			return T.error(`Failed to get video info by video ID: ${e}`, t.message), !1;
		}
	}
	async getPrivateVideoSource(e) {
		try {
			let { default_cdn: t, cdns: n } = e.dash, r = n[t].url, i = await this.fetch(r);
			if (i.status !== 200) throw new N(await i.text());
			let a = await i.json(), o = new URL(a.base_url, r), s = a.audio.find((e) => e.mime_type === "audio/mp4" && e.format === "dash");
			if (!s) throw new N("Failed to find video data");
			let c = s.segments?.[0]?.url;
			if (!c) throw new N("Failed to find first segment url");
			let [l, u] = c.split("?", 2), d = new URLSearchParams(u);
			return d.delete("range"), new URL(`${s.base_url}${l}?${d.toString()}`, o).href;
		} catch (e) {
			return T.error("Failed to get private video source", e.message), !1;
		}
	}
	async getPrivateVideoInfo(e) {
		try {
			if (typeof playerConfig > "u") return;
			let t = await this.getPrivateVideoSource(playerConfig.request.files);
			if (!t) throw new N("Failed to get private video source");
			let { video: { title: n, duration: r }, request: { text_tracks: i } } = playerConfig;
			return {
				url: `${this.SITE_ORIGIN}/${e}`,
				video_url: t,
				title: n,
				duration: r,
				subs: i
			};
		} catch (t) {
			return T.error(`Failed to get private video info by video ID: ${e}`, t.message), !1;
		}
	}
	async getSubsInfo(e) {
		try {
			let t = new URLSearchParams({
				per_page: "100",
				fields: "language,type,link"
			}).toString(), n = await (await this.fetch(`${this.API_ORIGIN}/videos/${e}/texttracks?${t}`, { headers: { Authorization: this.API_KEY } })).json();
			if (this.isErrorData(n)) throw Error(n.developer_message ?? n.error);
			return n.data;
		} catch (t) {
			return T.error(`Failed to get subtitles info by video ID: ${e}`, t.message), [];
		}
	}
	async getVideoData(e) {
		if (this.isPrivatePlayer()) {
			let t = await this.getPrivateVideoInfo(e);
			if (!t) return;
			let { url: n, subs: r, video_url: i, title: a, duration: o } = t, s = r.map((e) => ({
				language: E(e.lang),
				source: "vimeo",
				format: "vtt",
				url: new URL(e.url, this.SITE_ORIGIN).href,
				isAutoGenerated: e.lang.includes("autogenerated")
			})), c = s.length ? [{
				target: "video_file_url",
				targetUrl: i
			}, {
				target: "subtitles_file_url",
				targetUrl: s[0].url
			}] : null;
			return {
				...c ? {
					url: n,
					translationHelp: c
				} : { url: i },
				subtitles: s,
				title: a,
				duration: o
			};
		}
		if (!this.extraInfo || (e.includes("/") && (e = e.replace("/", ":")), !await this.getViewerData())) return this.returnPublicBaseData(e);
		let t = await this.getVideoInfo(e);
		if (!t) return this.returnPublicBaseData(e);
		let n = (await this.getSubsInfo(e)).map((e) => ({
			language: E(e.language),
			source: "vimeo",
			format: "vtt",
			url: e.link,
			isAutoGenerated: e.language.includes("autogen")
		})), { link: r, duration: i, name: a, description: o } = t;
		return {
			url: this.normalizePublicVideoUrl(r, e),
			title: a,
			description: o,
			subtitles: n,
			duration: i
		};
	}
	async getVideoId(e) {
		let t = e.pathname.replace(/\/+$/, ""), n = /video\/[^/]+$/.exec(t)?.[0];
		if (this.isPrivatePlayer()) return n;
		if (n) {
			let t = e.searchParams.get("h"), r = n.replace("video/", "");
			return t ? `${r}/${t}` : r;
		}
		return (/channels\/[^/]+\/([^/]+)/.exec(t)?.[1] ?? /groups\/[^/]+\/videos\/([^/]+)/.exec(t)?.[1] ?? /(showcase|album)\/[^/]+\/video\/([^/]+)/.exec(t)?.[2]) || /([^/]+\/)?[^/]+$/.exec(t)?.[0];
	}
}, br = class e extends P {
	static getPlayer() {
		if (!(typeof Videoview > "u")) try {
			return Videoview?.getPlayerObject?.();
		} catch {
			return;
		}
	}
	async getVideoData(t) {
		let n = new URL(window.location.href), r = e.getPlayer();
		if (!r) {
			let e = this.returnBaseData(t);
			return e && {
				...e,
				url: xt(t, n)
			};
		}
		try {
			let { description: e, duration: i, md_title: a } = r.vars, o = new DOMParser().parseFromString(e, "text/html"), s = Array.from(o.body.childNodes).filter((e) => e.nodeName !== "BR").map((e) => e.textContent).join("\n"), c;
			return Object.hasOwn(r.vars, "subs") && (c = r.vars.subs.map((e) => ({
				language: E(e.lang),
				source: "vk",
				format: "vtt",
				url: e.url,
				isAutoGenerated: !!e.is_auto
			}))), {
				url: xt(t, n),
				title: a,
				description: s,
				duration: i,
				subtitles: c
			};
		} catch (e) {
			T.error(`Failed to get VK video data, because: ${e.message}`);
			let r = this.returnBaseData(t);
			return r && {
				...r,
				url: xt(t, n)
			};
		}
	}
	async getVideoId(e) {
		let t = /^\/((?:video|clip)-?\d+_\d+)(?:\/)?$/.exec(e.pathname);
		if (t) return t[1];
		let n = /\/playlist\/[^/]+\/(video-?\d+_\d+)/.exec(e.pathname);
		if (n) return n[1];
		let r = e.searchParams.get("z");
		if (r) return r.split("/")[0];
		let i = e.searchParams.get("oid"), a = e.searchParams.get("id");
		if (i && a) {
			let e = Math.abs(Number.parseInt(i, 10));
			if (!Number.isNaN(e)) return `video-${e}_${a}`;
		}
	}
}, xr = class extends P {
	async getVideoId(e) {
		return /(video|embed)\/(\d+)(\/[^/]+\/)?/.exec(e.pathname)?.[0];
	}
}, Sr = /^\d+:(?:[\da-f]{32}|\d{16,})$/i, Cr = /^[A-Za-z0-9]+$/, wr = /^(?:www\.)?weibo\.com$/, Tr = /^\/newlogin\/?$/, Er = class extends P {
	async getVideoId(e) {
		if (e.hostname === "video.weibo.com") {
			let t = e.searchParams.get("fid");
			return !t || !Sr.test(t) ? void 0 : `tv/show/${t}`;
		}
		if (wr.test(e.host) && Tr.test(e.pathname)) {
			let t = e.searchParams.get("url");
			if (t) try {
				let n = new URL(t, e.origin);
				if (n.href !== e.href) {
					let e = await this.getVideoId(n);
					if (e) return e;
				}
			} catch {}
			let n = e.searchParams.get("layerid");
			if (n && Cr.test(n)) return `0/${n}`;
		}
		let t = e.pathname.replace(/\/+$/, "");
		if (/^\/\d+\/[A-Za-z0-9]+$/.test(t) || /^\/0\/[A-Za-z0-9]+$/.test(t) || /^\/tv\/show\/\d+:(?:[\da-f]{32}|\d{16,})$/i.test(t)) return t.slice(1);
	}
}, Dr = class extends P {
	API_ORIGIN = "https://global.apis.naver.com/weverse/wevweb";
	API_APP_ID = "be4d79eb8fc7bd008ee82c8ec4ff6fd4";
	API_HMAC_KEY = "1b9cb6378d959b45714bec49971ade22e6e24e42";
	HEADERS = {
		Accept: "application/json, text/plain, */*",
		Origin: "https://weverse.io",
		Referer: "https://weverse.io/"
	};
	getURLData() {
		return {
			appId: this.API_APP_ID,
			language: "en",
			os: "WEB",
			platform: "WEB",
			wpf: "pc"
		};
	}
	async createHash(e) {
		let t = Date.now(), n = e.substring(0, Math.min(255, e.length)) + t, r = await ht(this.API_HMAC_KEY, n);
		if (!r) throw new N("Failed to get weverse HMAC signature");
		return {
			wmsgpad: t.toString(),
			wmd: r
		};
	}
	async getHashURLParams(e) {
		let t = await this.createHash(e);
		return new URLSearchParams(t).toString();
	}
	async getPostPreview(e) {
		let t = `/post/v1.0/post-${e}/preview?` + new URLSearchParams({
			fieldSet: "postForPreview",
			...this.getURLData()
		}).toString();
		try {
			let e = await this.getHashURLParams(t);
			return await (await this.fetch(`${this.API_ORIGIN + t}&${e}`, { headers: this.HEADERS })).json();
		} catch (t) {
			return T.error(`Failed to get weverse post preview by postId: ${e}`, t.message), !1;
		}
	}
	async getVideoInKey(e) {
		let t = `/video/v1.1/vod/${e}/inKey?` + new URLSearchParams({
			gcc: "RU",
			...this.getURLData()
		}).toString();
		try {
			let e = await this.getHashURLParams(t);
			return await (await this.fetch(`${this.API_ORIGIN + t}&${e}`, {
				method: "POST",
				headers: this.HEADERS
			})).json();
		} catch (t) {
			return T.error(`Failed to get weverse InKey by videoId: ${e}`, t.message), !1;
		}
	}
	async getVideoInfo(e, t, n) {
		let r = Date.now();
		try {
			let i = new URLSearchParams({
				key: t,
				sid: n,
				nonce: r.toString(),
				devt: "html5_pc",
				prv: "N",
				aup: "N",
				stpb: "N",
				cpl: "en",
				env: "prod",
				lc: "en",
				adi: JSON.stringify([{ adSystem: null }]),
				adu: "/"
			}).toString();
			return await (await this.fetch(`https://global.apis.naver.com/rmcnmv/rmcnmv/vod/play/v2.0/${e}?` + i, { headers: this.HEADERS })).json();
		} catch (r) {
			return T.error(`Failed to get weverse video info (infraVideoId: ${e}, inkey: ${t}, serviceId: ${n}`, r.message), !1;
		}
	}
	extractVideoInfo(e) {
		return e.find((e) => e.useP2P === !1 && e.source.includes(".mp4"));
	}
	async getVideoData(e) {
		let t = await this.getPostPreview(e);
		if (!t) return;
		let { videoId: n, serviceId: r, infraVideoId: i } = t.extension.video;
		if (!(n && r && i)) return;
		let a = await this.getVideoInKey(n);
		if (!a) return;
		let o = await this.getVideoInfo(i, a.inKey, r);
		if (!o) return;
		let s = this.extractVideoInfo(o.videos.list);
		if (s) return {
			url: s.source,
			duration: s.duration
		};
	}
	async getVideoId(e) {
		return /([^/]+)\/(live|media)\/([^/]+)/.exec(e.pathname)?.[3];
	}
}, Or = class extends P {
	async getVideoId(e) {
		return /\/(videos\/[^/]+-[\dA-Za-z]+)\/?$/.exec(e.pathname)?.[1];
	}
}, kr = class extends P {
	async getVideoId(e) {
		return /[^/]+\/[^/]+$/.exec(e.pathname)?.[0];
	}
}, Ar = class extends P {
	API_ORIGIN = window.location.origin;
	CLIENT_PREFIX = "/client/disk";
	INLINE_PREFIX = "/i/";
	DISK_PREFIX = "/d/";
	isErrorData(e) {
		return Object.hasOwn(e, "error");
	}
	async getClientVideoData(e) {
		let t = new URL(window.location.href).searchParams.get("idDialog");
		if (!t) return;
		let n = document.querySelector("#preloaded-data");
		if (n) try {
			let { idClient: e, sk: r } = JSON.parse(n.innerText).config, i = await (await this.fetch(`${this.API_ORIGIN}/models-v2?m=mpfs/info`, {
				method: "POST",
				body: JSON.stringify({
					apiMethod: "mpfs/info",
					connection_id: e,
					requestParams: { path: t },
					sk: r
				}),
				headers: { "Content-Type": "application/json" }
			})).json();
			if (this.isErrorData(i)) throw new N(i.error?.message ?? i.error?.code);
			if (i?.type !== "file") throw new N("Failed to get resource info");
			let { meta: { short_url: a, video_info: o }, name: s } = i;
			if (!o) throw new N("There's no video open right now");
			if (!a) throw new N("Access to the video is limited");
			return {
				url: a,
				title: this.clearTitle(s),
				duration: Math.round(o.duration / 1e3)
			};
		} catch (t) {
			T.error(`Failed to get yandex disk video data by video ID: ${e}, because ${t.message}`);
			return;
		}
	}
	clearTitle(e) {
		return e.replace(/(\.[^.]+)$/, "");
	}
	getBodyHash(e, t) {
		let n = JSON.stringify({
			hash: e,
			sk: t
		});
		return encodeURIComponent(n);
	}
	async fetchList(e, t) {
		let n = this.getBodyHash(e, t), r = await (await this.fetch(`${this.API_ORIGIN}/public/api/fetch-list`, {
			method: "POST",
			body: n
		})).json();
		if (Object.hasOwn(r, "error")) throw new N("Failed to fetch folder list");
		return r.resources;
	}
	async getDownloadUrl(e, t) {
		let n = this.getBodyHash(e, t), r = await (await this.fetch(`${this.API_ORIGIN}/public/api/download-url`, {
			method: "POST",
			body: n
		})).json();
		if (r.error) throw new N("Failed to get download url");
		return r.data.url;
	}
	async getDiskVideoData(e) {
		try {
			let t = document.getElementById("store-prefetch");
			if (!t) throw new N("Failed to get prefetch data");
			let n = e.split("/").slice(3);
			if (!n.length) throw new N("Failed to find video file path");
			let { resources: r, rootResourceId: i, environment: { sk: a } } = JSON.parse(t.innerText), o = r[i], s = n.length - 1, c = n.filter((e, t) => t !== s).join("/"), l = Object.values(r);
			c.includes("/") && (l = await this.fetchList(`${o.hash}:/${c}`, a));
			let u = l.find((e) => e.name === n[s]);
			if (!u) throw new N("Failed to find resource");
			if (u && u.type === "dir") throw new N("Path is dir, but expected file");
			let { meta: { short_url: d, mediatype: f, videoDuration: p }, path: m, name: h } = u;
			if (f !== "video") throw new N("Resource isn't a video");
			let g = this.clearTitle(h), _ = Math.round(p / 1e3);
			if (d) return {
				url: d,
				duration: _,
				title: g
			};
			let v = await this.getDownloadUrl(m, a);
			return {
				url: D(new URL(v)),
				duration: _,
				title: g
			};
		} catch (t) {
			T.error(`Failed to get yandex disk video data by disk video ID: ${e}`, t.message);
			return;
		}
	}
	async getVideoData(e) {
		return e.startsWith(this.INLINE_PREFIX) || /^\/d\/([^/]+)$/.exec(e) ? { url: this.service?.url + e.slice(1) } : (e = decodeURIComponent(e), e.startsWith(this.CLIENT_PREFIX) ? await this.getClientVideoData(e) : await this.getDiskVideoData(e));
	}
	async getVideoId(e) {
		return e.pathname.startsWith(this.CLIENT_PREFIX) ? e.pathname + e.search : /\/i\/([^/]+)/.exec(e.pathname)?.[0] || (/\/d\/([^/]+)/.exec(e.pathname) ? e.pathname : void 0);
	}
}, jr = class extends P {
	async getVideoId(e) {
		return /v_show\/id_[\w=]+/.exec(e.pathname)?.[0];
	}
}, F = class e extends P {
	static isMobile() {
		return /^m\.youtube\.com$/.test(window.location.hostname);
	}
	static extractVideoId(t) {
		let n = t.hash.replace(/^#/, "");
		if (n) {
			let r = n.startsWith("!") ? n.slice(1) : n, i = r;
			try {
				i = decodeURIComponent(r);
			} catch {}
			try {
				let n = i.startsWith("http") ? new URL(i) : new URL(i.startsWith("/") ? i : `/${i}`, t.origin), r = e.extractVideoId(n);
				if (r) return r;
			} catch {
				let e = /(?:^|[?&#])v=([^&#]+)/.exec(i)?.[1];
				if (e) return e;
			}
		}
		return t.hostname === "youtu.be" ? t.pathname.replace(/^\/+/, "").split("/")[0] || void 0 : (/\/(?:watch|embed|shorts|live|v|e)\/([^/?#]+)/.exec(t.pathname)?.[1] ?? void 0) || (t.searchParams.get("v") ?? void 0);
	}
	static getPlayer() {
		return window.location.pathname.startsWith("/shorts/") && !e.isMobile() ? document.querySelector("#shorts-player") : document.querySelector("#movie_player");
	}
	static getPlayerResponse() {
		return e.getPlayer()?.getPlayerResponse?.call(void 0);
	}
	static getPlayerData() {
		return e.getPlayer()?.getVideoData?.call(void 0);
	}
	static getVolume() {
		let t = e.getPlayer();
		return t?.getVolume ? t.getVolume() / 100 : 1;
	}
	static setVolume(t) {
		let n = e.getPlayer();
		return n?.setVolume ? (n.setVolume(Math.round(t * 100)), !0) : !1;
	}
	static isMuted() {
		let t = e.getPlayer();
		return t?.isMuted ? t.isMuted() : !1;
	}
	static videoSeek(t, n) {
		T.log("videoSeek", n), t.currentTime = (e.getPlayer()?.getProgressState()?.seekableEnd ?? t.currentTime) - n;
	}
	static getPoToken() {
		let t = e.getPlayer();
		if (!t) return;
		let n = t.getAudioTrack?.call(void 0);
		if (!n?.captionTracks?.length) return;
		let r = n.captionTracks.find((e) => e.url.includes("&pot="));
		if (r) return /&pot=([^&]+)/.exec(r.url)?.[1];
	}
	static getGlobalConfig() {
		return typeof yt < "u" ? yt?.config_ : typeof ytcfg < "u" ? ytcfg?.data_ : void 0;
	}
	static getDeviceParams() {
		let t = e.getGlobalConfig();
		if (!t) return "c=WEB";
		let n = t.INNERTUBE_CONTEXT?.client, r = new URLSearchParams(t.DEVICE);
		return r.delete("ceng"), r.delete("cengver"), r.set("c", n?.clientName ?? t.INNERTUBE_CLIENT_NAME), r.set("cver", n?.clientVersion ?? t.INNERTUBE_CLIENT_VERSION), r.set("cplayer", "UNIPLAYER"), r.toString();
	}
	static getSubtitles(t) {
		let n = e.getPlayerResponse()?.captions?.playerCaptionsTracklistRenderer;
		if (!n) return [];
		let r = n.captionTracks ?? [], i = (n.translationLanguages ?? []).find((e) => e.languageCode === t), a = r.find((e) => e?.kind === "asr")?.languageCode ?? "en", o = r.reduce((e, n) => {
			if (!("languageCode" in n)) return e;
			let r = n.languageCode ? E(n.languageCode) : void 0, o = n.baseUrl;
			if (!r || !o) return e;
			let s = `${o.startsWith("http") ? o : `${window.location.origin}/${o}`}&fmt=json3`;
			return e.push({
				source: "youtube",
				format: "json",
				language: r,
				isAutoGenerated: n?.kind === "asr",
				url: s
			}), i && n.isTranslatable && n.languageCode === a && t !== r && e.push({
				source: "youtube",
				format: "json",
				language: t,
				isAutoGenerated: n?.kind === "asr",
				translatedFromLanguage: r,
				url: `${s}&tlang=${t}`
			}), e;
		}, []);
		return T.log("youtube subtitles:", o), o;
	}
	static getLanguage() {
		if (!e.isMobile()) {
			let t = e.getPlayer()?.getAudioTrack?.call(void 0)?.getLanguageInfo();
			if (t && t.id !== "und") return E(t.id.split(".")[0]);
		}
		let t = e.getPlayerResponse()?.captions?.playerCaptionsTracklistRenderer.captionTracks.find((e) => e.kind === "asr" && e.languageCode);
		return t ? E(t.languageCode) : void 0;
	}
	async getVideoData(t) {
		let { title: n } = e.getPlayerData() ?? {}, { shortDescription: r, isLive: i, title: a } = e.getPlayerResponse()?.videoDetails ?? {}, o = e.getSubtitles(this.language), s = e.getLanguage();
		s && !dn.includes(s) && (s = void 0);
		let c = e.getPlayer()?.getDuration?.call(void 0) ?? void 0;
		return {
			url: this.service?.url + t,
			isStream: i,
			title: a,
			localizedTitle: n,
			detectedLanguage: s,
			description: r,
			subtitles: o,
			duration: c
		};
	}
	async getVideoId(t) {
		if (t.searchParams.has("enablejsapi")) {
			let n = e.getPlayer()?.getVideoUrl();
			t = n ? new URL(n) : t;
		}
		return e.extractVideoId(t);
	}
}, Mr = /^\/play\/([^/?#]+)\/([^/?#]+)\/([^/?#]+)\/?$/i, Nr = class extends P {
	async getVideoId(e) {
		let t = Mr.exec(e.pathname);
		if (!t) return;
		let [, n, r, i] = t;
		return `${n}/${r}/${i}`;
	}
}, Pr = {
	[k.mailru]: Fn,
	[k.weverse]: Dr,
	[k.weibo]: Er,
	[k.kodik]: jn,
	[k.patreon]: Gn,
	[k.reddit]: Zn,
	[k.bannedvideo]: nn,
	[k.kick]: kn,
	[k.appledeveloper]: $t,
	[k.epicgames]: xn,
	[k.odysee]: Vn,
	[k.coursehunterLike]: un,
	[k.twitch]: cr,
	[k.sap]: nr,
	[k.jove]: On,
	[k.linkedin]: Mn,
	[k.vimeo]: yr,
	[k.yandexdisk]: Ar,
	[k.vk]: br,
	[k.trovo]: sr,
	[k.incestflix]: Dn,
	[k.porntn]: Yn,
	[k.googledrive]: wn,
	[k.bilibili]: rn,
	[k.xvideos]: kr,
	[k.xhamster]: Or,
	[k.spankbang]: rr,
	[k.rule34video]: $n,
	[k.picarto]: qn,
	[k.olympicsreplay]: Un,
	[k.watchpornto]: xr,
	[k.archive]: en,
	[k.dailymotion]: hn,
	[k.youku]: jr,
	[k.egghead]: bn,
	[k.newgrounds]: Rn,
	[k.okru]: Hn,
	[k.peertube]: Kn,
	[k.eporner]: Sn,
	[k.bitchute]: an,
	[k.rutube]: tr,
	[k.facebook]: Cn,
	[k.rumble]: er,
	[k.twitter]: lr,
	[k.pornhub]: Jn,
	[k.tiktok]: or,
	[k.proxitok]: or,
	[k.nine_gag]: Bn,
	[k.youtube]: F,
	[k.preservetube]: Xn,
	[k.invidious]: F,
	[k.piped]: F,
	[k.zdf]: Nr,
	[k.dzen]: yn,
	[k.bunnystream]: cn,
	[k.cloudflarestream]: ln,
	[k.loom]: Pn,
	[k.rtnews]: Qn,
	[k.bitview]: on,
	[k.thisvid]: ar,
	[k.ign]: Tn,
	[k.bunkr]: sn,
	[k.imdb]: En,
	[k.telegram]: ir,
	[k.niconico]: zn,
	[j.udemy]: vr,
	[j.coursera]: mn,
	[j.douyin]: vn,
	[j.artstation]: tn,
	[j.kickstarter]: An,
	[j.datacamp]: gn,
	[j.oraclelearn]: Wn,
	[j.deeplearningai]: _n,
	[j.netacad]: Ln,
	[j.mediafile]: In
}, Fr = class {
	helpersData;
	constructor(e = {}) {
		this.helpersData = e;
	}
	getHelper(e) {
		return new Pr[e](this.helpersData);
	}
};
//#endregion
//#region node_modules/@vot.js/ext/dist/utils/videoData.js
function Ir(e) {
	return e in Pr;
}
function Lr(e, t) {
	let n = e.replace(/^\/+/, ""), r = new URL("https://vk.com/video");
	r.searchParams.set("z", n);
	for (let e of ["list", "access_key"]) {
		let n = t.searchParams.get(e);
		n && r.searchParams.set(e, n);
	}
	return r.toString();
}
function Rr() {
	if (Kt.exec(window.location.href)) return [];
	let e = window.location.hostname, t = new URL(window.location.href), n = (n) => n instanceof RegExp ? n.test(e) : typeof n == "string" ? e.includes(n) : typeof n == "function" ? n(t) : !1;
	return Qt.filter((e) => !!e.match && (Array.isArray(e.match) ? e.match.some(n) : n(e.match)) && e.host && e.url);
}
async function zr(e, t = {}) {
	let n = new URL(window.location.href), r = e.host;
	return Ir(r) ? await new Fr(t).getHelper(r).getVideoId(n) : r === k.custom ? n.href : void 0;
}
async function Br(e, t = {}) {
	let n = new URL(window.location.href), r = await zr(e, t);
	if (!r) throw new Gt(`Entered unsupported link: "${e.host}"`);
	let i = n.origin;
	if ([
		k.peertube,
		k.coursehunterLike,
		k.bunnystream,
		k.cloudflarestream
	].includes(e.host) && (e.url = i), e.rawResult) return {
		url: r,
		videoId: r,
		host: e.host,
		duration: void 0
	};
	if (!e.needExtraData) return e.host === k.vk ? {
		url: Lr(r, n),
		videoId: r,
		host: e.host,
		duration: void 0
	} : {
		url: e.url + r,
		videoId: r,
		host: e.host,
		duration: void 0
	};
	if (!Ir(e.host)) throw new Gt(`No helper is available for "${e.host}"`);
	let a = await new Fr({
		...t,
		service: e,
		origin: i
	}).getHelper(e.host).getVideoData(r);
	if (!a) throw new Gt(`Failed to get video raw url for ${e.host}`);
	return {
		...a,
		url: e.host === k.vk ? Lr(r, n) : a.url,
		videoId: r,
		host: e.host
	};
}
var Vr = {
	version: "1.0.6",
	debug: !1,
	fetchFn: (...e) => {
		if (typeof globalThis.fetch != "function") throw Error("Fetch API is not available in this environment");
		return globalThis.fetch(...e);
	}
}, I = { log: (...e) => {
	if (Vr.debug) return console.log(`%c✦ chaimu.js v${Vr.version} ✦`, "background: #000; color: #fff; padding: 0 8px", ...e);
} }, Hr = [
	"playing",
	"ratechange",
	"play",
	"waiting",
	"stalled",
	"seeking",
	"pause",
	"ended",
	"seeked"
];
function Ur() {
	let e = window.AudioContext ?? window.webkitAudioContext;
	return e ? new e() : void 0;
}
var Wr = 1e4, Gr = class {
	static name = "BasePlayer";
	chaimu;
	fetch;
	isBuffering = !1;
	_src;
	fetchOpts;
	constructor(e, t) {
		this.chaimu = e, this._src = t, this.fetch = this.chaimu.fetchFn, this.fetchOpts = this.chaimu.fetchOpts;
	}
	async init() {
		return this;
	}
	async clear() {
		return this;
	}
	lipSync(e = !1) {
		return this;
	}
	handleVideoEvent = (e) => (I.log(`handle video ${e.type}`), this.lipSync(e.type), this);
	isPlaybackBlocked() {
		let e = this.chaimu.video;
		return this.isBuffering || !e || e.ended || e.seeking || e.readyState < HTMLMediaElement.HAVE_FUTURE_DATA;
	}
	handlePlaybackError(e, t) {
		if (t instanceof DOMException && t.name === "NotAllowedError") {
			I.log(`[${this.name}] ${e} blocked by autoplay policy`);
			return;
		}
		console.error(`[${this.name}] ${e} failed`, t);
	}
	async resumeAudioContext() {
		let e = this.chaimu.audioContext;
		if (!e || e.state === "running") return !0;
		if (e.state === "closed") return this.handlePlaybackError("resume AudioContext", /* @__PURE__ */ Error("AudioContext is closed")), !1;
		try {
			return await e.resume(), !0;
		} catch (e) {
			return this.handlePlaybackError("resume AudioContext", e), !1;
		}
	}
	async suspendAudioContext() {
		let e = this.chaimu.audioContext;
		if (!(!e || e.state !== "running")) try {
			await e.suspend();
		} catch (e) {
			this.handlePlaybackError("suspend AudioContext", e);
		}
	}
	removeVideoEvents() {
		for (let e of Hr) this.chaimu.video?.removeEventListener(e, this.handleVideoEvent);
		return this;
	}
	addVideoEvents() {
		for (let e of Hr) this.chaimu.video?.addEventListener(e, this.handleVideoEvent);
		return this;
	}
	async play() {
		return this;
	}
	async pause() {
		return this;
	}
	get name() {
		return this.constructor.name;
	}
	set src(e) {
		this._src = e;
	}
	get src() {
		return this._src;
	}
	get currentSrc() {
		return this._src;
	}
	set volume(e) {}
	get volume() {
		return 0;
	}
	get playbackRate() {
		return 0;
	}
	set playbackRate(e) {}
	get currentTime() {
		return 0;
	}
}, Kr = class extends Gr {
	static name = "AudioPlayer";
	audio;
	gainNode;
	audioSource;
	suspendTimer;
	constructor(e, t) {
		super(e, t), this.updateAudio();
	}
	initAudioBooster() {
		if (!this.chaimu.audioContext) return this;
		this.disconnectAudioNodes();
		let e = this.chaimu.audioContext.createGain();
		return this.gainNode = e, e.connect(this.chaimu.audioContext.destination), this.audioSource = this.chaimu.audioContext.createMediaElementSource(this.audio), this.audioSource.connect(e), this;
	}
	disconnectAudioNodes() {
		this.audioSource &&= (this.audioSource.disconnect(), void 0), this.gainNode &&= (this.gainNode.disconnect(), void 0);
	}
	scheduleSuspend() {
		this.cancelSuspend(), this.suspendTimer = setTimeout(async () => {
			I.log("[AudioPlayer] idle suspend"), await this.suspendAudioContext();
		}, Wr);
	}
	cancelSuspend() {
		this.suspendTimer !== void 0 && (clearTimeout(this.suspendTimer), this.suspendTimer = void 0);
	}
	updateAudio() {
		return this.audio = new Audio(this.src), this.audio.crossOrigin = "anonymous", this;
	}
	async init() {
		return this.updateAudio(), this.initAudioBooster(), this;
	}
	async resumeAndPlayAudio() {
		if (!(!this.audio || this.isPlaybackBlocked()) && (this.cancelSuspend(), !(!await this.resumeAudioContext() || this.isPlaybackBlocked()))) try {
			await this.audio.play();
		} catch (e) {
			this.handlePlaybackError("play audio element", e);
		}
	}
	lipSync(e = !1) {
		if (I.log("[AudioPlayer] lipsync video", this.chaimu.video), !this.chaimu.video || (this.audio.currentTime = this.chaimu.video.currentTime, this.audio.playbackRate = this.chaimu.video.playbackRate, !e)) return this;
		switch (e) {
			case "play":
			case "playing":
			case "seeked": return this.isBuffering = !1, this.chaimu.video.paused || this.syncPlay(), this;
			case "waiting":
			case "stalled":
			case "seeking": return this.isBuffering = !0, this.audio.pause(), this;
			case "pause":
			case "ended": return this.isBuffering = !1, this.pause(), this;
			default: return this;
		}
	}
	async clear() {
		return this.cancelSuspend(), this.audio.pause(), this.audio.src = "", this.audio.removeAttribute("src"), this.disconnectAudioNodes(), await this.suspendAudioContext(), this;
	}
	syncPlay() {
		return I.log("[AudioPlayer] sync play called"), this.resumeAndPlayAudio(), this;
	}
	async play() {
		return I.log("[AudioPlayer] play called"), await this.resumeAndPlayAudio(), this;
	}
	async pause() {
		return I.log("[AudioPlayer] pause called"), this.isBuffering = !1, this.audio && this.audio.pause(), this.scheduleSuspend(), this;
	}
	set src(e) {
		if (this._src = e, !e) {
			this.clear();
			return;
		}
		this.audio.src = e;
	}
	get src() {
		return this._src;
	}
	get currentSrc() {
		return this.audio.currentSrc;
	}
	set volume(e) {
		if (this.gainNode) {
			this.gainNode.gain.value = e;
			return;
		}
		this.audio.volume = e;
	}
	get volume() {
		return this.gainNode ? this.gainNode.gain.value : this.audio.volume;
	}
	get playbackRate() {
		return this.audio.playbackRate;
	}
	set playbackRate(e) {
		this.audio.playbackRate = e;
	}
	get currentTime() {
		return this.audio.currentTime;
	}
}, qr = class extends Gr {
	static name = "ChaimuPlayer";
	audioBuffer;
	audioElement;
	mediaElementSource;
	gainNode;
	blobUrl;
	isClearing = !1;
	isInitializing = !1;
	clearingPromise;
	suspendTimer;
	async fetchAudio() {
		if (!this._src) throw Error("No audio source provided");
		if (!this.chaimu.audioContext) throw Error("No audio context available");
		I.log(`[ChaimuPlayer] Fetching audio from ${this._src}...`);
		let e;
		try {
			let t = await this.fetch(this._src, this.fetchOpts);
			if (!t.ok) throw Error(`Response status: ${t.status}`);
			I.log("[ChaimuPlayer] Decoding fetched audio...");
			let n = await t.arrayBuffer(), r = new Blob([n]);
			e = URL.createObjectURL(r), this.audioBuffer = await this.chaimu.audioContext.decodeAudioData(n), this.blobUrl && URL.revokeObjectURL(this.blobUrl), this.blobUrl = e, e = void 0;
		} catch (t) {
			throw e && URL.revokeObjectURL(e), Error(`Failed to fetch audio file, because ${t.message}`);
		}
		return this;
	}
	initAudioBooster() {
		return this.chaimu.audioContext ? (this.disconnectAudioNodes(), this.gainNode = this.chaimu.audioContext.createGain(), this) : this;
	}
	disconnectAudioNodes() {
		this.mediaElementSource &&= (this.mediaElementSource.disconnect(), void 0), this.gainNode &&= (this.gainNode.disconnect(), void 0);
	}
	scheduleSuspend() {
		this.cancelSuspend(), this.suspendTimer = setTimeout(async () => {
			I.log("[ChaimuPlayer] idle suspend"), await this.suspendAudioContext();
		}, Wr);
	}
	cancelSuspend() {
		this.suspendTimer !== void 0 && (clearTimeout(this.suspendTimer), this.suspendTimer = void 0);
	}
	async init() {
		if (this.isInitializing) throw Error("Initialization already in progress");
		this.isInitializing = !0;
		try {
			return await this.fetchAudio(), this.initAudioBooster(), this.createAudioElement(), this;
		} finally {
			this.isInitializing = !1;
		}
	}
	createAudioElement() {
		if (!this.chaimu.audioContext) throw Error("No audio context available");
		if (!this.blobUrl) throw Error("No blob URL available.");
		let e = new Audio(this.blobUrl);
		e.crossOrigin = "anonymous", "preservesPitch" in e && (e.preservesPitch = !0, "mozPreservesPitch" in e && (e.mozPreservesPitch = !0), "webkitPreservesPitch" in e && (e.webkitPreservesPitch = !0)), this.audioElement = e;
		let t = this.gainNode;
		if (!t) throw Error("Audio gain node is missing");
		this.mediaElementSource = this.chaimu.audioContext.createMediaElementSource(e), this.mediaElementSource.connect(t), t.connect(this.chaimu.audioContext.destination);
	}
	lipSync(e = !1) {
		if (I.log("[ChaimuPlayer] lipsync video", this.chaimu.video, this), !this.chaimu.video || !e) return this;
		switch (e) {
			case "play":
			case "playing":
			case "ratechange":
			case "seeked": return this.isBuffering = !1, this.chaimu.video.paused || this.start(), this;
			case "waiting":
			case "stalled":
			case "seeking": return this.isBuffering = !0, this.audioElement && this.audioElement.pause(), this;
			case "pause":
			case "ended": return this.isBuffering = !1, this.pause(), this;
			default: return this;
		}
	}
	async reopenCtx() {
		if (!this.chaimu.audioContext) throw Error("No audio context available");
		try {
			this.chaimu.audioContext.state !== "closed" && await this.chaimu.audioContext.close();
		} catch (e) {
			I.log("[ChaimuPlayer] Failed to close audio context:", e);
		}
		return this.chaimu.audioContext = Ur(), this;
	}
	async clear() {
		if (this.isClearing && this.clearingPromise) return this.clearingPromise;
		if (!this.chaimu.audioContext) throw Error("No audio context available");
		return I.log("clear audio context"), this.cancelSuspend(), this.isClearing = !0, this.clearingPromise = (async () => {
			try {
				this.audioElement &&= (this.audioElement.pause(), void 0), this.blobUrl &&= (URL.revokeObjectURL(this.blobUrl), void 0);
				let e = this.gainNode ? this.gainNode.gain.value : 1;
				return this.disconnectAudioNodes(), await this.reopenCtx(), this.chaimu.audioContext && (this.initAudioBooster(), this.volume = e, await this.suspendAudioContext()), this;
			} finally {
				this.isClearing = !1, this.clearingPromise = void 0;
			}
		})(), this.clearingPromise;
	}
	async start() {
		if (!this.chaimu.audioContext) throw Error("No audio context available");
		if (!this.audioElement) throw Error("Audio element is missing");
		if (this.isClearing && this.clearingPromise && (I.log("The other cleaner is still running, waiting..."), await this.clearingPromise), this.cancelSuspend(), this.isPlaybackBlocked() || (I.log("starting audio via HTMLAudioElement"), !await this.resumeAudioContext()) || this.isPlaybackBlocked()) return this;
		this.chaimu.video && (this.audioElement.currentTime = this.chaimu.video.currentTime, this.audioElement.playbackRate = this.chaimu.video.playbackRate);
		try {
			await this.audioElement.play();
		} catch (e) {
			this.handlePlaybackError("play audio element", e);
		}
		return this;
	}
	async pause() {
		if (!this.chaimu.audioContext) throw Error("No audio context available");
		return this.isBuffering = !1, this.audioElement && this.audioElement.pause(), this.scheduleSuspend(), this;
	}
	async play() {
		if (!this.chaimu.audioContext) throw Error("No audio context available");
		return this.cancelSuspend(), await this.resumeAudioContext(), this;
	}
	set src(e) {
		this._src = e;
	}
	get src() {
		return this._src;
	}
	get currentSrc() {
		return this._src;
	}
	set volume(e) {
		this.gainNode && (this.gainNode.gain.value = e);
	}
	get volume() {
		return this.gainNode ? this.gainNode.gain.value : 0;
	}
	set playbackRate(e) {
		this.audioElement && (this.audioElement.playbackRate = e);
	}
	get playbackRate() {
		return this.audioElement ? this.audioElement.playbackRate : this.chaimu.video?.playbackRate ?? 1;
	}
	get currentTime() {
		return this.chaimu.video?.currentTime ?? 0;
	}
}, Jr = class {
	_debug = !1;
	audioContext;
	player;
	video;
	fetchFn;
	fetchOpts;
	constructor({ url: e, video: t, debug: n = !1, fetchFn: r = Vr.fetchFn, fetchOpts: i = {}, preferAudio: a = !1 }) {
		this._debug = Vr.debug = n, this.fetchFn = r, this.fetchOpts = i, this.audioContext = Ur(), this.player = this.audioContext && !a ? new qr(this, e) : new Kr(this, e), this.video = t;
	}
	async init() {
		await this.player.init(), this.player.addVideoEvents(), this.video.paused || this.video.ended || this.video.seeking || this.video.readyState < HTMLMediaElement.HAVE_FUTURE_DATA ? await this.player.pause() : this.player.lipSync("play");
	}
	set debug(e) {
		this._debug = Vr.debug = e;
	}
	get debug() {
		return this._debug;
	}
}, Yr = "__VOT_MAIN_BOOT_STATE__";
function Xr(e) {
	return e === "idle" || e === "booting" || e === "booted" || e === "failed";
}
function Zr(e) {
	return !e || typeof e != "object" ? !1 : Xr(e.status);
}
function Qr(e = Yr) {
	let t = globalThis, n = t[e];
	if (Zr(n)) return n;
	let r = {
		status: "idle",
		promise: null,
		error: null
	};
	return t[e] = r, r;
}
//#endregion
//#region src/bootstrap/iframeInteractor.ts
var $r = !1;
function ei() {
	if ($r) return;
	$r = !0;
	let e = Object.entries({
		"https://dev.epicgames.com": {
			targetOrigin: "https://dev.epicgames.com",
			dataFilter: (e) => typeof e == "string" && e.startsWith("getVideoId:"),
			extractVideoId: (e) => e.pathname.split("/").at(-2) ?? null,
			responseFormatter: (e, t) => `${typeof t == "string" ? t : ""}:${e}`
		},
		"https://www.dailymotion.com": {
			targetOrigin: "https://geo.dailymotion.com",
			dataFilter: (e) => typeof e == "string" && e.startsWith("getVideoId:"),
			extractVideoId: (e) => /(?:^|\/)video\/([^/]+)/.exec(e.pathname)?.[1],
			responseFormatter: (e) => `getVideoId:${e}`
		}
	}).find(([e]) => globalThis.location.origin === e)?.[1];
	e && globalThis.addEventListener("message", (t) => {
		try {
			if (t.origin !== e.targetOrigin || !e.dataFilter(t.data)) return;
			let n = e.extractVideoId(new URL(globalThis.location.href));
			if (!n) return;
			let r = e.responseFormatter(n, t.data);
			t.source && "postMessage" in t.source && t.source.postMessage(r, e.targetOrigin);
		} catch (e) {
			console.error("Iframe communication error:", e);
		}
	});
}
//#endregion
//#region src/config/config.ts
var ti = "api.browser.yandex.ru", ni = "media-proxy.toil.cc/v1/proxy/m3u8", ri = "vot-new.toil-dump.workers.dev", ii = "vot-worker.kload.workers.dev", ai = "https://vot.toil.cc/v1", oi = "https://translate-backend.transly.workers.dev/v2", si = "https://rust-server-531j.onrender.com/detect", ci = "https://rust-server-531j.onrender.com", li = "https://avatars.mds.yandex.net/get-yapic", ui = "ilyhalight/voice-over-translation", di = `https://raw.githubusercontent.com/${ui}`, fi = `https://github.com/${ui}`, pi = "yandexbrowser", mi = "yandexbrowser", hi = [
	"UA",
	"LV",
	"LT"
], gi = 1e3, _i = "2025-05-09", vi = ["auto", "original"], yi = /* @__PURE__ */ "autoTranslate.autoSubtitles.dontTranslateLanguages.enabledDontTranslateLanguages.enabledAutoVolume.enabledSmartDucking.autoVolume.buttonPos.showVideoSlider.syncVolume.downloadWithName.sendNotifyOnComplete.subtitlesMaxLength.subtitlesSmartLayout.highlightWords.subtitlesFontSize.subtitlesFontFamily.subtitlesOpacity.subtitlesDownloadFormat.responseLanguage.responseLanguageSubtitles.defaultVolume.onlyBypassMediaCSP.newAudioPlayer.showPiPButton.translateAPIErrors.translationService.detectService.translationHotkey.subtitlesHotkey.m3u8ProxyHost.proxyWorkerHost.translateProxyEnabled.translateProxyEnabledDefault.audioBooster.useLivelyVoice.autoHideButtonDelay.useAudioDownload.compatVersion.localePhrases.localeLang.localeHash.localeVersion.localeUpdatedAt.localeLangOverride.account".split("."), bi = () => {}, L = {
	log: bi,
	warn: bi,
	error: bi
};
//#endregion
//#region src/utils/localization.ts
function xi() {
	return navigator.language?.substring(0, 2).toLowerCase() || "en";
}
var Si = new Set([
	"uk",
	"be",
	"bg",
	"mk",
	"sr",
	"bs",
	"hr",
	"sl",
	"pl",
	"sk",
	"cs"
]);
function Ci(e) {
	return fn.includes(e) ? e : Si.has(e) ? "ru" : "en";
}
var wi = xi(), Ti = Ci(wi), Ei = 3e4, Di = /\p{Cc}/gu, Oi = /[\\/:*?"'<>|]+/g, ki = /^https?:\/\//i, Ai = /-{2,}/g, ji = /^[.\s-]+|[.\s-]+$/g;
function Mi() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function Ni(e) {
	return e.replace(Di, "");
}
function Pi(e) {
	let t = /* @__PURE__ */ new WeakSet();
	return JSON.stringify(e, (e, n) => {
		if (n && typeof n == "object") {
			if (t.has(n)) return "[Circular]";
			if (t.add(n), Array.isArray(n)) return n;
			let e = {}, r = Object.keys(n).sort();
			for (let t of r) e[t] = n[t];
			return e;
		}
		return n;
	});
}
function Fi(e) {
	let t = 2166136261, n = 0;
	for (; n < e.length;) {
		let r = e.codePointAt(n) ?? 0;
		t ^= r, t = Math.imul(t, 16777619), n += r > 65535 ? 2 : 1;
	}
	return (t >>> 0).toString(36);
}
var Ii = () => !!document.pictureInPictureEnabled;
async function Li(e, t) {
	try {
		let n = await e.createWritable();
		return await n.write(t), await n.close(), !0;
	} catch {
		return !1;
	}
}
async function Ri(e, t) {
	let n = typeof navigator > "u" ? void 0 : navigator;
	if (!n?.share || typeof File > "u") return "unsupported";
	let r;
	try {
		r = new File([e], t, { type: e.type || "application/octet-stream" });
	} catch {
		return "unsupported";
	}
	if (typeof n.canShare == "function" && !n.canShare({ files: [r] })) return "unsupported";
	try {
		return await n.share({
			files: [r],
			title: t
		}), "shared";
	} catch (e) {
		return e instanceof DOMException && e.name === "AbortError" ? "shared" : "error";
	}
}
function zi(e, t) {
	let n = URL.createObjectURL(e), r = document.createElement("a");
	r.href = n, r.download = t, r.rel = "noopener noreferrer", r.target = "_blank", r.style.position = "fixed", r.style.left = "-9999px", r.style.top = "0", (document.body ?? document.documentElement).append(r);
	try {
		return r.click(), !0;
	} catch {
		return !1;
	} finally {
		r.remove(), Vi(n);
	}
}
async function Bi(e, t, n = {}) {
	return n.fileHandle && await Li(n.fileHandle, e) ? !0 : n.preferShare ? await Ri(e, t) === "shared" : zi(e, t);
}
function Vi(e, t = Ei) {
	let n = Number.isFinite(t) && t >= 0 ? t : Ei;
	globalThis.setTimeout(() => URL.revokeObjectURL(e), n);
}
function Hi(e) {
	let t = e.trim();
	return t && Ni(t).replace(ki, "").replace(Oi, "-").replace(Ai, "-").replace(ji, "") || Mi();
}
var Ui = () => Math.floor(Date.now() / 1e3), Wi = (e) => e ? Object.fromEntries(new Headers(e)) : {};
function R(e, t = 0, n = 100) {
	return Math.min(Math.max(e, Math.min(t, n)), Math.max(t, n));
}
function Gi(e) {
	let t = {}, n = Object.entries(e);
	for (; n.length;) {
		let e = n.pop();
		if (!e) continue;
		let [r, i] = e;
		if (i !== void 0) {
			if (!(typeof i == "object" && i && !Array.isArray(i))) {
				t[r] = i;
				continue;
			}
			for (let [e, t] of Object.entries(i)) n.push([`${r}.${e}`, t]);
		}
	}
	return t;
}
//#endregion
//#region src/core/cacheManager.ts
var Ki = 7200 * 1e3, qi = "x-vot-cache-created-at", Ji = "x-vot-cache-key", Yi = "vot-http-cache-v1", Xi = 500, Zi = "VOTSession", Qi = {
	translation: "translationExpiresAt",
	subtitles: "subtitlesExpiresAt"
};
function $i() {
	return Math.floor(Date.now() / 1e3);
}
function ea(e) {
	if (!e || typeof e != "object") return !1;
	let t = e;
	return typeof t.expires == "number" && Number.isFinite(t.expires) && typeof t.timestamp == "number" && Number.isFinite(t.timestamp) && typeof t.uuid == "string" && t.uuid.length > 0 && typeof t.secretKey == "string" && t.secretKey.length > 0;
}
function ta(e) {
	if (!e || typeof e != "object") return {};
	let t = $i(), n = Object.entries(e).flatMap(([e, n]) => !ea(n) || n.timestamp + n.expires <= t ? [] : [[e, n]]);
	return Object.fromEntries(n);
}
function na(e) {
	return Object.keys(e).length > 0;
}
var ra = class {
	constructor(e = B) {
		this.storage = e;
	}
	getStorageKey() {
		return Zi;
	}
	async restore(e, t = {}) {
		let n = this.getStorageKey(), r = await this.storage.getRaw(n), i = ta(r);
		return na(i) ? {
			...t,
			...i
		} : (r !== void 0 && await this.storage.deleteRaw(n), t);
	}
	async persist(e, t) {
		let n = this.getStorageKey(), r = ta(t);
		if (!na(r)) {
			await this.storage.deleteRaw(n);
			return;
		}
		await this.storage.setRaw(n, r);
	}
}, ia = class {
	cache = /* @__PURE__ */ new Map();
	clear() {
		this.cache.clear();
	}
	getTranslation(e) {
		return this.getValue(e, "translation");
	}
	setTranslation(e, t) {
		this.setValue(e, "translation", t);
	}
	getSubtitles(e) {
		return this.getValue(e, "subtitles");
	}
	setSubtitles(e, t) {
		this.setValue(e, "subtitles", t);
	}
	deleteSubtitles(e) {
		this.deleteValue(e, "subtitles");
	}
	getValue(e, t) {
		let n = Date.now(), r = this.cache.get(e);
		if (!r) return;
		let i = Qi[t], a = r[i];
		if (a !== void 0 && a <= n) {
			r[t] = void 0, r[i] = void 0, this.evictIfEmpty(e, r);
			return;
		}
		return r[t];
	}
	setValue(e, t, n) {
		let r = Date.now(), i = this.getOrCreateEntry(e), a = r + Ki, o = Qi[t];
		i[t] = n, i[o] = a;
	}
	deleteValue(e, t) {
		let n = this.cache.get(e);
		if (!n) return;
		let r = Qi[t];
		n[t] = void 0, n[r] = void 0, this.evictIfEmpty(e, n);
	}
	evictIfEmpty(e, t) {
		t.translation === void 0 && t.subtitles === void 0 && this.cache.delete(e);
	}
	getOrCreateEntry(e) {
		let t = this.cache.get(e);
		if (t) return t;
		let n = {};
		return this.cache.set(e, n), n;
	}
}, aa = new class {
	memoryCache = /* @__PURE__ */ new Map();
	inFlightRequests = /* @__PURE__ */ new Map();
	async execute(e, t, n) {
		if (!t || t.ttlMs <= 0) return n();
		let r = t.key ?? this.buildDefaultCacheKey(e);
		if (!r) return n();
		let i = this.normalizeMethod(e.method), a = t.ttlMs, o = t.cacheName || Yi, s = t.useMemory !== !1, c = t.useCacheApi !== !1 && i === "GET" && this.supportsCacheApi(), l = c ? Fi(r) : "", u = t.dedupe !== !1, d = t.allowStaleOnError !== !1, f = Date.now(), p = await this.readCachedResponse({
			key: r,
			nowMs: f,
			useMemory: s,
			useCacheApi: c,
			cacheName: o,
			url: e.url,
			cacheApiKey: l,
			ttlMs: a,
			allowStaleOnError: d
		});
		if (p.fresh) return p.fresh;
		if (!u) return await this.runNetworkRequestWithFallback({
			key: r,
			cacheName: o,
			url: e.url,
			cacheApiKey: l,
			ttlMs: a,
			useMemory: s,
			useCacheApi: c
		}, n, d ? p.stale : void 0);
		let m = this.inFlightRequests.get(r);
		if (m !== void 0) return (await m).clone();
		let h = this.runNetworkRequestWithFallback({
			key: r,
			cacheName: o,
			url: e.url,
			cacheApiKey: l,
			ttlMs: a,
			useMemory: s,
			useCacheApi: c
		}, n, d ? p.stale?.clone() : void 0);
		this.inFlightRequests.set(r, h);
		try {
			return (await h).clone();
		} finally {
			this.inFlightRequests.delete(r);
		}
	}
	async readCachedResponse({ key: e, nowMs: t, useMemory: n, useCacheApi: r, cacheName: i, url: a, cacheApiKey: o, ttlMs: s, allowStaleOnError: c }) {
		let l;
		if (n) {
			let n = this.readMemoryCache(e, t);
			if (n.fresh) return { fresh: n.fresh };
			l = n.stale;
		}
		if (!r) return { stale: l };
		let u = await this.readCacheApi(i, a, o, s, t, c);
		return u.fresh ? (n && this.writeMemoryCache(e, u.fresh.clone(), u.expiresAt ?? t + s), { fresh: u.fresh }) : { stale: l ?? u.stale };
	}
	async runNetworkRequestWithFallback(e, t, n) {
		try {
			return await this.runNetworkRequest(e, t);
		} catch (e) {
			if (n) return n;
			throw e;
		}
	}
	async runNetworkRequest({ key: e, cacheName: t, url: n, cacheApiKey: r, ttlMs: i, useMemory: a, useCacheApi: o }, s) {
		let c = await s();
		if (!c.ok) return c;
		let l = Date.now(), u = this.computeExpiresAt(l, i);
		if (a && this.writeMemoryCache(e, c.clone(), u), o) {
			let e = this.toStorableResponse(c.clone(), l);
			await this.writeCacheApi(t, n, r, e);
		}
		return c;
	}
	computeExpiresAt(e, t) {
		return !Number.isFinite(t) || t <= 0 ? e : t >= 2 ** 53 - 1 - e ? 2 ** 53 - 1 : e + t;
	}
	normalizeMethod(e) {
		return (e || "GET").toUpperCase();
	}
	resolveBodyKey(e) {
		if (e == null) return "";
		if (typeof e == "string") return e;
		if (e instanceof URLSearchParams) return e.toString();
	}
	buildDefaultCacheKey(e) {
		let t = this.normalizeMethod(e.method);
		if (t === "GET") return `${t}:${e.url}`;
		let n = this.resolveBodyKey(e.body);
		if (n !== void 0) return `${t}:${e.url}#${Fi(n)}`;
	}
	supportsCacheApi() {
		return typeof caches < "u" && typeof caches.open == "function";
	}
	readCreatedAtMs(e) {
		let t = e.headers.get(qi);
		if (!t) return null;
		let n = Number(t);
		return Number.isFinite(n) ? n : null;
	}
	ensureVaryByCacheKey(e) {
		let t = e.get("vary");
		if (!t) {
			e.set("vary", Ji);
			return;
		}
		let n = new Set(t.split(",").map((e) => e.trim().toLowerCase()));
		!n.has("*") && !n.has(Ji) && e.set("vary", `${t}, ${Ji}`);
	}
	toStorableResponse(e, t) {
		let n = new Headers(e.headers);
		return n.set(qi, String(t)), this.ensureVaryByCacheKey(n), new Response(e.body, {
			status: e.status,
			statusText: e.statusText,
			headers: n
		});
	}
	readMemoryCache(e, t) {
		let n = this.memoryCache.get(e);
		return n ? n.expiresAt > t ? (this.touchMemoryCache(e, n), {
			fresh: n.response.clone(),
			expiresAt: n.expiresAt
		}) : (this.memoryCache.delete(e), {
			stale: n.response.clone(),
			expiresAt: n.expiresAt
		}) : {};
	}
	touchMemoryCache(e, t) {
		this.memoryCache.delete(e), this.memoryCache.set(e, t);
	}
	trimMemoryCache() {
		for (; this.memoryCache.size > Xi;) {
			let e = this.memoryCache.keys().next().value;
			if (typeof e != "string") break;
			this.memoryCache.delete(e);
		}
	}
	writeMemoryCache(e, t, n) {
		this.memoryCache.has(e) && this.memoryCache.delete(e), this.memoryCache.set(e, {
			response: t,
			expiresAt: n
		}), this.trimMemoryCache();
	}
	async readCacheApi(e, t, n, r, i, a) {
		try {
			let o = new Request(t, {
				method: "GET",
				headers: { [Ji]: n }
			}), s = await caches.open(e), c = await s.match(o);
			if (!c) return {};
			let l = this.readCreatedAtMs(c);
			if (l === null) return await s.delete(o), {};
			let u = this.computeExpiresAt(l, r);
			if (u > i) return {
				fresh: c.clone(),
				expiresAt: u
			};
			if (!a) return await s.delete(o), {};
			let d = c.clone();
			return await s.delete(o), {
				stale: d,
				expiresAt: u
			};
		} catch {
			return {};
		}
	}
	async writeCacheApi(e, t, n, r) {
		try {
			let i = new Request(t, {
				method: "GET",
				headers: { [Ji]: n }
			});
			await (await caches.open(e)).put(i, r);
		} catch {}
	}
}();
async function oa(e, t, n) {
	return aa.execute(e, t, n);
}
//#endregion
//#region src/utils/errors.ts
function sa(e) {
	let t = /* @__PURE__ */ new WeakSet();
	try {
		return JSON.stringify(e, (e, n) => typeof n != "object" || !n ? n : t.has(n) ? "[Circular]" : (t.add(n), n)) ?? null;
	} catch {
		return null;
	}
}
function ca(e) {
	let t = [
		e?.data?.message,
		e?.error?.message,
		e?.message
	];
	for (let e of t) if (typeof e == "string" && e) return e;
	return null;
}
function la(e, t) {
	let n = ca(e);
	if (n) return n;
	let r = sa(e);
	if (r && r !== "{}") return r;
	let i = e.constructor?.name;
	return i ? `[${i}]` : t;
}
function ua(e, t) {
	return typeof e == "number" || typeof e == "boolean" || typeof e == "bigint" ? `${e}` : typeof e == "symbol" ? e.description ? `Symbol(${e.description})` : "Symbol" : typeof e == "function" ? e.name ? `[Function ${e.name}]` : "[Function]" : t;
}
function da(e, t = "Unknown error") {
	return e instanceof Error ? e.message || t : typeof e == "string" ? e || t : e == null ? t : typeof e == "object" ? la(e, t) : ua(e, t);
}
function fa(e) {
	return da(e, "");
}
function pa(e) {
	let t = e;
	return typeof DOMException < "u" && t instanceof DOMException && t.name === "AbortError" || t instanceof Error && t.name === "AbortError" || t?.message === "AbortError";
}
function ma(e = "Aborted") {
	try {
		return new DOMException(e, "AbortError");
	} catch {
		let t = Error(e);
		return t.name = "AbortError", t;
	}
}
//#endregion
//#region src/utils/abort.ts
var ha = new AbortController().signal;
function ga(e) {
	let t = e.throwIfAborted;
	if (typeof t == "function") try {
		t.call(e);
		return;
	} catch (t) {
		throw e.aborted || pa(t) ? ma() : t instanceof Error ? t : Error(String(t));
	}
	if (e.aborted) throw ma();
}
function _a(e, t) {
	if (!(Number.isFinite(e) && e > 0)) return {
		signal: t ?? ha,
		cleanup: () => {}
	};
	let n = new AbortController(), r, i = () => {
		r !== void 0 && (clearTimeout(r), r = void 0), n.abort(t?.reason);
	};
	return t && (t.addEventListener("abort", i, { once: !0 }), t.aborted && i()), n.signal.aborted || (r = setTimeout(() => {
		n.abort(ma("Timeout")), r = void 0;
	}, e)), {
		signal: n.signal,
		cleanup: () => {
			r !== void 0 && (clearTimeout(r), r = void 0), t?.removeEventListener("abort", i);
		}
	};
}
//#endregion
//#region src/utils/gm.ts
var va = "api.browser.yandex.ru", ya = "googlevideo.com", ba = /^([\w-]+):\s*(.+)$/, xa = /^[a-zA-Z][a-zA-Z\d+.-]*:/;
typeof GM_info > "u" || GM_info?.scriptHandler;
function Sa() {
	let e = typeof GM_xmlhttpRequest > "u" ? globalThis.GM_xmlhttpRequest : GM_xmlhttpRequest;
	return typeof e == "function" ? e : void 0;
}
function Ca() {
	let e = typeof GM > "u" ? globalThis.GM : GM, t = e?.xmlHttpRequest ?? e?.xmlhttpRequest;
	return typeof t == "function" ? t.bind(e) : void 0;
}
function wa() {
	return !!(Sa() || Ca());
}
var Ta = typeof GM < "u" || globalThis.GM !== void 0, Ea = wa();
function Da(e) {
	let t = e.trim();
	try {
		return new URL(t).hostname.toLowerCase();
	} catch {
		if (!xa.test(t)) try {
			return new URL(`https://${t}`).hostname.toLowerCase();
		} catch {}
		return;
	}
}
function Oa(e, t) {
	return e === t || e.endsWith(`.${t}`);
}
function ka(e, t, n = !1) {
	if (n) return !0;
	if (!e) {
		let e = t.toLowerCase();
		return e.includes(va) || e.includes(ya);
	}
	return Oa(e, va) || Oa(e, ya);
}
function Aa(e) {
	return typeof e == "string" ? e : e instanceof URL ? e.href : e.url;
}
function ja(e, t) {
	return t ? t.toUpperCase() : e instanceof Request ? (e.method || "GET").toUpperCase() : "GET";
}
function Ma(e) {
	return typeof e != "string" || e.length === 0 ? {} : e.split(/\r?\n/).reduce((e, t) => {
		let n = ba.exec(t);
		if (!n) return e;
		let [, r, i] = n;
		return e[r] = i, e;
	}, {});
}
function Na(e) {
	let t = e;
	return typeof t?.error == "string" ? t.error : typeof t?.statusText == "string" ? t.statusText : fa(e) || "Unknown error";
}
async function Pa(e, t, n) {
	let r = Wi(n.headers), i = Sa(), a = Ca();
	if (i) return await new Promise((a, o) => {
		let s = !1, c, l = () => {
			c && n.signal?.removeEventListener("abort", c);
		}, u = (e) => {
			s || (s = !0, l(), o(e));
		}, d = i({
			method: n.method || "GET",
			url: e,
			responseType: "blob",
			data: n.body,
			timeout: t,
			headers: r,
			onload: (t) => {
				if (s) return;
				s = !0, l();
				let n = Ma(t.responseHeaders), r = new Response(t.response, {
					status: t.status,
					statusText: typeof t.statusText == "string" ? t.statusText : "",
					headers: n
				});
				Object.defineProperty(r, "url", { value: t.finalUrl ?? e }), a(r);
			},
			ontimeout: () => u(/* @__PURE__ */ Error("Timeout")),
			onerror: (e) => u(Error(Na(e))),
			onabort: () => u(ma())
		});
		if (c = () => {
			try {
				d?.abort?.();
			} catch {}
			u(ma());
		}, n.signal && (n.signal.addEventListener("abort", c, { once: !0 }), n.signal.aborted)) {
			c();
			return;
		}
	});
	if (!a) throw TypeError("GM_xmlhttpRequest is not available");
	let o = a({
		method: n.method || "GET",
		url: e,
		responseType: "blob",
		data: n.body,
		timeout: t,
		headers: r
	}), s;
	try {
		let t = new Promise((e, t) => {
			n.signal && (s = () => {
				try {
					o.abort?.();
				} catch {}
				t(ma());
			}, n.signal.addEventListener("abort", s, { once: !0 }), n.signal.aborted && s());
		}), r = await Promise.race([o, t]), i = Ma(r.responseHeaders), a = new Response(r.response, {
			status: r.status,
			statusText: typeof r.statusText == "string" ? r.statusText : "",
			headers: i
		});
		return Object.defineProperty(a, "url", { value: r.finalUrl ?? e }), a;
	} finally {
		s && n.signal?.removeEventListener("abort", s);
	}
}
async function z(e, t = {}) {
	let { timeout: n = 15e3, forceGmXhr: r = !1, responseCache: i, ...a } = t, o = Aa(e), s = Da(o), c = ja(e, a.method), l = async () => {
		if (ka(s, o, r)) return L.log("GM_fetch: routing request via GM_xmlhttpRequest", {
			host: s ?? "unknown",
			reason: r ? "forced" : "host-policy",
			url: o
		}), await Pa(o, n, a);
		let { signal: t, cleanup: i } = _a(n, a.signal);
		try {
			return await fetch(e, {
				...a,
				signal: t
			});
		} catch (e) {
			if (t.aborted || pa(e)) throw e;
			return L.log("GM_fetch preventing CORS by GM_xmlhttpRequest", fa(e) || "Unknown error"), await Pa(o, n, a);
		} finally {
			i();
		}
	};
	return i ? await oa({
		url: o,
		method: c,
		body: a.body
	}, i, l) : await l();
}
//#endregion
//#region src/utils/storage.ts
var Fa = Object.entries({
	numToBool: [
		["autoTranslate"],
		["dontTranslateYourLang", "enabledDontTranslateLanguages"],
		["autoSetVolumeYandexStyle", "enabledAutoVolume"],
		["showVideoSlider"],
		["syncVolume"],
		["downloadWithName"],
		["sendNotifyOnComplete"],
		["highlightWords"],
		["onlyBypassMediaCSP"],
		["newAudioPlayer"],
		["showPiPButton"],
		["translateAPIErrors"],
		["audioBooster"],
		["useNewModel", "useLivelyVoice"]
	],
	number: [["autoVolume"]],
	array: [["dontTranslateLanguage", "dontTranslateLanguages"]],
	string: [
		["hotkeyButton", "translationHotkey"],
		["locale-lang-override", "localeLangOverride"],
		["locale-lang", "localeLang"]
	]
}).flatMap(([e, t]) => t.map(([t, n]) => ({
	category: e,
	oldKey: t,
	newKey: n ?? t,
	shouldDeleteOldKey: !!n
}))), Ia = new Map(Fa.map((e) => [e.oldKey, e])), La = Array.from(new Set(Fa.map((e) => e.oldKey)));
function Ra(e) {
	let t = {};
	for (let n of e) t[n] = void 0;
	return t;
}
function za(e, t) {
	switch (e) {
		case "numToBool":
		case "number": return typeof t == "number";
		case "array": return Array.isArray(t);
		case "string": return typeof t == "string" || t === null;
		default: return !1;
	}
}
function Ba(e, t) {
	switch (e) {
		case "string":
		case "array":
		case "number": return t;
		default: return !!t;
	}
}
function Va(e, t) {
	let n = Ba(e.category, t);
	return e.oldKey === "autoVolume" && typeof t == "number" && t < 1 && (n = Math.round(t * 100)), n;
}
function Ha(e, t) {
	return Array.isArray(e) && Array.isArray(t) ? e.length === t.length && e.every((e, n) => Object.is(e, t[n])) : Object.is(e, t);
}
function Ua(e) {
	if (e !== null) try {
		return JSON.parse(e);
	} catch {
		return;
	}
}
async function Wa(e) {
	if (e.compatVersion === "2025-05-09") return e;
	let t = new Set([...Object.keys(e), ...La]), n = await B.getValues(Ra(t)), r = { ...e }, i = [], a = [];
	for (let [e, t] of Object.entries(n)) {
		if (t === void 0) continue;
		let o = Ia.get(e);
		if (!o || !za(o.category, t)) continue;
		let s = Va(o, t);
		r[o.newKey] = s;
		let c = n[o.newKey];
		(o.shouldDeleteOldKey || !Ha(c, s)) && i.push(B.set(o.newKey, s)), o.shouldDeleteOldKey && a.push(B.delete(o.oldKey));
	}
	return await Promise.all([...i, ...a]), {
		...r,
		compatVersion: _i
	};
}
var Ga = class {
	support = null;
	localStorageListeners = /* @__PURE__ */ new Map();
	shouldUseSyntheticListeners(e) {
		return !e.promiseAddValueChangeListener && !e.legacyAddValueChangeListener;
	}
	getGMRuntime() {
		return typeof GM < "u" ? GM : globalThis.GM;
	}
	resolveSupport() {
		if (this.support) return this.support;
		let e = this.getGMRuntime(), t = {
			legacyGet: typeof GM_getValue == "function",
			legacySet: typeof GM_setValue == "function",
			legacyDelete: typeof GM_deleteValue == "function",
			legacyList: typeof GM_listValues == "function",
			legacyAddValueChangeListener: typeof globalThis.GM_addValueChangeListener == "function",
			legacyRemoveValueChangeListener: typeof globalThis.GM_removeValueChangeListener == "function",
			promiseGet: Ta && typeof e?.getValue == "function",
			promiseGetValues: Ta && typeof e?.getValues == "function",
			promiseSet: Ta && typeof e?.setValue == "function",
			promiseDelete: Ta && typeof e?.deleteValue == "function",
			promiseList: Ta && typeof e?.listValues == "function",
			promiseAddValueChangeListener: Ta && typeof e?.addValueChangeListener == "function",
			promiseRemoveValueChangeListener: Ta && typeof e?.removeValueChangeListener == "function"
		};
		return this.support = t, L.log(`[VOT Storage] GM Promises: ${t.promiseGet} | GM legacy: ${t.legacyGet}`), t;
	}
	get isSupportOnlyLS() {
		let e = this.resolveSupport();
		return !e.legacyGet && !e.legacySet && !e.legacyDelete && !e.legacyList && !e.promiseGet && !e.promiseGetValues && !e.promiseSet && !e.promiseDelete && !e.promiseList;
	}
	syncGetByName(e, t, n) {
		if (n.legacyGet) return GM_getValue(e, t);
		let r = globalThis.localStorage.getItem(e);
		if (r === null) return t;
		try {
			return JSON.parse(r);
		} catch {
			return t;
		}
	}
	async getRaw(e, t) {
		let n = this.resolveSupport();
		return n.promiseGet && GM.getValue ? await GM.getValue(e, t) : this.syncGetByName(e, t, n);
	}
	async get(e, t) {
		return this.getRaw(e, t);
	}
	async getValues(e) {
		let t = this.resolveSupport();
		if (t.promiseGetValues && GM.getValues) return await GM.getValues(e);
		let n = Object.entries(e);
		if (t.promiseGet && GM.getValue) {
			let e = await Promise.all(n.map(async ([e, t]) => [e, await GM.getValue(e, t)]));
			return Object.fromEntries(e);
		}
		return Object.fromEntries(n.map(([e, n]) => [e, this.syncGetByName(e, n, t)]));
	}
	syncSetByName(e, t, n) {
		return n.legacySet ? GM_setValue(e, t) : globalThis.localStorage.setItem(e, JSON.stringify(t));
	}
	async setRaw(e, t) {
		let n = this.resolveSupport(), r = e, i = this.shouldUseSyntheticListeners(n), a = i ? await this.getRaw(e) : void 0;
		if (n.promiseSet && GM.setValue) {
			await GM.setValue(e, t), i && this.notifyLocalStorageListeners(r, a, t, !1);
			return;
		}
		let o = this.syncSetByName(e, t, n);
		return this.notifyLocalStorageListeners(r, a, t, !1), o;
	}
	async set(e, t) {
		return this.setRaw(e, t);
	}
	syncDeleteByName(e, t) {
		return t.legacyDelete ? GM_deleteValue(e) : globalThis.localStorage.removeItem(e);
	}
	async deleteRaw(e) {
		let t = this.resolveSupport(), n = e, r = this.shouldUseSyntheticListeners(t), i = r ? await this.getRaw(e) : void 0;
		if (t.promiseDelete && GM.deleteValue) {
			await GM.deleteValue(e), r && this.notifyLocalStorageListeners(n, i, void 0, !1);
			return;
		}
		let a = this.syncDeleteByName(e, t);
		return this.notifyLocalStorageListeners(n, i, void 0, !1), a;
	}
	async delete(e) {
		return this.deleteRaw(e);
	}
	addValueChangeListener(e, t) {
		let n = this.resolveSupport(), r = this.getGMRuntime();
		if (n.promiseAddValueChangeListener) {
			let i = r?.addValueChangeListener, a = n.promiseRemoveValueChangeListener ? r?.removeValueChangeListener : void 0;
			if (typeof i == "function") {
				let n = i(e, this.createTypedListener(t));
				return () => {
					typeof a == "function" && a(n);
				};
			}
		}
		if (n.legacyAddValueChangeListener) {
			let r = globalThis.GM_addValueChangeListener, i = n.legacyRemoveValueChangeListener ? globalThis.GM_removeValueChangeListener : void 0;
			if (typeof r == "function") {
				let n = r(e, this.createTypedListener(t));
				return () => {
					typeof i == "function" && i(n);
				};
			}
		}
		let i = this.getLocalStorageListeners(e), a = t;
		i.add(a);
		let o = (t) => {
			t.storageArea !== globalThis.localStorage || t.key !== e || a(e, Ua(t.oldValue), Ua(t.newValue), !0);
		};
		return globalThis.addEventListener("storage", o), () => {
			i.delete(a), i.size === 0 && this.localStorageListeners.delete(e), globalThis.removeEventListener("storage", o);
		};
	}
	createTypedListener(e) {
		return (t, n, r, i) => {
			e(t, n, r, i);
		};
	}
	getLocalStorageListeners(e) {
		let t = this.localStorageListeners.get(e);
		if (t) return t;
		let n = /* @__PURE__ */ new Set();
		return this.localStorageListeners.set(e, n), n;
	}
	notifyLocalStorageListeners(e, t, n, r) {
		let i = this.localStorageListeners.get(e);
		if (!(!i || i.size === 0)) for (let a of i) a(e, t, n, r);
	}
	syncList(e) {
		return e.legacyList ? GM_listValues() : yi;
	}
	async list() {
		let e = this.resolveSupport();
		return e.promiseList && GM.listValues ? await GM.listValues() : this.syncList(e);
	}
}, Ka = "__VOT_STORAGE_SINGLETON__", B = (() => {
	let e = globalThis, t = e[Ka];
	if (t instanceof Ga) return t;
	let n = new Ga();
	return e[Ka] = n, n;
})(), qa = "vot-auth", Ja = "account-updated";
function Ya() {
	return {
		source: qa,
		type: Ja
	};
}
function Xa(e) {
	if (!e || typeof e != "object") return !1;
	let t = e;
	return t.source === "vot-auth" && t.type === "account-updated";
}
function Za(e = globalThis.opener) {
	!e || typeof e.postMessage != "function" || e.postMessage(Ya(), "*");
}
//#endregion
//#region src/core/auth.ts
function Qa() {
	let e = globalThis._userData;
	if (!e || typeof e != "object") return null;
	let t = e;
	return typeof t.avatar_id != "string" || typeof t.username != "string" || t.avatar_id.length === 0 || t.username.length === 0 ? null : {
		avatar_id: t.avatar_id,
		username: t.username
	};
}
async function $a() {
	let { access_token: e, expires_in: t } = Object.fromEntries(new URLSearchParams(globalThis.location.hash.slice(1)));
	if (!e || !t) throw Error("[VOT] Invalid token response");
	let n = Number.parseInt(t, 10);
	if (Number.isNaN(n)) throw TypeError("[VOT] Invalid expires_in value");
	await B.set("account", {
		token: e,
		expires: Date.now() + n * 1e3,
		username: void 0,
		avatarId: void 0
	}), Za();
}
async function eo() {
	let e = Qa();
	if (!e) throw Error("[VOT] Invalid user data");
	let { avatar_id: t, username: n } = e, r = await B.get("account");
	if (!r) throw Error("[VOT] No account data found");
	await B.set("account", {
		...r,
		username: n,
		avatarId: t
	}), Za();
}
async function to() {
	if (globalThis.location.pathname === "/auth/callback") return $a();
	if (globalThis.location.pathname === "/my/profile") return eo();
}
var no = {
	recommended: "recommended",
	translateVideo: "Translate video",
	disableTranslate: "Turn off",
	translationSettings: "Translation settings",
	subtitlesSettings: "Subtitles settings",
	subtitlesSmartLayout: "Smart subtitle layout",
	resetSettings: "Reset settings",
	videoBeingTranslated: "The video is being translated",
	videoLanguage: "Video language",
	translationLanguage: "Translation language",
	translationTake: "The translation will take",
	translationTakeMoreThanHour: "The translation will take more than an hour",
	translationTakeAboutMinute: "The translation will take about a minute",
	translationTakeFewMinutes: "The translation will take a few minutes",
	translationTakeApproximatelyMinutes: "The translation will take approximately {0} minutes",
	translationTakeApproximatelyMinute: "The translation will take approximately {0} minutes",
	requestTranslationFailed: "Failed to request video translation",
	audioNotReceived: "Audio link not received",
	VOTFailedDownloadAudio: "Failed to download audio",
	audioFormatNotSupported: "The audio format is not supported",
	VOTAutoTranslate: "Translate on open",
	VOTAutoSubtitles: "Subtitles on open",
	VOTDontTranslateYourLang: "Don't translate from my language",
	VOTVolume: "Video volume:",
	VOTVolumeTranslation: "Translation volume:",
	VOTAutoSetVolume: "Reduce video volume to",
	VOTShowVideoSlider: "Video volume slider",
	VOTSyncVolume: "Link translation and video volume",
	VOTDisableFromYourLang: "You have disabled the translation of the video in your language",
	VOTVideoIsTooLong: "Video is too long",
	VOTNoVideoIDFound: "No video ID found",
	VOTSubtitles: "Subtitles",
	VOTSubtitlesDisabled: "Disabled",
	VOTDefaultSubtitlesLanguage: "Default subtitle language",
	VOTOriginalVideoLanguage: "Original video language",
	VOTSubtitlesMaxLength: "Subtitles max length",
	VOTHighlightWords: "Highlight words",
	VOTTranslatedFrom: "translated from",
	VOTAutogenerated: "autogenerated",
	VOTSettings: "VOT Settings",
	VOTMenuLanguage: "Menu language",
	VOTAuthors: "Authors",
	VOTVersion: "Version",
	VOTLoader: "Loader",
	VOTBrowser: "Browser",
	VOTShowPiPButton: "Show PiP button",
	langs: {
		auto: "Auto",
		af: "Afrikaans",
		ak: "Akan",
		sq: "Albanian",
		am: "Amharic",
		ar: "Arabic",
		hy: "Armenian",
		as: "Assamese",
		ay: "Aymara",
		az: "Azerbaijani",
		bn: "Bangla",
		eu: "Basque",
		be: "Belarusian",
		bho: "Bhojpuri",
		bs: "Bosnian",
		bg: "Bulgarian",
		my: "Burmese",
		ca: "Catalan",
		ceb: "Cebuano",
		zh: "Chinese",
		"zh-Hans": "Chinese (Simplified)",
		"zh-Hant": "Chinese (Traditional)",
		co: "Corsican",
		hr: "Croatian",
		cs: "Czech",
		da: "Danish",
		dv: "Divehi",
		nl: "Dutch",
		en: "English",
		eo: "Esperanto",
		et: "Estonian",
		ee: "Ewe",
		fil: "Filipino",
		fi: "Finnish",
		fr: "French",
		gl: "Galician",
		lg: "Ganda",
		ka: "Georgian",
		de: "German",
		el: "Greek",
		gn: "Guarani",
		gu: "Gujarati",
		ht: "Haitian Creole",
		ha: "Hausa",
		haw: "Hawaiian",
		iw: "Hebrew",
		hi: "Hindi",
		hmn: "Hmong",
		hu: "Hungarian",
		is: "Icelandic",
		ig: "Igbo",
		id: "Indonesian",
		ga: "Irish",
		it: "Italian",
		ja: "Japanese",
		jv: "Javanese",
		kn: "Kannada",
		kk: "Kazakh",
		km: "Khmer",
		rw: "Kinyarwanda",
		ko: "Korean",
		kri: "Krio",
		ku: "Kurdish",
		ky: "Kyrgyz",
		lo: "Lao",
		la: "Latin",
		lv: "Latvian",
		ln: "Lingala",
		lt: "Lithuanian",
		lb: "Luxembourgish",
		mk: "Macedonian",
		mg: "Malagasy",
		ms: "Malay",
		ml: "Malayalam",
		mt: "Maltese",
		mi: "Māori",
		mr: "Marathi",
		mn: "Mongolian",
		ne: "Nepali",
		nso: "Northern Sotho",
		no: "Norwegian",
		ny: "Nyanja",
		or: "Odia",
		om: "Oromo",
		ps: "Pashto",
		fa: "Persian",
		pl: "Polish",
		pt: "Portuguese",
		pa: "Punjabi",
		qu: "Quechua",
		ro: "Romanian",
		ru: "Russian",
		sm: "Samoan",
		sa: "Sanskrit",
		gd: "Scottish Gaelic",
		sr: "Serbian",
		sn: "Shona",
		sd: "Sindhi",
		si: "Sinhala",
		sk: "Slovak",
		sl: "Slovenian",
		so: "Somali",
		st: "Southern Sotho",
		es: "Spanish",
		su: "Sundanese",
		sw: "Swahili",
		sv: "Swedish",
		tg: "Tajik",
		ta: "Tamil",
		tt: "Tatar",
		te: "Telugu",
		th: "Thai",
		ti: "Tigrinya",
		ts: "Tsonga",
		tr: "Turkish",
		tk: "Turkmen",
		uk: "Ukrainian",
		ur: "Urdu",
		ug: "Uyghur",
		uz: "Uzbek",
		vi: "Vietnamese",
		cy: "Welsh",
		fy: "Western Frisian",
		xh: "Xhosa",
		yi: "Yiddish",
		yo: "Yoruba",
		zu: "Zulu"
	},
	streamNoConnectionToServer: "There is no connection to the server",
	searchField: "Search...",
	VOTTranslateAPIErrors: "Translate errors from the API",
	VOTDetectService: "Language detection service",
	VOTProxyWorkerHost: "Enter the proxy worker address",
	VOTM3u8ProxyHost: "Enter the address of the m3u8 proxy worker",
	proxySettings: "Proxy Settings",
	translationTakeApproximatelyMinute2: "The translation will take approximately {0} minutes",
	VOTAudioBooster: "Extended translation volume increase",
	VOTSubtitlesDesign: "Subtitles design",
	VOTSubtitlesFont: "Subtitle font",
	VOTSubtitlesFontSize: "Font size of subtitles",
	VOTSubtitlesOpacity: "Transparency of the subtitle background",
	VOTSubtitlesDownloadFormat: "The format for downloading subtitles",
	VOTDownloadWithName: "Download files with the video name",
	VOTUpdateLocaleFiles: "Update localization files",
	VOTLocaleHash: "Locale hash",
	VOTUpdatedAt: "Updated at",
	VOTNeedWebAudioAPI: "To enable this, you must have a Web Audio API",
	VOTMediaCSPEnabledOnSite: "Media CSP is enabled on this site",
	VOTOnlyBypassMediaCSP: "Use it only for bypassing Media CSP",
	VOTNewAudioPlayer: "Use the new audio player",
	VOTUseNewModel: "Use an experimental variation of Yandex voices for some videos",
	TranslationDelayed: "The translation is slightly delayed",
	VOTTranslationCompletedNotify: "The translation on the {0} has been completed!",
	VOTSendNotifyOnComplete: "Send a notification that the video has been translated",
	VOTBugReport: "Report a bug",
	VOTTranslateProxyDisabled: "Disabled",
	VOTTranslateProxyEnabled: "Enabled",
	VOTTranslateProxyEverything: "Proxy everything",
	VOTTranslateProxyStatus: "Proxying mode",
	VOTTranslatedBy: "Translated by {0}",
	VOTStreamNotAvailable: "Translate stream isn't available",
	VOTTranslationTextService: "Text translation service",
	VOTNotAffectToVoice: "Doesn't affect the translation of text in voice over",
	DontTranslateSelectedLanguages: "Don't translate from selected languages",
	showVideoVolumeSlider: "Display the video volume slider",
	hotkeysSettings: "Hotkeys settings",
	None: "None",
	VOTUseLivelyVoice: "Use lively voices. Speakers sound like native Russians.",
	miscSettings: "Misc settings",
	services: {
		yandexbrowser: "Yandex Browser",
		msedge: "Microsoft Edge",
		"rust-server": "Rust Server"
	},
	aboutExtension: "About extension",
	appearance: "Appearance",
	buttonPosition: "Button position in the player",
	position: {
		left: "Left",
		right: "Right",
		top: "Top",
		default: "Default"
	},
	secs: "secs",
	autoHideButtonDelay: "Delay before hiding the translate button",
	notFound: "not found",
	minButtonPositionContainer: "The button position only changes in players larger than 600 pixels.",
	VOTTranslateProxyStatusDefault: "Completely disabling proxying in your country may break the extension",
	PressTheKeyCombination: "Press the key combination...",
	VOTUseAudioDownload: "Use audio download",
	VOTUseAudioDownloadWarning: "Disabling audio downloads may affect the functionality of the extension",
	VOTAccountRequired: "You need to log in to use this feature",
	VOTMyAccount: "My account",
	VOTLogin: "Login",
	VOTLogout: "Logout",
	VOTRefresh: "Refresh",
	VOTYandexToken: "Enter the Yandex OAuth Token",
	VOTYandexTokenInfo: "You can manually set the account token in this field. Please note that we don't check its validity before sending a translate request",
	VOTLoginViaToken: "Login via token",
	smartDucking: "Adaptive volume"
}, ro = [
	"localePhrases",
	"localeLang",
	"localeHash",
	"localeVersion",
	"localeUpdatedAt",
	"localeLangOverride"
], io = Gi(no), ao = "master", oo = (() => {
	let e = Array.isArray(/* @__PURE__ */ "auto.en.ru.af.am.ar.az.bg.bn.bs.ca.cs.cy.da.de.el.es.et.eu.fa.fi.fr.gl.hi.hr.hu.hy.id.it.ja.jv.kk.km.kn.ko.lo.mk.ml.mn.ms.mt.my.ne.nl.pa.pl.pt.ro.si.sk.sl.sq.sr.su.sv.sw.tr.uk.ur.uz.vi.zh.zu".split(".")) ? /* @__PURE__ */ "auto.en.ru.af.am.ar.az.bg.bn.bs.ca.cs.cy.da.de.el.es.et.eu.fa.fi.fr.gl.hi.hr.hu.hy.id.it.ja.jv.kk.km.kn.ko.lo.mk.ml.mn.ms.mt.my.ne.nl.pa.pl.pt.ro.si.sk.sl.sq.sr.su.sv.sw.tr.uk.ur.uz.vi.zh.zu".split(".") : ["en"];
	return e.includes("auto") ? e : ["auto", ...e];
})();
function so(e, t) {
	return e || t || "unknown";
}
function co() {
	return so("1.11.4", typeof GM_info < "u" ? String(GM_info?.script?.version || "") : "");
}
var V = new class {
	lang;
	locale;
	defaultLocale = io;
	localesUrl = `${di}/${ao}/src/localization/locales`;
	hashesUrl = `${di}/${ao}/src/localization/hashes.json`;
	warnedMissingKeys = /* @__PURE__ */ new Set();
	_langOverride = "auto";
	constructor() {
		this.lang = this.getLang(), this.locale = {};
	}
	async init() {
		let [e, t] = await Promise.all([B.get("localeLangOverride", "auto"), B.get("localePhrases", "")]);
		return this._langOverride = e, this.lang = this.getLang(), this.setLocaleFromJsonString(t), this;
	}
	get langOverride() {
		return this._langOverride;
	}
	getLang() {
		return this.langOverride === "auto" ? wi : this.langOverride;
	}
	getAvailableLangs() {
		return [...oo];
	}
	async reset() {
		return await Promise.all(ro.map((e) => B.delete(e))), this;
	}
	buildUrl(e, t = "", n = !1) {
		return `${e}${t}${n ? `?timestamp=${Ui()}` : ""}`;
	}
	async changeLang(e) {
		return this.langOverride === e ? !1 : (await B.set("localeLangOverride", e), this._langOverride = e, this.lang = this.getLang(), await this.update(!0), !0);
	}
	async checkUpdates(e = !1) {
		L.log("Check locale updates...");
		try {
			let t = await z(this.buildUrl(this.hashesUrl, "", e));
			if (!t.ok) throw t.status;
			let n = await t.json();
			if (!n || typeof n != "object") throw Error("Invalid locale hashes payload");
			let r = n[this.lang];
			return typeof r != "string" || !r || await B.get("localeHash", "") === r ? !1 : r;
		} catch (e) {
			return console.error("[VOT] [localizationProvider] Failed to get locales hash:", e), null;
		}
	}
	async update(e = !1) {
		let t = co(), n = await B.get("localeVersion", ""), r = await this.checkUpdates(e);
		if (r === null) return this;
		if (!r) return n !== t && await B.set("localeVersion", t), this;
		let i = Ui();
		L.log("Updating locale...");
		try {
			let n = await z(this.buildUrl(this.localesUrl, `/${this.lang}.json`, e));
			if (!n.ok) throw n.status;
			let a = await n.text();
			this.setLocaleFromJsonString(a), await Promise.all([
				B.set("localePhrases", a),
				B.set("localeHash", r),
				B.set("localeLang", this.lang),
				B.set("localeVersion", t),
				B.set("localeUpdatedAt", i)
			]);
		} catch (e) {
			console.error("[VOT] [localizationProvider] Failed to get locale:", e), this.setLocaleFromJsonString(await B.get("localePhrases", ""));
		}
		return this;
	}
	setLocaleFromJsonString(e) {
		let t = e.trim();
		if (!t) return this.locale = {}, this.warnedMissingKeys.clear(), this;
		try {
			let e = JSON.parse(t);
			if (!e || typeof e != "object" || Array.isArray(e)) throw Error("Locale payload should be a JSON object");
			this.locale = Gi(e);
		} catch (e) {
			console.error("[VOT] [localizationProvider]", e), this.locale = {};
		}
		return this.warnedMissingKeys.clear(), this;
	}
	getFromLocale(e, t, n = "locale") {
		return e[t] ?? this.warnMissingKey(e, t, n);
	}
	warnMissingKey(e, t, n) {
		let r = `${n}:${t}`;
		this.warnedMissingKeys.has(r) || (this.warnedMissingKeys.add(r), console.warn("[VOT] [localizationProvider] locale", e, "doesn't contain key", t));
	}
	getDefault(e) {
		return this.getFromLocale(this.defaultLocale, e, "default") ?? e;
	}
	get(e) {
		return this.getFromLocale(this.locale, e) ?? this.getDefault(e);
	}
	getLangLabel(e) {
		let t = `langs.${e}`;
		if (t in this.defaultLocale) {
			let e = this.get(t);
			if (e) return e;
		}
		return e.toUpperCase();
	}
}(), lo = null;
function uo() {
	return lo ??= V.init(), lo;
}
//#endregion
//#region src/utils/iframeConnector.ts
var fo = () => globalThis.self !== globalThis.top, po = !1, mo = null;
async function ho(e, t) {
	if (!po) {
		if (mo !== null) {
			await mo;
			return;
		}
		mo = (async () => {
			if (t("Activating runtime", { reason: e }), globalThis.location.origin === "https://rust-server-531j.onrender.com") {
				await to(), po = !0;
				return;
			}
			await uo(), fo() || await V.update(), L.log(`Selected menu language: ${V.lang}`), po = !0;
		})();
		try {
			await mo;
		} finally {
			mo = null;
		}
	}
}
//#endregion
//#region src/bootstrap/videoObserverBinding.ts
var go = /* @__PURE__ */ new WeakSet();
function _o(e) {
	let { videoObserver: t, videosWrappers: n, ensureRuntimeActivated: r, getServicesCached: i, findContainer: a, createVideoHandler: o } = e;
	if (go.has(t)) return;
	go.add(t);
	let s = /* @__PURE__ */ new WeakSet(), c = /* @__PURE__ */ new WeakMap(), l = /* @__PURE__ */ new WeakMap(), u = /* @__PURE__ */ new WeakMap(), d = (e) => {
		let t = l.get(e);
		return t && c.get(t) === e && c.delete(t), l.delete(e), t ?? void 0;
	}, f = (e) => {
		e && u.delete(e);
	}, p = async (e, t) => {
		let r = n.get(e);
		if (r) try {
			await r.release();
		} catch (e) {
			console.error(`[VOT] Failed to release videoHandler (${t})`, e);
		} finally {
			n.delete(e);
		}
	}, m = (e) => {
		for (let t of i()) {
			let n = a(t, e);
			if (n) return {
				site: t,
				container: n
			};
		}
		return null;
	}, h = (e) => {
		let t = String(e.host);
		return t === "peertube" || t === "directlink" ? {
			...e,
			url: globalThis.location.origin
		} : e;
	}, g = async (e) => {
		if (!e) return;
		let t = u.get(e);
		t && (u.delete(e), !(!t.isConnected || n.has(t) || s.has(t)) && await _(t));
	}, _ = async (e) => {
		if (!(n.has(e) || s.has(e))) {
			s.add(e);
			try {
				try {
					await r("video-detected");
				} catch (e) {
					console.error("[VOT] Failed to activate runtime", e);
					return;
				}
				let t = m(e);
				if (!t) return;
				let { site: i, container: a } = t, s = c.get(a);
				if (s && s !== e) {
					if (s.isConnected) {
						u.set(a, e);
						return;
					}
					await p(s, "stale container"), d(s);
				}
				let _ = o(e, a, h(i));
				n.set(e, _), l.set(e, a), c.set(a, e);
				try {
					if (await _.init(), n.get(e) !== _) return;
					try {
						await _.setCanPlay();
					} catch (e) {
						console.error("[VOT] Failed to get video data", e);
					}
				} catch (t) {
					if (n.get(e) === _) {
						await p(e, "init failed");
						let t = d(e);
						f(t), await g(t);
					}
					console.error("[VOT] Failed to initialize videoHandler", t);
				}
			} finally {
				s.delete(e);
			}
		}
	};
	t.onVideoAdded.addListener(_), t.onVideoRemoved.addListener(async (e) => {
		let t = d(e);
		await p(e, "video removed"), s.delete(e), t && u.get(t) === e && f(t), await g(t);
	});
}
//#endregion
//#region src/core/bootstrapPolicy.ts
function vo(e) {
	return e.isIframe ? e.href === "about:blank" || e.href.startsWith("about:srcdoc") || e.origin === "null" : !1;
}
function yo(e) {
	return vo(e) ? "skip" : !e.isIframe && e.origin === e.authOrigin ? "auth-eager" : "lazy";
}
//#endregion
//#region src/utils/dom.ts
function bo(e) {
	return e ? typeof ShadowRoot < "u" && e instanceof ShadowRoot ? e.host : e.parentNode ?? null : null;
}
function xo(e, t) {
	let n = t;
	for (; n;) {
		if (n === e) return !0;
		n = bo(n);
	}
	return !1;
}
function So(e) {
	return e === document.body || e === document.documentElement;
}
function Co(e, t, n = {}) {
	let { allowDocumentViewport: r = !1 } = n;
	if (!(e instanceof HTMLElement) || So(e) && !r) return null;
	for (let n of t) if (n && (xo(e, n) || xo(n, e))) return e;
	return null;
}
function wo(e, t) {
	return !e || !t ? null : Do(e, t, e instanceof Document ? null : e);
}
function To(e, t, n) {
	if (!n) return e.querySelector(t);
	let r = e.querySelectorAll(t);
	for (let e of r) if (xo(e, n)) return e;
	return null;
}
function Eo(e) {
	let t = e.getRootNode();
	if (t instanceof ShadowRoot) return t.host;
	if (t instanceof Document) return t;
	if (t !== e) {
		let n = bo(t);
		if (n && n !== e && n instanceof Element) return n;
	}
	return null;
}
function Do(e, t, n) {
	return e ? e instanceof Document ? To(e, t, n) : e.closest(t) || Do(Eo(e), t, n) : null;
}
//#endregion
//#region src/core/containerResolution.ts
function Oo(e, t) {
	if (!t) return null;
	let n = wo(e, t);
	return n instanceof HTMLElement && n.isConnected && xo(n, e) ? n : null;
}
//#endregion
//#region src/core/overlayMountTargets.ts
function ko(e, t) {
	return t.host === "youtube" && t.additionalData !== "mobile" ? e.parentElement ?? e : e;
}
function Ao(e) {
	let t = ko(e.container, e.site), n = e.fullscreenRoot ?? t;
	return {
		base: t,
		root: n,
		portalContainer: t,
		subtitlesMountContainer: n
	};
}
//#endregion
//#region src/core/eventImpl.ts
var H = class {
	listeners = /* @__PURE__ */ new Set();
	get size() {
		return this.listeners.size;
	}
	addListener(e) {
		return this.listeners.add(e), this;
	}
	removeListener(e) {
		return this.listeners.delete(e), this;
	}
	dispatch(...e) {
		for (let t of this.listeners) try {
			t(...e);
		} catch (e) {
			console.error("[VOT]", e);
		}
	}
	async dispatchAsync(...e) {
		let t = [];
		for (let n of this.listeners) try {
			let r = n(...e);
			r && typeof r.then == "function" && t.push(Promise.resolve(r));
		} catch (e) {
			console.error("[VOT]", e);
		}
		if (!t.length) return;
		let n = await Promise.allSettled(t);
		for (let e of n) e.status === "rejected" && console.error("[VOT]", e.reason);
	}
	clear() {
		this.listeners.clear();
	}
};
//#endregion
//#region src/audioDownloader/strategies/fileId.ts
function jo(e, t, n, r) {
	return JSON.stringify({
		downloadType: e,
		itag: t,
		minChunkSize: r,
		fileSize: n
	});
}
//#endregion
//#region src/audioDownloader/ytAudio/src/internal/format-selection.ts
function Mo(e) {
	return e?.toLowerCase() ?? "";
}
function No(e) {
	let t = Mo(e);
	return t.includes("audio/") && !t.includes("video/");
}
function Po(e) {
	let t = Mo(e);
	return t.includes("audio/mp4") && t.includes("mp4a.");
}
function Fo(e) {
	let t = Mo(e);
	return t.includes("audio/webm") && t.includes("opus");
}
function Io(e) {
	if (!e) return "mp4a.40.2";
	let t = /codecs="([^"]+)"/i.exec(e);
	if (!t?.[1]) return "mp4a.40.2";
	let n = t[1].split(",").map((e) => e.trim());
	return n.find((e) => e.toLowerCase().startsWith("mp4a.")) ?? n[0] ?? "mp4a.40.2";
}
function Lo(e, t) {
	let n = null, r = t === "max" ? -Infinity : Infinity;
	for (let i of e) {
		let e = i.bitrate ?? 0;
		(t === "max" && e > r || t === "min" && e < r) && (n = i, r = e);
	}
	return n;
}
function Ro(e, t) {
	let n = e.filter((e) => No(e.mimeType));
	if (!n.length) throw Error("No adaptive audio formats were found in player response");
	let r = t === "bestefficiency" ? "min" : "max", i = t === "bestefficiency" ? [n.filter((e) => Fo(e.mimeType)), n] : [
		n.filter((e) => Po(e.mimeType)),
		n.filter((e) => Fo(e.mimeType)),
		n
	];
	for (let e of i) {
		if (!e.length) continue;
		let t = Lo(e, r);
		if (t) return t;
	}
	throw Error("No adaptive audio formats were found in player response");
}
//#endregion
//#region src/audioDownloader/ytAudio/src/AudioDownloader.ts
var zo = class extends Error {
	status;
	constructor(e = 403) {
		super(`Failed to load watch page: ${e}`), this.name = "YtWatchContextForbiddenError", this.status = e;
	}
}, Bo = /^[a-zA-Z0-9_-]{11}$/, Vo = "https://www.youtube.com", Ho = "19.44.38", Uo = "1.60.19", Wo = "19.45.4", Go = [
	"ANDROID_VR",
	"ANDROID",
	"IOS",
	"WEB",
	"MWEB"
], Ko = {
	accept: "*/*",
	origin: Vo,
	referer: `${Vo}/`
}, qo = 256 * 1024;
function Jo(e) {
	return e ? { signal: e } : {};
}
function Yo(e, t, n) {
	switch (e) {
		case "ANDROID":
		case "YTMUSIC_ANDROID":
		case "YTSTUDIO_ANDROID": return {
			clientName: "ANDROID",
			clientVersion: Ho,
			hl: "en",
			gl: "US",
			androidSdkVersion: 34,
			osName: "Android",
			osVersion: "14",
			platform: "MOBILE"
		};
		case "ANDROID_VR": return {
			clientName: "ANDROID_VR",
			clientVersion: Uo,
			hl: "en",
			gl: "US",
			androidSdkVersion: 31,
			osName: "Android",
			osVersion: "12",
			platform: "MOBILE"
		};
		case "IOS": return {
			clientName: "IOS",
			clientVersion: Wo,
			hl: "en",
			gl: "US",
			platform: "MOBILE",
			osName: "iPhone",
			osVersion: "18.0.0.22A3354",
			deviceMake: "Apple",
			deviceModel: "iPhone16,2"
		};
		case "MWEB": return {
			clientName: "MWEB",
			clientVersion: t.clientVersion,
			hl: "en",
			gl: "US",
			originalUrl: `${Vo}/watch?v=${n}`
		};
		default: return {
			clientName: "WEB",
			clientVersion: t.clientVersion,
			hl: "en",
			gl: "US",
			utcOffsetMinutes: 0,
			originalUrl: `${Vo}/watch?v=${n}`
		};
	}
}
function Xo(e) {
	let t = e.trim();
	if (Bo.test(t)) return t;
	let n;
	try {
		n = new URL(t);
	} catch {
		throw Error(`Cannot extract YouTube video id from: ${e}`);
	}
	let r = n.hostname.toLowerCase();
	if (r === "youtu.be" || r.endsWith(".youtu.be")) return Zo(n.pathname.split("/").find(Boolean), e);
	let i = n.searchParams.get("v");
	if (i && Bo.test(i)) return i;
	let a = Qo(n.pathname.split("/").filter(Boolean));
	if (a) return a;
	throw Error(`Cannot extract YouTube video id from: ${e}`);
}
function Zo(e, t) {
	if (e && Bo.test(e)) return e;
	throw Error(`Cannot extract YouTube video id from: ${t}`);
}
function Qo(e) {
	for (let t of ["shorts", "embed"]) {
		let n = e.indexOf(t);
		if (n === -1) continue;
		let r = e[n + 1];
		if (r && Bo.test(r)) return r;
	}
	return null;
}
function $o(e) {
	return e.replaceAll("\\u0026", "&").replaceAll("\\/", "/");
}
function es(e) {
	let t = e.videoId ?? e.videoUrl;
	if (!t) throw Error("Either videoId or videoUrl is required");
	return Xo(t);
}
function ts(e, t) {
	for (let n of t) {
		let t = n.exec(e)?.[1];
		if (t) return t;
	}
}
async function ns(e) {
	return new Uint8Array(await e.arrayBuffer());
}
function rs(e = 16) {
	let t = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_", n = "";
	if (typeof crypto < "u" && typeof crypto.getRandomValues == "function") {
		let r = new Uint8Array(e);
		crypto.getRandomValues(r);
		for (let e of r) n += t[e % 64] ?? "a";
		return n;
	}
	for (let r = 0; r < e; r++) n += t[Math.floor(Math.random() * 64)] ?? "a";
	return n;
}
function is(e) {
	if (!e) return null;
	let t = Number.parseInt(e, 10);
	return !Number.isFinite(t) || t <= 0 ? null : t;
}
function as(e) {
	return e ? is(/\/(\d+)\s*$/i.exec(e)?.[1]) : null;
}
function os(e) {
	if (!e) return null;
	let t = /^bytes\s+(\d+)-(\d+)\/(?:\d+|\*)$/i.exec(e.trim());
	if (!t) return null;
	let n = Number.parseInt(t[1] ?? "", 10), r = Number.parseInt(t[2] ?? "", 10);
	return !Number.isFinite(n) || !Number.isFinite(r) || n < 0 || r < n ? null : {
		start: n,
		end: r
	};
}
function ss(e, t) {
	return t - e + 1;
}
function cs(e, t, n, r) {
	let i = ss(n, r);
	if (i <= 0 || t.byteLength <= 0 || t.byteLength > i) return !1;
	let a = os(e.headers.get("content-range"));
	return a ? a.start === n && a.end === n + t.byteLength - 1 : e.status === 206 ? t.byteLength === i : e.status === 200 ? n === 0 && t.byteLength === i : !1;
}
function ls(e, t) {
	let n = e.headers.get("content-range") ?? "none", r = e.headers.get("content-length") ?? "none";
	return `status=${e.status}; bytes=${t.byteLength}; content-range=${n}; content-length=${r}`;
}
function us(e) {
	let t = e?.toLowerCase() ?? "";
	return t.includes("audio/webm") ? "audio/webm" : t.includes("audio/mp4") ? "audio/mp4" : "audio/aac";
}
function ds(e) {
	let t = e ? [e, ...Go] : [...Go], n = /* @__PURE__ */ new Set();
	return t.filter((e) => n.has(e) ? !1 : (n.add(e), !0));
}
var fs = class {
	fetchFn;
	constructor(e = {}) {
		this.fetchFn = e.fetchImplementation ?? fetch;
	}
	async fetchRangeChunk(e, t, n, r) {
		let i = `bytes=${t}-${n}`, a = await this.fetchFn(e, {
			headers: {
				...Ko,
				range: i
			},
			...Jo(r)
		});
		if (!a.ok) throw Error(`Failed to download stream chunk: ${a.status}`);
		let o = await ns(a);
		if (!cs(a, o, t, n)) throw Error(`Received unexpected stream chunk payload: ${ls(a, o)}`);
		return o;
	}
	async downloadStreamByRanges(e, t, n) {
		let r = await this.resolveStreamContentLength(e, t, n, !0), i = new Uint8Array(r), a = 0;
		for (let t = 0; t < r; t += qo) {
			let o = Math.min(r - 1, t + qo - 1), s = await this.fetchRangeChunk(e, t, o, n);
			if (a + s.byteLength > i.byteLength) throw Error("Downloaded stream chunk exceeds probed stream content length");
			i.set(s, a), a += s.byteLength;
		}
		return a === i.byteLength ? i : i.slice(0, a);
	}
	async downloadAudioToChunkStream(e, t) {
		if (t.chunkSize <= 0) throw RangeError("Audio downloader. ytAudio. chunkSize must be > 0");
		return this.withResolvedPlayableAudioFormat(e, e.videoQuality ?? "best", "Chunk mode requires an adaptive audio stream format", "Unable to resolve streamable format for chunk mode", async ({ resolved: e, signal: n }) => {
			let r = await this.resolveStreamContentLength(e.streamUrl, e.chosenFormat.contentLength, n, !0), i = Math.max(1, Math.ceil(r / t.chunkSize));
			return {
				videoId: e.videoId,
				fileSize: r,
				itag: e.chosenFormat.itag ?? 0,
				mediaPartsLength: i,
				getMediaBuffers: async function* () {
					for (let a = 0; a < i; a++) {
						let i = a * t.chunkSize, o = Math.min(r - 1, i + t.chunkSize - 1);
						yield await this.fetchRangeChunk(e.streamUrl, i, o, n);
					}
				}.bind(this)
			};
		});
	}
	async downloadAudioToUint8Array(e) {
		let t = [], n = 0, r = await this.extractAndWriteAudio(e, { async write(e) {
			t.push(e), n += e.byteLength;
		} }), i = new Uint8Array(n), a = 0;
		for (let e of t) i.set(e, a), a += e.byteLength;
		return {
			...r,
			bytes: i
		};
	}
	async extractAndWriteAudio(e, t) {
		return this.withResolvedPlayableAudioFormat(e, e.videoQuality ?? "bestefficiency", "Selected stream is not audio-only", "Unable to download playable stream format", async ({ resolved: e, signal: n }) => {
			let r = await this.downloadStreamByRanges(e.streamUrl, e.chosenFormat.contentLength, n), i = this.getExtractionHints(e.chosenFormat);
			return await t.write(r), {
				videoId: e.videoId,
				bytesWritten: r.byteLength,
				mimeType: us(e.chosenFormat.mimeType),
				codec: i.codec,
				sampleRate: i.sampleRate,
				channels: i.channels
			};
		});
	}
	async withResolvedPlayableAudioFormat(e, t, n, r, i) {
		let a = es(e), { signal: o } = e, s = await this.fetchWatchContext(a, o), c = ds(e.client), l = [];
		for (let e of c) try {
			let r = await this.resolvePlayableFormatForClient({
				videoId: a,
				watchContext: s,
				client: e,
				quality: t,
				signal: o
			});
			if (!No(r.chosenFormat.mimeType)) throw Error(n);
			return await i({
				resolved: r,
				signal: o
			});
		} catch (t) {
			let n = t instanceof Error ? t.message : String(t);
			l.push(`${e}: ${n}`);
		}
		throw Error(`${r}. Attempts: ${l.join(" | ")}`);
	}
	async resolvePlayableFormatForClient({ videoId: e, watchContext: t, client: n, quality: r, signal: i }) {
		let a = ((await this.fetchPlayerResponse(e, t, n, i)).streamingData?.adaptiveFormats ?? []).filter((e) => !!e.url);
		if (!a.length) throw Error("Player response did not contain direct adaptive audio stream URLs");
		let o = Ro(a, r);
		return {
			videoId: e,
			chosenFormat: o,
			streamUrl: this.resolveFormatUrl(o, t.clientVersion)
		};
	}
	async resolveStreamContentLength(e, t, n, r = !1) {
		let i = is(t);
		if (i !== null && !r) return i;
		let a;
		try {
			a = await this.fetchFn(e, {
				headers: {
					...Ko,
					range: "bytes=0-0"
				},
				...Jo(n)
			});
		} catch (e) {
			if (i !== null) return i;
			let t = e instanceof Error ? e.message : String(e);
			throw Error(`Failed to probe stream content length: ${t}`);
		}
		if (!a.ok) {
			if (i !== null) return i;
			throw Error(`Failed to probe stream content length: ${a.status}`);
		}
		let o = as(a.headers.get("content-range")), s = is(a.headers.get("x-goog-stored-content-length")), c = is(a.headers.get("content-length"));
		if (typeof a.body?.cancel == "function") try {
			await a.body.cancel();
		} catch {}
		return o ?? s ?? i ?? c ?? (() => {
			throw Error("Failed to resolve stream content length");
		})();
	}
	getExtractionHints(e) {
		let t = Io(e.mimeType), n = Number.parseInt(e.audioSampleRate ?? "", 10);
		return {
			codec: t,
			sampleRate: Number.isFinite(n) && n > 0 ? n : 44100,
			channels: e.audioChannels && e.audioChannels > 0 ? e.audioChannels : 2
		};
	}
	resolveFormatUrl(e, t) {
		if (!e.url) throw Error("Selected format does not contain a direct stream URL");
		let n = new URL(e.url);
		return n.searchParams.get("c") === "WEB" && n.searchParams.set("cver", t), n.searchParams.set("cpn", rs()), n.toString();
	}
	async fetchWatchContext(e, t) {
		let n = `${Vo}/watch?v=${encodeURIComponent(e)}&hl=en`, r = await this.fetchFn(n, {
			headers: Ko,
			...Jo(t)
		});
		if (!r.ok) throw r.status === 403 ? new zo(r.status) : Error(`Failed to load watch page: ${r.status}`);
		let i = await r.text(), a = ts(i, [/"INNERTUBE_API_KEY":"([^"]+)"/, /["']INNERTUBE_API_KEY["']\s*:\s*"([^"]+)"/]), o = ts(i, [/"INNERTUBE_CLIENT_VERSION":"([^"]+)"/, /["']INNERTUBE_CLIENT_VERSION["']\s*:\s*"([^"]+)"/]), s = ts(i, [/"STS":(\d+)/, /["']STS["']\s*:\s*(\d+)/]), c = ts(i, [
			/"VISITOR_DATA":"([^"]+)"/,
			/"visitorData":"([^"]+)"/,
			/["'](?:VISITOR_DATA|visitorData)["']\s*:\s*"([^"]+)"/
		]);
		if (!a || !o) throw Error("Failed to extract required player context from watch page");
		let l = s ? Number.parseInt(s, 10) : void 0, u = {
			apiKey: a,
			clientVersion: o
		};
		return typeof l == "number" && Number.isFinite(l) && (u.signatureTimestamp = l), c && (u.visitorData = $o(c)), u;
	}
	async fetchPlayerResponse(e, t, n, r) {
		let i = Yo(n, t, e);
		t.visitorData && (i.visitorData = t.visitorData);
		let a = {
			context: { client: i },
			videoId: e,
			contentCheckOk: !0,
			racyCheckOk: !0
		};
		t.signatureTimestamp && (a.playbackContext = { contentPlaybackContext: { signatureTimestamp: t.signatureTimestamp } });
		let o = `${Vo}/youtubei/v1/player?key=${encodeURIComponent(t.apiKey)}`, s = await this.fetchFn(o, {
			method: "POST",
			headers: {
				...Ko,
				"content-type": "application/json",
				...t.visitorData ? { "x-goog-visitor-id": t.visitorData } : {}
			},
			body: JSON.stringify(a),
			...Jo(r)
		});
		if (!s.ok) throw Error(`Player API request failed with status ${s.status}`);
		let c = await s.json(), l = !!c.streamingData?.formats?.length, u = !!c.streamingData?.adaptiveFormats?.length;
		if (!l && !u) throw Error("Player response did not contain streaming formats");
		return c;
	}
}, ps = "bestefficiency", ms = 3e4;
function hs(e) {
	if (e <= 0) throw RangeError("Audio downloader. ytAudio. chunkSize must be > 0");
}
function gs({ signal: e, timeoutMs: t }) {
	return async (n, r = {}) => await z(n, {
		...r,
		signal: r.signal ?? e,
		forceGmXhr: !0,
		timeout: t
	});
}
function _s(e) {
	return e instanceof zo ? !0 : e instanceof Error && /failed to load watch page:\s*403/i.test(e.message);
}
async function vs({ videoId: e, signal: t }, n = {}) {
	let r = n.chunkSize ?? l.minChunkSize;
	hs(r);
	let i = gs({
		signal: t,
		timeoutMs: n.fetchTimeoutMs ?? ms
	}), a = n.createDownloader?.(i) ?? new fs({ fetchImplementation: i });
	try {
		let n = await a.downloadAudioToChunkStream({
			videoId: e,
			videoQuality: ps,
			signal: t
		}, { chunkSize: r });
		return {
			fileId: jo(Rt.WEB_API_STEAL_SIG_AND_N, n.itag, String(n.fileSize), r),
			mediaPartsLength: n.mediaPartsLength,
			getMediaBuffers: n.getMediaBuffers
		};
	} catch (e) {
		if (_s(e)) throw e;
		console.warn("[VOT] ytAudio streaming mode failed, falling back to buffered mode", e);
	}
	let o = (await a.downloadAudioToUint8Array({
		videoId: e,
		videoQuality: ps,
		signal: t
	})).bytes;
	if (!o || o.byteLength === 0) throw Error("Audio downloader. ytAudio. Empty audio");
	let s = Math.max(1, Math.ceil(o.byteLength / r));
	return {
		fileId: jo(Rt.WEB_API_STEAL_SIG_AND_N, 0, String(o.byteLength), r),
		mediaPartsLength: s,
		async *getMediaBuffers() {
			for (let e = 0; e < o.byteLength; e += r) {
				let t = Math.min(e + r, o.byteLength);
				yield o.subarray(e, t);
			}
		}
	};
}
//#endregion
//#region src/audioDownloader/strategies/index.ts
var ys = "ytAudio", bs = { [ys]: vs };
//#endregion
//#region src/audioDownloader/index.ts
function xs(e) {
	if (!Number.isInteger(e) || e < 1) throw Error("Audio downloader. Invalid media parts length");
}
function Ss(e) {
	if (!e || e.byteLength === 0) throw Error("Audio downloader. Empty audio");
	return e;
}
async function Cs({ audioDownloader: e, translationId: t, videoId: n, signal: r }) {
	let i = await bs[e.strategy]({
		videoId: n,
		signal: r
	});
	if (!i) throw Error("Audio downloader. Can not get audio data");
	L.log("Audio downloader. Url found", { audioDownloadType: e.strategy });
	let { getMediaBuffers: a, mediaPartsLength: o, fileId: s } = i;
	if (xs(o), o < 2) {
		let { value: r } = await a().next(), i = Ss(r);
		await e.onDownloadedAudio.dispatchAsync(t, {
			videoId: n,
			fileId: s,
			audioData: i
		});
		return;
	}
	let c = 0;
	for await (let r of a()) {
		let i = Ss(r);
		await e.onDownloadedPartialAudio.dispatchAsync(t, {
			videoId: n,
			fileId: s,
			audioData: i,
			version: 1,
			index: c,
			amount: o
		}), c++;
	}
	if (c !== o) throw Error(`Audio downloader. Expected ${o} chunks, got ${c}`);
}
var ws = class {
	onDownloadedAudio = new H();
	onDownloadedPartialAudio = new H();
	onDownloadAudioError = new H();
	strategy;
	constructor(e = ys) {
		this.strategy = e, L.log("Audio downloader created", { strategy: e });
	}
	async runAudioDownload(e, t, n) {
		try {
			await Cs({
				audioDownloader: this,
				translationId: t,
				videoId: e,
				signal: n
			}), L.log("Audio downloader. Audio download finished", { videoId: e });
		} catch (t) {
			L.error("Audio downloader. Failed to download audio", {
				videoId: e,
				error: t instanceof Error ? t.message : String(t)
			}), this.onDownloadAudioError.dispatch(e);
		}
	}
	addEventListener(e, t) {
		switch (e) {
			case "downloadedAudio":
				this.onDownloadedAudio.addListener(t);
				break;
			case "downloadedPartialAudio":
				this.onDownloadedPartialAudio.addListener(t);
				break;
			case "downloadAudioError":
				this.onDownloadAudioError.addListener(t);
				break;
		}
		return this;
	}
	removeEventListener(e, t) {
		switch (e) {
			case "downloadedAudio":
				this.onDownloadedAudio.removeListener(t);
				break;
			case "downloadedPartialAudio":
				this.onDownloadedPartialAudio.removeListener(t);
				break;
			case "downloadAudioError":
				this.onDownloadAudioError.removeListener(t);
				break;
		}
		return this;
	}
}, Ts = .66;
function Es(e, t) {
	let n = Math.floor(e / 60);
	if (Math.floor(e % 60) / 60 >= Ts && (n += 1), n >= 60) return t("translationTakeMoreThanHour");
	if (n <= 1) return t("translationTakeAboutMinute");
	let r = String(n);
	return n !== 11 && n % 10 == 1 ? t("translationTakeApproximatelyMinute2").replace("{0}", r) : ![
		12,
		13,
		14
	].includes(n) && [
		2,
		3,
		4
	].includes(n % 10) ? t("translationTakeApproximatelyMinute").replace("{0}", r) : t("translationTakeApproximatelyMinutes").replace("{0}", r);
}
//#endregion
//#region src/utils/VOTLocalizedError.ts
var U = class extends Error {
	name = "VOTLocalizedError";
	unlocalizedMessage;
	localizedMessage;
	constructor(e) {
		super(V.getDefault(e)), this.unlocalizedMessage = e, this.localizedMessage = V.get(e);
	}
};
//#endregion
//#region src/videoHandler/modules/translationShared.ts
function Ds(e) {
	return e ?? null;
}
async function Os(e, t) {
	let n = await e.translateVideoImpl(t.videoData, t.requestLang, t.responseLang, Ds(t.translationHelp), !t.useAudioDownload, t.signal);
	return n?.url ? {
		url: n.url,
		usedLivelyVoice: !!n.usedLivelyVoice
	} : null;
}
function ks(e) {
	return {
		videoId: e.videoId,
		from: e.requestLang,
		to: e.responseLang,
		url: e.downloadTranslationUrl ?? e.fallbackUrl,
		useLivelyVoice: e.usedLivelyVoice
	};
}
async function As(e) {
	return !(e.isActionStale(e.actionContext) || (await e.updateTranslation(e.url, e.actionContext), e.isActionStale(e.actionContext)));
}
async function js(e) {
	let t = await Os(e.requester, {
		videoData: e.request.videoData,
		requestLang: e.request.requestLang,
		responseLang: e.request.responseLang,
		translationHelp: e.request.translationHelp,
		useAudioDownload: e.request.useAudioDownload,
		signal: e.request.signal
	});
	return !t || !await As({
		url: t.url,
		actionContext: e.actionContext,
		isActionStale: e.isActionStale,
		updateTranslation: e.updateTranslation
	}) || e.isActionStale(e.actionContext) ? null : t;
}
function Ms(e) {
	e.setTranslation(e.cacheKey, ks({
		videoId: e.videoId,
		requestLang: e.requestLang,
		responseLang: e.responseLang,
		fallbackUrl: e.fallbackUrl,
		downloadTranslationUrl: e.downloadTranslationUrl,
		usedLivelyVoice: e.usedLivelyVoice
	}));
}
function Ns(e) {
	return e.aborted || !e.translateApiErrorsEnabled || !e.hadAsyncWait ? e.hadAsyncWait : (e.notify({
		videoId: e.videoId,
		message: e.error
	}), !1);
}
//#endregion
//#region src/core/translationHandler.ts
function Ps(e) {
	if (!e || typeof e != "object") return null;
	let t = e, n = t.data && typeof t.data == "object" ? t.data : void 0;
	return {
		name: t.name,
		message: t.message,
		data: n
	};
}
function Fs(e) {
	let t = Ps(e)?.data?.message;
	return typeof t == "string" && t.length > 0 ? t : void 0;
}
function Is(e) {
	let t = Ps(e);
	if (!t || t.name !== "VOTJSError") return e;
	let n = typeof t.message == "string" ? t.message : "", r = typeof t.data?.message == "string" && t.data.message.length > 0;
	return n === "Yandex couldn't translate video" && !r || n === "Failed to request video translation" ? new U("requestTranslationFailed") : n === "Audio link wasn't received" || n === "Audio link wasn't received from VOT response" ? new U("audioNotReceived") : e;
}
var Ls = class {
	videoHandler;
	audioDownloader;
	downloading;
	downloadWaiters = /* @__PURE__ */ new Set();
	requestedFailAudio = /* @__PURE__ */ new Set();
	constructor(e) {
		this.videoHandler = e, this.audioDownloader = new ws(), this.downloading = !1, this.audioDownloader.addEventListener("downloadedAudio", this.onDownloadedAudio).addEventListener("downloadedPartialAudio", this.onDownloadedPartialAudio).addEventListener("downloadAudioError", this.onDownloadAudioError);
	}
	onDownloadedAudio = async (e, t) => {
		if (L.log("downloadedAudio", t), !this.downloading) {
			L.log("skip downloadedAudio");
			return;
		}
		let { videoId: n, fileId: r, audioData: i } = t, a = this.getCanonicalUrl(n);
		try {
			await this.videoHandler.votClient.requestVtransAudio(a, e, {
				audioFile: i,
				fileId: r
			});
		} catch (e) {
			L.error("Failed to upload downloaded audio", e), this.finishDownloadFailure(/* @__PURE__ */ Error("Audio downloader failed while uploading full audio"));
			return;
		}
		this.finishDownloadSuccess();
	};
	onDownloadedPartialAudio = async (e, t) => {
		if (L.log("downloadedPartialAudio", t), !this.downloading) {
			L.log("skip downloadedPartialAudio");
			return;
		}
		let { audioData: n, fileId: r, videoId: i, amount: a, version: o, index: s } = t, c = this.getCanonicalUrl(i);
		try {
			await this.videoHandler.votClient.requestVtransAudio(c, e, {
				audioFile: n,
				chunkId: s
			}, {
				audioPartsLength: a,
				fileId: r,
				version: o
			});
		} catch (e) {
			L.error("Failed to upload downloaded audio chunk", e), this.finishDownloadFailure(/* @__PURE__ */ Error("Audio downloader failed while uploading chunk"));
			return;
		}
		s === a - 1 && this.finishDownloadSuccess();
	};
	onDownloadAudioError = async (e) => {
		if (!this.downloading) {
			L.log("skip downloadAudioError");
			return;
		}
		L.log(`Failed to download audio ${e}`);
		let t = this.getCanonicalUrl(e);
		if (!(this.videoHandler.site.host === "youtube" && this.videoHandler.data?.useAudioDownload)) {
			this.finishDownloadFailure(new U("VOTFailedDownloadAudio"));
			return;
		}
		try {
			this.requestedFailAudio.has(t) ? L.log("fail-audio-js request already sent for this video") : (L.log("Sending fail-audio-js request"), await this.videoHandler.votClient.requestVtransFailAudio(t), this.requestedFailAudio.add(t)), this.finishDownloadSuccess();
		} catch (e) {
			L.error("fail-audio-js request failed", e), this.finishDownloadFailure(new U("VOTFailedDownloadAudio"));
		}
	};
	finishDownloadSuccess() {
		this.downloading = !1, this.resolveDownloadWaiters();
	}
	finishDownloadFailure(e) {
		this.downloading = !1, this.rejectDownloadWaiters(e);
	}
	getCanonicalUrl(e) {
		return `https://youtu.be/${e}`;
	}
	isLivelyVoiceUnavailableError(e) {
		let t = fa(e);
		return !!t && t.toLowerCase().includes("обычная озвучка");
	}
	scheduleRetry(e, t, n) {
		return new Promise((r, i) => {
			let a = null, o = () => {
				a !== null && clearTimeout(a), n.removeEventListener("abort", s);
			}, s = () => {
				o(), i(ma());
			};
			if (n.addEventListener("abort", s, { once: !0 }), n.aborted) {
				s();
				return;
			}
			a = setTimeout(async () => {
				if (n.aborted) {
					s();
					return;
				}
				o();
				try {
					r(await e());
				} catch (e) {
					i(e);
				}
			}, t), a !== null && (this.videoHandler.autoRetry = a);
		});
	}
	getVideoTranslationRetryDelayMs(e, t) {
		return e > 0 ? 25e3 : t <= 600 ? 6e4 : 75e3;
	}
	async translateVideoImpl(e, t, n, r = null, i = !1, a = ha, o = {}) {
		let { disableLivelyVoice: s = !1, retryAttempt: c = 0 } = o;
		clearTimeout(this.videoHandler.autoRetry), this.finishDownloadSuccess();
		let l = this.videoHandler.getRequestLangForTranslation(t, n);
		L.log(e, `Translate video (requestLang: ${t}, requestLangForApi: ${l}, responseLang: ${n})`);
		let u = s;
		try {
			ga(a);
			let o = this.videoHandler.isLivelyVoiceAllowed(l, n), s = await this.requestTranslationWithLivelyFallback({
				videoData: e,
				requestLangForApi: l,
				responseLang: n,
				translationHelp: r,
				shouldSendFailedAudio: i,
				livelyDisabled: u,
				livelyVoiceAllowed: o
			});
			u = s.livelyDisabled;
			let d = s.useLivelyVoice, f = s.response;
			if (!f) throw Error("Failed to get translation response");
			if (L.log("Translate video result", f), ga(a), f.translated && f.remainingTime < 1) return L.log("Video translation finished with this data: ", f), {
				...f,
				usedLivelyVoice: d
			};
			let p = f.message ?? V.get("translationTakeFewMinutes");
			if (await this.videoHandler.updateTranslationErrorMsg(f.remainingTime > 0 ? Es(f.remainingTime, (e) => V.get(e)) : p, a), f.status === Lt.AUDIO_REQUESTED && this.videoHandler.isYouTubeHosts()) return this.videoHandler.hadAsyncWait = !0, L.log("Start audio download"), this.downloading = !0, await this.audioDownloader.runAudioDownload(e.videoId, f.translationId, a), L.log("waiting downloading finish"), await this.waitForAudioDownloadCompletion(a, 15e3), await this.translateVideoImpl(e, t, n, r, !0, a, {
				disableLivelyVoice: u,
				retryAttempt: c
			});
		} catch (t) {
			if (pa(t)) return L.log("aborted video translation"), null;
			let n = Is(t);
			return await this.videoHandler.updateTranslationErrorMsg(Fs(n) ?? n, a), this.videoHandler.hadAsyncWait = Ns({
				aborted: !!this.videoHandler.actionsAbortController?.signal?.aborted,
				translateApiErrorsEnabled: !!this.videoHandler.data?.translateAPIErrors,
				hadAsyncWait: this.videoHandler.hadAsyncWait,
				videoId: e.videoId,
				error: t,
				notify: (e) => this.videoHandler.notifier.translationFailed(e)
			}), console.error("[VOT]", t), null;
		}
		return this.videoHandler.hadAsyncWait = !0, this.scheduleRetry(() => this.translateVideoImpl(e, t, n, r, i, a, {
			disableLivelyVoice: u,
			retryAttempt: c + 1
		}), this.getVideoTranslationRetryDelayMs(c, e.duration), a);
	}
	async requestTranslationWithLivelyFallback({ videoData: e, requestLangForApi: t, responseLang: n, translationHelp: r, shouldSendFailedAudio: i, livelyDisabled: a, livelyVoiceAllowed: o }) {
		let s = !a && o && !!this.videoHandler.data?.useLivelyVoice;
		for (;;) {
			try {
				let o = await this.videoHandler.votClient.translateVideo({
					videoData: e,
					requestLang: t,
					responseLang: n,
					translationHelp: r,
					extraOpts: {
						useLivelyVoice: s,
						videoTitle: this.videoHandler.videoData?.title
					},
					shouldSendFailedAudio: i
				});
				if (!s || !this.isLivelyVoiceUnavailableError(o)) return {
					response: o,
					useLivelyVoice: s,
					livelyDisabled: a
				};
				L.log("[translateVideoImpl] Server responded that lively voices are unavailable. Falling back to standard translation.", o);
			} catch (e) {
				if (!s || !this.isLivelyVoiceUnavailableError(e)) throw e;
				L.log("[translateVideoImpl] Lively voices are unavailable. Falling back to standard translation.", e);
			}
			a = !0, s = !1;
		}
	}
	waitForAudioDownloadCompletion(e, t) {
		return this.downloading ? new Promise((n, r) => {
			let i, a = () => {
				s(), r(ma());
			}, o = setTimeout(() => {
				s(), n();
			}, t), s = () => {
				clearTimeout(o), e.removeEventListener("abort", a), this.downloadWaiters.delete(i);
			};
			i = {
				resolve: () => {
					s(), n();
				},
				reject: (e) => {
					s(), r(e);
				}
			}, this.downloadWaiters.add(i), e.addEventListener("abort", a, { once: !0 }), e.aborted && a();
		}) : Promise.resolve();
	}
	resolveDownloadWaiters() {
		this.forEachDownloadWaiter((e) => e.resolve());
	}
	rejectDownloadWaiters(e) {
		this.forEachDownloadWaiter((t) => t.reject(e));
	}
	forEachDownloadWaiter(e) {
		if (!this.downloadWaiters.size) return;
		let t = Array.from(this.downloadWaiters);
		this.downloadWaiters.clear();
		for (let n of t) e(n);
	}
}, Rs = class {
	state = { status: "idle" };
	deps;
	constructor(e) {
		this.deps = e;
	}
	get currentState() {
		return this.state;
	}
	setState(e) {
		this.state = e, L.log("[TranslationOrchestrator] state", e);
	}
	reset() {
		this.setState({ status: "idle" });
	}
	async runAutoTranslationIfEligible() {
		if (this.state.status === "idle" && this.deps.isFirstPlay() && this.deps.isAutoTranslateEnabled() && this.deps.getVideoId()) {
			if (this.deps.isMobileYouTubeMuted?.()) {
				L.log("[TranslationOrchestrator] Mobile YouTube video is muted, deferring auto-translate"), this.setState({
					status: "deferred",
					reason: "muted"
				}), this.deps.setMuteWatcher?.(() => {
					L.log("[TranslationOrchestrator] Video unmuted, running deferred auto-translate"), this.setState({ status: "idle" }), this.runAutoTranslationIfEligible();
				});
				return;
			}
			this.setState({
				status: "pending",
				reason: "auto"
			});
			try {
				await this.deps.scheduleAutoTranslate(), this.deps.setFirstPlay(!1), this.reset();
			} catch (e) {
				throw this.setState({
					status: "error",
					message: e
				}), e;
			}
		}
	}
};
//#endregion
//#region src/core/lifecycleShared.ts
function zs(e, t = {}) {
	let { requireVideoData: n = !1, clearVideoData: r = !1 } = t;
	n && !e.videoData || (r && (e.videoData = void 0), e.stopTranslation(), e.resetSubtitlesWidget());
}
function Bs(e, t = {}) {
	let { hideMenu: n = !1 } = t;
	e?.votButton?.container && (e.votButton.container.hidden = !0), n && e?.votMenu && (e.votMenu.hidden = !0);
}
function Vs(e, t, n = {}) {
	let { requireVideoData: r, clearVideoData: i, hideMenu: a } = n;
	zs(e, {
		requireVideoData: r,
		clearVideoData: i
	}), Bs(t, { hideMenu: a });
}
//#endregion
//#region src/core/videoLifecycleController.ts
var Hs = class {
	host;
	lifecycleGeneration = 0;
	lastSetCanPlaySourceKey = "";
	activeSetCanPlaySourceKey = "";
	setCanPlayRequested = !1;
	setCanPlayLoopPromise;
	constructor(e) {
		this.host = e;
	}
	isStale(e) {
		return e !== this.lifecycleGeneration;
	}
	resetActions(e) {
		if (typeof this.host.resetActionsAbortController == "function") {
			this.host.resetActionsAbortController(e);
			return;
		}
		this.host.actionsAbortController?.abort(e);
	}
	invalidateActiveSession(e) {
		this.lifecycleGeneration !== 0 && (this.lifecycleGeneration += 1, this.resetActions(`[VideoLifecycle] ${e}`), L.log(`[VideoLifecycle] cancelled active session (active: ${this.lifecycleGeneration})`, { reason: e }));
	}
	startSession(e) {
		this.lifecycleGeneration += 1;
		let t = this.lifecycleGeneration;
		return this.resetActions(`[VideoLifecycle][session:${t}] ${e}`), L.log(`[VideoLifecycle][session:${t}] started`, { reason: e }), t;
	}
	shouldAbortHandleSrcChanged(e, t) {
		return this.isStale(e) ? (L.log(`[VideoLifecycle][session:${e}] handleSrcChanged aborted at ${t} (active: ${this.lifecycleGeneration})`), !0) : !1;
	}
	showOverlayButton(e) {
		e.votButton.container.hidden = !1, e.votButton.opacity = 1, this.host.queueOverlayAutoHide?.();
	}
	teardown() {
		this.setCanPlayRequested = !1, this.invalidateActiveSession("teardown");
	}
	getCurrentSourceKey() {
		let e = this.host.video.srcObject ? "1" : "0";
		if (this.host.site.host === "youtube") {
			let t = globalThis.location.pathname;
			return `${`${globalThis.location.origin}${t}${globalThis.location.search}`}||${e}`;
		}
		let t = this.host.video.currentSrc || this.host.video.src || "";
		return `${globalThis.location.href}||${t}||${e}`;
	}
	resolveContainer() {
		let { site: e, video: t, container: n } = this.host;
		return e.selector ? Oo(t, e.selector) || (n.isConnected && xo(n, t) ? n : t.parentElement ?? n) : t.parentElement ?? n;
	}
	async setCanPlay() {
		if (this.setCanPlayRequested = !0, this.setCanPlayLoopPromise !== void 0) {
			let e = this.getCurrentSourceKey();
			return this.activeSetCanPlaySourceKey && e !== this.activeSetCanPlaySourceKey ? this.invalidateActiveSession("setCanPlay source changed while previous trigger is running") : L.log("[VideoLifecycle] setCanPlay deduplicated for same source", { sourceKey: e }), await this.setCanPlayLoopPromise;
		}
		let e = (async () => {
			for (; this.setCanPlayRequested;) this.setCanPlayRequested = !1, await this.runSetCanPlayOnce();
		})();
		this.setCanPlayLoopPromise = e;
		try {
			await e;
		} finally {
			this.setCanPlayLoopPromise === e && (this.setCanPlayLoopPromise = void 0);
		}
	}
	async runSetCanPlayOnce() {
		let e = this.getCurrentSourceKey();
		if (this.host.videoData?.videoId && e === this.lastSetCanPlaySourceKey) {
			L.log("[VideoLifecycle] setCanPlay deduplicated for same source", { sourceKey: e });
			return;
		}
		let t;
		try {
			t = await this.host.getVideoData();
		} catch (t) {
			L.log(`[VideoLifecycle] getVideoData failed for source ${e}`, t), this.host.videoData = void 0, Bs(this.host.uiManager.votOverlayView, { hideMenu: !0 });
			return;
		}
		if (this.getCurrentSourceKey() !== e) {
			L.log("[VideoLifecycle] discarded stale getVideoData result after source change", { sourceKey: e });
			return;
		}
		this.host.videoData = t, this.activeSetCanPlaySourceKey = e;
		let n = this.startSession(`setCanPlay (source: ${e})`);
		L.log(`[VideoLifecycle][session:${n}] setCanPlay started`, { sourceKey: e });
		try {
			if (await this.handleSrcChanged(n, e), this.isStale(n)) {
				L.log(`[VideoLifecycle][session:${n}] setCanPlay aborted after src change (active: ${this.lifecycleGeneration})`);
				return;
			}
			let t = this.runAutoSubtitlesIfEnabled(n);
			if (await this.host.translationOrchestrator.runAutoTranslationIfEligible(), this.isStale(n)) {
				L.log(`[VideoLifecycle][session:${n}] auto-translation result ignored (stale session)`);
				return;
			}
			if (await t, this.isStale(n)) {
				L.log(`[VideoLifecycle][session:${n}] auto-subtitles result ignored (stale session)`);
				return;
			}
			L.log(`[VideoLifecycle][session:${n}] setCanPlay finished`);
		} finally {
			this.activeSetCanPlaySourceKey === e && (this.activeSetCanPlaySourceKey = "");
		}
	}
	async runAutoSubtitlesIfEnabled(e) {
		if (!(!this.host.data.autoSubtitles || !this.host.videoData?.videoId)) try {
			await this.host.enableSubtitlesForCurrentLangPair();
		} catch (t) {
			L.log(`[VideoLifecycle][session:${e}] auto-subtitles failed`, t);
		}
	}
	async handleSrcChanged(e, t) {
		let n = typeof e == "number" ? e : this.startSession("manual handleSrcChanged"), r = typeof t == "string" && t.length > 0 ? t : this.getCurrentSourceKey();
		if (this.shouldAbortHandleSrcChanged(n, "before start")) return;
		L.log(`[VideoLifecycle][session:${n}] src changed`, { sourceKey: r }), this.host.translationOrchestrator.reset(), this.host.firstPlay = !0;
		let i = this.host.uiManager.votOverlayView;
		Vs(this.host, i, { requireVideoData: !0 }), !this.host.video.src && !this.host.video.currentSrc && !this.host.video.srcObject && Bs(i, { hideMenu: !0 });
		let a = this.resolveContainer();
		if (a !== this.host.container && (this.host.container = a), this.shouldAbortHandleSrcChanged(n, "before getVideoData") || (this.showOverlayButton(i), this.shouldAbortHandleSrcChanged(n, "after getVideoData"))) return;
		if (!this.host.videoData?.videoId) {
			L.log(`[VideoLifecycle][session:${n}] No videoId resolved, hiding overlay`), Bs(i, { hideMenu: !0 });
			return;
		}
		let o = this.host.getPreferredSubtitlesLanguage(this.host.videoData.detectedLanguage, this.host.videoData.responseLanguage);
		if (o) {
			let e = this.host.getSubtitlesCacheKey(this.host.videoData.videoId, this.host.videoData.detectedLanguage, o), t = this.host.cacheManager.getSubtitles(e);
			this.host.subtitles = t ?? [], this.host.subtitlesCacheKey = t === void 0 ? null : e;
		} else this.host.subtitles = [], this.host.subtitlesCacheKey = null;
		await this.host.updateSubtitlesLangSelect(), !this.shouldAbortHandleSrcChanged(n, "after subtitles update") && (this.host.translateToLang = this.host.data.responseLanguage ?? "ru", this.host.setSelectMenuValues(this.host.videoData.detectedLanguage, this.host.videoData.responseLanguage), this.showOverlayButton(i), this.lastSetCanPlaySourceKey = r, L.log(`[VideoLifecycle][session:${n}] src handling finished`));
	}
};
//#endregion
//#region src/core/videoLifecycleHost.ts
function Us(e, t) {
	let n = () => e;
	return {
		get video() {
			return n().video;
		},
		get site() {
			return n().site;
		},
		get container() {
			return n().container;
		},
		set container(e) {
			n().container !== e && (n().container = e, n().uiManager.updateMount(t(e)));
		},
		get firstPlay() {
			return n().firstPlay;
		},
		set firstPlay(e) {
			n().firstPlay = e;
		},
		stopTranslation: () => e.stopTranslation(),
		get uiManager() {
			return n().uiManager;
		},
		getVideoData: () => e.getVideoData(),
		cacheManager: { getSubtitles: (e) => n().cacheManager.getSubtitles(e) },
		getSubtitlesCacheKey: (t, n, r) => e.getSubtitlesCacheKey(t, n, r),
		getPreferredSubtitlesLanguage: (t, n) => e.getPreferredSubtitlesLanguage(t, n),
		updateSubtitlesLangSelect: () => e.updateSubtitlesLangSelect(),
		enableSubtitlesForCurrentLangPair: () => e.enableSubtitlesForCurrentLangPair(),
		setSelectMenuValues: (t, n) => e.setSelectMenuValues(t, n),
		get translateToLang() {
			return n().translateToLang;
		},
		set translateToLang(e) {
			n().translateToLang = e;
		},
		get data() {
			return n().data ?? {};
		},
		get subtitles() {
			return n().subtitles;
		},
		set subtitles(e) {
			n().subtitles = e;
		},
		get subtitlesCacheKey() {
			return n().subtitlesCacheKey;
		},
		set subtitlesCacheKey(e) {
			n().subtitlesCacheKey = e;
		},
		get videoData() {
			return n().videoData;
		},
		set videoData(e) {
			n().videoData = e;
		},
		get actionsAbortController() {
			return n().actionsAbortController;
		},
		set actionsAbortController(e) {
			n().actionsAbortController = e;
		},
		resetActionsAbortController: (t) => e.resetActionsAbortController(t),
		translationOrchestrator: e.translationOrchestrator,
		resetSubtitlesWidget: () => e.resetSubtitlesWidget(),
		queueOverlayAutoHide: () => e.overlayVisibility?.queueAutoHide()
	};
}
//#endregion
//#region src/utils/text.ts
var Ws = 450, Gs = new RegExp([
	String.raw`(?:https?:\/\/|www\.)\S+`,
	String.raw`#[^\s#]+`,
	String.raw`auto-generated\s+by\s+youtube`,
	String.raw`provided\s+to\s+youtube\s+by`,
	String.raw`released\s+on`,
	String.raw`\bpaypal\b`,
	String.raw`\b0x[a-f0-9]{40}\b`,
	String.raw`\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b`,
	String.raw`\b(?:bc1|tb1|bcrt1)[ac-hj-np-z02-9]{11,71}\b`,
	String.raw`\b(?:-1|0):[a-f0-9]{64}\b`
].join("|"), "giu"), Ks = /[\p{N}\p{P}\p{S}]+/gu, qs = /\s+/g, Js = /\p{L}/u;
function Ys(e, t) {
	return e.length <= t ? e : e.slice(0, t).trimEnd();
}
function Xs(e, t) {
	let n = `${e ?? ""} ${t ?? ""}`.trim();
	if (!n) return "";
	let r = n.normalize("NFKC").replace(Gs, " ").replace(Ks, " ").replace(qs, " ").trim();
	return Js.test(r) ? Ys(r, Ws) : "";
}
//#endregion
//#region src/utils/translateApis.ts
var Zs = 5e3, Qs = 2 ** 53 - 1, $s = null, ec = 0, tc = null, nc = 0;
async function rc() {
	let e = Date.now();
	if ($s && e - ec < Zs) return $s;
	let t = await B.get("translationService", pi);
	return $s = String(t), ec = e, $s;
}
async function ic() {
	let e = Date.now();
	if (tc && e - nc < Zs) return tc;
	let t = await B.get("detectService", mi);
	return tc = String(t), nc = e, tc;
}
var ac = ["yandexbrowser", "msedge"], oc = new class {
	isFOSWLYError(e) {
		return Object.hasOwn(e, "error");
	}
	async request(e, t = {}) {
		try {
			let n = await (await z(`${oi}${e}`, {
				timeout: 3e3,
				responseCache: {
					ttlMs: Qs,
					cacheName: "vot-foswly-api-v1",
					allowStaleOnError: !0
				},
				...t
			})).json();
			if (this.isFOSWLYError(n)) throw Error(n.error);
			return n;
		} catch (e) {
			console.error(`[VOT] Failed to get data from FOSWLY Translate API, because ${e instanceof Error ? e.message : String(e)}`);
			return;
		}
	}
	async translateMultiple(e, t, n) {
		let r = await this.request("/translate", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				text: e,
				lang: t,
				service: n
			})
		});
		return r ? r.translations : e;
	}
	async translate(e, t, n) {
		let r = await this.request(`/translate?${new URLSearchParams({
			text: e,
			lang: t,
			service: n
		})}`);
		return r ? r.translations[0] : e;
	}
	async detect(e, t) {
		let n = await this.request(`/detect?${new URLSearchParams({
			text: e,
			service: t
		})}`);
		return n ? n.lang : "en";
	}
}(), sc = { async detect(e) {
	try {
		return await (await z(si, {
			method: "POST",
			body: e,
			timeout: 3e3,
			responseCache: {
				ttlMs: Qs,
				cacheName: "vot-rust-detect-v1",
				allowStaleOnError: !0
			}
		})).text();
	} catch (e) {
		return console.error(`[VOT] Error getting lang from text, because ${e.message}`), "en";
	}
} };
async function cc(e, t = "", n = "ru") {
	if (t && n && t === n) return e;
	let r = await rc();
	switch (r) {
		case "yandexbrowser":
		case "msedge": {
			let i = t && n ? `${t}-${n}` : n;
			return Array.isArray(e) ? await oc.translateMultiple(e, i, r) : await oc.translate(e, i, r);
		}
		default: return e;
	}
}
async function lc(e) {
	let t = await ic();
	switch (t) {
		case "yandexbrowser":
		case "msedge": return await oc.detect(e, t);
		case "rust-server": return await sc.detect(e);
		default: return "en";
	}
}
var uc = [...ac, "rust-server"], dc = 0, fc = 100, pc = .01, mc = 1e-6;
function hc(e, t, n) {
	return !Number.isFinite(e) || n < t ? t : Math.max(t, Math.min(n, e));
}
function gc(e, t, n) {
	return Math.trunc(hc(e, t, n));
}
function W(e, t = dc, n = fc) {
	return Number.isFinite(e) ? gc(Math.round(e), t, n) : t;
}
function _c(e) {
	return W(hc(e, 0, 1) * 100);
}
function vc(e) {
	return W(e) / 100;
}
function yc(e, t, n) {
	if (!Number.isFinite(e) || !Number.isFinite(t) || t <= 0) return e;
	let r = 1 / t, i = e * r;
	switch (n) {
		case "down": return Math.floor(i + mc) / r;
		case "up": return Math.ceil(i - mc) / r;
		default: return Math.round(i) / r;
	}
}
function bc(e, t = "nearest", n = pc) {
	return hc(yc(hc(e, 0, 1), n, t), 0, 1);
}
function xc(e, t, n, r = pc) {
	let i = hc(t, 0, 1), a = hc(n, 0, 1);
	if (a < i) {
		let t = bc(e, "down", r);
		return Math.max(a, t);
	}
	if (a > i) {
		let t = bc(e, "up", r);
		return Math.min(a, t);
	}
	return bc(e, "nearest", r);
}
//#endregion
//#region src/core/hostPolicies.ts
var Sc = new Set(["youtube", "googledrive"]), Cc = Sc, wc = new Set(["rutube", "ok"]), Tc = new Set([
	"youtube",
	"invidious",
	"piped"
]);
function Ec(e) {
	return Sc.has(e);
}
function Dc(e) {
	return Cc.has(e);
}
function Oc(e) {
	return wc.has(e);
}
function kc(e) {
	return Dc(e.host) && e.additionalData !== "mobile";
}
function Ac(e) {
	return Tc.has(e);
}
//#endregion
//#region src/core/videoManager.ts
var jc = {
	rutube: "ru",
	"ok.ru": "ru",
	mail_ru: "ru",
	weverse: "ko",
	niconico: "ja",
	youku: "zh",
	bilibili: "zh",
	weibo: "zh",
	zdf: "de"
}, Mc = ".ytp-volume-panel [aria-valuenow]", Nc = 35, Pc = 500, Fc = new Set(dn), Ic = /* @__PURE__ */ new Map();
function Lc(e) {
	let t = Ic.get(e);
	if (t) return t;
	let n = {};
	for (Ic.set(e, n); Ic.size > Pc;) {
		let e = Ic.keys().next().value;
		if (typeof e != "string") break;
		Ic.delete(e);
	}
	return n;
}
function Rc(e) {
	if (typeof e != "string") return;
	let t = e.toLowerCase().split(/[-_]/)[0];
	return Fc.has(t) ? t : void 0;
}
function zc(e) {
	return !!(e && e !== "auto");
}
function Bc(e, t) {
	return Xs(typeof e == "string" ? e : "", typeof t == "string" ? t : void 0);
}
function Vc(e) {
	let t = jc[e];
	if (t) return t;
	if (e === "vk") {
		let e = document.getElementsByTagName("track")?.[0]?.srclang;
		return Rc(e);
	}
}
function Hc(e) {
	if (!Array.isArray(e) || e.length === 0) return;
	let t = (t) => {
		for (let n of e) {
			if (!n || typeof n != "object") continue;
			let e = n;
			if (e.source !== "youtube" || typeof e.translatedFromLanguage == "string" || t && e.isAutoGenerated === !0) continue;
			let r = Rc(e.language);
			if (zc(r)) return r;
		}
	};
	return t(!0) ?? t(!1);
}
async function Uc(e) {
	if (e.isStream) return { detectedLanguage: "auto" };
	if (e.userOverrideLanguage) return { detectedLanguage: e.userOverrideLanguage };
	let t = Vc(e.host);
	if (zc(t)) return {
		detectedLanguage: t,
		cacheLanguage: t
	};
	let n = Rc(e.possibleLanguage);
	if (zc(n)) return {
		detectedLanguage: n,
		cacheLanguage: n
	};
	let r = e.host === "youtube" ? Hc(e.subtitles) : void 0;
	if (zc(r)) return {
		detectedLanguage: r,
		cacheLanguage: r
	};
	if (e.cachedDetectedLanguage) return { detectedLanguage: e.cachedDetectedLanguage };
	if (!e.allowTextLanguageDetection) return { detectedLanguage: "auto" };
	let i = Bc(e.title, e.description);
	if (!i || i.length < Nc) return { detectedLanguage: "auto" };
	let a = await e.detectLanguage(i);
	return a ? {
		detectedLanguage: a,
		cacheLanguage: a
	} : { detectedLanguage: "auto" };
}
function Wc(e) {
	let t = document.querySelector(e), n = t?.getAttribute("aria-valuenow"), r = t?.getAttribute("aria-valuemax"), i = n == null ? NaN : Number.parseFloat(n), a = r == null ? NaN : Number.parseFloat(r);
	return Number.isFinite(i) ? W(Number.isFinite(a) && a > 0 ? i / a * 100 : i) : null;
}
var Gc = class {
	videoHandler;
	constructor(e) {
		this.videoHandler = e;
	}
	setDetectedLanguageCache(e, t) {
		Lc(e).detectedLanguage = t;
	}
	rememberUserLanguageSelection(e, t) {
		let n = Rc(t);
		if (!zc(n)) {
			let t = Ic.get(e);
			t && delete t.userLanguageOverride;
			return;
		}
		let r = Lc(e);
		r.userLanguageOverride = n, r.detectedLanguage = n;
	}
	rememberDetectedLanguage(e, t) {
		let n = Rc(t);
		zc(n) && (this.setDetectedLanguageCache(e, n), this.videoHandler.videoData?.videoId === e && (this.videoHandler.videoData.detectedLanguage = n));
	}
	async detectLanguageSingleFlight(e, t) {
		let n = Lc(e), r = n.detectInFlight;
		if (r !== void 0) return r;
		let i = (async () => {
			L.log(`Detecting language text: ${t}`);
			let e = Rc(await lc(t));
			return zc(e) ? e : void 0;
		})();
		n.detectInFlight = i;
		try {
			return await i;
		} finally {
			n.detectInFlight === i && delete n.detectInFlight;
		}
	}
	async ensureDetectedLanguageForTranslation(e) {
		if (!e?.videoId || e.detectedLanguage !== "auto") return;
		let t = Lc(e.videoId), { detectedLanguage: n, cacheLanguage: r } = await Uc({
			isStream: e.isStream,
			host: this.videoHandler.site.host,
			possibleLanguage: e.detectedLanguage,
			subtitles: e.subtitles,
			userOverrideLanguage: t.userLanguageOverride,
			cachedDetectedLanguage: t.detectedLanguage,
			title: e.title,
			description: e.description,
			allowTextLanguageDetection: !0,
			detectLanguage: async (t) => await this.detectLanguageSingleFlight(e.videoId, t)
		});
		r && this.setDetectedLanguageCache(e.videoId, r), !(!n || n === "auto") && this.videoHandler.setSelectMenuValues(n, this.videoHandler.translateToLang);
	}
	async getVideoData() {
		let { duration: e, url: t, videoId: n, host: r, title: i, translationHelp: a = null, localizedTitle: o, description: s, detectedLanguage: c, subtitles: u, isStream: d = !1 } = await Br(this.videoHandler.site, {
			fetchFn: z,
			video: this.videoHandler.video,
			language: V.lang
		}), f = Lc(n), { detectedLanguage: p, cacheLanguage: m } = await Uc({
			isStream: d,
			host: this.videoHandler.site.host,
			possibleLanguage: c,
			subtitles: u,
			userOverrideLanguage: f.userLanguageOverride,
			cachedDetectedLanguage: f.detectedLanguage,
			title: i,
			description: s,
			allowTextLanguageDetection: !1,
			detectLanguage: async (e) => await this.detectLanguageSingleFlight(n, e)
		});
		m && this.setDetectedLanguageCache(n, m);
		let h = {
			translationHelp: a,
			isStream: d,
			duration: e || this.videoHandler.video?.duration || l.defaultDuration,
			videoId: n,
			url: t,
			host: r,
			detectedLanguage: p,
			responseLanguage: this.videoHandler.translateToLang,
			subtitles: u,
			title: i,
			localizedTitle: o,
			description: s,
			downloadTitle: o ?? i ?? document.title ?? n
		};
		return f.lastLoggedDetectedLanguage !== p && (console.log("[VOT] Detected language:", p), f.lastLoggedDetectedLanguage = p), h;
	}
	async videoValidator() {
		let e = this.videoHandler.videoData, t = this.videoHandler.data;
		if (!e || !t) throw new U("VOTNoVideoIDFound");
		if (L.log("VideoValidator videoData: ", this.videoHandler.videoData), this.videoHandler.data.enabledDontTranslateLanguages && this.videoHandler.data.dontTranslateLanguages?.includes(this.videoHandler.videoData.detectedLanguage)) throw new U("VOTDisableFromYourLang");
		if (this.videoHandler.videoData.isStream) throw new U("VOTStreamNotAvailable");
		if (this.videoHandler.videoData.duration > 14400) throw new U("VOTVideoIsTooLong");
		return !0;
	}
	getVideoVolume() {
		let e = this.videoHandler.video;
		if (e) {
			if (Ec(this.videoHandler.site.host)) {
				let e = Wc(Mc);
				if (e != null) return vc(e);
				let t = F.getVolume();
				if (typeof t == "number" && Number.isFinite(t)) return bc(t);
			}
			return bc(e.volume);
		}
	}
	setVideoVolume(e) {
		let t = bc(e), n = t > 0;
		if (!Ec(this.videoHandler.site.host)) return n && (this.videoHandler.video.muted = !1), this.videoHandler.video.volume = t, this;
		try {
			let e = F.getPlayer(), r = F.setVolume(t);
			if (n && (e?.unMute?.(), this.videoHandler.video.muted = !1), typeof r == "boolean" && r || typeof r == "number" && Number.isFinite(r)) return this;
		} catch {}
		return n && (this.videoHandler.video.muted = !1), this.videoHandler.video.volume = t, this;
	}
	isMuted() {
		return Ec(this.videoHandler.site.host) ? F.isMuted() : this.videoHandler.video?.muted;
	}
	syncVideoVolumeSlider() {
		let e = this.videoHandler.uiManager.votOverlayView;
		if (!e?.isInitialized()) return this;
		let t = Ec(this.videoHandler.site.host) ? Wc(Mc) : null, n = this.isMuted() ? 0 : t ?? _c(this.getVideoVolume() ?? 0);
		return e.videoVolumeSlider.value = n, this.videoHandler.onVideoVolumeSliderSynced?.(n), this;
	}
	setSelectMenuValues(e, t) {
		let n = this.videoHandler.videoData;
		if (!n) return this;
		let r = Rc(e) ?? "auto", i = `${r}->${t}`, a = Lc(n.videoId);
		a.lastLoggedLangPair !== i && (console.log(`[VOT] Set translation from ${r} to ${t}`), a.lastLoggedLangPair = i), n.detectedLanguage = r, n.responseLanguage = t, this.videoHandler.translateFromLang = r, this.videoHandler.translateToLang = t;
		let o = this.videoHandler.uiManager.votOverlayView;
		return o?.isInitialized() ? (o.languagePairSelect.fromSelect.selectTitle = V.getLangLabel(r), o.languagePairSelect.toSelect.selectTitle = V.getLangLabel(t), o.languagePairSelect.fromSelect.setSelectedValue(r), o.languagePairSelect.toSelect.setSelectedValue(t), this) : this;
	}
}, Kc = globalThis, qc = (e) => e, Jc = Kc.trustedTypes, Yc = Jc ? Jc.createPolicy("lit-html", { createHTML: (e) => e }) : void 0, Xc = "$lit$", Zc = `lit$${Math.random().toFixed(9).slice(2)}$`, Qc = "?" + Zc, $c = `<${Qc}>`, el = document, tl = () => el.createComment(""), nl = (e) => e === null || typeof e != "object" && typeof e != "function", rl = Array.isArray, il = (e) => rl(e) || typeof e?.[Symbol.iterator] == "function", al = "[ 	\n\f\r]", ol = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, sl = /-->/g, cl = />/g, ll = RegExp(`>|${al}(?:([^\\s"'>=/]+)(${al}*=${al}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`, "g"), ul = /'/g, dl = /"/g, fl = /^(?:script|style|textarea|title)$/i, pl = (e) => (t, ...n) => ({
	_$litType$: e,
	strings: t,
	values: n
}), ml = pl(1), G = pl(2), hl = Symbol.for("lit-noChange"), K = Symbol.for("lit-nothing"), gl = /* @__PURE__ */ new WeakMap(), _l = el.createTreeWalker(el, 129);
function vl(e, t) {
	if (!rl(e) || !e.hasOwnProperty("raw")) throw Error("invalid template strings array");
	return Yc === void 0 ? t : Yc.createHTML(t);
}
var yl = (e, t) => {
	let n = e.length - 1, r = [], i, a = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", o = ol;
	for (let t = 0; t < n; t++) {
		let n = e[t], s, c, l = -1, u = 0;
		for (; u < n.length && (o.lastIndex = u, c = o.exec(n), c !== null);) u = o.lastIndex, o === ol ? c[1] === "!--" ? o = sl : c[1] === void 0 ? c[2] === void 0 ? c[3] !== void 0 && (o = ll) : (fl.test(c[2]) && (i = RegExp("</" + c[2], "g")), o = ll) : o = cl : o === ll ? c[0] === ">" ? (o = i ?? ol, l = -1) : c[1] === void 0 ? l = -2 : (l = o.lastIndex - c[2].length, s = c[1], o = c[3] === void 0 ? ll : c[3] === "\"" ? dl : ul) : o === dl || o === ul ? o = ll : o === sl || o === cl ? o = ol : (o = ll, i = void 0);
		let d = o === ll && e[t + 1].startsWith("/>") ? " " : "";
		a += o === ol ? n + $c : l >= 0 ? (r.push(s), n.slice(0, l) + Xc + n.slice(l) + Zc + d) : n + Zc + (l === -2 ? t : d);
	}
	return [vl(e, a + (e[n] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), r];
}, bl = class e {
	constructor({ strings: t, _$litType$: n }, r) {
		let i;
		this.parts = [];
		let a = 0, o = 0, s = t.length - 1, c = this.parts, [l, u] = yl(t, n);
		if (this.el = e.createElement(l, r), _l.currentNode = this.el.content, n === 2 || n === 3) {
			let e = this.el.content.firstChild;
			e.replaceWith(...e.childNodes);
		}
		for (; (i = _l.nextNode()) !== null && c.length < s;) {
			if (i.nodeType === 1) {
				if (i.hasAttributes()) for (let e of i.getAttributeNames()) if (e.endsWith(Xc)) {
					let t = u[o++], n = i.getAttribute(e).split(Zc), r = /([.?@])?(.*)/.exec(t);
					c.push({
						type: 1,
						index: a,
						name: r[2],
						strings: n,
						ctor: r[1] === "." ? Tl : r[1] === "?" ? El : r[1] === "@" ? Dl : wl
					}), i.removeAttribute(e);
				} else e.startsWith(Zc) && (c.push({
					type: 6,
					index: a
				}), i.removeAttribute(e));
				if (fl.test(i.tagName)) {
					let e = i.textContent.split(Zc), t = e.length - 1;
					if (t > 0) {
						i.textContent = Jc ? Jc.emptyScript : "";
						for (let n = 0; n < t; n++) i.append(e[n], tl()), _l.nextNode(), c.push({
							type: 2,
							index: ++a
						});
						i.append(e[t], tl());
					}
				}
			} else if (i.nodeType === 8) if (i.data === Qc) c.push({
				type: 2,
				index: a
			});
			else {
				let e = -1;
				for (; (e = i.data.indexOf(Zc, e + 1)) !== -1;) c.push({
					type: 7,
					index: a
				}), e += Zc.length - 1;
			}
			a++;
		}
	}
	static createElement(e, t) {
		let n = el.createElement("template");
		return n.innerHTML = e, n;
	}
};
function xl(e, t, n = e, r) {
	if (t === hl) return t;
	let i = r === void 0 ? n._$Cl : n._$Co?.[r], a = nl(t) ? void 0 : t._$litDirective$;
	return i?.constructor !== a && (i?._$AO?.(!1), a === void 0 ? i = void 0 : (i = new a(e), i._$AT(e, n, r)), r === void 0 ? n._$Cl = i : (n._$Co ??= [])[r] = i), i !== void 0 && (t = xl(e, i._$AS(e, t.values), i, r)), t;
}
var Sl = class {
	constructor(e, t) {
		this._$AV = [], this._$AN = void 0, this._$AD = e, this._$AM = t;
	}
	get parentNode() {
		return this._$AM.parentNode;
	}
	get _$AU() {
		return this._$AM._$AU;
	}
	u(e) {
		let { el: { content: t }, parts: n } = this._$AD, r = (e?.creationScope ?? el).importNode(t, !0);
		_l.currentNode = r;
		let i = _l.nextNode(), a = 0, o = 0, s = n[0];
		for (; s !== void 0;) {
			if (a === s.index) {
				let t;
				s.type === 2 ? t = new Cl(i, i.nextSibling, this, e) : s.type === 1 ? t = new s.ctor(i, s.name, s.strings, this, e) : s.type === 6 && (t = new Ol(i, this, e)), this._$AV.push(t), s = n[++o];
			}
			a !== s?.index && (i = _l.nextNode(), a++);
		}
		return _l.currentNode = el, r;
	}
	p(e) {
		let t = 0;
		for (let n of this._$AV) n !== void 0 && (n.strings === void 0 ? n._$AI(e[t]) : (n._$AI(e, n, t), t += n.strings.length - 2)), t++;
	}
}, Cl = class e {
	get _$AU() {
		return this._$AM?._$AU ?? this._$Cv;
	}
	constructor(e, t, n, r) {
		this.type = 2, this._$AH = K, this._$AN = void 0, this._$AA = e, this._$AB = t, this._$AM = n, this.options = r, this._$Cv = r?.isConnected ?? !0;
	}
	get parentNode() {
		let e = this._$AA.parentNode, t = this._$AM;
		return t !== void 0 && e?.nodeType === 11 && (e = t.parentNode), e;
	}
	get startNode() {
		return this._$AA;
	}
	get endNode() {
		return this._$AB;
	}
	_$AI(e, t = this) {
		e = xl(this, e, t), nl(e) ? e === K || e == null || e === "" ? (this._$AH !== K && this._$AR(), this._$AH = K) : e !== this._$AH && e !== hl && this._(e) : e._$litType$ === void 0 ? e.nodeType === void 0 ? il(e) ? this.k(e) : this._(e) : this.T(e) : this.$(e);
	}
	O(e) {
		return this._$AA.parentNode.insertBefore(e, this._$AB);
	}
	T(e) {
		this._$AH !== e && (this._$AR(), this._$AH = this.O(e));
	}
	_(e) {
		this._$AH !== K && nl(this._$AH) ? this._$AA.nextSibling.data = e : this.T(el.createTextNode(e)), this._$AH = e;
	}
	$(e) {
		let { values: t, _$litType$: n } = e, r = typeof n == "number" ? this._$AC(e) : (n.el === void 0 && (n.el = bl.createElement(vl(n.h, n.h[0]), this.options)), n);
		if (this._$AH?._$AD === r) this._$AH.p(t);
		else {
			let e = new Sl(r, this), n = e.u(this.options);
			e.p(t), this.T(n), this._$AH = e;
		}
	}
	_$AC(e) {
		let t = gl.get(e.strings);
		return t === void 0 && gl.set(e.strings, t = new bl(e)), t;
	}
	k(t) {
		rl(this._$AH) || (this._$AH = [], this._$AR());
		let n = this._$AH, r, i = 0;
		for (let a of t) i === n.length ? n.push(r = new e(this.O(tl()), this.O(tl()), this, this.options)) : r = n[i], r._$AI(a), i++;
		i < n.length && (this._$AR(r && r._$AB.nextSibling, i), n.length = i);
	}
	_$AR(e = this._$AA.nextSibling, t) {
		for (this._$AP?.(!1, !0, t); e !== this._$AB;) {
			let t = qc(e).nextSibling;
			qc(e).remove(), e = t;
		}
	}
	setConnected(e) {
		this._$AM === void 0 && (this._$Cv = e, this._$AP?.(e));
	}
}, wl = class {
	get tagName() {
		return this.element.tagName;
	}
	get _$AU() {
		return this._$AM._$AU;
	}
	constructor(e, t, n, r, i) {
		this.type = 1, this._$AH = K, this._$AN = void 0, this.element = e, this.name = t, this._$AM = r, this.options = i, n.length > 2 || n[0] !== "" || n[1] !== "" ? (this._$AH = Array(n.length - 1).fill(/* @__PURE__ */ new String()), this.strings = n) : this._$AH = K;
	}
	_$AI(e, t = this, n, r) {
		let i = this.strings, a = !1;
		if (i === void 0) e = xl(this, e, t, 0), a = !nl(e) || e !== this._$AH && e !== hl, a && (this._$AH = e);
		else {
			let r = e, o, s;
			for (e = i[0], o = 0; o < i.length - 1; o++) s = xl(this, r[n + o], t, o), s === hl && (s = this._$AH[o]), a ||= !nl(s) || s !== this._$AH[o], s === K ? e = K : e !== K && (e += (s ?? "") + i[o + 1]), this._$AH[o] = s;
		}
		a && !r && this.j(e);
	}
	j(e) {
		e === K ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, e ?? "");
	}
}, Tl = class extends wl {
	constructor() {
		super(...arguments), this.type = 3;
	}
	j(e) {
		this.element[this.name] = e === K ? void 0 : e;
	}
}, El = class extends wl {
	constructor() {
		super(...arguments), this.type = 4;
	}
	j(e) {
		this.element.toggleAttribute(this.name, !!e && e !== K);
	}
}, Dl = class extends wl {
	constructor(e, t, n, r, i) {
		super(e, t, n, r, i), this.type = 5;
	}
	_$AI(e, t = this) {
		if ((e = xl(this, e, t, 0) ?? K) === hl) return;
		let n = this._$AH, r = e === K && n !== K || e.capture !== n.capture || e.once !== n.once || e.passive !== n.passive, i = e !== K && (n === K || r);
		r && this.element.removeEventListener(this.name, this, n), i && this.element.addEventListener(this.name, this, e), this._$AH = e;
	}
	handleEvent(e) {
		typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, e) : this._$AH.handleEvent(e);
	}
}, Ol = class {
	constructor(e, t, n) {
		this.element = e, this.type = 6, this._$AN = void 0, this._$AM = t, this.options = n;
	}
	get _$AU() {
		return this._$AM._$AU;
	}
	_$AI(e) {
		xl(this, e);
	}
}, kl = Kc.litHtmlPolyfillSupport;
kl?.(bl, Cl), (Kc.litHtmlVersions ??= []).push("3.3.2");
var q = (e, t, n) => {
	let r = n?.renderBefore ?? t, i = r._$litPart$;
	if (i === void 0) {
		let e = n?.renderBefore ?? null;
		r._$litPart$ = i = new Cl(t.insertBefore(tl(), e), e, void 0, n ?? {});
	}
	return i._$AI(e), i;
}, Al = ".vot-button{--vot-helper-theme:var(--vot-theme-rgb,var(--vot-primary-rgb,33, 150, 243));--vot-helper-ontheme:var(--vot-ontheme-rgb,var(--vot-onprimary-rgb,255, 255, 255));box-sizing:border-box;vertical-align:middle;text-align:center;text-overflow:ellipsis;cursor:pointer;min-width:64px;height:36px;color:rgb(var(--vot-helper-ontheme));background-color:rgb(var(--vot-helper-theme));box-shadow:var(--vot-shadow-1);transition:box-shadow var(--vot-duration-medium) var(--vot-easing-standard);outline:none;font-size:14px;line-height:36px;display:inline-block;position:relative;border-radius:var(--vot-radius-s)!important;padding:0 var(--vot-space-4)!important;font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif)!important;border:none!important;font-weight:500!important}.vot-button:before,.vot-button:after{content:\"\";opacity:0;position:absolute;inset:0;border-radius:inherit!important}.vot-button:before{background-color:rgb(var(--vot-helper-ontheme));transition:opacity var(--vot-duration-medium) var(--vot-easing-standard)}.vot-button:after{transition:opacity var(--vot-duration-slow) var(--vot-easing-standard), background-size var(--vot-duration-slow) var(--vot-easing-standard);background:radial-gradient(circle,currentColor 1%,#0000 1%) 50%/10000% 10000% no-repeat}.vot-button:hover:before{opacity:.08}.vot-button:active:after{opacity:.32;background-size:100% 100%;transition:background-size}.vot-button:hover,.vot-button:active{box-shadow:var(--vot-shadow-2)}.vot-button[disabled=true]{background-color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .12);color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38);box-shadow:none;cursor:initial}.vot-button[disabled=true]:before,.vot-button[disabled=true]:after{opacity:0}.vot-outlined-button{--vot-helper-theme:var(--vot-theme-rgb,var(--vot-primary-rgb,33, 150, 243));box-sizing:border-box;vertical-align:middle;text-align:center;text-overflow:ellipsis;cursor:pointer;min-width:64px;height:36px;color:rgb(var(--vot-helper-theme));background-color:#0000;outline:none;font-size:14px;line-height:34px;display:inline-block;position:relative;border-radius:var(--vot-radius-s)!important;padding:0 var(--vot-space-4)!important;font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif)!important;border:solid 1px var(--vot-border-color)!important;margin:0!important;font-weight:500!important}.vot-outlined-button:before,.vot-outlined-button:after{content:\"\";opacity:0;position:absolute;inset:0;border-radius:inherit!important}.vot-outlined-button:before{background-color:rgb(var(--vot-helper-theme));transition:opacity var(--vot-duration-medium) var(--vot-easing-standard)}.vot-outlined-button:after{transition:opacity var(--vot-duration-slow) var(--vot-easing-standard), background-size var(--vot-duration-slow) var(--vot-easing-standard);background:radial-gradient(circle,currentColor 1%,#0000 1%) 50%/10000% 10000% no-repeat}.vot-outlined-button:hover:before{opacity:.04}.vot-outlined-button:active:after{opacity:.16;background-size:100% 100%;transition:background-size}.vot-outlined-button[disabled=true]{color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38);cursor:initial;background-color:#0000}.vot-outlined-button[disabled=true]:before,.vot-outlined-button[disabled=true]:after{opacity:0}.vot-text-button{--vot-helper-theme:var(--vot-theme-rgb,var(--vot-primary-rgb,33, 150, 243));box-sizing:border-box;vertical-align:middle;text-align:center;text-overflow:ellipsis;cursor:pointer;min-width:64px;height:36px;color:rgb(var(--vot-helper-theme));background-color:#0000;outline:none;font-size:14px;line-height:36px;display:inline-block;position:relative;border-radius:var(--vot-radius-s)!important;padding:0 var(--vot-space-2)!important;font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif)!important;border:none!important;margin:0!important;font-weight:500!important}.vot-text-button:before,.vot-text-button:after{content:\"\";opacity:0;position:absolute;inset:0;border-radius:inherit!important}.vot-text-button:before{background-color:rgb(var(--vot-helper-theme));transition:opacity var(--vot-duration-medium) var(--vot-easing-standard)}.vot-text-button:after{transition:opacity var(--vot-duration-slow) var(--vot-easing-standard), background-size var(--vot-duration-slow) var(--vot-easing-standard);background:radial-gradient(circle,currentColor 1%,#0000 1%) 50%/10000% 10000% no-repeat}.vot-text-button:hover:before{opacity:.04}.vot-text-button:active:after{opacity:.16;background-size:100% 100%;transition:background-size}.vot-text-button[disabled=true]{color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38);cursor:initial;background-color:#0000}.vot-text-button[disabled=true]:before,.vot-text-button[disabled=true]:after{opacity:0}.vot-icon-button{--vot-helper-onsurface:rgba(var(--vot-onsurface-rgb,0, 0, 0), .87);box-sizing:border-box;vertical-align:middle;text-align:center;text-overflow:ellipsis;cursor:pointer;width:36px;min-width:36px;height:36px;fill:var(--vot-helper-onsurface);color:var(--vot-helper-onsurface);background-color:#0000;outline:none;font-size:14px;line-height:36px;display:inline-block;position:relative;font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif)!important;border:none!important;border-radius:50%!important;margin:0!important;padding:0!important;font-weight:500!important}.vot-icon-button:before,.vot-icon-button:after{content:\"\";opacity:0;position:absolute;inset:0;border-radius:inherit!important}.vot-icon-button:before{background-color:var(--vot-helper-onsurface);transition:opacity var(--vot-duration-medium) var(--vot-easing-standard)}.vot-icon-button:after{transition:opacity var(--vot-duration-slow) var(--vot-easing-standard), background-size var(--vot-duration-slow) var(--vot-easing-standard);background:radial-gradient(circle,currentColor 1%,#0000 1%) 50%/10000% 10000% no-repeat}.vot-icon-button:hover:before{opacity:.04}.vot-icon-button:active:after{opacity:.32;background-size:100% 100%;transition:background-size}.vot-icon-button[disabled=true]{color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38);fill:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38);cursor:initial;background-color:#0000}.vot-icon-button[disabled=true]:before,.vot-icon-button[disabled=true]:after{opacity:0}.vot-icon-button svg{fill:inherit;stroke:inherit;width:24px;height:36px}.vot-hotkey{justify-content:flex-start;align-items:center;gap:var(--vot-space-3,12px);flex-wrap:wrap;display:flex}.vot-hotkey-label{word-break:break-word;max-width:80%}.vot-hotkey-button{--vot-helper-theme:var(--vot-theme-rgb,var(--vot-primary-rgb,33, 150, 243));box-sizing:border-box;vertical-align:middle;text-align:center;text-overflow:ellipsis;cursor:pointer;background-color:#0000;outline:none;width:fit-content;min-width:32px;height:fit-content;font-size:15px;line-height:1.5;display:inline-block;position:relative;border-radius:var(--vot-radius-s)!important;padding:0 var(--vot-space-2)!important;font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif)!important;border:solid 1px var(--vot-border-color)!important;margin:0!important;font-weight:400!important}.vot-hotkey-button:before,.vot-hotkey-button:after{content:\"\";opacity:0;position:absolute;inset:0;border-radius:inherit!important}.vot-hotkey-button:before{background-color:rgb(var(--vot-helper-theme));transition:opacity var(--vot-duration-medium) var(--vot-easing-standard)}.vot-hotkey-button:after{transition:opacity var(--vot-duration-slow) var(--vot-easing-standard), background-size var(--vot-duration-slow) var(--vot-easing-standard);background:radial-gradient(circle,currentColor 1%,#0000 1%) 50%/10000% 10000% no-repeat}.vot-hotkey-button:hover:before{opacity:.04}.vot-hotkey-button:active:after{opacity:.16;background-size:100% 100%;transition:background-size}.vot-hotkey-button[data-status=active]{color:rgb(var(--vot-helper-theme))}.vot-hotkey-button[data-status=active]:before{opacity:.04}.vot-hotkey-button[disabled=true]{color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38);cursor:initial;background-color:#0000}.vot-hotkey-button[disabled=true]:before,.vot-hotkey-button[disabled=true]:after{opacity:0}.vot-textfield{display:inline-block;--vot-helper-theme:rgb(var(--vot-theme-rgb,var(--vot-primary-rgb,33, 150, 243)))!important;--vot-helper-safari1:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38)!important;--vot-helper-safari2:rgba(var(--vot-onsurface-rgb,0, 0, 0), .6)!important;--vot-helper-safari3:rgba(var(--vot-onsurface-rgb,0, 0, 0), .87)!important;font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif)!important;text-align:start!important;padding-top:6px!important;font-size:16px!important;line-height:1.5!important;position:relative!important}.vot-textfield>:is(input,textarea){box-sizing:border-box!important;border-style:solid!important;border-width:1px!important;border-color:transparent var(--vot-helper-safari2) var(--vot-helper-safari2)!important;width:100%!important;height:inherit!important;color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .87)!important;-webkit-text-fill-color:currentColor!important;font-family:inherit!important;font-size:inherit!important;line-height:inherit!important;caret-color:var(--vot-helper-theme)!important;background-color:#0000!important;border-radius:4px!important;margin:0!important;padding:15px 13px!important;transition:border .2s,box-shadow .2s!important;box-shadow:inset 1px 0 #0000,inset -1px 0 #0000,inset 0 -1px #0000!important}.vot-textfield>:is(input,textarea):not(:focus):not(:is(.vot-show-placeholder,.vot-show-placeholer))::placeholder{color:#0000!important}.vot-textfield>:is(input,textarea):not(:focus):placeholder-shown{border-top-color:var(--vot-helper-safari2)!important}.vot-textfield>:is(input,textarea)+span{font-family:inherit;width:100%!important;max-height:100%!important;color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .6)!important;cursor:text!important;pointer-events:none!important;font-size:75%!important;line-height:15px!important;transition:color .2s,font-size .2s,line-height .2s!important;display:flex!important;position:absolute!important;top:0!important;left:0!important}.vot-textfield>:is(input,textarea):not(:focus):placeholder-shown+span{font-size:inherit!important;line-height:68px!important}.vot-textfield>input+span:before,.vot-textfield>input+span:after,.vot-textfield>textarea+span:before,.vot-textfield>textarea+span:after{content:\"\"!important;box-sizing:border-box!important;border-top:solid 1px var(--vot-helper-safari2)!important;pointer-events:none!important;min-width:10px!important;height:8px!important;margin-top:6px!important;transition:border .2s,box-shadow .2s!important;display:block!important;box-shadow:inset 0 1px #0000!important}.vot-textfield>input+span:before,.vot-textfield>textarea+span:before{border-left:1px solid #0000!important;border-radius:4px 0!important;margin-right:4px!important}.vot-textfield>input+span:after,.vot-textfield>textarea+span:after{border-right:1px solid #0000!important;border-radius:0 4px!important;flex-grow:1!important;margin-left:4px!important}.vot-textfield>input:is(.vot-show-placeholder,.vot-show-placeholer)+span:before,.vot-textfield>textarea:is(.vot-show-placeholder,.vot-show-placeholer)+span:before{margin-right:0!important}.vot-textfield>input:is(.vot-show-placeholder,.vot-show-placeholer)+span:after,.vot-textfield>textarea:is(.vot-show-placeholder,.vot-show-placeholer)+span:after{margin-left:0!important}.vot-textfield>input:not(:focus):placeholder-shown+span:before,.vot-textfield>input:not(:focus):placeholder-shown+span:after,.vot-textfield>textarea:not(:focus):placeholder-shown+span:before,.vot-textfield>textarea:not(:focus):placeholder-shown+span:after{border-top-color:#0000!important}.vot-textfield:hover>input:not(:disabled),.vot-textfield:hover>textarea:not(:disabled){border-color:transparent var(--vot-helper-safari3) var(--vot-helper-safari3)!important}.vot-textfield:hover>input:not(:disabled)+span:before,.vot-textfield:hover>input:not(:disabled)+span:after,.vot-textfield:hover>textarea:not(:disabled)+span:before,.vot-textfield:hover>textarea:not(:disabled)+span:after{border-top-color:var(--vot-helper-safari3)!important}.vot-textfield:hover>input:not(:disabled):not(:focus):placeholder-shown,.vot-textfield:hover>textarea:not(:disabled):not(:focus):placeholder-shown{border-color:var(--vot-helper-safari3)!important}.vot-textfield>input:focus,.vot-textfield>textarea:focus{border-color:transparent var(--vot-helper-theme) var(--vot-helper-theme)!important;box-shadow:inset 1px 0 var(--vot-helper-theme), inset -1px 0 var(--vot-helper-theme), inset 0 -1px var(--vot-helper-theme)!important;outline:none!important}.vot-textfield>input:focus+span,.vot-textfield>textarea:focus+span{color:var(--vot-helper-theme)!important}.vot-textfield>input:focus+span:before,.vot-textfield>input:focus+span:after,.vot-textfield>textarea:focus+span:before,.vot-textfield>textarea:focus+span:after{border-top-color:var(--vot-helper-theme)!important;box-shadow:inset 0 1px var(--vot-helper-theme)!important}.vot-textfield>input:disabled,.vot-textfield>input:disabled+span,.vot-textfield>textarea:disabled,.vot-textfield>textarea:disabled+span{border-color:transparent var(--vot-helper-safari1) var(--vot-helper-safari1)!important;color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38)!important;pointer-events:none!important}.vot-textfield>input:disabled+span:before,.vot-textfield>input:disabled+span:after,.vot-textfield>textarea:disabled+span:before,.vot-textfield>textarea:disabled+span:after,.vot-textfield>input:disabled:placeholder-shown,.vot-textfield>input:disabled:placeholder-shown+span,.vot-textfield>textarea:disabled:placeholder-shown,.vot-textfield>textarea:disabled:placeholder-shown+span{border-top-color:var(--vot-helper-safari1)!important}.vot-textfield>input:disabled:placeholder-shown+span:before,.vot-textfield>input:disabled:placeholder-shown+span:after,.vot-textfield>textarea:disabled:placeholder-shown+span:before,.vot-textfield>textarea:disabled:placeholder-shown+span:after{border-top-color:#0000!important}@media not all and (resolution>=.001dpcm){@supports ((-webkit-appearance:none)){.vot-textfield>input,.vot-textfield>input+span,.vot-textfield>textarea,.vot-textfield>textarea+span,.vot-textfield>input+span:before,.vot-textfield>input+span:after,.vot-textfield>textarea+span:before,.vot-textfield>textarea+span:after{transition-duration:.1s!important}}}.vot-checkbox{--vot-checkbox-label-offset:30px;--vot-helper-theme:var(--vot-theme-rgb,var(--vot-primary-rgb,33, 150, 243));--vot-helper-ontheme:var(--vot-ontheme-rgb,var(--vot-onprimary-rgb,255, 255, 255));z-index:0;color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .87);text-align:start;font-size:16px;line-height:1.5;display:inline-block;position:relative;font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif)!important;text-transform:none!important}.vot-checkbox-sub{padding-left:var(--vot-checkbox-label-offset)!important}.vot-checkbox>input{appearance:none;z-index:10000;box-sizing:border-box;opacity:1;cursor:pointer;background:0 0;outline:none;width:18px;height:18px;transition:border-color .2s,background-color .2s;display:block;position:absolute;border:2px solid!important;border-color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .6)!important;border-radius:2px!important;margin:3px 1px!important;padding:0!important}.vot-checkbox>input+span{box-sizing:border-box;width:inherit;cursor:pointer;font-family:inherit;display:inline-block;position:relative;padding-left:var(--vot-checkbox-label-offset)!important;font-weight:400!important}.vot-checkbox>input+span:before{content:\"\";background-color:rgb(var(--vot-onsurface-rgb,0, 0, 0));opacity:0;pointer-events:none;width:40px;height:40px;transition:opacity .3s,transform .2s;display:block;position:absolute;top:-8px;left:-10px;transform:scale(1);border-radius:50%!important}.vot-checkbox>input+span:after{content:\"\";z-index:10000;pointer-events:none;width:10px;height:5px;transition:border-color .2s;display:block;position:absolute;top:3px;left:1px;transform:translate(3px,4px)rotate(-45deg);box-sizing:content-box!important;border:0 solid #0000!important;border-width:0 0 2px 2px!important}.vot-checkbox>input:checked,.vot-checkbox>input:indeterminate{background-color:rgb(var(--vot-helper-theme));border-color:rgb(var(--vot-helper-theme))!important}.vot-checkbox>input:checked+span:before,.vot-checkbox>input:indeterminate+span:before{background-color:rgb(var(--vot-helper-theme))}.vot-checkbox>input:checked+span:after,.vot-checkbox>input:indeterminate+span:after{border-color:rgb(var(--vot-helper-ontheme,255, 255, 255))!important}.vot-checkbox>input:hover{box-shadow:none!important}.vot-checkbox>input:indeterminate+span:after{transform:translate(4px,3px);border-left-width:0!important}.vot-checkbox:hover>input+span:before{opacity:.04}.vot-checkbox:active>input,.vot-checkbox:active:hover>input:not(:disabled){border-color:rgb(var(--vot-helper-theme))!important}.vot-checkbox:active>input:checked{background-color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .6);border-color:#0000!important}.vot-checkbox:active>input+span:before{opacity:1;transition:transform,opacity;transform:scale(0)}.vot-checkbox>input:disabled{cursor:initial;border-color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38)!important}.vot-checkbox>input:disabled:checked,.vot-checkbox>input:disabled:indeterminate{background-color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38);border-color:#0000!important}.vot-checkbox>input:disabled+span{color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38);cursor:initial}.vot-checkbox>input:disabled+span:before{opacity:0;transform:scale(0)}html.vot-keyboard-nav .vot-checkbox>input:focus-visible{box-shadow:var(--vot-focus-ring), var(--vot-focus-ring-offset)!important}@supports not selector(:focus-visible){html.vot-keyboard-nav .vot-checkbox>input:focus{box-shadow:var(--vot-focus-ring), var(--vot-focus-ring-offset)!important}}.vot-slider{flex-direction:column;gap:6px;display:flex;width:100%!important;color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .87)!important;font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", BlinkMacSystemFont, system-ui, -apple-system)!important;text-align:start!important;font-size:16px!important;line-height:1.5!important}.vot-slider>span{order:1;margin:0!important;display:block!important}.vot-slider .vot-slider-label{flex-wrap:wrap;align-items:baseline;gap:6px;width:100%;display:inline-flex}.vot-slider-label-value{font-variant-numeric:tabular-nums;margin-left:0!important;font-weight:500!important}.vot-slider .vot-slider-label-text{min-width:0}.vot-slider>input{order:2;appearance:none!important;cursor:pointer!important;background-color:#0000!important;border:none!important;width:100%!important;height:32px!important;margin:0!important;padding:0!important;display:block!important;position:relative!important;top:0!important}.vot-slider>input:hover{box-shadow:none!important}.vot-slider>input:before{content:\"\"!important;width:calc(100% * var(--vot-progress,0))!important;background:rgb(var(--vot-primary-rgb,33, 150, 243))!important;height:2px!important;display:block!important;position:absolute!important;top:calc(50% - 1px)!important}.vot-slider>input:disabled{cursor:default!important;opacity:.38!important}.vot-slider>input:disabled+span{color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38)!important}.vot-slider>input:disabled::-webkit-slider-runnable-track{background-color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38)!important}.vot-slider>input:disabled::-moz-range-track{background-color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38)!important}.vot-slider>input:disabled::-webkit-slider-thumb{background-color:rgb(var(--vot-onsurface-rgb,0, 0, 0))!important;box-shadow:0 0 0 1px rgb(var(--vot-surface-rgb,255, 255, 255))!important;transform:scale(4)!important}.vot-slider>input:disabled::-moz-range-thumb{background-color:rgb(var(--vot-onsurface-rgb,0, 0, 0))!important;box-shadow:0 0 0 1px rgb(var(--vot-surface-rgb,255, 255, 255))!important;transform:scale(4)!important}.vot-slider>input:disabled::-moz-range-progress{background-color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .87)!important}.vot-slider>input:focus{outline:none!important}.vot-slider>input::-webkit-slider-runnable-track{background-color:rgba(var(--vot-primary-rgb,33, 150, 243), .24)!important;border-radius:1px!important;width:100%!important;height:2px!important;margin:15px 0!important}.vot-slider>input::-moz-range-track{background-color:rgba(var(--vot-primary-rgb,33, 150, 243), .24)!important;border-radius:1px!important;width:100%!important;height:2px!important;margin:15px 0!important}.vot-slider>input::-webkit-slider-thumb{appearance:none!important;background-color:rgb(var(--vot-primary-rgb,33, 150, 243))!important;width:2px!important;height:2px!important;box-shadow:none!important;border:none!important;border-radius:50%!important;transition:box-shadow .2s!important;transform:scale(6)!important}.vot-slider>input::-moz-range-thumb{appearance:none!important;background-color:rgb(var(--vot-primary-rgb,33, 150, 243))!important;width:2px!important;height:2px!important;box-shadow:none!important;border:none!important;border-radius:50%!important;transition:box-shadow .2s!important;transform:scale(6)!important}.vot-slider>input::-webkit-slider-thumb{-webkit-appearance:none!important;margin:0!important}.vot-slider>input::-moz-range-progress{background-color:rgb(var(--vot-primary-rgb,33, 150, 243))!important;border-radius:1px!important;height:2px!important}.vot-slider>input:focus:not(:focus-visible)::-webkit-slider-thumb{box-shadow:none!important}.vot-slider>input:focus:not(:focus-visible)::-moz-range-thumb{box-shadow:none!important}html.vot-keyboard-nav .vot-slider>input:focus-visible::-webkit-slider-thumb{box-shadow:0 0 0 2px rgba(var(--vot-primary-rgb,33, 150, 243), .24)!important}html.vot-keyboard-nav .vot-slider>input:focus-visible::-moz-range-thumb{box-shadow:0 0 0 2px rgba(var(--vot-primary-rgb,33, 150, 243), .24)!important}@supports not selector(:focus-visible){html.vot-keyboard-nav .vot-slider>input:focus::-webkit-slider-thumb{box-shadow:0 0 0 2px rgba(var(--vot-primary-rgb,33, 150, 243), .24)!important}html.vot-keyboard-nav .vot-slider>input:focus::-moz-range-thumb{box-shadow:0 0 0 2px rgba(var(--vot-primary-rgb,33, 150, 243), .24)!important}}.vot-select{--vot-helper-theme-rgb:var(--vot-onsurface-rgb,0, 0, 0);--vot-helper-theme:rgba(var(--vot-helper-theme-rgb), .87);--vot-helper-safari1:rgba(var(--vot-onsurface-rgb,0, 0, 0), .6);--vot-helper-safari2:rgba(var(--vot-onsurface-rgb,0, 0, 0), .87);font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif);text-align:start;color:var(--vot-helper-theme);fill:var(--vot-helper-theme);justify-content:space-between;align-items:center;font-size:14px;line-height:1.5;display:flex;font-weight:400!important}.vot-select-outer{cursor:pointer;justify-content:space-between;align-items:center;width:120px;max-width:120px;display:flex;border:1px solid var(--vot-helper-safari1)!important;border-radius:4px!important;padding:0 5px!important;transition:border .2s!important}.vot-select-outer:hover{border-color:var(--vot-helper-safari2)!important}.vot-select-outer[disabled=true]{opacity:.5;cursor:default}.vot-select-outer[disabled=true]:hover{border-color:var(--vot-helper-safari1)!important}.vot-select-title{text-overflow:ellipsis;white-space:nowrap;font-family:inherit;overflow:hidden}.vot-select-arrow-icon{justify-content:center;align-items:center;width:20px;height:32px;display:flex}.vot-select-arrow-icon svg{fill:inherit;stroke:inherit}.vot-select-content-list{flex-direction:column;display:flex}.vot-select-content-list .vot-select-content-item{cursor:pointer;border-radius:8px!important;padding:5px 10px!important}.vot-select-content-list .vot-select-content-item:not([inert]):hover{background-color:#2a2c31}.vot-select-content-list .vot-select-content-item[data-vot-selected=true]{color:rgb(var(--vot-primary-rgb,33, 150, 243));background-color:rgba(var(--vot-primary-rgb,33, 150, 243), .2)}.vot-select-content-list .vot-select-content-item[data-vot-selected=true]:hover{background-color:rgba(var(--vot-primary-rgb,33, 150, 243), .1)!important}.vot-select-content-list .vot-select-content-item[inert]{cursor:default;color:rgba(var(--vot-onsurface-rgb,0, 0, 0), .38)}.vot-header{color:rgba(var(--vot-helper-onsurface-rgb), .87);font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif);text-align:start;line-height:1.5;font-weight:700!important}.vot-header:not(:first-child){padding-top:8px}.vot-header-level-1{font-size:2em}.vot-header-level-2{font-size:1.5em}.vot-header-level-3{font-size:1.17em}.vot-header-level-4{font-size:1em}.vot-header-level-5{font-size:.83em}.vot-header-level-6{font-size:.67em}.vot-info{color:rgba(var(--vot-helper-onsurface-rgb), .87);font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif);text-align:start;-webkit-user-select:text;user-select:text;font-size:16px;line-height:1.5;display:flex}.vot-info>:not(:first-child){color:rgba(var(--vot-helper-onsurface-rgb), .5);flex:1;margin-left:8px!important}.vot-details{color:rgba(var(--vot-helper-onsurface-rgb), .87);font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif);text-align:start;cursor:pointer;transition:background var(--vot-duration-medium) var(--vot-easing-standard);justify-content:space-between;align-items:center;font-size:16px;line-height:1.5;display:flex;border-radius:.5em!important;margin:-.5em!important;padding:.5em!important}.vot-details-arrow-icon{width:20px;height:32px;fill:rgba(var(--vot-helper-onsurface-rgb), .87);justify-content:center;align-items:center;display:flex;transform:scale(1.25)rotate(-90deg)}.vot-details:hover{background:rgba(var(--vot-onsurface-rgb,0, 0, 0), .06)}.vot-settings-section{border:1px solid var(--vot-border-color);border-radius:var(--vot-radius-l);padding:var(--vot-space-2);background:rgba(var(--vot-helper-onsurface-rgb), .03);flex-direction:column;display:flex}.vot-settings-section>*{margin:0!important}.vot-settings-section>*+*{margin-top:var(--vot-space-2)!important}.vot-settings-section-header{border-radius:var(--vot-radius-m);margin:0!important;padding:.45em .5em!important}.vot-settings-section-header .vot-details-arrow-icon{transition:transform var(--vot-duration-medium) var(--vot-easing-standard)}.vot-settings-section-header[data-open=true] .vot-details-arrow-icon{transform:scale(1.25)rotate(0)}.vot-settings-section-content{--vot-settings-control-width:200px;--vot-settings-row-gap:var(--vot-space-2);padding:0 var(--vot-space-1) var(--vot-space-1);flex-direction:column;display:flex}.vot-settings-section-content>*{margin:0!important}.vot-settings-section-content>*+*{margin-top:var(--vot-settings-row-gap)!important}.vot-settings-section-content>.vot-checkbox,.vot-settings-section-content>.vot-hotkey,.vot-settings-section-content>.vot-textfield,.vot-settings-section-content>.vot-select,.vot-settings-section-content>.vot-slider{padding:var(--vot-space-1);box-sizing:border-box;width:100%!important}.vot-settings-section-content>.vot-textfield{gap:var(--vot-space-1);flex-direction:column;padding-top:0!important;display:flex!important}.vot-settings-section-content>.vot-textfield>span{order:0;width:auto!important;max-height:none!important;color:rgba(var(--vot-helper-onsurface-rgb), .72)!important;cursor:default!important;pointer-events:none!important;font-size:13px!important;line-height:1.2!important;display:block!important;position:static!important}.vot-settings-section-content>.vot-textfield>span:before,.vot-settings-section-content>.vot-textfield>span:after{content:none!important;display:none!important}.vot-settings-section-content>.vot-textfield>input,.vot-settings-section-content>.vot-textfield>textarea{transition:border-color var(--vot-duration-fast) var(--vot-easing-standard), background-color var(--vot-duration-fast) var(--vot-easing-standard);order:1;width:100%!important;height:36px!important;padding:0 var(--vot-space-3)!important;border:1px solid var(--vot-border-color)!important;border-radius:var(--vot-radius-s)!important;background:rgba(var(--vot-helper-onsurface-rgb), .04)!important;color:rgba(var(--vot-helper-onsurface-rgb), .9)!important;-webkit-text-fill-color:currentColor!important;box-shadow:none!important}.vot-settings-section-content>.vot-textfield>textarea{resize:vertical;height:auto!important;min-height:84px!important;padding:var(--vot-space-2) var(--vot-space-3)!important}.vot-settings-section-content>.vot-textfield>input::placeholder,.vot-settings-section-content>.vot-textfield>textarea::placeholder{color:rgba(var(--vot-helper-onsurface-rgb), .55)!important}.vot-settings-section-content>.vot-textfield:hover>input,.vot-settings-section-content>.vot-textfield:hover>textarea{border-color:var(--vot-border-color-hover)!important}.vot-settings-section-content>.vot-textfield>input:not(:focus):placeholder-shown,.vot-settings-section-content>.vot-textfield>textarea:not(:focus):placeholder-shown{border-color:var(--vot-border-color)!important}.vot-settings-section-content>.vot-textfield>input:focus,.vot-settings-section-content>.vot-textfield>textarea:focus{border-color:rgba(var(--vot-primary-rgb), .7)!important}.vot-lang-select{--vot-helper-theme-rgb:var(--vot-onsurface-rgb,0, 0, 0);--vot-helper-theme:rgba(var(--vot-helper-theme-rgb), .87);color:var(--vot-helper-theme);fill:var(--vot-helper-theme);justify-content:space-between;align-items:center;display:flex}.vot-lang-select-icon{justify-content:center;align-items:center;width:32px;height:32px;display:flex}.vot-lang-select-icon svg{fill:inherit;stroke:inherit}.vot-segmented-button{--vot-helper-theme-rgb:var(--vot-onsurface-rgb,0, 0, 0);--vot-helper-theme:rgba(var(--vot-helper-theme-rgb), .87);-webkit-user-select:none;user-select:none;background:rgb(var(--vot-surface-rgb,255, 255, 255));max-width:100vw;height:36px;color:var(--vot-helper-theme);fill:var(--vot-helper-theme);cursor:default;transition:opacity var(--vot-duration-slow) var(--vot-easing-standard);z-index:2147483647;align-items:center;font-size:16px;line-height:1.5;display:flex;position:absolute;top:5rem;left:50%;overflow:hidden;transform:translate(-50%);opacity:1!important;pointer-events:auto!important;touch-action:none!important;border:1px solid var(--vot-border-color)!important;border-radius:var(--vot-radius-s)!important;box-shadow:var(--vot-shadow-1)!important;font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif)!important}.vot-segmented-button.vot-segmented-button--hidden{opacity:0!important;pointer-events:none!important}.vot-segmented-button *{box-sizing:border-box!important}.vot-segmented-button .vot-separator{background:rgba(var(--vot-helper-theme-rgb), .1);width:1px;height:50%}.vot-segmented-button .vot-segment,.vot-segmented-button .vot-segment-only-icon{height:100%;color:inherit;transition:background-color var(--vot-duration-fast) var(--vot-easing-standard);-webkit-tap-highlight-color:transparent;background-color:#0000;outline:none;justify-content:center;align-items:center;display:flex;position:relative;overflow:hidden;padding:0 var(--vot-space-2)!important;border:none!important}.vot-segmented-button .vot-segment:focus,.vot-segmented-button .vot-segment-only-icon:focus{box-shadow:inset 0 0 0 2px var(--vot-focus-ring-color);outline:none}.vot-segmented-button .vot-segment:focus:not(:focus-visible),.vot-segmented-button .vot-segment-only-icon:focus:not(:focus-visible){box-shadow:none}.vot-segmented-button .vot-segment:before,.vot-segmented-button .vot-segment-only-icon:before,.vot-segmented-button .vot-segment:after,.vot-segmented-button .vot-segment-only-icon:after{content:\"\";opacity:0;position:absolute;inset:0;border-radius:inherit!important}.vot-segmented-button .vot-segment:before,.vot-segmented-button .vot-segment-only-icon:before{background-color:rgb(var(--vot-helper-theme-rgb));transition:opacity var(--vot-duration-medium) var(--vot-easing-standard)}.vot-segmented-button .vot-segment:after,.vot-segmented-button .vot-segment-only-icon:after{transition:opacity var(--vot-duration-slow) var(--vot-easing-standard), background-size var(--vot-duration-slow) var(--vot-easing-standard);background:radial-gradient(circle,currentColor 1%,#0000 1%) 50%/10000% 10000% no-repeat}.vot-segmented-button .vot-segment:hover:before,.vot-segmented-button .vot-segment-only-icon:hover:before{opacity:.04}.vot-segmented-button .vot-segment:active:after,.vot-segmented-button .vot-segment-only-icon:active:after{opacity:.16;background-size:100% 100%;transition:background-size}.vot-segmented-button .vot-segment-only-icon{min-width:36px;padding:0!important}.vot-segmented-button .vot-segment-label{white-space:nowrap;color:inherit;margin-left:var(--vot-space-2)!important;font-weight:400!important}.vot-segmented-button[data-status=success] .vot-translate-button{color:rgb(var(--vot-primary-rgb,33, 150, 243));fill:rgb(var(--vot-primary-rgb,33, 150, 243))}.vot-segmented-button[data-status=error] .vot-translate-button{color:#f28b82;fill:#f28b82}.vot-segmented-button[data-loading=true] #vot-loading-icon{display:block!important}.vot-segmented-button[data-loading=true] #vot-translate-icon{display:none!important}.vot-segmented-button[data-direction=column]{flex-direction:column;height:fit-content}.vot-segmented-button[data-direction=column] .vot-segment-label{display:none}.vot-segmented-button[data-direction=column]>.vot-segment-only-icon,.vot-segmented-button[data-direction=column]>.vot-segment{padding:8px!important}.vot-segmented-button[data-direction=column] .vot-separator{width:50%;height:1px}.vot-segmented-button[data-position=left]{top:12.5vh;left:50px}.vot-segmented-button[data-position=right]{top:12.5vh;left:auto;right:0}.vot-segmented-button svg{width:24px;fill:inherit;stroke:inherit}.vot-tooltip{--vot-helper-theme-rgb:var(--vot-onsurface-rgb,0, 0, 0);--vot-helper-theme:rgba(var(--vot-helper-theme-rgb), .87);--vot-helper-ondialog:rgb(var(--vot-ondialog-rgb,37, 38, 40));--vot-helper-border:rgb(var(--vot-tooltip-border,69, 69, 69));-webkit-user-select:none;user-select:none;background:rgb(var(--vot-surface-rgb,255, 255, 255));color:var(--vot-helper-theme);fill:var(--vot-helper-theme);cursor:default;z-index:2147483647;opacity:0;align-items:center;width:max-content;max-width:calc(100vw - 10px);height:max-content;font-size:14px;line-height:1.5;transition:opacity .5s;display:flex;position:absolute;inset:0;overflow:hidden;box-shadow:0 1px 3px #0000001f;font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif)!important;border-radius:4px!important;padding:4px 8px!important}.vot-tooltip[data-trigger=click]{-webkit-user-select:text;user-select:text}.vot-tooltip.vot-tooltip-bordered{border:1px solid var(--vot-helper-border)}.vot-tooltip *{box-sizing:border-box!important;font-family:inherit!important}.vot-menu{--vot-helper-surface-rgb:var(--vot-surface-rgb,255, 255, 255);--vot-helper-surface:rgb(var(--vot-helper-surface-rgb));--vot-helper-onsurface-rgb:var(--vot-onsurface-rgb,0, 0, 0);--vot-helper-onsurface:rgba(var(--vot-helper-onsurface-rgb), .87);--vot-settings-control-width:clamp(120px, 45%, 200px);-webkit-user-select:none;user-select:none;background-color:var(--vot-helper-surface);color:var(--vot-helper-onsurface);cursor:default;z-index:2147483646;visibility:visible;opacity:1;transform-origin:top;width:fit-content;min-width:320px;max-width:min(90vw,560px);transition:opacity var(--vot-duration-medium) var(--vot-easing-standard), transform var(--vot-duration-medium) var(--vot-easing-standard);font-size:16px;line-height:1.5;position:absolute;top:calc(5rem + 48px);left:50%;overflow:hidden;transform:translate(-50%)scale(1);border:1px solid var(--vot-border-color)!important;border-radius:var(--vot-radius-m)!important;box-shadow:var(--vot-shadow-2)!important;font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif)!important}.vot-menu *{box-sizing:border-box!important}.vot-menu[hidden]{pointer-events:none;visibility:hidden;opacity:0;transform:translate(-50%,-4px)scale(.98);display:block!important}.vot-menu-content-wrapper{min-width:320px;min-height:100px;max-height:calc(var(--vot-container-height,75vh) - (5rem + 32px + 16px) * 2);flex-direction:column;display:flex;overflow:auto}.vot-menu-header-container{flex-shrink:0;align-items:center;min-height:31px;display:flex;padding-inline-end:var(--vot-space-2)!important}.vot-menu-header-container:empty{padding:0 0 16px!important}.vot-menu-header-container>.vot-icon-button{margin-inline-end:var(--vot-space-1)!important;margin-top:var(--vot-space-1)!important}.vot-menu-title-container{font-size:inherit;text-align:start;outline:0;flex:1;display:flex;font-weight:inherit!important;margin:0!important}.vot-menu-title{flex:1;font-size:16px;line-height:1;padding:var(--vot-space-4)!important;font-weight:500!important}.vot-menu-body-container{box-sizing:border-box;gap:var(--vot-space-2);overscroll-behavior:contain;flex-direction:column;min-height:1.375rem;display:flex;overflow:auto;padding:0 var(--vot-space-4)!important;scrollbar-color:rgba(var(--vot-helper-onsurface-rgb), .1) var(--vot-helper-surface)!important}.vot-menu-body-container::-webkit-scrollbar{background:var(--vot-helper-surface)!important;width:12px!important;height:12px!important}.vot-menu-body-container::-webkit-scrollbar-track{background:var(--vot-helper-surface)!important;width:12px!important;height:12px!important}.vot-menu-body-container::-webkit-scrollbar-thumb{border-radius:1ex;background:rgba(var(--vot-helper-onsurface-rgb), .1)!important;border:5px solid var(--vot-helper-surface)!important}.vot-menu-body-container::-webkit-scrollbar-thumb:hover{border-width:3px!important}.vot-menu-body-container::-webkit-scrollbar-corner{background:var(--vot-helper-surface)!important}.vot-menu-footer-container{flex-shrink:0;justify-content:flex-end;display:flex;padding:var(--vot-space-4)!important}.vot-menu-footer-container:empty{padding:var(--vot-space-4) 0 0 0!important}.vot-menu .vot-select--labeled>.vot-select-outer{margin-left:auto}.vot-menu[data-position=left]{transform-origin:0;top:12.5vh;left:240px}.vot-menu[data-position=right]{transform-origin:100%;top:12.5vh;left:auto;right:-80px}.vot-dialog{--vot-helper-surface-rgb:var(--vot-surface-rgb,255, 255, 255);--vot-helper-surface:rgb(var(--vot-helper-surface-rgb));--vot-helper-onsurface-rgb:var(--vot-onsurface-rgb,0, 0, 0);--vot-helper-onsurface:rgba(var(--vot-helper-onsurface-rgb), .87);--vot-dialog-viewport-margin:16px;--vot-dialog-max-height:75vh;max-width:initial;max-height:initial;width:min(var(--vot-dialog-width,512px), 100%);border:1px solid var(--vot-border-color);border-radius:var(--vot-radius-l);background-color:var(--vot-helper-surface);height:fit-content;color:var(--vot-helper-onsurface);box-shadow:var(--vot-shadow-2);-webkit-user-select:none;user-select:none;visibility:visible;opacity:1;transform-origin:50%;transition:opacity var(--vot-duration-medium) var(--vot-easing-standard), transform var(--vot-duration-medium) var(--vot-easing-standard);font-size:16px;line-height:1.5;display:block;position:fixed;inset-block:0;inset-inline:0;overflow:auto hidden;transform:scale(1);font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif)!important;margin:auto!important;padding:0!important}[hidden]>.vot-dialog{pointer-events:none;opacity:0;transition:opacity var(--vot-duration-fast) var(--vot-easing-standard), transform var(--vot-duration-medium) var(--vot-easing-standard);transform:translateY(-4px)scale(.98)}.vot-dialog[data-vertical-align=top]{inset-block-start:var(--vot-dialog-viewport-margin);inset-block-end:auto;margin:0 auto!important}.vot-dialog-container{visibility:visible;z-index:2147483647;position:absolute}.vot-dialog-container[hidden]{pointer-events:none;visibility:hidden;display:block!important}.vot-dialog-container *{box-sizing:border-box!important}.vot-dialog-backdrop{opacity:1;background-color:#0009;transition:opacity .3s;position:fixed;inset:0}[hidden]>.vot-dialog-backdrop{pointer-events:none;opacity:0}.vot-dialog-content-wrapper{max-height:var(--vot-dialog-max-height,75vh);flex-direction:column;display:flex;overflow:auto}.vot-dialog-header-container{flex-shrink:0;align-items:flex-start;min-height:31px;display:flex}.vot-dialog-header-container:empty{padding:0 0 20px}.vot-dialog-header-container>.vot-icon-button{margin-inline-end:var(--vot-space-1)!important;margin-top:var(--vot-space-1)!important}.vot-dialog-title-container{font-size:inherit;outline:0;flex:1;display:flex;font-weight:inherit!important;margin:0!important}.vot-dialog-title{flex:1;font-size:115.385%;line-height:1;padding:var(--vot-space-5) var(--vot-space-5) var(--vot-space-4)!important;font-weight:700!important}.vot-dialog-body-container{box-sizing:border-box;gap:var(--vot-space-4);overscroll-behavior:contain;flex-direction:column;min-height:1.375rem;display:flex;overflow:auto;padding:0 var(--vot-space-5)!important;scrollbar-color:rgba(var(--vot-helper-onsurface-rgb), .1) var(--vot-helper-surface)!important}.vot-dialog-body-container::-webkit-scrollbar{background:var(--vot-helper-surface)!important;width:12px!important;height:12px!important}.vot-dialog-body-container::-webkit-scrollbar-track{background:var(--vot-helper-surface)!important;width:12px!important;height:12px!important}.vot-dialog-body-container::-webkit-scrollbar-thumb{border-radius:1ex;background:rgba(var(--vot-helper-onsurface-rgb), .1)!important;border:5px solid var(--vot-helper-surface)!important}.vot-dialog-body-container::-webkit-scrollbar-thumb:hover{border-width:3px!important}.vot-dialog-body-container::-webkit-scrollbar-corner{background:var(--vot-helper-surface)!important}.vot-dialog-footer-container{justify-content:flex-end;gap:var(--vot-space-2);flex-wrap:wrap;flex-shrink:0;display:flex;padding:var(--vot-space-4)!important}.vot-dialog-footer-container:empty{padding:var(--vot-space-5) 0 0 0!important}@media (width<=480px){.vot-dialog-footer-container{flex-direction:column;align-items:stretch}.vot-dialog-footer-container>:is(.vot-button,.vot-outlined-button,.vot-text-button){white-space:normal;text-overflow:clip;text-align:center;justify-content:center;align-items:center;width:100%;height:auto;min-height:36px;padding:8px 16px;line-height:1.2;display:flex;overflow:visible}}.vot-inline-loader{aspect-ratio:5;--vot-loader-bg:no-repeat radial-gradient(farthest-side, rgba(var(--vot-onsurface-rgb,0, 0, 0), .38) 94%, transparent);background:var(--vot-loader-bg), var(--vot-loader-bg), var(--vot-loader-bg), var(--vot-loader-bg);background-size:20% 100%;height:8px;animation:.75s infinite alternate dotsSlide,1.5s infinite alternate dotsFlip}.vot-loader-progress{--vot-helper-theme:var(--vot-theme-rgb,var(--vot-primary-rgb,33, 150, 243));fill:none;stroke:rgb(var(--vot-helper-theme));stroke-width:2px;stroke-linecap:round;transform-origin:50%;transform:rotate(-90deg)}@keyframes dotsSlide{0%,10%{background-position:0 0,0 0,0 0,0 0}33%{background-position:0 0,33.3333% 0,33.3333% 0,33.3333% 0}66%{background-position:0 0,33.3333% 0,66.6667% 0,66.6667% 0}90%,to{background-position:0 0,33.3333% 0,66.6667% 0,100% 0}}@keyframes dotsFlip{0%,49.99%{transform:scale(1)}50%,to{transform:scale(-1)}}.vot-label{font-family:inherit;font-size:16px;line-height:1.5;display:block}.vot-label-text{display:inline}.vot-label-icon{vertical-align:text-bottom;cursor:help;justify-content:center;align-items:center;width:20px;height:20px;margin-left:4px;display:inline-flex}.vot-label-icon>svg{width:20px;height:20px;display:block}.vot-account{justify-content:space-between;align-items:center;gap:1rem;display:flex}.vot-account-container,.vot-account-wrapper,.vot-account-buttons{align-items:center;gap:1rem;display:flex}.vot-account-avatar{min-width:36px;max-width:36px;min-height:36px;max-height:36px;overflow:hidden}.vot-account-avatar-img{object-fit:cover;border-radius:50%;width:36px;height:36px}@property --vot-subtitles-opacity{syntax:\"<number>\";inherits:true;initial-value:.8}@property --vot-subtitles-scale-compensation{syntax:\"<number>\";inherits:true;initial-value:1}.vot-subtitles{--vot-subtitles-background:rgba(var(--vot-surface-rgb,46, 47, 52), var(--vot-subtitles-opacity,.8));--vot-subtitles-effective-max-width:var(--vot-subtitles-max-width,var(--vot-subtitles-smart-max-width,70vw));max-width:var(--vot-subtitles-effective-max-width);max-inline-size:var(--vot-subtitles-effective-max-width);background:var(--vot-subtitles-background,#2e2f34cc);width:max-content;inline-size:max-content;color:var(--vot-subtitles-color,#e3e3e3);pointer-events:all;touch-action:none;font-size:calc(var(--vot-subtitles-font-size,clamp(18px, var(--vot-subtitles-smart-font-preferred,2.2vw), 50px)) * var(--vot-subtitles-scale-compensation,1));-webkit-text-stroke:var(--vot-subtitles-text-stroke-width,clamp(1px, .08em, 2px)) var(--vot-subtitles-text-stroke-color,#000000eb);paint-order:stroke fill;text-shadow:var(--vot-subtitles-text-shadow,0 1px 2px #00000073, 0 2px 8px #00000040);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;font-synthesis:none;position:relative;--vot-subtitles-font-family:var(--vot-subtitles-font-family-custom,var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif))!important;font-family:var(--vot-subtitles-font-family)!important;font-style:normal!important;font-weight:var(--vot-subtitles-font-weight,500)!important;text-transform:none!important;letter-spacing:normal!important;border-radius:.5em!important;padding:.5em .75em!important;line-height:1.25!important}.vot-subtitles,.vot-subtitles *{-webkit-text-stroke:inherit;paint-order:inherit;font-family:var(--vot-subtitles-font-family)!important}.vot-subtitles{box-sizing:border-box;-webkit-user-select:none;user-select:none;contain:layout paint;isolation:isolate;text-align:center;text-wrap:balance;white-space:normal;overflow-wrap:anywhere;unicode-bidi:plaintext;margin:0 auto;display:block}.vot-subtitles-widget{--vot-subtitles-anchor-width:100vw;--vot-subtitles-anchor-height:100vh;--vot-subtitles-effective-max-width:var(--vot-subtitles-max-width,var(--vot-subtitles-smart-max-width,70vw));--vot-subtitles-smart-target-width:48ch;--vot-subtitles-smart-min-width-ratio:.62;--vot-subtitles-smart-max-width-ratio:.78;--vot-subtitles-smart-font-preferred:calc(var(--vot-subtitles-anchor-height) * .0333);--vot-subtitles-smart-max-width:clamp(calc(var(--vot-subtitles-anchor-width) * var(--vot-subtitles-smart-min-width-ratio)), var(--vot-subtitles-smart-target-width), calc(var(--vot-subtitles-anchor-width) * var(--vot-subtitles-smart-max-width-ratio)));box-sizing:border-box;z-index:2147483647;--vot-subtitles-fallback-bottom-inset:calc(env(safe-area-inset-bottom,0px) + clamp(56px, 10vh, 220px) + 10px);left:50%;top:calc(100% - var(--vot-subtitles-fallback-bottom-inset));width:max-content;inline-size:max-content;max-width:var(--vot-subtitles-effective-max-width);max-inline-size:var(--vot-subtitles-effective-max-width);pointer-events:none;will-change:left, top, transform;max-height:100%;display:block;position:absolute;transform:translate(-50%,-100%)}.vot-subtitles-info{flex-direction:column;gap:2px;max-width:100%;display:flex;padding:6px!important}.vot-subtitles-info-service,.vot-subtitles-info-header,.vot-subtitles-info-context{overflow-wrap:anywhere;word-break:break-word;white-space:normal!important}.vot-subtitles-info-service{color:var(--vot-subtitles-context-color,#86919b);margin-bottom:8px!important;font-size:10px!important;line-height:1!important}.vot-subtitles-info-header{color:var(--vot-subtitles-header-color,#fff);margin-bottom:6px!important;font-size:20px!important;font-weight:500!important;line-height:1!important}.vot-subtitles-info-context{color:var(--vot-subtitles-context-color,#86919b);font-size:12px!important;line-height:1.2!important}.vot-subtitles span[data-vot-highlight-index].passed{color:var(--vot-subtitles-passed-color,#2196f3)}.vot-subtitles span[data-vot-token=\"1\"]{cursor:pointer;white-space:normal;overflow-wrap:inherit;word-break:normal;position:relative;font-size:inherit!important;font-family:inherit!important;font-style:inherit!important;font-weight:inherit!important;line-height:inherit!important;text-transform:inherit!important;text-decoration:none!important}.vot-subtitles span[data-vot-token=\"1\"]:before{content:\"\";z-index:-1;position:absolute;inset:2px -2px;border-radius:4px!important}.vot-subtitles span[data-vot-token=\"1\"]:hover:before{background:var(--vot-subtitles-hover-color,#ffffff8c)}.vot-subtitles span[data-vot-token=\"1\"].selected:before{background:var(--vot-subtitles-passed-color,#2196f3)}.vot-subtitles span[data-vot-style-italic=\"1\"]{font-style:italic!important}.vot-subtitles span[data-vot-style-bold=\"1\"]{font-weight:700!important}.vot-subtitles span[data-vot-style-underline=\"1\"]{text-decoration:underline!important}.vot-subtitles span[data-vot-style-color=\"1\"]{color:var(--vot-subtitles-inline-color)!important}.vot-subtitles-layer{pointer-events:none;z-index:2147483647;contain:layout paint;width:100vw!important;height:100vh!important;position:fixed!important;inset:0!important}.vot-subtitles-guides{pointer-events:none;z-index:2147483646;position:absolute;inset:0}.vot-subtitles-guide{background:rgba(var(--vot-primary-rgb,33, 150, 243), .7);box-shadow:0 0 0 1px rgba(var(--vot-primary-rgb,33, 150, 243), .12);opacity:0;transition:opacity .12s linear;position:absolute}.vot-subtitles-guide[data-visible=true]{opacity:1}.vot-subtitles-guide--vertical{width:2px;transform:translate(-50%)}.vot-subtitles-guide--horizontal{height:2px;transform:translateY(-50%)}@media (aspect-ratio<=1){.vot-subtitles-widget{--vot-subtitles-smart-target-width:28ch;--vot-subtitles-smart-min-width-ratio:.8;--vot-subtitles-smart-max-width-ratio:.92;--vot-subtitles-smart-font-preferred:calc(var(--vot-subtitles-anchor-height) * .0296)}}@media (aspect-ratio>=1) and (aspect-ratio<=7/5){.vot-subtitles-widget{--vot-subtitles-smart-target-width:32ch;--vot-subtitles-smart-min-width-ratio:.55;--vot-subtitles-smart-max-width-ratio:.9;--vot-subtitles-smart-font-preferred:calc(var(--vot-subtitles-anchor-height) * .0333)}}@media (width<=900px) and (pointer:coarse){.vot-subtitles-widget{--vot-subtitles-fallback-bottom-inset:env(safe-area-inset-bottom,0px)}}@media (prefers-contrast:more){.vot-subtitles{--vot-subtitles-background:rgba(var(--vot-surface-rgb,46, 47, 52), .92);--vot-subtitles-text-stroke-width:max(2px, .1em);--vot-subtitles-text-shadow:0 2px 10px #0000008c}}:is(:fullscreen .vot-subtitles-widget,:fullscreen .vot-subtitles-widget){--vot-subtitles-smart-max-width-ratio:.8}:is(:fullscreen .vot-subtitles,:fullscreen .vot-subtitles){font-size:calc(var(--vot-subtitles-font-size,clamp(18px, var(--vot-subtitles-smart-font-preferred,2vw), 50px)) * var(--vot-subtitles-fullscreen-scale,1) * .95 * var(--vot-subtitles-scale-compensation,1))}#vot-subtitles-info.vot-subtitles-info *{-webkit-user-select:text!important;user-select:text!important}:root{--vot-font-family:\"Roboto\", \"Segoe UI\", system-ui, sans-serif;--vot-primary-rgb:139, 180, 245;--vot-onprimary-rgb:32, 33, 36;--vot-surface-rgb:32, 33, 36;--vot-onsurface-rgb:227, 227, 227;--vot-subtitles-color:rgb(var(--vot-onsurface-rgb,227, 227, 227));--vot-subtitles-passed-color:rgb(var(--vot-primary-rgb,33, 150, 243));--vot-space-1:4px;--vot-space-2:8px;--vot-space-3:12px;--vot-space-4:16px;--vot-space-5:20px;--vot-space-6:24px;--vot-radius-xs:6px;--vot-radius-s:10px;--vot-radius-m:14px;--vot-radius-l:18px;--vot-border-color:rgba(var(--vot-onsurface-rgb,227, 227, 227), .14);--vot-border-color-hover:rgba(var(--vot-onsurface-rgb,227, 227, 227), .22);--vot-shadow-1:0 1px 2px #0000002e, 0 8px 24px #00000024;--vot-shadow-2:0 2px 4px #00000038, 0 12px 32px #00000038;--vot-duration-fast:.12s;--vot-duration-medium:.2s;--vot-duration-slow:.32s;--vot-easing-standard:cubic-bezier(.4, 0, .2, 1);--vot-focus-ring-color:rgba(var(--vot-primary-rgb,139, 180, 245), .9);--vot-focus-ring:0 0 0 2px var(--vot-focus-ring-color);--vot-focus-ring-offset:0 0 0 4px rgba(var(--vot-surface-rgb,32, 33, 36), .9)}vot-block,vot-block *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}vot-block[hidden]:not(.vot-menu):not(.vot-dialog-container),vot-block [hidden]:not(.vot-menu):not(.vot-dialog-container){display:none!important}vot-block{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-rendering:optimizelegibility;-webkit-text-size-adjust:100%;-moz-text-size-adjust:100%;text-size-adjust:100%;display:block;--vot-font-family:\"Roboto\", \"Segoe UI\", system-ui, sans-serif!important;font-family:var(--vot-font-family,\"Roboto\", \"Segoe UI\", system-ui, sans-serif)!important;visibility:visible!important;font-weight:400!important}vot-block *{font-weight:inherit!important}.vot-portal-local,.vot-subtitles-widget{isolation:isolate}vot-block:focus,vot-block :focus{box-shadow:none!important;outline:none!important}html.vot-keyboard-nav vot-block:focus-visible,html.vot-keyboard-nav vot-block :focus-visible{box-shadow:var(--vot-focus-ring), var(--vot-focus-ring-offset)!important}@supports not selector(:focus-visible){html.vot-keyboard-nav vot-block:focus,html.vot-keyboard-nav vot-block :focus{box-shadow:var(--vot-focus-ring), var(--vot-focus-ring-offset)!important}}@media (prefers-reduced-motion:reduce){.vot-portal-local *,.vot-portal *,.vot-subtitles-widget *{scroll-behavior:auto!important;transition-duration:.001ms!important;animation-duration:.001ms!important;animation-iteration-count:1!important}}.vot-portal{display:inline}.vot-portal-local{z-index:2147483647;position:fixed;top:0;left:0}";
//#endregion
//#region src/ui.ts
function jl(e) {
	let t = globalThis.GM_addStyle;
	if (typeof t == "function") return t(e);
	let n = document.createElement("style");
	return n.textContent = e, (document.head || document.documentElement).appendChild(n), n;
}
jl(Al);
function Ml() {
	if (globalThis.__votKeyboardNavInitialized) return;
	globalThis.__votKeyboardNavInitialized = !0;
	let e = document.documentElement, t = "vot-keyboard-nav", n = () => e.classList.add(t), r = () => e.classList.remove(t);
	globalThis.addEventListener("keydown", (e) => {
		e.key === "Tab" && n();
	}, !0);
	for (let e of [
		"pointerdown",
		"mousedown",
		"touchstart"
	]) globalThis.addEventListener(e, r, {
		capture: !0,
		passive: !0
	});
}
Ml();
var J = {
	makeButtonLike(e, { ariaLabel: t } = {}) {
		e.setAttribute("role", "button"), e.hasAttribute("tabindex") || (e.tabIndex = 0);
		let n = e.tabIndex, r = () => {
			e.getAttribute("disabled") === "true" ? (e.setAttribute("aria-disabled", "true"), e.tabIndex = -1) : (e.removeAttribute("aria-disabled"), e.tabIndex = n);
		};
		return r(), new MutationObserver(() => r()).observe(e, {
			attributes: !0,
			attributeFilter: ["disabled"]
		}), t && e.setAttribute("aria-label", t), e.addEventListener("keydown", (t) => {
			e.getAttribute("disabled") === "true" || e.getAttribute("aria-disabled") === "true" || (t.key === "Enter" || t.key === " ") && (t.preventDefault(), e.click());
		}), e;
	},
	createEl(e, t = [], n = null) {
		let r = document.createElement(e);
		return t.length && r.classList.add(...t), n !== null && r.append(n), r;
	},
	createHeader(e, t = 4) {
		return J.createEl("vot-block", ["vot-header", `vot-header-level-${t}`], e);
	},
	createInformation(e, t) {
		let n = J.createEl("vot-block", ["vot-info"]), r = J.createEl("vot-block");
		q(e, r);
		let i = J.createEl("vot-block");
		return q(t, i), n.append(r, i), {
			container: n,
			header: r,
			value: i
		};
	},
	createButton(e) {
		let t = J.createEl("vot-block", ["vot-button"], e);
		return J.makeButtonLike(t);
	},
	createTextButton(e) {
		let t = J.createEl("vot-block", ["vot-text-button"], e);
		return J.makeButtonLike(t);
	},
	createOutlinedButton(e) {
		let t = J.createEl("vot-block", ["vot-outlined-button"], e);
		return J.makeButtonLike(t);
	},
	createIconButton(e, t = {}) {
		let n = J.createEl("vot-block", ["vot-icon-button"]);
		return q(e, n), J.makeButtonLike(n, t);
	},
	createInlineLoader() {
		return J.createEl("vot-block", ["vot-inline-loader"]);
	},
	createPortal(e = !1) {
		return J.createEl("vot-block", [`vot-portal${e ? "-local" : ""}`]);
	},
	createSubtitleInfo(e, t, n) {
		let r = J.createEl("vot-block", ["vot-subtitles-info"]);
		r.id = "vot-subtitles-info";
		let i = J.createEl("vot-block", ["vot-subtitles-info-service"], V.get("VOTTranslatedBy").replace("{0}", n)), a = J.createEl("vot-block", ["vot-subtitles-info-header"], e), o = J.createEl("vot-block", ["vot-subtitles-info-context"], t);
		return r.append(i, a, o), {
			container: r,
			translatedWith: i,
			header: a,
			context: o
		};
	}
}, Nl = [
	"left",
	"top",
	"right",
	"bottom"
], Pl = ["hover", "click"], Y = class e {
	showed = !1;
	target;
	anchor;
	content;
	position;
	preferredPosition;
	trigger;
	parentElement;
	layoutRoot;
	offsetX;
	offsetY;
	_hidden;
	autoLayout;
	pageWidth;
	pageHeight;
	globalOffsetX;
	globalOffsetY;
	maxWidth;
	backgroundColor;
	borderRadius;
	_bordered;
	container;
	onResizeObserver;
	intersectionObserver;
	scrollListening = !1;
	positionRafId = null;
	destroyFallbackTimerId;
	static DESTROY_FALLBACK_MS = 700;
	tooltipId = typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `vot-tooltip-${Math.random().toString(36).slice(2)}`;
	prevAriaDescribedBy = null;
	constructor({ target: t, anchor: n = void 0, content: r = "", position: i = "top", trigger: a = "hover", offset: o = 4, maxWidth: s = void 0, hidden: c = !1, autoLayout: l = !0, backgroundColor: u = void 0, borderRadius: d = void 0, bordered: f = !0, parentElement: p = document.body, layoutRoot: m = document.documentElement }) {
		if (!(t instanceof HTMLElement)) throw TypeError("target must be a valid HTMLElement");
		this.target = t, this.anchor = n instanceof HTMLElement ? n : t, this.content = r, typeof o == "number" ? this.offsetY = this.offsetX = o : (this.offsetX = o.x, this.offsetY = o.y), this._hidden = c, this.autoLayout = l, this.trigger = e.validateTrigger(a) ? a : "hover", this.position = e.validatePos(i) ? i : "top", this.preferredPosition = this.position, this.parentElement = p, this.layoutRoot = m, this.borderRadius = d, this._bordered = f, this.maxWidth = s, this.backgroundColor = u, this.updatePageSize(), this.init();
	}
	static validatePos(e) {
		return Nl.includes(e);
	}
	static validateTrigger(e) {
		return Pl.includes(e);
	}
	setPosition(t) {
		return this.preferredPosition = e.validatePos(t) ? t : "top", this.position = this.preferredPosition, this.schedulePositionUpdate(), this;
	}
	setContent(e) {
		return this.content = e, this.container ? (this.container.replaceChildren(), typeof e == "string" ? this.container.textContent = e : this.container.append(e), this.schedulePositionUpdate(), this) : this;
	}
	updateMount({ parentElement: e, layoutRoot: t }) {
		return e && this.parentElement !== e && (this.parentElement = e, this.container?.isConnected && e.appendChild(this.container)), t && this.layoutRoot !== t && (this.layoutRoot = t), this.schedulePositionUpdate(), this;
	}
	onResize = () => {
		this.schedulePositionUpdate();
	};
	onClick = () => {
		this.showed ? this.destroy() : this.create();
	};
	onTargetKeyDown = (e) => {
		e.key !== "Escape" || !this.showed || this.destroy();
	};
	onScroll = () => {
		this.schedulePositionUpdate();
	};
	onHoverPointerDown = (e) => {
		e.pointerType !== "mouse" && this.create();
	};
	onHoverPointerUp = (e) => {
		e.pointerType !== "mouse" && this.destroy();
	};
	onMouseEnter = () => {
		this.create();
	};
	onMouseLeave = (e) => {
		this.isInTooltipContext(e.relatedTarget) || this.destroy();
	};
	onTooltipMouseLeave = (e) => {
		this.isInTooltipContext(e.relatedTarget) || this.destroy();
	};
	isInTooltipContext(e) {
		return e instanceof Node ? this.target.contains(e) || this.container?.contains(e) : !1;
	}
	updatePageSize() {
		if (this.layoutRoot === document.documentElement) this.globalOffsetX = 0, this.globalOffsetY = 0;
		else {
			let { left: e, top: t } = this.layoutRoot.getBoundingClientRect();
			this.globalOffsetX = e, this.globalOffsetY = t;
		}
		return this.pageWidth = this.layoutRoot.clientWidth || document.documentElement.clientWidth, this.pageHeight = this.layoutRoot.clientHeight || document.documentElement.clientHeight, this;
	}
	onIntersect = ([e]) => {
		if (!e.isIntersecting) return this.destroy(!0);
	};
	init() {
		return this.onResizeObserver = new ResizeObserver(this.onResize), this.intersectionObserver = new IntersectionObserver(this.onIntersect), this.target.addEventListener("keydown", this.onTargetKeyDown), this.trigger === "click" ? (this.target.addEventListener("pointerdown", this.onClick), this) : (this.target.addEventListener("mouseenter", this.onMouseEnter), this.target.addEventListener("mouseleave", this.onMouseLeave), this.target.addEventListener("focusin", this.onMouseEnter), this.target.addEventListener("focusout", this.onMouseLeave), this.target.addEventListener("pointerdown", this.onHoverPointerDown), this.target.addEventListener("pointerup", this.onHoverPointerUp), this);
	}
	release() {
		return this.destroy(!0), this.detachScrollListener(), this.target.removeEventListener("keydown", this.onTargetKeyDown), this.trigger === "click" ? (this.target.removeEventListener("pointerdown", this.onClick), this) : (this.target.removeEventListener("mouseenter", this.onMouseEnter), this.target.removeEventListener("mouseleave", this.onMouseLeave), this.target.removeEventListener("focusin", this.onMouseEnter), this.target.removeEventListener("focusout", this.onMouseLeave), this.target.removeEventListener("pointerdown", this.onHoverPointerDown), this.target.removeEventListener("pointerup", this.onHoverPointerUp), this);
	}
	schedulePositionUpdate() {
		this.container && this.positionRafId === null && (this.positionRafId = requestAnimationFrame(() => {
			this.positionRafId = null, this.updatePageSize(), this.updatePos();
		}));
	}
	cancelPositionUpdate() {
		this.positionRafId !== null && (cancelAnimationFrame(this.positionRafId), this.positionRafId = null);
	}
	clearDestroyFallbackTimer() {
		this.destroyFallbackTimerId !== void 0 && (globalThis.clearTimeout(this.destroyFallbackTimerId), this.destroyFallbackTimerId = void 0);
	}
	create() {
		return this.destroy(!0), this.showed = !0, this.container = J.createEl("vot-block", ["vot-tooltip"], this.content), this.bordered && this.container.classList.add("vot-tooltip-bordered"), this.container.setAttribute("role", "tooltip"), this.container.id = this.tooltipId, this.container.dataset.trigger = this.trigger, this.container.dataset.position = this.position, this.parentElement.appendChild(this.container), this.schedulePositionUpdate(), this.backgroundColor !== void 0 && (this.container.style.backgroundColor = this.backgroundColor), this.borderRadius !== void 0 && (this.container.style.borderRadius = `${this.borderRadius}px`), this.hidden ? this.container.hidden = !0 : this.syncAriaDescribedBy(!0), this.container.style.opacity = "1", this.trigger === "hover" && this.container.addEventListener("mouseleave", this.onTooltipMouseLeave), this.attachScrollListener(), this.onResizeObserver?.observe(this.layoutRoot), this.anchor !== this.layoutRoot && this.onResizeObserver?.observe(this.anchor), this.intersectionObserver?.observe(this.target), this;
	}
	updatePos() {
		if (!this.container) return this;
		let { top: e, left: t } = this.calcPos(this.autoLayout, this.preferredPosition), n = Math.max(0, this.pageWidth - this.offsetX * 2), r = R(this.maxWidth ?? n, 0, n);
		return this.container.style.transform = `translate(${t}px, ${e}px)`, this.container.dataset.position = this.position, this.container.style.maxWidth = `${r}px`, this;
	}
	calcPos(e = !0, t = this.preferredPosition) {
		if (!this.container) return {
			top: 0,
			left: 0
		};
		let { left: n, right: r, top: i, bottom: a, width: o, height: s } = this.anchor.getBoundingClientRect(), { width: c, height: l } = this.container.getBoundingClientRect(), u = R(c, 0, this.pageWidth), d = R(l, 0, this.pageHeight), f = {
			left: n - this.globalOffsetX,
			right: r - this.globalOffsetX,
			top: i - this.globalOffsetY,
			bottom: a - this.globalOffsetY,
			anchorWidth: o,
			anchorHeight: s
		}, p = {
			width: u,
			height: d
		}, m = this.resolveTooltipPosition(f, p, t, e), h = this.getTooltipCoordinates(f, p, m);
		return this.position = m, {
			top: h.top + this.globalOffsetY,
			left: h.left + this.globalOffsetX
		};
	}
	resolveTooltipPosition(e, t, n, r) {
		if (!r) return n;
		switch (n) {
			case "top": return R(e.top - t.height - this.offsetY, 0, this.pageHeight) + this.offsetY < t.height ? "bottom" : "top";
			case "right": return R(e.right + this.offsetX, 0, this.pageWidth - t.width) + t.width > this.pageWidth - this.offsetX ? "left" : "right";
			case "bottom": return R(e.bottom + this.offsetY, 0, this.pageHeight - t.height) + t.height > this.pageHeight - this.offsetY ? "top" : "bottom";
			case "left": return Math.max(0, e.left - t.width - this.offsetX) + t.width > e.left - this.offsetX ? "right" : "left";
			default: return n;
		}
	}
	getTooltipCoordinates(e, t, n) {
		switch (n) {
			case "top": return {
				top: R(e.top - t.height - this.offsetY, 0, this.pageHeight),
				left: R(e.left - t.width / 2 + e.anchorWidth / 2, this.offsetX, this.pageWidth - t.width - this.offsetX)
			};
			case "right": return {
				top: R(e.top + (e.anchorHeight - t.height) / 2, this.offsetY, this.pageHeight - t.height - this.offsetY),
				left: R(e.right + this.offsetX, 0, this.pageWidth - t.width)
			};
			case "bottom": return {
				top: R(e.bottom + this.offsetY, 0, this.pageHeight - t.height),
				left: R(e.left - t.width / 2 + e.anchorWidth / 2, this.offsetX, this.pageWidth - t.width - this.offsetX)
			};
			case "left": return {
				top: R(e.top + (e.anchorHeight - t.height) / 2, this.offsetY, this.pageHeight - t.height - this.offsetY),
				left: Math.max(0, e.left - t.width - this.offsetX)
			};
			default: return {
				top: 0,
				left: 0
			};
		}
	}
	destroy(t = !1) {
		if (!this.container) return this;
		let n = this.container;
		if (this.cancelPositionUpdate(), this.clearDestroyFallbackTimer(), this.showed = !1, this.syncAriaDescribedBy(!1), this.onResizeObserver?.disconnect(), this.intersectionObserver?.disconnect(), this.detachScrollListener(), t) return n.remove(), this.container = void 0, this;
		n.removeEventListener("mouseleave", this.onTooltipMouseLeave), n.style.pointerEvents = "none", n.style.opacity = "0";
		let r = () => {
			this.clearDestroyFallbackTimer(), n?.remove(), this.container === n && (this.container = void 0);
		};
		return n.addEventListener("transitionend", r, { once: !0 }), n.addEventListener("transitioncancel", r, { once: !0 }), this.destroyFallbackTimerId = globalThis.setTimeout(r, e.DESTROY_FALLBACK_MS), this;
	}
	syncAriaDescribedBy(e) {
		let t = this.target.getAttribute("aria-describedby");
		if (this.prevAriaDescribedBy ??= t, !e) {
			this.prevAriaDescribedBy === null ? this.target.removeAttribute("aria-describedby") : this.target.setAttribute("aria-describedby", this.prevAriaDescribedBy), this.prevAriaDescribedBy = null;
			return;
		}
		let n = new Set((t ?? "").split(/\s+/).filter(Boolean));
		n.add(this.tooltipId), this.target.setAttribute("aria-describedby", Array.from(n).join(" "));
	}
	set bordered(e) {
		this._bordered = e, this.container?.classList.toggle("vot-tooltip-bordered", e);
	}
	get bordered() {
		return this._bordered;
	}
	set hidden(e) {
		this._hidden = e, this.container && (this.container.hidden = e), this.showed && this.syncAriaDescribedBy(!e);
	}
	get hidden() {
		return this._hidden;
	}
	attachScrollListener() {
		this.scrollListening || (this.scrollListening = !0, document.addEventListener("scroll", this.onScroll, {
			passive: !0,
			capture: !0
		}));
	}
	detachScrollListener() {
		this.scrollListening && (this.scrollListening = !1, document.removeEventListener("scroll", this.onScroll, { capture: !0 }));
	}
};
//#endregion
//#region src/subtitles/layoutController.ts
function Fl(e, t) {
	return e >= t.startMs && e < t.startMs + t.durationMs;
}
//#endregion
//#region src/subtitles/activeCues.ts
var Il = (e) => {
	if (e.tokens.length) return e.tokens;
	let t = e.text.trim();
	return t ? [{
		text: t,
		startMs: e.startMs,
		durationMs: e.durationMs,
		isWordLike: !!t
	}] : [];
}, Ll = (e) => (e.text || Il(e).map((e) => e.text).join("")).replaceAll(/\s+/gu, " ").trim(), Rl = (e, t) => {
	let n = e.startMs + Math.max(0, e.durationMs), r = t.startMs + Math.max(0, t.durationMs);
	return e.startMs < r && t.startMs < n;
}, zl = (e) => {
	let t = [];
	for (let n of e) {
		let e = Ll(n.line);
		e && (t.some((t) => e === Ll(t.line) && t.line.speakerId === n.line.speakerId && Rl(t.line, n.line)) || t.push(n));
	}
	return t;
}, Bl = (e, t) => {
	let n = 0, r = t.length - 1, i = -1;
	for (; n <= r;) {
		let a = n + r >> 1;
		if (t[a].startMs <= e) {
			i = a, n = a + 1;
			continue;
		}
		r = a - 1;
	}
	return i;
}, Vl = (e, t, n = Infinity) => {
	let r = Bl(e, t);
	if (r < 0) return [];
	let i = Number.isFinite(n) ? Math.max(0, e - Math.max(0, n)) : -Infinity, a = [];
	for (let n = r; n >= 0; --n) {
		let r = t[n];
		if (r.startMs < i) break;
		Fl(e, r) && a.push(n);
	}
	return a.reverse(), a;
}, Hl = (e, t, n = Infinity) => {
	let r = Vl(e, t, n);
	if (!r.length) return null;
	let i = zl(r.map((e) => ({
		index: e,
		line: t[e]
	})));
	if (!i.length) return null;
	if (i.length === 1) {
		let [e] = i;
		return {
			line: e.line,
			lineKey: `${e.index}`
		};
	}
	let a = [], o = [], s = [], c = [], l = Infinity, u = 0;
	for (let e of i) {
		let t = Il(e.line);
		if (t.length) {
			if (a.length > 0) {
				let t = Math.max(l, e.line.startMs);
				a.push({
					text: "\n",
					startMs: t,
					durationMs: 0,
					isWordLike: !1
				});
			}
			a.push(...t), o.push(e.line.text || t.map((e) => e.text).join("")), s.push(e.line.metadata?.rawText ?? e.line.text), c.push(`${e.index}`), l = Math.min(l, e.line.startMs), u = Math.max(u, e.line.startMs + Math.max(0, e.line.durationMs));
		}
	}
	return !a.length || !c.length ? null : {
		line: {
			text: o.join("\n"),
			startMs: l,
			durationMs: Math.max(0, u - l),
			speakerId: i[0]?.line.speakerId ?? "0",
			tokens: a,
			metadata: s.length ? { rawText: s.join("\n") } : void 0
		},
		lineKey: c.join(",")
	};
}, Ul = [
	"srt",
	"vtt",
	"ass",
	"json"
], Wl = [
	"default-sans",
	"arial",
	"helvetica",
	"roboto",
	"verdana",
	"open-sans",
	"poppins",
	"lato",
	"montserrat",
	"barlow"
], Gl = {
	"default-sans": "\"Roboto\", \"Segoe UI\", system-ui, sans-serif",
	arial: "Arial, \"Helvetica Neue\", Helvetica, sans-serif",
	helvetica: "\"Helvetica Neue\", Helvetica, Arial, sans-serif",
	roboto: "\"Roboto\", \"Segoe UI\", system-ui, sans-serif",
	verdana: "Verdana, Geneva, sans-serif",
	"open-sans": "\"Open Sans\", \"Segoe UI\", system-ui, sans-serif",
	poppins: "\"Poppins\", \"Segoe UI\", system-ui, sans-serif",
	lato: "\"Lato\", \"Segoe UI\", system-ui, sans-serif",
	montserrat: "\"Montserrat\", \"Segoe UI\", system-ui, sans-serif",
	barlow: "\"Barlow\", \"Segoe UI\", system-ui, sans-serif"
}, Kl = new Set(Ul);
function ql(e) {
	return typeof e == "string" && Kl.has(e);
}
function Jl(e) {
	return typeof e == "object" && !!e;
}
function Yl(e) {
	if (!Jl(e)) return null;
	let t = e.format;
	return typeof e.source != "string" || typeof e.language != "string" || typeof e.url != "string" || !ql(t) ? null : {
		source: e.source,
		format: t,
		language: e.language,
		url: e.url,
		translatedFromLanguage: typeof e.translatedFromLanguage == "string" ? e.translatedFromLanguage : void 0,
		isAutoGenerated: typeof e.isAutoGenerated == "boolean" ? e.isAutoGenerated : void 0
	};
}
function Xl(e) {
	return Wl.includes(e);
}
//#endregion
//#region src/subtitles/fonts.ts
var Zl = "google:", Ql = "https://fonts.googleapis.com/css2", $l = "https://fonts.google.com/metadata/fonts", eu = {
	roboto: "Roboto",
	"open-sans": "Open Sans",
	poppins: "Poppins",
	lato: "Lato",
	montserrat: "Montserrat",
	barlow: "Barlow"
}, tu = /* @__PURE__ */ new Set(), nu = /* @__PURE__ */ new Map(), ru = null;
function iu(e) {
	return `${Zl}${e}`;
}
function au(e) {
	if (e.startsWith(Zl)) {
		let t = e.slice(7).trim();
		return t.length > 0 ? t : null;
	}
	return eu[e] ?? null;
}
function ou(e) {
	if (Xl(e)) return Gl[e];
	let t = au(e);
	return t ? `"${t}", "Segoe UI", system-ui, sans-serif` : Gl["default-sans"];
}
function su(e) {
	let t = au(e);
	return t ? `${Ql}?family=${t.trim().replaceAll(/\s+/g, "+")}&display=swap` : null;
}
function cu(e, t) {
	let n = `vot-google-font-${e}`;
	if (document.getElementById(n)) return;
	let r = globalThis.GM_addStyle, i = typeof r == "function" ? r(t) : document.createElement("style");
	i instanceof HTMLElement && (i.id = n, i.textContent ||= t, i.parentElement || (document.head || document.documentElement).appendChild(i));
}
async function lu(e, t = {}) {
	if (tu.has(e)) return;
	let n = nu.get(e);
	if (n !== void 0) {
		await n;
		return;
	}
	let r = su(e);
	if (!r) {
		tu.add(e);
		return;
	}
	let i = au(e), a = (async () => {
		try {
			let n = await z(r, {
				timeout: 1e4,
				forceGmXhr: t.forceGmXhr ?? !0,
				headers: { Accept: "text/css,*/*;q=0.1" }
			});
			if (!n.ok) throw Error(`Google Fonts CSS request failed with ${n.status}`);
			let a = await n.text();
			if (!a.trim()) throw Error("Google Fonts CSS response is empty");
			cu(e, a), tu.add(e), document.fonts && i && await document.fonts.load(`500 20px "${i}"`), t.onLoaded?.();
		} catch (t) {
			L.log("Failed to load Google Font for subtitles", {
				fontFamily: e,
				error: t
			});
		} finally {
			nu.delete(e);
		}
	})();
	nu.set(e, a), await a;
}
async function uu() {
	return ru === null && (ru = (async () => {
		let e = await z($l, {
			timeout: 15e3,
			forceGmXhr: Ea
		});
		if (!e.ok) throw Error(`Google Fonts metadata request failed with ${e.status}`);
		let t = (await e.text()).replace(/^\)\]\}'\n?/, ""), n = JSON.parse(t).familyMetadataList?.map((e) => e.family?.trim() ?? "").filter((e) => e.length > 0);
		return Array.from(new Set(n)).sort((e, t) => e.localeCompare(t));
	})().catch((e) => (ru = null, L.log("Failed to load Google Fonts catalog", e), []))), await ru;
}
//#endregion
//#region src/subtitles/fullscreenLayerController.ts
var du = class {
	video;
	container;
	fullscreenLayer = null;
	constructor({ video: e, container: t }) {
		this.video = e, this.container = t;
	}
	updateContainer(e) {
		this.container = e;
	}
	getWidgetParentElement() {
		return this.shouldUseFullscreenViewportLayer() ? this.ensureFullscreenLayer() : this.container;
	}
	getLayoutRootElement() {
		return this.fullscreenLayer?.isConnected ? this.fullscreenLayer : this.container;
	}
	syncWidgetContainer(e) {
		let t = this.getWidgetParentElement();
		t === this.container && getComputedStyle(this.container).position === "static" && (this.container.style.position = "relative"), e && e.parentElement !== t && t.appendChild(e), t === this.container && this.fullscreenLayer?.parentElement && (this.fullscreenLayer.remove(), this.fullscreenLayer = null);
	}
	release() {
		this.fullscreenLayer &&= (this.fullscreenLayer.remove(), null);
	}
	getActiveFullscreenElement() {
		let e = document;
		return Co(e.fullscreenElement ?? e.webkitFullscreenElement, [this.container, this.video], { allowDocumentViewport: !0 });
	}
	isCurrentVideoInFullscreenSession() {
		let e = this.getActiveFullscreenElement();
		return e ? e === this.container || e.contains(this.container) || this.container.contains(e) ? !0 : !!(this.video && (e === this.video || e.contains(this.video) || this.video.contains(e))) : !1;
	}
	shouldUseFullscreenViewportLayer() {
		return this.isCurrentVideoInFullscreenSession();
	}
	ensureFullscreenLayer() {
		if (!this.fullscreenLayer) {
			let e = document.createElement("vot-block");
			e.classList.add("vot-subtitles-layer"), this.fullscreenLayer = e;
		}
		return this.fullscreenLayer.parentElement !== this.container && this.container.appendChild(this.fullscreenLayer), this.fullscreenLayer;
	}
}, fu = /^[a-z]+$/iu, pu = /^#(?:[0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/iu, mu = /^(?:rgb|rgba|hsl|hsla)\(\s*[0-9.,%\s/+-]+\)$/iu, hu = /^[a-z0-9_-]+$/iu, gu = (e) => {
	if (!e?.length) return;
	let t = Array.from(new Set(e.map((e) => e.trim()).filter((e) => e && hu.test(e)))).sort((e, t) => e.localeCompare(t));
	return t.length ? t : void 0;
}, _u = (e) => {
	let t = e.trim();
	if (t) {
		if (pu.test(t) || fu.test(t)) return t.toLowerCase();
		if (mu.test(t)) return t;
	}
}, vu = (e) => {
	if (!e) return;
	let t = {};
	e.italic && (t.italic = !0), e.bold && (t.bold = !0), e.underline && (t.underline = !0);
	let n = typeof e.color == "string" ? _u(e.color) : void 0;
	n && (t.color = n);
	let r = gu(e.classes);
	return r && (t.classes = r), Object.keys(t).length ? t : void 0;
}, yu = (e) => {
	if (!e || typeof e != "object") return;
	let t = e;
	return vu({
		italic: t.italic === !0,
		bold: t.bold === !0,
		underline: t.underline === !0,
		color: typeof t.color == "string" ? t.color : void 0,
		classes: Array.isArray(t.classes) ? t.classes.filter((e) => typeof e == "string") : void 0
	});
}, bu = (e, t) => {
	let n = vu(e), r = vu(t), i = n?.classes ?? [], a = r?.classes ?? [];
	return !!n?.italic == !!r?.italic && !!n?.bold == !!r?.bold && !!n?.underline == !!r?.underline && (n?.color ?? "") === (r?.color ?? "") && i.length === a.length && i.every((e, t) => e === a[t]);
}, xu = (e) => {
	let t = vu(e);
	return t?.color ? `--vot-subtitles-inline-color:${t.color};` : "";
};
//#endregion
//#region src/subtitles/positionController.ts
function Su(e, t, n) {
	return Math.max(t, Math.min(e, n));
}
function Cu(e, t, n, r, i) {
	let a = n - e, o = r - t;
	return a * a + o * o >= i * i;
}
function wu({ elementHeight: e, boxHeight: t, bottomInset: n }) {
	let r = Math.max(0, e || 0), i = Math.max(r, t - n);
	return {
		minAnchorY: r,
		baselineAnchorY: i,
		travelPx: Math.max(0, i - r)
	};
}
function Tu({ anchorY: e, elementHeight: t, boxHeight: n, bottomInset: r }) {
	let { minAnchorY: i, baselineAnchorY: a, travelPx: o } = wu({
		elementHeight: t,
		boxHeight: n,
		bottomInset: r
	});
	return {
		offsetFromBaselinePx: Su(e, i, a) - a,
		travelPx: o
	};
}
function Eu({ state: e, elementHeight: t, boxHeight: n, bottomInset: r }) {
	let { minAnchorY: i, baselineAnchorY: a, travelPx: o } = wu({
		elementHeight: t,
		boxHeight: n,
		bottomInset: r
	});
	if (!e || o <= 0) return a;
	let s = Math.max(0, e.travelPx || 0), c = Math.max(0, -(e.offsetFromBaselinePx || 0));
	if (s <= 0 || c <= 0) return a;
	let l = c / s * o;
	return Su(a - Math.min(o >= s ? c : o, l), i, a);
}
function Du({ anchorX: e, anchorY: t, elementWidth: n, elementHeight: r, boxWidth: i, boxHeight: a, bottomInset: o }) {
	let s = e, c = t, l = Math.max(0, a - o), u = r || 0;
	if (n) {
		let e = s - n / 2, t = i - n;
		e = t >= 0 ? Su(e, 0, t) : t / 2, s = e + n / 2;
	}
	return c = Su(c, u, l), {
		anchorX: s,
		anchorY: c
	};
}
function Ou({ current: e, candidates: t, thresholdPx: n }) {
	let r = e, i = Infinity;
	for (let n of t) {
		let t = Math.abs(n - e);
		t < i && (i = t, r = n);
	}
	return !Number.isFinite(i) || i > n ? {
		snapped: !1,
		value: e
	} : {
		snapped: !0,
		value: r
	};
}
//#endregion
//#region src/subtitles/renderPlan.ts
var ku = /^[\p{P}\p{S}]+/u, Au = /[\p{P}\p{S}]+$/u, ju = /^[\p{P}\p{S}]+$/u, Mu = /\s+|[\p{P}\p{S}]+|[^\s\p{P}\p{S}]+/gu, Nu = (e, t, n, r = {}) => {
	e.push({
		kind: "text",
		text: t,
		style: n,
		highlightIndex: r.highlightIndex
	}), r.withBreak && e.push({ kind: "break" });
}, Pu = (e, t, n) => {
	let r = t;
	for (; r <= n && !e[r]?.isWordLike && !e[r]?.text.trim();) r += 1;
	return r;
}, Fu = (e, t, n) => {
	for (let r = t; r <= n; r += 1) {
		let t = e[r]?.text ?? "";
		if (!(!e[r]?.isWordLike || !t.trim()) && t.trimStart().replace(ku, "").replace(Au, "")) return !0;
	}
	return !1;
}, Iu = (e, t, n, r, i, a) => {
	let o = t[n], s = /^\s+/u.exec(o.text)?.[0] ?? "", c = o.text.slice(s.length);
	s && Nu(e, s, o.style);
	let l = ku.exec(c)?.[0] ?? "", u = c.slice(l.length), d = Au.exec(u)?.[0] ?? "", f = d ? u.slice(0, u.length - d.length) : u;
	return f ? (l && Nu(e, l, o.style, { highlightIndex: a }), e.push({
		kind: "word",
		text: f,
		style: o.style,
		highlightIndex: a
	}), d && Nu(e, d, o.style, { highlightIndex: a }), i?.has(n) ? (e.push({ kind: "break" }), {
		consumedWord: !0,
		nextTokenIndex: Pu(t, n + 1, r)
	}) : {
		consumedWord: !0,
		nextTokenIndex: n + 1
	}) : (c && Nu(e, c, o.style), i?.has(n) ? (e.push({ kind: "break" }), {
		consumedWord: !1,
		nextTokenIndex: Pu(t, n + 1, r)
	}) : {
		consumedWord: !1,
		nextTokenIndex: n + 1
	});
}, Lu = (e, t, n, r, i, a, o, s, c) => {
	let l = s ?? (Fu(n, t + 1, r) ? c : void 0), u = a.match(Mu) ?? [a];
	for (let t of u) Nu(e, t, i.style, { highlightIndex: ju.test(t) ? l : void 0 });
	return o ? (e.push({ kind: "break" }), Pu(n, t + 1, r)) : t + 1;
};
function Ru(e, t, n) {
	let r = [], i = 0, a = null;
	for (let o = 0; o <= t;) {
		let s = e[o], c = s?.text ?? "";
		if (!c) {
			o += 1;
			continue;
		}
		if (c === "\n") {
			r.push({ kind: "break" }), o += 1;
			continue;
		}
		if (s.isWordLike) {
			let s = Iu(r, e, o, t, n, i);
			o = s.nextTokenIndex, s.consumedWord && (a = i, i += 1);
			continue;
		}
		let l = !!n?.has(o);
		o = Lu(r, o, e, t, s, c, l, a, i);
	}
	return r;
}
//#endregion
//#region src/subtitles/smartLayout.ts
var zu = (e, t, n) => Math.min(n, Math.max(t, e)), Bu = (e) => Math.round(e), Vu = (e) => e < .8 ? {
	widthRatio: .9,
	charsPerLine: 27,
	fontHeightRatio: .03
} : e < 1.1 ? {
	widthRatio: .84,
	charsPerLine: 31,
	fontHeightRatio: .031
} : e < 1.5 ? {
	widthRatio: .76,
	charsPerLine: 36,
	fontHeightRatio: .033
} : e < 1.95 ? {
	widthRatio: .72,
	charsPerLine: 40,
	fontHeightRatio: .034
} : {
	widthRatio: .68,
	charsPerLine: 44,
	fontHeightRatio: .035
}, Hu = (e) => e >= 1920 ? {
	extraChars: 4,
	widthScale: 1.04
} : e >= 1440 ? {
	extraChars: 3,
	widthScale: 1.03
} : e >= 960 ? {
	extraChars: 2,
	widthScale: 1.02
} : e >= 640 ? {
	extraChars: 1,
	widthScale: 1.01
} : {
	extraChars: 0,
	widthScale: 1
}, Uu = (e) => Math.max(7, e * .56);
function Wu(e, t = null) {
	let n = Number.isFinite(e.w) ? Math.max(0, e.w) : 0, r = Number.isFinite(e.h) ? Math.max(0, e.h) : 0;
	if (n <= 0 || r <= 0) return {
		fontSizePx: t?.fontSizePx ?? 20,
		maxWidthPx: t?.maxWidthPx ?? null
	};
	let { widthRatio: i, charsPerLine: a, fontHeightRatio: o } = Vu(n / r), { extraChars: s, widthScale: c } = Hu(n), l = zu(r * o, 16, 42), u = t?.fontSizePx ?? l, d = Uu(u), f = n * Math.min(.92, i), p = n * zu(i * c, .66, .92);
	return {
		fontSizePx: u,
		maxWidthPx: Bu(zu(zu(a + s, 25, 48) * d, f, p))
	};
}
//#endregion
//#region src/subtitles/smartWrap.ts
var Gu = /[.!?…:;][)"'\]»”]*\s*$/u, Ku = /[,،、][)"'\]»”]*\s*$/u, qu = /^\s*[\p{Pe}\p{Pf},.;:!?%‰…]/u, Ju = /\s*[\p{Ps}\p{Pi}¿¡([{«“"'`-]\s*$/u, Yu = (e) => e.replaceAll(/\s+/gu, " ").trim(), Xu = (e) => Gu.test(e) ? "strong" : Ku.test(e) ? "soft" : "neutral", Zu = (e) => qu.test(e), Qu = (e) => Ju.test(e), $u = (e) => !!(e?.isWordLike && e.text.trim()), ed = (e) => e && Number.isFinite(e.startMs) ? e.startMs : 0, td = (e) => e ? ed(e) + Math.max(0, e.durationMs) : 0, nd = (e, t, n) => {
	for (let r = t; r < n; r += 1) {
		let t = e[r];
		if ($u(t)) return ed(t);
	}
	return ed(e[t]);
}, rd = (e, t, n) => {
	for (let r = n - 1; r >= t; --r) {
		let t = e[r];
		if ($u(t)) return td(t);
	}
	return td(e[n - 1]);
}, id = (e, t) => {
	let n = e[t], r = ed(n);
	return {
		text: "\n",
		tokenIndex: t,
		breakAfterTokenIndex: t,
		startToken: t,
		endToken: t + 1,
		charLength: 0,
		startMs: r,
		endMs: r,
		boundary: "strong",
		forcesLineBreak: !0
	};
}, ad = (e, t) => {
	let n = t;
	for (; n > 0 && e[n - 1]?.text !== "\n" && !$u(e[n - 1]);) --n;
	let r = t + 1;
	for (; r < e.length && e[r]?.text !== "\n" && !$u(e[r]);) r += 1;
	let i = e.slice(n, r).map((e) => e.text).join("");
	return {
		text: i,
		tokenIndex: t,
		breakAfterTokenIndex: r - 1,
		startToken: n,
		endToken: r,
		charLength: Yu(i).length,
		startMs: nd(e, n, r),
		endMs: rd(e, n, r),
		boundary: Xu(i),
		forcesLineBreak: !1
	};
};
function od(e) {
	let t = [], n = [], r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (!i?.text) {
			r += 1;
			continue;
		}
		if (i.text === "\n") {
			let i = id(e, r);
			t.push(i), n.push("\n"), r += 1;
			continue;
		}
		if (!$u(i)) {
			r += 1;
			continue;
		}
		let a = ad(e, r);
		t.push(a), n.push(Yu(a.text)), r = a.breakAfterTokenIndex + 1;
	}
	if (!t.length && e.length) {
		let r = e.map((e) => e.text).join("");
		t.push({
			text: r,
			tokenIndex: 0,
			breakAfterTokenIndex: e.length - 1,
			startToken: 0,
			endToken: e.length,
			charLength: Yu(r).length,
			startMs: nd(e, 0, e.length),
			endMs: rd(e, 0, e.length),
			boundary: Xu(r),
			forcesLineBreak: !1
		}), n.push(Yu(r));
	}
	return {
		slices: t,
		key: n.join("|")
	};
}
function sd(e, t) {
	return e.map((e) => ({
		...e,
		width: e.forcesLineBreak ? 0 : t(e.text)
	}));
}
var cd = (e, t) => t <= 0 ? 0 : td(e[t - 1]), ld = (e, t, n, r) => {
	if (r <= n) return;
	let i = nd(t, n, r), a = cd(t, r);
	e.push({
		startToken: n,
		endToken: r,
		startMs: i,
		endMs: Math.max(i, a)
	});
};
function ud(e, t, n, r) {
	if (!t.length || !e.length) return [];
	let i = Math.max(1, n), a = Math.max(1, r), o = [], s = t[0].startToken, c = 0, l = 0, u = 1, d = s;
	for (let n of t) {
		if (n.forcesLineBreak) {
			if (u += 1, l = 0, d = n.endToken, u > 2) {
				let t = Math.max(n.startToken, n.tokenIndex);
				ld(o, e, s, t), s = t, c = 0, d = s;
			}
			continue;
		}
		let t = c + n.charLength;
		if ((l === 0 || l + n.width <= i) && t <= a) {
			l += n.width, c = t, d = n.endToken;
			continue;
		}
		if (u === 1) {
			u = 2, l = n.width, c = t, d = n.endToken;
			continue;
		}
		let r = Math.max(n.startToken, n.tokenIndex);
		ld(o, e, s, r), s = r, c = n.charLength, l = n.width, u = 1, d = n.endToken;
	}
	if (ld(o, e, s, d), !o.length) return [{
		startToken: 0,
		endToken: e.length,
		startMs: nd(e, 0, e.length),
		endMs: rd(e, 0, e.length)
	}];
	for (let e = 0; e < o.length - 1; e += 1) {
		let t = o[e], n = o[e + 1];
		n.startMs > t.startMs && (t.endMs = n.startMs);
	}
	let f = o.at(-1);
	return f && (f.endMs = Math.max(f.endMs, rd(e, f.startToken, f.endToken))), o.filter((e) => e.endToken > e.startToken);
}
var dd = (e, t, n, r) => n <= t ? 0 : r(e.slice(t, n).map((e) => e.text).join("")), fd = (e, t) => {
	let n = t;
	for (; n + 1 < e.length && e[n + 1]?.text !== "\n" && !e[n + 1]?.isWordLike;) n += 1;
	return n;
}, pd = (e, t, n) => {
	let r = null, i = Infinity;
	for (let a = 0; a < e.length - 1; a += 1) {
		let o = e[a], s = e[a + 1];
		if (!o?.text || !s?.text || s.text === "\n") continue;
		let c = fd(e, a);
		if (c >= e.length - 1) continue;
		let l = c + 1, u = l, d = dd(e, 0, l, t), f = dd(e, u, e.length, t), p = e.slice(0, l).map((e) => e.text).join(""), m = e.slice(u).map((e) => e.text).join(""), h = Math.max(0, d - n) * 12 + Math.max(0, f - n) * 12 + Math.abs(f - d) * .4 + (Zu(m) ? 260 : 0) + (Qu(p) ? 70 : 0);
		h < i && (i = h, r = c);
	}
	return r;
}, md = ({ firstWidth: e, secondWidth: t, firstText: n, secondText: r, firstWordCount: i, secondWordCount: a, maxWidthPx: o, boundary: s }) => {
	let c = Math.max(0, e - o) * 12 + Math.max(0, t - o) * 12, l = Math.abs(t / Math.max(e, 1) - 1.08) * 120, u = i < 2 ? 80 : 0, d = a < 2 ? 80 : 0, f = Zu(r) ? 260 : 0, p = Qu(n) ? 70 : 0, m = s === "strong" ? -28 : s === "soft" ? -14 : 0;
	return c + l + u + d + f + p + m;
};
function hd(e, t, n) {
	if (!e.length || e.reduce((e, t) => e + Number(t.text === "\n"), 0) > 0) return { breakAfterTokenIndices: [] };
	let { slices: r } = od(e), i = r.filter((e) => !e.forcesLineBreak);
	if (!i.length || dd(e, 0, e.length, t) <= n) return { breakAfterTokenIndices: [] };
	let a = null, o = Infinity;
	for (let r = 0; r < i.length - 1; r += 1) {
		let s = i[r], c = i[r + 1], l = Math.max(s.breakAfterTokenIndex, c.tokenIndex - 1), u = l + 1, d = c.tokenIndex, f = md({
			firstWidth: dd(e, 0, u, t),
			secondWidth: dd(e, d, e.length, t),
			firstText: e.slice(0, u).map((e) => e.text).join(""),
			secondText: e.slice(d).map((e) => e.text).join(""),
			firstWordCount: r + 1,
			secondWordCount: i.length - (r + 1),
			maxWidthPx: n,
			boundary: s.boundary
		});
		f < o && (o = f, a = l);
	}
	if (a !== null) return { breakAfterTokenIndices: [a] };
	let s = pd(e, t, n);
	return s === null ? { breakAfterTokenIndices: [] } : { breakAfterTokenIndices: [s] };
}
//#endregion
//#region src/subtitles/widget.ts
var gd = 8, _d = .97, vd = 24;
function yd(e) {
	if (!Number.isFinite(e) || e <= 0) return 0;
	let t = e - gd, n = e * _d;
	return Math.max(vd, Math.min(t, n));
}
var bd = class {
	video;
	container;
	fullscreenLayerController;
	tooltipLayoutRoot;
	subtitlesContainer = null;
	subtitlesBlock = null;
	renderedHighlightEls = [];
	passedFlagsBuffer = [];
	subtitles = null;
	subtitleLang;
	lastRenderKey = null;
	lastActiveLineKey = null;
	maxActiveCueLookbackMs = 0;
	highlightWords = !1;
	fontSize = 20;
	fontSizeOverridden = !1;
	fontFamily = "default-sans";
	maxLength = 300;
	smartLayoutEnabled = !0;
	smartFontSizePx = 0;
	smartMaxWidthPx = 0;
	smartAnchorWidthPx = 0;
	smartAnchorHeightPx = 0;
	lastSmartLayoutKey = null;
	lastSmartLayoutCheckTs = 0;
	opacity = "0.2";
	repositionPending = !1;
	positionRefreshPending = !1;
	updatePending = !1;
	lastUpdateRequestTs = 0;
	updateMinIntervalMs = 100;
	updateMinIntervalHighlightMs = 33;
	useVideoFrameCallbacks;
	videoFrameRequestId = null;
	lastPlaybackTimeMs = null;
	dragDocListenersAttached = !1;
	lastPositionRefreshTs = 0;
	positionRefreshIntervalMs = 250;
	subtitleMaxWidthPx = 0;
	breakAfterTokenIndices = [];
	breakAfterTokenIndexSet = null;
	wrapPending = !1;
	lastWrapKey = null;
	lastWrapTokens = null;
	measureCanvas = null;
	measureCtx = null;
	tokenProcessingMemo = null;
	tokenPrecomputeMemo = null;
	lineMeasureMemo = null;
	lastSegmentIndex = 0;
	lastAppliedLeftPct = null;
	lastAppliedTopPct = null;
	position = {
		left: 50,
		top: 100
	};
	customVerticalAnchorState = null;
	positionPreset = "bottom-center";
	dragging = {
		pointerId: null,
		candidate: !1,
		active: !1,
		moved: !1,
		startClientX: 0,
		startClientY: 0,
		offset: {
			x: 0,
			y: 0
		}
	};
	dragStartThresholdPx = 4;
	snapThresholdPx = 18;
	suppressTokenClicksUntil = 0;
	abortController = new AbortController();
	resizeObserver;
	tokenTooltip;
	tooltipTranslationRequestId = 0;
	intervalIdleChecker;
	checkerUnsubscribe = null;
	edgePunctuationTrimRe = /(?:^[\p{P}\p{S}]+|[\p{P}\p{S}]+$)/gu;
	strTokens = "";
	strTranslatedTokens = "";
	passedStateKey = null;
	passedThresholds = [];
	normalizeTokenTextForTranslation(e) {
		return e.trim().replace(this.edgePunctuationTrimRe, "");
	}
	bottomInsetCachedPx = 0;
	safeAreaBottomInsetCachedPx = 0;
	containerPaddingBottomCachedPx = 0;
	insetCacheReady = !1;
	bottomInsetByMode = {
		normal: {
			ratio: .1,
			minPx: 56,
			maxPx: 220,
			gapPx: 10
		},
		fullscreen: {
			ratio: .07,
			minPx: 44,
			maxPx: 140,
			gapPx: 9
		}
	};
	safeAreaProbeEl = null;
	guidesLayer = null;
	verticalGuide = null;
	horizontalGuide = null;
	onPointerDownBound;
	onPointerUpBound;
	onPointerMoveBound;
	onPlaybackStateChangeBound;
	onVisualViewportChangeBound;
	constructor(e, t, n, r = void 0) {
		this.video = e, this.container = t, this.fullscreenLayerController = new du({
			video: e,
			container: t
		}), this.intervalIdleChecker = n, this.tooltipLayoutRoot = r, this.useVideoFrameCallbacks = !!this.video && typeof this.video.requestVideoFrameCallback == "function", this.onPointerDownBound = (e) => this.onPointerDown(e), this.onPointerUpBound = (e) => this.onPointerUp(e), this.onPointerMoveBound = (e) => this.onPointerMove(e), this.onPlaybackStateChangeBound = () => this.handlePlaybackStateChange(), this.onVisualViewportChangeBound = () => this.scheduleReposition(), this.checkerUnsubscribe = this.intervalIdleChecker.subscribe(() => {
			this.onCheckerTick();
		}), this.bindEvents();
	}
	updateMount({ container: e, tooltipLayoutRoot: t }) {
		let n = this.container !== e, r = this.tooltipLayoutRoot !== t;
		this.container = e, this.fullscreenLayerController.updateContainer(e), this.tooltipLayoutRoot = t, this.syncWidgetMount(), (n || r) && this.tokenTooltip?.updateMount({
			parentElement: this.getTokenTooltipParentElement(),
			layoutRoot: this.tooltipLayoutRoot ?? document.documentElement
		}), this.subtitles && (this.insetCacheReady = !1, this.lastAppliedLeftPct = null, this.lastAppliedTopPct = null, this.updateContainerRect(), this.requestUpdate());
	}
	resetTranslationContext(e = !1) {
		this.strTranslatedTokens = "", e && this.releaseTooltip();
	}
	resetSegmentationMemo() {
		this.tokenProcessingMemo = null, this.tokenPrecomputeMemo = null, this.lineMeasureMemo = null, this.lastSegmentIndex = 0;
	}
	resetWrapMemo() {
		this.setBreakAfterTokenIndices([]), this.lastWrapKey = null;
	}
	resetRenderMemo() {
		this.lastRenderKey = null;
	}
	computeAnchorBoxLayout(e) {
		let t = {
			left: 0,
			top: 0,
			w: e.w,
			h: e.h
		}, n = this.video;
		if (!n) return t;
		let r = n.getBoundingClientRect();
		if (!(r.width > 0 && r.height > 0)) return t;
		let i = e.rect;
		if (!(r.right > i.left && r.left < i.right && r.bottom > i.top && r.top < i.bottom)) return t;
		let a = r.width / e.scaleX, o = r.height / e.scaleY;
		if (!(a > 0 && o > 0)) return t;
		let s = (r.left - i.left) / e.scaleX, c = (r.top - i.top) / e.scaleY, l = e.w - a, u = e.h - o;
		return {
			left: l >= 0 ? Su(s, 0, l) : (e.w - a) / 2,
			top: u >= 0 ? Su(c, 0, u) : (e.h - o) / 2,
			w: a,
			h: o
		};
	}
	readSmartCssMetrics() {
		let e = this.subtitlesBlock;
		if (!e) return null;
		let t = getComputedStyle(e), n = Number.parseFloat(t.fontSize), r = Number.parseFloat(t.maxWidth);
		if (!Number.isFinite(n) || !Number.isFinite(r) || n <= 0 || r <= 0) return null;
		this.subtitleMaxWidthPx = r;
		let i = Number.parseFloat(t.paddingLeft) || 0, a = Number.parseFloat(t.paddingRight) || 0, o = Math.max(0, r - i - a);
		return o <= 0 ? null : {
			fontSizePx: n,
			maxWidthPx: o
		};
	}
	ensureSmartLayout(e) {
		if (!this.smartLayoutEnabled) return null;
		let t = this.readSmartCssMetrics(), n = t?.fontSizePx ?? this.smartFontSizePx, r = Wu(e, t), i = r.maxWidthPx ?? this.smartMaxWidthPx, a = `${Math.round(n)}|${Math.round(i)}|${Math.round(r.maxWidthPx ?? 0)}`, o = Math.abs(n - this.smartFontSizePx) > .5, s = Math.abs(i - this.smartMaxWidthPx) > .5;
		return a !== this.lastSmartLayoutKey && (this.lastSmartLayoutKey = a, this.smartFontSizePx = n, this.smartMaxWidthPx = i, this.resetRenderMemo()), this.setSubtitlesContainerVar("--vot-subtitles-max-width", r.maxWidthPx && r.maxWidthPx > 0 ? `${r.maxWidthPx}px` : null), (o || s) && this.lastWrapTokens && (this.lastWrapKey = null, this.resetSegmentationMemo(), this.scheduleWrapRecompute()), r;
	}
	scheduleReposition() {
		this.abortController.signal.aborted || this.subtitles && (this.repositionPending = !0, this.intervalIdleChecker.markActivity("subtitles-reposition"), this.intervalIdleChecker.requestImmediateTick());
	}
	setSubtitlesContainerVar(e, t) {
		let n = this.subtitlesContainer;
		if (n) {
			if (t === null) {
				n.style.removeProperty(e);
				return;
			}
			n.style.setProperty(e, t);
		}
	}
	applyOpacityStyle() {
		this.setSubtitlesContainerVar("--vot-subtitles-opacity", this.opacity);
	}
	applyManualFontSizeStyle() {
		if (!this.smartLayoutEnabled && this.fontSizeOverridden) {
			this.setSubtitlesContainerVar("--vot-subtitles-font-size", `${this.fontSize}px`);
			return;
		}
		this.setSubtitlesContainerVar("--vot-subtitles-font-size", null);
	}
	applyFontFamilyStyle() {
		let e = this.fontFamily;
		this.setSubtitlesContainerVar("--vot-subtitles-font-family-custom", ou(e)), lu(e, {
			forceGmXhr: !0,
			onLoaded: () => {
				this.fontFamily === e && (this.lastWrapKey = null, this.resetSegmentationMemo(), this.scheduleWrapRecompute(), this.scheduleReposition());
			}
		});
	}
	syncVisualStyleVars() {
		this.applyOpacityStyle(), this.applyManualFontSizeStyle(), this.applyFontFamilyStyle();
	}
	ensureGuidesLayer() {
		if (this.guidesLayer) return this.guidesLayer;
		let e = document.createElement("vot-block");
		e.classList.add("vot-subtitles-guides");
		let t = document.createElement("vot-block");
		t.classList.add("vot-subtitles-guide", "vot-subtitles-guide--vertical");
		let n = document.createElement("vot-block");
		return n.classList.add("vot-subtitles-guide", "vot-subtitles-guide--horizontal"), e.append(t, n), this.guidesLayer = e, this.verticalGuide = t, this.horizontalGuide = n, this.hideSnapGuides(), e;
	}
	hideSnapGuides() {
		this.verticalGuide?.removeAttribute("data-visible"), this.horizontalGuide?.removeAttribute("data-visible");
	}
	updateSnapGuides(e, t) {
		let { showVerticalCenter: n = !1, showHorizontalCenter: r = !1 } = t;
		this.ensureGuidesLayer().isConnected || this.syncGuideLayerMount(), this.verticalGuide && (this.verticalGuide.style.left = `${e.left + e.w / 2}px`, this.verticalGuide.style.top = `${e.top}px`, this.verticalGuide.style.height = `${e.h}px`, n ? this.verticalGuide.dataset.visible = "true" : delete this.verticalGuide.dataset.visible), this.horizontalGuide && (this.horizontalGuide.style.left = `${e.left}px`, this.horizontalGuide.style.top = `${e.top + e.h / 2}px`, this.horizontalGuide.style.width = `${e.w}px`, r ? this.horizontalGuide.dataset.visible = "true" : delete this.horizontalGuide.dataset.visible);
	}
	syncGuideLayerMount() {
		let e = this.fullscreenLayerController.getWidgetParentElement(), t = this.ensureGuidesLayer();
		t.parentElement !== e && e.appendChild(t);
	}
	syncWidgetMount() {
		this.fullscreenLayerController.syncWidgetContainer(this.subtitlesContainer), this.syncGuideLayerMount();
	}
	getTokenTooltipParentElement() {
		let e = this.fullscreenLayerController.getWidgetParentElement();
		return e === this.container ? document.documentElement : e;
	}
	createSubtitlesContainer() {
		if (this.subtitlesContainer) return this.subtitlesContainer;
		let e = document.createElement("vot-block");
		return e.classList.add("vot-subtitles-widget"), this.subtitlesContainer = e, this.syncWidgetMount(), e.addEventListener("pointerdown", this.onPointerDownBound, {
			signal: this.abortController.signal,
			passive: !0
		}), this.syncVisualStyleVars(), this.insetCacheReady = !1, this.updateContainerRect(), e;
	}
	bindEvents() {
		let { signal: e } = this.abortController, t = { signal: e };
		this.video?.addEventListener("play", this.onPlaybackStateChangeBound, t), this.video?.addEventListener("pause", this.onPlaybackStateChangeBound, t), this.video?.addEventListener("seeking", this.onPlaybackStateChangeBound, t), this.video?.addEventListener("seeked", this.onPlaybackStateChangeBound, t), this.video?.addEventListener("ended", this.onPlaybackStateChangeBound, t), this.resizeObserver = new ResizeObserver(() => this.onResize()), this.resizeObserver.observe(this.container), this.video && this.resizeObserver.observe(this.video), globalThis.visualViewport?.addEventListener("resize", this.onVisualViewportChangeBound, t), globalThis.visualViewport?.addEventListener("scroll", this.onVisualViewportChangeBound, t);
	}
	getUpdateMinIntervalMs() {
		return this.highlightWords ? this.updateMinIntervalHighlightMs : this.updateMinIntervalMs;
	}
	requestUpdate(e, t = performance.now()) {
		if (this.abortController.signal.aborted || !this.subtitles) return;
		typeof e == "number" && Number.isFinite(e) ? this.lastPlaybackTimeMs = Math.max(0, e) : this.video && (this.lastPlaybackTimeMs = Math.max(0, this.video.currentTime * 1e3));
		let n = this.getUpdateMinIntervalMs();
		t - this.lastUpdateRequestTs < n || (this.lastUpdateRequestTs = t, this.updatePending = !0, this.intervalIdleChecker.requestImmediateTick());
	}
	resolvePlaybackTimeMs() {
		return typeof this.lastPlaybackTimeMs == "number" && Number.isFinite(this.lastPlaybackTimeMs) ? this.lastPlaybackTimeMs : this.video ? Math.max(0, this.video.currentTime * 1e3) : 0;
	}
	handlePlaybackStateChange() {
		if (!this.subtitles) {
			this.stopVideoFrameLoop();
			return;
		}
		this.scheduleReposition(), this.requestUpdate(this.video ? Math.max(0, this.video.currentTime * 1e3) : 0), this.syncVideoFrameLoop();
	}
	syncVideoFrameLoop() {
		if (!this.useVideoFrameCallbacks) return;
		let e = this.video;
		if (e) {
			if (!this.subtitles || e.paused || e.ended) {
				this.stopVideoFrameLoop();
				return;
			}
			this.startVideoFrameLoop();
		}
	}
	startVideoFrameLoop() {
		if (!this.useVideoFrameCallbacks) return;
		let e = this.video;
		e && this.videoFrameRequestId === null && (this.videoFrameRequestId = e.requestVideoFrameCallback(this.onVideoFrame));
	}
	stopVideoFrameLoop() {
		if (!this.useVideoFrameCallbacks) return;
		let e = this.video;
		if (e && this.videoFrameRequestId !== null) {
			try {
				e.cancelVideoFrameCallback(this.videoFrameRequestId);
			} catch {}
			this.videoFrameRequestId = null;
		}
	}
	onVideoFrame = (e, t) => {
		if (this.videoFrameRequestId = null, this.abortController.signal.aborted) return;
		let n = this.video;
		if (!n || n.paused || n.ended || !this.subtitles) return;
		let r = typeof t.mediaTime == "number" && Number.isFinite(t.mediaTime) ? t.mediaTime * 1e3 : void 0;
		this.requestUpdate(r, e), this.startVideoFrameLoop();
	};
	onCheckerTick() {
		this.abortController.signal.aborted || (this.repositionPending && (this.repositionPending = !1, this.updateContainerRect(), this.updatePending = !0), this.wrapPending && (this.wrapPending = !1, this.recomputeWrapNow()), this.positionRefreshPending && (this.positionRefreshPending = !1, this.applySubtitlePosition()), this.updatePending && (this.updatePending = !1, this.update()));
	}
	attachDragDocumentListeners() {
		this.dragDocListenersAttached || (this.dragDocListenersAttached = !0, document.addEventListener("pointermove", this.onPointerMoveBound, { passive: !1 }), document.addEventListener("pointerup", this.onPointerUpBound), document.addEventListener("pointercancel", this.onPointerUpBound));
	}
	detachDragDocumentListeners() {
		this.dragDocListenersAttached && (this.dragDocListenersAttached = !1, document.removeEventListener("pointermove", this.onPointerMoveBound), document.removeEventListener("pointerup", this.onPointerUpBound), document.removeEventListener("pointercancel", this.onPointerUpBound));
	}
	onResize() {
		this.syncWidgetMount(), this.scheduleReposition();
	}
	updateContainerRect() {
		let e = this.getLayoutSize();
		if (!e.w || !e.h) return;
		let t = this.computeAnchorBoxLayout(e);
		!t.w || !t.h || (this.refreshBottomInsetNow(e, t), this.applySubtitlePositionWithLayout(e, t));
	}
	getLayoutSize() {
		let e = this.fullscreenLayerController.getLayoutRootElement(), t = e.getBoundingClientRect(), n = e.clientWidth || t.width, r = e.clientHeight || t.height;
		return {
			w: n,
			h: r,
			rect: t,
			scaleX: t.width && n ? t.width / n : 1,
			scaleY: t.height && r ? t.height / r : 1
		};
	}
	ensureSafeAreaProbe() {
		if (this.safeAreaProbeEl) return;
		let e = document.createElement("div");
		e.style.position = "fixed", e.style.left = "0", e.style.right = "0", e.style.bottom = "0", e.style.height = "env(safe-area-inset-bottom, 0px)", e.style.pointerEvents = "none", e.style.opacity = "0", e.style.zIndex = "-1", document.documentElement.appendChild(e), this.safeAreaProbeEl = e;
	}
	getSafeAreaBottomInsetPx() {
		return this.ensureSafeAreaProbe(), this.safeAreaProbeEl && this.safeAreaProbeEl.offsetHeight || 0;
	}
	refreshInsetCache() {
		let e = this.fullscreenLayerController.getLayoutRootElement();
		this.safeAreaBottomInsetCachedPx = this.getSafeAreaBottomInsetPx(), this.containerPaddingBottomCachedPx = Number.parseFloat(getComputedStyle(e).paddingBottom || "0") || 0, this.insetCacheReady = !0;
	}
	isMobileViewport() {
		return typeof globalThis.matchMedia == "function" ? globalThis.matchMedia("(max-width: 900px) and (pointer: coarse)").matches : !1;
	}
	getBottomInsetPreset() {
		let e = document, t = e.fullscreenElement ?? e.webkitFullscreenElement;
		if (!(t instanceof Element)) return this.bottomInsetByMode.normal;
		let { container: n, video: r } = this;
		return t === n || t.contains(n) || n.contains(t) || r && (t === r || t.contains(r) || r.contains(t)) ? this.bottomInsetByMode.fullscreen : this.bottomInsetByMode.normal;
	}
	computeReservedBottomInsetPx(e, t = this.getBottomInsetPreset()) {
		return Su(e * t.ratio, t.minPx, t.maxPx);
	}
	refreshBottomInsetNow(e, t) {
		this.refreshInsetCache();
		let n = t?.h ?? this.computeAnchorBoxLayout(e ?? this.getLayoutSize()).h;
		if (!n) {
			this.bottomInsetCachedPx = 0;
			return;
		}
		let r = this.getBottomInsetPreset();
		this.bottomInsetCachedPx = this.computeReservedBottomInsetPx(n, r);
	}
	getBottomInsetPx(e, t) {
		this.insetCacheReady || this.refreshInsetCache();
		let n = this.getBottomInsetPreset(), r = this.safeAreaBottomInsetCachedPx, i = this.containerPaddingBottomCachedPx;
		if (this.isMobileViewport()) return Math.max(i, r);
		let a = t?.h ?? this.computeAnchorBoxLayout(e ?? this.getLayoutSize()).h, o = a ? this.computeReservedBottomInsetPx(a, n) : n.minPx, s = Math.max(this.bottomInsetCachedPx, o);
		return Math.max(i, r, s) + n.gapPx;
	}
	onPointerDown(e) {
		let t = this.subtitlesContainer;
		if (!t) return;
		let n = e.target;
		if (!(n instanceof Node) || !t.contains(n) || !e.isPrimary || e.pointerType === "mouse" && e.button !== 0) return;
		let r = this.getLayoutSize(), { rect: i, w: a, h: o, scaleX: s, scaleY: c } = r;
		if (!a || !o) return;
		let l = this.computeAnchorBoxLayout(r);
		if (!l.w || !l.h) return;
		this.lastPositionRefreshTs = performance.now();
		let u = t.getBoundingClientRect(), d = (e.clientX - i.left) / s - l.left, f = (e.clientY - i.top) / c - l.top, p = (u.left - i.left + u.width / 2) / s - l.left, m = (u.top - i.top + u.height) / c - l.top;
		this.dragging.pointerId = e.pointerId, this.dragging.candidate = !0, this.dragging.active = !1, this.dragging.moved = !1, this.dragging.startClientX = e.clientX, this.dragging.startClientY = e.clientY, this.dragging.offset.x = p - d, this.dragging.offset.y = m - f, this.hideSnapGuides(), this.attachDragDocumentListeners();
		let h = this.subtitlesBlock ?? (n instanceof Element ? n : null);
		try {
			h?.setPointerCapture(e.pointerId);
		} catch {}
	}
	onPointerUp(e) {
		this.dragging.pointerId !== null && e.pointerId === this.dragging.pointerId && (this.dragging.moved && (this.suppressTokenClicksUntil = performance.now() + 450), this.dragging.pointerId = null, this.dragging.candidate = !1, this.dragging.active = !1, this.dragging.moved = !1, this.hideSnapGuides(), this.detachDragDocumentListeners());
	}
	onPointerMove(e) {
		if (!this.dragging.candidate || this.dragging.pointerId === null || e.pointerId !== this.dragging.pointerId) return;
		if (this.dragging.active) this.dragging.moved = !0;
		else {
			if (!Cu(this.dragging.startClientX, this.dragging.startClientY, e.clientX, e.clientY, this.dragStartThresholdPx)) return;
			this.dragging.active = !0, this.dragging.moved = !0, this.suppressTokenClicksUntil = performance.now() + 450, this.releaseTooltip();
		}
		e.preventDefault(), e.stopPropagation();
		let t = this.getLayoutSize(), { rect: n, w: r, h: i, scaleX: a, scaleY: o } = t;
		if (!r || !i) return;
		let s = this.computeAnchorBoxLayout(t);
		if (!s.w || !s.h) return;
		let c = (e.clientX - n.left) / a - s.left, l = (e.clientY - n.top) / o - s.top, u = c + this.dragging.offset.x, d = l + this.dragging.offset.y, f = this.subtitlesContainer?.offsetWidth ?? 0, p = this.subtitlesContainer?.offsetHeight ?? 0, m = this.getBottomInsetPx(t, s), h = Ou({
			current: u,
			candidates: [s.w / 2],
			thresholdPx: this.snapThresholdPx
		});
		h.snapped && (u = h.value);
		let g = s.h / 2 + p / 2, _ = Ou({
			current: d,
			candidates: [g],
			thresholdPx: this.snapThresholdPx
		});
		_.snapped && (d = _.value), {anchorX: u, anchorY: d} = Du({
			anchorX: u,
			anchorY: d,
			elementWidth: f,
			elementHeight: p,
			boxWidth: s.w,
			boxHeight: s.h,
			bottomInset: m
		}), this.positionPreset = "custom", this.customVerticalAnchorState = Tu({
			anchorY: d,
			elementHeight: p,
			boxHeight: s.h,
			bottomInset: m
		}), this.position.left = u / s.w * 100, this.position.top = d / s.h * 100, this.updateSnapGuides(s, {
			showVerticalCenter: h.snapped,
			showHorizontalCenter: _.snapped
		}), this.applySubtitlePositionWithLayout(t, s);
	}
	applySubtitlePosition() {
		if (!this.subtitlesContainer) return;
		let e = this.getLayoutSize();
		if (!e.w || !e.h) return;
		let t = this.computeAnchorBoxLayout(e);
		!t.w || !t.h || this.applySubtitlePositionWithLayout(e, t);
	}
	applySubtitlePositionWithLayout(e, t) {
		let n = this.subtitlesContainer;
		if (!n) return;
		this.applyScaleCompensation(n, e), this.syncAnchorDimensions(n, t), this.smartLayoutEnabled && this.ensureSmartLayout(t);
		let r = n.offsetWidth, i = n.offsetHeight, a = this.getBottomInsetPx(e, t), o = this.resolveCurrentAnchorPosition(t, r, i, a), s = this.clampContainerPosition(t, o.anchorX, o.anchorY, r, i, a), c = s.anchorX, l = s.anchorY, u = t.left + c, d = t.top + l, f = u / e.w * 100, p = d / e.h * 100;
		this.updateContainerPosition(n, f, p), this.tokenTooltip?.updatePos();
	}
	applyScaleCompensation(e, t) {
		let n = Math.min(t.scaleX || 1, t.scaleY || 1), r = n > 0 && n < .999 ? Math.min(1 / n, 3) : 1;
		if (Math.abs(r - 1) < .001) {
			e.style.removeProperty("--vot-subtitles-scale-compensation");
			return;
		}
		e.style.setProperty("--vot-subtitles-scale-compensation", r.toFixed(3));
	}
	syncAnchorDimensions(e, t) {
		let n = Math.max(1, Math.round(t.w)), r = Math.max(1, Math.round(t.h));
		(n !== this.smartAnchorWidthPx || r !== this.smartAnchorHeightPx) && (this.smartAnchorWidthPx = n, this.smartAnchorHeightPx = r, e.style.setProperty("--vot-subtitles-anchor-width", `${n}px`), e.style.setProperty("--vot-subtitles-anchor-height", `${r}px`), this.lastWrapTokens && (this.lastWrapKey = null, this.resetSegmentationMemo(), this.scheduleWrapRecompute()));
	}
	resolveCurrentAnchorPosition(e, t, n, r) {
		let i = this.position.left / 100 * e.w, a = this.position.top / 100 * e.h;
		if (this.positionPreset === "custom") return a = Eu({
			state: this.customVerticalAnchorState,
			elementHeight: n,
			boxHeight: e.h,
			bottomInset: r
		}), {
			anchorX: i,
			anchorY: a
		};
		let o = this.resolvePresetAnchorPosition({
			preset: this.positionPreset,
			anchorBox: e,
			elementWidth: t,
			elementHeight: n,
			bottomInset: r
		});
		return i = o.anchorX, a = o.anchorY, e.w > 0 && (this.position.left = i / e.w * 100), e.h > 0 && (this.position.top = a / e.h * 100), {
			anchorX: i,
			anchorY: a
		};
	}
	clampContainerPosition(e, t, n, r, i, a) {
		let o = t - r / 2, s = n - i, c = e.w - r, l = e.h - a - i;
		return o = c >= 0 ? Su(o, 0, c) : c / 2, s = l >= 0 ? Su(s, 0, l) : 0, {
			anchorX: o + r / 2,
			anchorY: s + i
		};
	}
	updateContainerPosition(e, t, n) {
		(this.lastAppliedLeftPct === null || Math.abs(t - this.lastAppliedLeftPct) >= .01) && (e.style.left = `${t}%`, this.lastAppliedLeftPct = t), (this.lastAppliedTopPct === null || Math.abs(n - this.lastAppliedTopPct) >= .01) && (e.style.top = `${n}%`, this.lastAppliedTopPct = n);
	}
	resolvePresetAnchorPosition({ preset: e, anchorBox: t, elementWidth: n, elementHeight: r, bottomInset: i }) {
		let a = t.w / 2, o = t.h - i;
		switch (e) {
			case "top-center":
				o = r;
				break;
			case "center":
				o = t.h / 2 + r / 2;
				break;
			case "bottom-left":
				a = n / 2;
				break;
			case "bottom-right":
				a = t.w - n / 2;
				break;
			case "bottom-center":
			case "custom": break;
		}
		return Du({
			anchorX: a,
			anchorY: o,
			elementWidth: n,
			elementHeight: r,
			boxWidth: t.w,
			boxHeight: t.h,
			bottomInset: i
		});
	}
	applyPositionAfterContentRender() {
		let e = this.getLayoutSize();
		if (e.w && e.h) {
			let t = this.computeAnchorBoxLayout(e);
			if (t.w && t.h) {
				this.refreshBottomInsetNow(e, t), this.applySubtitlePositionWithLayout(e, t);
				return;
			}
			this.refreshBottomInsetNow(e), this.applySubtitlePosition();
			return;
		}
		this.refreshBottomInsetNow(), this.applySubtitlePosition();
	}
	trimEdgeWhitespaceTokens(e) {
		if (!e.length) return e;
		let t = 0, n = e.length;
		for (; t < n && !e[t]?.text.trim();) t += 1;
		for (; n > t && !e[n - 1]?.text.trim();) --n;
		return t === 0 && n === e.length ? e : t >= n ? [] : e.slice(t, n);
	}
	selectTokensByMaxLength(e, t) {
		if (!e.length) return e;
		let n = 0, r = 0, i = !1, a = 0, o = e.length, s = !1, c = !1, l = (n, r) => {
			if (r <= n || (s ||= (a = n, o = r, !0), c)) return;
			let i = e[n], l = e[r - 1];
			if (!i || !l) return;
			let u = (r < e.length ? e[r]?.startMs : void 0) ?? l.startMs + (l.durationMs ?? 0);
			i.startMs <= t && t < u && (a = n, o = r, c = !0);
		};
		for (let [t, a] of e.entries()) {
			let e = r + a.text.length;
			if (e > this.maxLength && t > n) {
				i = !0, l(n, t), n = t, r = a.text.length;
				continue;
			}
			r = e;
		}
		return i ? (l(n, e.length), this.trimEdgeWhitespaceTokens(e.slice(a, o))) : this.trimEdgeWhitespaceTokens(e);
	}
	buildTokenPrecomputeInput(e) {
		let t = this.tokenPrecomputeMemo;
		if (t?.tokens === e) return t.value;
		let { slices: n, key: r } = od(e), i = {
			wordSlices: n,
			normalizedWordsKey: r
		};
		return this.tokenPrecomputeMemo = {
			tokens: e,
			value: i
		}, i;
	}
	getTokenLayoutInputs(e) {
		let t = this.subtitlesBlock;
		if (t) {
			let n = getComputedStyle(t), r = `${n.fontStyle} ${n.fontVariant} ${n.fontWeight} ${n.fontSize} ${n.fontFamily}`;
			e.font = r;
			let i = Number.parseFloat(n.maxWidth), a = Number.parseFloat(n.paddingLeft) || 0, o = Number.parseFloat(n.paddingRight) || 0, s = Number.isFinite(i) ? i : this.subtitleMaxWidthPx || globalThis.innerWidth * .8;
			return Number.isFinite(s) && s > 0 && (this.subtitleMaxWidthPx = s), {
				fontKey: r,
				maxWidthPx: Math.max(0, s - a - o)
			};
		}
		let n = Number.parseFloat(getComputedStyle(document.documentElement).fontSize) || 16, r = Math.min(n * 52, this.subtitleMaxWidthPx || globalThis.innerWidth * .8), i = this.fontSizeOverridden ? this.fontSize : Math.min(24, Math.max(14, globalThis.innerWidth * .016)), a = `normal normal 500 ${i}px ${ou(this.fontFamily)}`;
		return e.font = a, {
			fontKey: a,
			maxWidthPx: Math.max(0, r - i)
		};
	}
	getActiveLineKey(e) {
		return this.lastActiveLineKey === null ? `${e[0]?.startMs ?? 0}:${e[0]?.durationMs ?? 0}:${e.length}` : this.lastActiveLineKey;
	}
	getLineMeasureMemo(e, t) {
		let { wordSlices: n, normalizedWordsKey: r } = this.buildTokenPrecomputeInput(e);
		if (!n.length) return null;
		let i = this.getMeasureContext();
		if (!i) return null;
		let { fontKey: a, maxWidthPx: o } = this.getTokenLayoutInputs(i);
		if (!Number.isFinite(o) || o < 24) return null;
		let s = `${t}|${a}|${Math.round(o)}|${r}`;
		if (this.lineMeasureMemo?.key === s) return this.lineMeasureMemo;
		let c = {
			key: s,
			metrics: sd(n, (e) => i.measureText(e).width),
			maxWidthPx: o
		};
		return this.lineMeasureMemo = c, c;
	}
	buildTokenProcessingMemo(e, t) {
		let n = this.getLineMeasureMemo(e, t);
		if (!n) return null;
		let r = `${n.key}|${this.maxLength}`;
		if (this.tokenProcessingMemo?.key === r) return this.tokenProcessingMemo;
		let i = yd(n.maxWidthPx), a = {
			key: r,
			segmentRanges: ud(e, n.metrics, i, this.maxLength)
		};
		return this.tokenProcessingMemo = a, this.lastSegmentIndex = 0, a;
	}
	selectSegmentIndexFromRanges(e, t) {
		if (!e.length) return -1;
		let n = this.lastSegmentIndex;
		for (n >= e.length && (n = 0); n < e.length - 1 && t >= e[n].endMs;) n += 1;
		for (; n > 0 && t < e[n].startMs;) --n;
		if (!(t >= e[n].startMs && t < e[n].endMs)) {
			let r = e.findIndex((e) => t >= e.startMs && t < e.endMs);
			n = r >= 0 ? r : t < e[0].startMs ? 0 : e.length - 1;
		}
		return this.lastSegmentIndex = n, n;
	}
	processTokens(e, t) {
		if (!e.length) return e;
		let n = this.getActiveLineKey(e), r = this.buildTokenProcessingMemo(e, n);
		if (!r) return this.selectTokensByMaxLength(e, t);
		let { segmentRanges: i } = r;
		if (!i.length) return this.trimEdgeWhitespaceTokens(e);
		let a = this.selectSegmentIndexFromRanges(i, t);
		if (a < 0) return this.trimEdgeWhitespaceTokens(e);
		let o = i[a];
		return this.trimEdgeWhitespaceTokens(e.slice(o.startToken, o.endToken));
	}
	async translateStrTokens(e) {
		let t = this.subtitleLang ?? "", n = V.lang;
		if (this.strTranslatedTokens) {
			let r = await cc(e, t, n);
			return [this.strTranslatedTokens, typeof r == "string" ? r : ""];
		}
		let r = await cc([this.strTokens, e], t, n), i = Array.isArray(r) ? r : [r, r], a = typeof i[0] == "string" ? i[0] : "", o = typeof i[1] == "string" ? i[1] : "";
		return this.strTranslatedTokens = a, [a, o];
	}
	isTokenSpanElement(e) {
		return e instanceof HTMLSpanElement && e.dataset.votToken === "1";
	}
	findTokenSpanInPath(e, t) {
		for (let n of e) if (this.isTokenSpanElement(n) && t.contains(n)) return n;
		return null;
	}
	findTokenSpanByPoint(e, t, n) {
		let r = document.elementFromPoint(e, t);
		if (this.isTokenSpanElement(r) && n.contains(r)) return r;
		if (!(r instanceof Element)) return null;
		let i = r.closest("span[data-vot-token=\"1\"]");
		return i instanceof HTMLSpanElement && n.contains(i) ? i : null;
	}
	resolveTokenSpanFromClick(e) {
		let t = this.subtitlesBlock ?? this.subtitlesContainer;
		if (!t) return null;
		if (this.isTokenSpanElement(e.target) && t.contains(e.target)) return e.target;
		let n = typeof e.composedPath == "function" ? e.composedPath() : [], r = this.findTokenSpanInPath(n, t);
		if (r) return r;
		let i = e.clientX, a = e.clientY;
		return Number.isFinite(i) && Number.isFinite(a) ? this.findTokenSpanByPoint(i, a, t) : null;
	}
	releaseTooltip() {
		return this.tooltipTranslationRequestId += 1, this.tokenTooltip?.target && this.tokenTooltip.target.classList.remove("selected"), this.tokenTooltip?.release(), this.tokenTooltip = void 0, this;
	}
	clearPendingSchedulerState() {
		this.repositionPending = !1, this.updatePending = !1, this.wrapPending = !1, this.positionRefreshPending = !1;
	}
	clearRenderedContent({ releaseTooltip: e = !1 } = {}) {
		e && this.releaseTooltip(), this.resetRenderMemo(), this.lastActiveLineKey = null, this.strTokens = "", this.resetTranslationContext(), this.subtitlesBlock = null, this.renderedHighlightEls = [], this.resetWrapMemo(), this.lastWrapTokens = null, this.subtitleMaxWidthPx = 0, this.smartAnchorWidthPx = 0, this.smartAnchorHeightPx = 0, this.smartFontSizePx = 0, this.smartMaxWidthPx = 0, this.lastAppliedLeftPct = null, this.lastAppliedTopPct = null, this.passedStateKey = null, this.passedThresholds.length = 0, this.insetCacheReady = !1, this.hideSnapGuides(), this.resetSegmentationMemo(), this.clearPendingSchedulerState(), this.subtitlesContainer && q(null, this.subtitlesContainer);
	}
	onClick = async (e) => {
		if (performance.now() < this.suppressTokenClicksUntil) {
			e.preventDefault(), e.stopPropagation();
			return;
		}
		let t = this.resolveTokenSpanFromClick(e);
		if (!t || this.toggleCurrentTooltipTarget(t)) return;
		this.releaseTooltip();
		let n = this.tooltipTranslationRequestId, r = this.normalizeTokenTextForTranslation(t.textContent ?? "");
		if (!r) return;
		let i = await B.get("translationService", pi);
		if (n !== this.tooltipTranslationRequestId) return;
		t.classList.add("selected");
		let a = J.createSubtitleInfo(r, this.strTranslatedTokens || this.strTokens, i), o = this.createTokenTooltip(t, a.container);
		this.tokenTooltip = o, o.onClick();
		let s = this.strTokens, c = await this.translateStrTokens(r);
		n === this.tooltipTranslationRequestId && (this.shouldSkipTooltipUpdate(n, o, t, s) || (a.header.textContent = c[1], a.context.textContent = c[0], o.setContent(a.container)));
	};
	toggleCurrentTooltipTarget(e) {
		return this.tokenTooltip?.target !== e || !this.tokenTooltip?.container ? !1 : (this.tokenTooltip.showed ? e.classList.add("selected") : e.classList.remove("selected"), !0);
	}
	createTokenTooltip(e, t) {
		let n = Math.max(this.subtitleMaxWidthPx, this.subtitlesContainer?.offsetWidth ?? 0, this.subtitlesBlock?.offsetWidth ?? 0, Math.min(globalThis.innerWidth * .6, 320));
		return new Y({
			target: e,
			anchor: this.subtitlesBlock ?? e,
			layoutRoot: this.tooltipLayoutRoot,
			content: t,
			parentElement: this.getTokenTooltipParentElement(),
			offset: {
				x: 4,
				y: 12
			},
			maxWidth: n,
			borderRadius: 12,
			bordered: !1,
			position: "top",
			trigger: "click"
		});
	}
	shouldSkipTooltipUpdate(e, t, n, r) {
		return e !== this.tooltipTranslationRequestId || r !== this.strTokens || this.tokenTooltip !== t || t.target !== n || !t.showed;
	}
	buildPassedState(e, t, n) {
		if (this.passedStateKey !== n) {
			this.passedStateKey = n, this.passedThresholds.length = 0;
			for (let t of e) {
				if (!t.isWordLike) continue;
				let e = t.startMs + t.durationMs / 2, n = Math.max(t.startMs - 100, e - 275);
				this.passedThresholds.push(Math.min(e, n));
			}
		}
		let r = this.passedFlagsBuffer, i = this.passedThresholds;
		for (let e = 0; e < i.length; e += 1) r[e] = t > i[e];
		return r.length = i.length, r;
	}
	renderTokens(e) {
		return Ru(e, e.length - 1, this.breakAfterTokenIndexSet).map((e) => this.renderPlanPart(e));
	}
	renderStyledSpan(e, t, n = !1, r) {
		return !t && !n && r === void 0 ? e : ml`<span
      data-vot-token=${n ? "1" : K}
      data-vot-highlight-index=${r ?? K}
      data-vot-style-italic=${t?.italic ? "1" : "0"}
      data-vot-style-bold=${t?.bold ? "1" : "0"}
      data-vot-style-underline=${t?.underline ? "1" : "0"}
      data-vot-style-color=${t?.color ? "1" : "0"}
      style=${xu(t)}
      >${e}</span
    >`;
	}
	renderPlanPart(e) {
		return e.kind === "break" ? ml`<br class="vot-subtitles-br" />` : this.renderStyledSpan(e.text, e.style, e.kind === "word", e.highlightIndex);
	}
	updatePassedClasses(e) {
		for (let t of this.renderedHighlightEls) {
			let n = Number.parseInt(t.dataset.votHighlightIndex ?? "", 10), r = Number.isInteger(n) && n >= 0 && n < e.length ? e[n] : !1;
			t.classList.toggle("passed", r);
		}
	}
	clearPassedClasses() {
		for (let e of this.renderedHighlightEls) e.classList.remove("passed");
	}
	setBreakAfterTokenIndices(e) {
		this.breakAfterTokenIndices = e, this.breakAfterTokenIndexSet = e.length ? new Set(e) : null;
	}
	scheduleWrapRecompute(e = null) {
		e && (this.lastWrapTokens = e);
		let t = !this.wrapPending;
		this.wrapPending = !0, t && this.intervalIdleChecker.requestImmediateTick();
	}
	maybeRefreshPosition(e = !1) {
		if (this.abortController.signal.aborted || !this.subtitlesContainer) return;
		let t = performance.now();
		!e && t - this.lastPositionRefreshTs < this.positionRefreshIntervalMs || (this.lastPositionRefreshTs = t, this.positionRefreshPending = !0, this.intervalIdleChecker.requestImmediateTick());
	}
	getMeasureContext(e) {
		return this.measureCanvas || (this.measureCanvas = document.createElement("canvas"), this.measureCanvas.width = 1, this.measureCanvas.height = 1), this.measureCtx ||= this.measureCanvas.getContext("2d", { alpha: !1 }) ?? this.measureCanvas.getContext("2d"), this.measureCtx ? (typeof e == "string" && e && (this.measureCtx.font = e), this.measureCtx) : null;
	}
	arraysEqual(e, t) {
		if (e === t) return !0;
		if (e.length !== t.length) return !1;
		for (let n = 0; n < e.length; n += 1) if (e[n] !== t[n]) return !1;
		return !0;
	}
	recomputeWrapNow() {
		let e = this.lastWrapTokens, t = this.subtitlesBlock;
		if (!e || !t) return;
		let n = this.getMeasureContext();
		if (!n) return;
		let { fontKey: r, maxWidthPx: i } = this.getTokenLayoutInputs(n);
		if (!Number.isFinite(i) || i < 50) return;
		let a = yd(i);
		if (a < 50) return;
		let o = `${this.getActiveLineKey(e)}|${r}|${Math.round(a)}|${this.stringifyTokens(e)}`;
		if (o === this.lastWrapKey) return;
		this.lastWrapKey = o;
		let s = hd(e, (e) => n.measureText(e).width, a);
		this.arraysEqual(s.breakAfterTokenIndices, this.breakAfterTokenIndices) || (this.setBreakAfterTokenIndices(s.breakAfterTokenIndices), this.resetRenderMemo(), this.update());
	}
	setContent(e, t = void 0) {
		if (this.releaseTooltip(), this.subtitleLang = t, !e || !this.video) {
			this.clearRenderedContent(), this.subtitles = null, this.maxActiveCueLookbackMs = 0, this.lastPlaybackTimeMs = null, this.clearPendingSchedulerState(), this.stopVideoFrameLoop(), this.detachDragDocumentListeners();
			return;
		}
		this.createSubtitlesContainer(), this.subtitles = e, this.maxActiveCueLookbackMs = e.subtitles.reduce((e, t) => Math.max(e, Math.max(0, t.durationMs)), 0), this.lastPlaybackTimeMs = Math.max(0, this.video.currentTime * 1e3), this.lastActiveLineKey = null, this.syncVideoFrameLoop(), this.updateContainerRect(), this.update(), this.intervalIdleChecker.requestImmediateTick();
	}
	setMaxLength(e) {
		typeof e == "number" && e > 0 && (this.maxLength = e, this.resetSegmentationMemo(), this.update(), this.scheduleReposition());
	}
	setHighlightWords(e) {
		let t = this.highlightWords;
		this.highlightWords = !!e, t && !this.highlightWords && this.clearPassedClasses(), this.update();
	}
	setSmartLayout(e) {
		let t = e !== !1;
		t !== this.smartLayoutEnabled && (this.smartLayoutEnabled = t, this.subtitlesContainer?.style.removeProperty("--vot-subtitles-max-width"), this.lastSmartLayoutKey = null, this.resetWrapMemo(), this.resetRenderMemo(), this.resetSegmentationMemo(), this.applyManualFontSizeStyle(), this.update(), this.scheduleWrapRecompute(), this.scheduleReposition());
	}
	setFontSize(e) {
		this.fontSize = e, this.fontSizeOverridden = !0, this.smartLayoutEnabled || (this.applyManualFontSizeStyle(), this.lastWrapKey = null, this.resetSegmentationMemo(), this.scheduleWrapRecompute(), this.scheduleReposition());
	}
	setFontFamily(e) {
		this.fontFamily = e, this.applyFontFamilyStyle(), this.lastWrapKey = null, this.resetSegmentationMemo(), this.scheduleWrapRecompute(), this.scheduleReposition();
	}
	setOpacity(e) {
		let t = Number(e);
		this.opacity = ((100 - (Number.isFinite(t) ? Su(t, 0, 100) : 0)) / 100).toFixed(2), this.applyOpacityStyle();
	}
	stringifyTokens(e) {
		let t = "";
		for (let n of e) t += n.text;
		return t;
	}
	resolveActiveLine(e, t) {
		return Hl(e, t, this.maxActiveCueLookbackMs);
	}
	clearInactiveLineState() {
		if (this.lastActiveLineKey = null, this.subtitlesBlock || this.lastRenderKey !== null || this.strTokens) {
			this.clearRenderedContent({ releaseTooltip: !0 });
			return;
		}
		this.releaseTooltip();
	}
	refreshSmartLayoutIfNeeded() {
		if (!this.smartLayoutEnabled) return;
		let e = performance.now();
		if (this.lastSmartLayoutKey !== null && e - this.lastSmartLayoutCheckTs <= 500) return;
		this.lastSmartLayoutCheckTs = e;
		let t = this.getLayoutSize();
		if (!t.w || !t.h) return;
		let n = this.computeAnchorBoxLayout(t);
		n.w && n.h && this.ensureSmartLayout(n);
	}
	getRenderState(e, t, n) {
		let r = this.processTokens(e.tokens, n);
		this.lastWrapTokens = r;
		let i = this.stringifyTokens(r), a = i !== this.strTokens;
		a && (this.releaseTooltip(), this.strTokens = i, this.resetTranslationContext(), this.resetWrapMemo());
		let o = `${t}:${i}`;
		return {
			tokens: r,
			tokensChanged: a,
			passedFlags: this.highlightWords ? this.buildPassedState(r, n, o) : null,
			renderKey: `${t}:${i}:${this.breakAfterTokenIndices.join(",")}`
		};
	}
	syncRenderedTokens(e) {
		this.subtitlesContainer = this.subtitlesContainer ?? this.createSubtitlesContainer(), q(ml`<vot-block
        class="vot-subtitles"
        dir="auto"
        lang=${this.subtitleLang ?? ""}
        @click=${this.onClick}
      >
        ${this.renderTokens(e)}
      </vot-block>`, this.subtitlesContainer);
		let t = this.subtitlesContainer.firstElementChild;
		this.subtitlesBlock = t instanceof HTMLElement && t.classList.contains("vot-subtitles") ? t : null, this.renderedHighlightEls = this.subtitlesBlock ? Array.from(this.subtitlesBlock.querySelectorAll("span[data-vot-highlight-index]")) : [];
	}
	update() {
		if (!this.video || !this.subtitles) return;
		let e = this.resolvePlaybackTimeMs(), t = this.subtitles.subtitles, n = this.resolveActiveLine(e, t);
		if (!n) {
			this.clearInactiveLineState();
			return;
		}
		this.lastActiveLineKey = n.lineKey, this.refreshSmartLayoutIfNeeded();
		let { tokens: r, tokensChanged: i, passedFlags: a, renderKey: o } = this.getRenderState(n.line, n.lineKey, e);
		if (o === this.lastRenderKey) {
			this.highlightWords && !i && a && this.updatePassedClasses(a), this.maybeRefreshPosition();
			return;
		}
		this.lastRenderKey = o, this.syncRenderedTokens(r), this.highlightWords && a && this.updatePassedClasses(a), i ? (this.applyPositionAfterContentRender(), this.scheduleWrapRecompute(r), this.scheduleReposition()) : this.maybeRefreshPosition();
	}
	release() {
		this.detachDragDocumentListeners(), this.stopVideoFrameLoop(), this.abortController.abort(), this.resizeObserver?.disconnect(), this.clearPendingSchedulerState(), this.checkerUnsubscribe?.(), this.checkerUnsubscribe = null, this.releaseTooltip(), this.subtitlesContainer &&= (this.subtitlesContainer.remove(), null), this.fullscreenLayerController.release(), this.safeAreaProbeEl &&= (this.safeAreaProbeEl.remove(), null), this.guidesLayer && (this.guidesLayer.remove(), this.guidesLayer = null, this.verticalGuide = null, this.horizontalGuide = null), this.measureCtx = null, this.measureCanvas = null, this.lastAppliedLeftPct = null, this.lastAppliedTopPct = null, this.passedStateKey = null, this.passedThresholds.length = 0, this.insetCacheReady = !1;
	}
}, xd = /^<\s*(\/?)\s*([a-z0-9]+)([^>]*)>/iu, Sd = /^\{([^}]*)\}/u, Cd = /^(\s*)>>\s*/u, wd = /(\d{1,2}:\d{2}(?::\d{2})?)(?=[\p{L}\p{M}])/gu, Td = /([\p{L}\p{M}]+)(\d+)|(\d+)([\p{L}\p{M}]+)/gu, Ed = /\\[^\\]+/gu, Dd = /^\\([ibu])([01])$/u, Od = /^\\(?:1?c|c)&H([0-9a-f]{6,8})&$/iu, kd = /^\\r(?:[^\\}]*)?$/u, Ad = (e) => ({
	italic: e.italic,
	bold: e.bold,
	underline: e.underline,
	color: e.color,
	classes: [...e.classes]
}), jd = (e, t) => {
	e.italic = t.italic, e.bold = t.bold, e.underline = t.underline, e.color = t.color, e.classes = [...t.classes];
}, Md = (e) => {
	e.italic = !1, e.bold = !1, e.underline = !1, e.color = void 0, e.classes = [];
}, Nd = (e) => vu({
	italic: e.italic,
	bold: e.bold,
	underline: e.underline,
	color: e.color,
	classes: e.classes
}), Pd = (e, t, n) => {
	if (!t) return;
	let r = Nd(n), i = e.at(-1);
	if (i && bu(i.style, r)) {
		i.text += t;
		return;
	}
	e.push({
		text: t,
		style: r
	});
}, Fd = (e) => {
	let t = e.trim();
	if (!/^[0-9a-f]{6,8}$/iu.test(t)) return;
	let n = t.slice(-6), r = n.slice(0, 2), i = n.slice(2, 4);
	return _u(`#${n.slice(4, 6)}${i}${r}`);
}, Id = (e, t) => {
	let n = Dd.exec(e.trim());
	if (n) {
		let e = n[2] === "1";
		if (n[1] === "i") {
			t.italic = e;
			return;
		}
		if (n[1] === "b") {
			t.bold = e;
			return;
		}
		if (n[1] === "u") {
			t.underline = e;
			return;
		}
	}
	if (kd.test(e.trim())) {
		Md(t);
		return;
	}
	let r = Od.exec(e.trim());
	r && (t.color = Fd(r[1]));
}, Ld = (e, t) => {
	let n = e.match(Ed) ?? [];
	for (let e of n) Id(e, t);
}, Rd = (e) => {
	for (let t of e) {
		if (!t.text) continue;
		let e = t.text.replace(Cd, "$1");
		if (t.text = e, e.length > 0) break;
	}
	for (; e[0]?.text === "";) e.shift();
}, zd = (e) => {
	for (let t of e) t.text &&= t.text.replaceAll(wd, "$1 ");
}, Bd = (e) => {
	for (let t of e) t.text &&= t.text.replaceAll(Td, (e, t, n, r, i) => {
		let a = t ?? i ?? "", o = n ?? r ?? "";
		return /^[A-Za-z]{1,3}$/u.test(a) || a.length === 1 && a === a.toLocaleUpperCase() && a !== a.toLocaleLowerCase() ? e : t ? `${a} ${o}` : `${o} ${a}`;
	});
}, Vd = (e) => {
	let t = e.trim();
	if (!t.startsWith(".")) return;
	let n = t.split(/\s+/u, 1)[0].split(".").filter(Boolean);
	return n.length ? n : void 0;
}, Hd = (e) => {
	let t = /\bcolor\s*=\s*(?:"([^"]+)"|'([^']+)'|([^\s>]+))/iu.exec(e), n = t?.[1] ?? t?.[2] ?? t?.[3];
	return n ? _u(n) : void 0;
}, Ud = (e, t, n) => {
	for (let r = t.length - 1; r >= 0; --r) {
		if (t[r].tagName !== e) continue;
		let [i] = t.splice(r, 1);
		if (!i) return;
		jd(n, i.previousStyle);
		return;
	}
	if (e === "b") {
		n.bold = !1;
		return;
	}
	if (e === "i") {
		n.italic = !1;
		return;
	}
	if (e === "u") {
		n.underline = !1;
		return;
	}
	if (e === "font") {
		n.color = void 0;
		return;
	}
	e === "c" && (n.classes = []);
}, Wd = (e, t, n, r) => {
	let i = e[1] === "/", a = e[2].toLowerCase(), o = e[3] ?? "";
	if (a === "br") {
		Pd(t, "\n", n);
		return;
	}
	if (i) {
		Ud(a, r, n);
		return;
	}
	if ([
		"b",
		"i",
		"u",
		"font",
		"c"
	].includes(a)) {
		if (r.push({
			tagName: a,
			previousStyle: Ad(n)
		}), a === "b") {
			n.bold = !0;
			return;
		}
		if (a === "i") {
			n.italic = !0;
			return;
		}
		if (a === "u") {
			n.underline = !0;
			return;
		}
		if (a === "font") {
			let e = Hd(o);
			e && (n.color = e);
			return;
		}
		n.classes = Vd(o) ?? [];
	}
}, Gd = (e, t, n, r, i) => {
	let a = e.slice(t);
	if (a.startsWith("\\N") || a.startsWith("\\n")) return Pd(n, "\n", r), t + 2;
	if (a.startsWith("\\h")) return Pd(n, " ", r), t + 2;
	if (a[0] === "\n") return Pd(n, "\n", r), t + 1;
	let o = Sd.exec(a);
	if (o) return Ld(o[1], r), t + o[0].length;
	let s = xd.exec(a);
	return s ? (Wd(s, n, r, i), t + s[0].length) : null;
}, Kd = (e) => {
	let t = [], n = "";
	for (let r of e) {
		if (!r.text) continue;
		let e = n.length;
		n += r.text, t.push({
			start: e,
			end: n.length,
			style: r.style
		});
	}
	return {
		text: n,
		styledSpans: t
	};
}, qd = (e, t) => {
	let n = e.replaceAll("\xA0", " "), r = /^\s*/u.exec(n)?.[0].length ?? 0, i = /\s*$/u.exec(n)?.[0].length ?? 0, a = Math.max(r, n.length - i), o = n.slice(r, a);
	return {
		text: o,
		styledSpans: t.map((e) => ({
			start: Math.max(0, e.start - r),
			end: Math.max(0, e.end - r),
			style: e.style
		})).filter((e) => e.end > e.start && e.start < o.length).map((e) => ({
			...e,
			end: Math.min(e.end, o.length)
		}))
	};
}, Jd = (e) => {
	let t = [], n = {
		italic: !1,
		bold: !1,
		underline: !1,
		color: void 0,
		classes: []
	}, r = [], i = 0;
	for (; i < e.length;) {
		let a = Gd(e, i, t, n, r);
		if (a !== null) {
			i = a;
			continue;
		}
		Pd(t, e[i], n), i += 1;
	}
	Rd(t), zd(t), Bd(t);
	let a = Kd(t);
	return qd(a.text, a.styledSpans);
}, Yd = (e, t, n) => {
	if (!(!e?.length || n <= t)) return e.find((e) => t < e.end && n > e.start && e.style)?.style;
}, Xd = "﻿", Zd = /\{[^}]*\}/gu, Qd = /^\s*(?<start>\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})\s*-->\s*(?<end>\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})\s*$/u, $d = /^(?<start>(?:\d{2}:)?\d{2}:\d{2}\.\d{3})\s+-->\s+(?<end>(?:\d{2}:)?\d{2}:\d{2}\.\d{3})(?<settings>(?:[ \t]+.+)?)$/u, ef = (e) => e.replace(Xd, "").replaceAll(/\r\n?/gu, "\n"), tf = (e) => e.length >= 3 ? e.slice(0, 3) : e.padEnd(3, "0"), nf = (e, t) => {
	let n = e.trim().split(":");
	if (n.length < 2 || n.length > 3) return null;
	let [r, i, a] = n.length === 2 ? ["00", ...n] : n, [o, s = "0"] = a.split(/[.,]/u);
	if (!/^\d+$/u.test(r) || !/^\d{2}$/u.test(i) || !/^\d{2}$/u.test(o) || !/^\d+$/u.test(s)) return null;
	let c = Number(r), l = Number(i), u = Number(o), d = Number(tf(s).slice(0, t));
	return !Number.isFinite(c) || !Number.isFinite(l) || !Number.isFinite(u) || l > 59 || u > 59 ? null : ((c * 60 + l) * 60 + u) * 1e3 + d;
}, rf = (e, { delimiter: t, allowOptionalHours: n, fractionDigits: r }) => {
	let { hours: i, minutes: a, seconds: o, milliseconds: s } = af(e, Math.round), c = s.toString().padStart(3, "0").slice(0, r);
	return `${n && i === 0 ? "" : `${i.toString().padStart(2, "0")}:`}${a.toString().padStart(2, "0")}:${o.toString().padStart(2, "0")}${t}${c}`;
}, af = (e, t) => {
	let n = Math.max(0, t(e));
	return {
		hours: Math.floor(n / 36e5),
		minutes: Math.floor(n % 36e5 / 6e4),
		seconds: Math.floor(n % 6e4 / 1e3),
		milliseconds: n % 1e3
	};
}, of = (e) => {
	let { hours: t, minutes: n, seconds: r, milliseconds: i } = af(e, Math.round), a = Math.floor(i / 10);
	return `${t}:${n.toString().padStart(2, "0")}:${r.toString().padStart(2, "0")}.${a.toString().padStart(2, "0")}`;
}, sf = (e) => {
	let t = /^(?<hours>\d+):(?<minutes>\d{2}):(?<seconds>\d{2})\.(?<centiseconds>\d{2})$/u.exec(e.trim());
	if (!t?.groups) return null;
	let n = Number(t.groups.hours), r = Number(t.groups.minutes), i = Number(t.groups.seconds), a = Number(t.groups.centiseconds);
	return r > 59 || i > 59 || !Number.isFinite(n) || !Number.isFinite(a) ? null : ((n * 60 + r) * 60 + i) * 1e3 + a * 10;
}, cf = (e) => Jd(e).text, lf = (e) => e.startMs + Math.max(0, e.durationMs), uf = (e, t) => Math.max(0, t - e), df = (e) => e.sort((e, t) => {
	let n = e.line.startMs - t.line.startMs;
	if (n !== 0) return n;
	let r = lf(e.line) - lf(t.line);
	return r === 0 ? e.index - t.index : r;
}).map(({ line: e }) => e), ff = (e) => {
	let t = 0, n = e.length;
	for (; t < n && e[t] === "";) t += 1;
	for (; n > t && e[n - 1] === "";) --n;
	return e.slice(t, n);
}, pf = (e) => {
	let t = e.trim();
	if (!t) return;
	let n = {};
	for (let e of t.split(/\s+/u)) {
		let t = e.indexOf(":");
		t <= 0 || (n[e.slice(0, t)] = e.slice(t + 1));
	}
	return {
		raw: t,
		values: n
	};
}, mf = (e) => (/^\s*<v(?:\.[^ >]+)?(?:\s+([^>]*?))?>/iu.exec(e) ?? /^\s*<v\s+([^>]*?)>/iu.exec(e))?.[1]?.trim() || void 0, hf = (e, t) => {
	let n = e[t]?.trim() ?? "", r = e[t + 1]?.trim() ?? "";
	return Qd.test(n) || /^\d+$/u.test(n) && Qd.test(r);
}, gf = (e, t) => /^\d+$/u.test(e[t]?.trim() ?? "") && Qd.test(e[t + 1]?.trim() ?? "") ? t + 1 : t, _f = (e, t) => {
	let n = Qd.exec(e[t]?.trim() ?? "");
	if (!n?.groups) return null;
	let r = nf(n.groups.start, 3), i = nf(n.groups.end, 3);
	return r == null || i == null || i < r ? null : {
		startMs: r,
		endMs: i
	};
}, vf = (e, t) => {
	let n = t, r = [];
	for (; n < e.length;) {
		if (e[n].trim() === "") {
			if (hf(e, n + 1)) break;
			n += 1;
			continue;
		}
		if (r.length > 0 && hf(e, n)) break;
		r.push(e[n]), n += 1;
	}
	return {
		rawText: ff(r).join("\n"),
		nextCursor: n
	};
}, yf = (e, { rawText: t, startMs: n, endMs: r, speakerId: i, displayModel: a, metadata: o }) => ({
	index: e,
	line: {
		text: a.text,
		startMs: n,
		durationMs: uf(n, r),
		speakerId: i,
		tokens: [],
		metadata: {
			rawText: t,
			styledSpans: a.styledSpans,
			...o
		}
	}
}), bf = () => ({
	format: "vtt",
	subtitles: [],
	metadata: { vtt: {
		headerText: "",
		blocks: []
	} }
}), xf = (e) => e.startsWith("NOTE") || e === "STYLE" || e === "REGION", Sf = (e, t) => {
	let n = [], r = t;
	for (; r < e.length && e[r].trim() !== "";) n.push(e[r]), r += 1;
	return {
		blockLines: n,
		nextCursor: r
	};
}, Cf = (e, t) => !$d.test(e[t] ?? "") && $d.test(e[t + 1] ?? "") ? {
	cueId: e[t],
	timingCursor: t + 1
} : {
	cueId: void 0,
	timingCursor: t
}, wf = (e) => {
	let t = $d.exec(e);
	if (!t?.groups) return null;
	let n = nf(t.groups.start, 3), r = nf(t.groups.end, 3);
	return n == null || r == null || r < n ? null : {
		startMs: n,
		endMs: r,
		settingsRaw: t.groups.settings ?? ""
	};
}, Tf = (e, t) => {
	let n = [], r = t;
	for (; r < e.length && e[r].trim() !== "";) n.push(e[r]), r += 1;
	return {
		payloadLines: n,
		nextCursor: r
	};
}, Ef = (e) => e.slice(7).split(",").map((e) => e.trim()), Df = (e, t) => e.length || !t.eventFormat ? e : Ef(t.eventFormat), Of = (e, t) => {
	let n = zf(t, e.length);
	return Object.fromEntries(e.map((e, t) => [e, n[t] ?? ""]));
}, kf = (e, t) => {
	if (t.startsWith("Format:")) {
		e.styleFormat = t;
		return;
	}
	if (t.startsWith("Style:")) {
		e.styleLines.push(t);
		return;
	}
	e.preEventLines.push(t);
}, Af = (e, t) => {
	let n = sf(t.Start ?? ""), r = sf(t.End ?? "");
	if (n == null || r == null || r < n) return null;
	let i = t.Text ?? "", a = Jd(i), o = {
		kind: "dialogue",
		layer: t.Layer ?? "0",
		style: t.Style ?? "Default",
		name: t.Name ?? "",
		marginL: t.MarginL ?? "0",
		marginR: t.MarginR ?? "0",
		marginV: t.MarginV ?? "0",
		effect: t.Effect ?? "",
		rawText: i,
		overrideTags: i.match(Zd) ?? []
	};
	return {
		index: e,
		line: yf(e, {
			rawText: i,
			startMs: n,
			endMs: r,
			speakerId: o.name || "0",
			displayModel: a,
			metadata: { ass: o }
		}).line
	};
}, jf = (e, t, n, r) => {
	if (t.startsWith("Format:")) return {
		eventFields: Ef(t),
		cue: null
	};
	if (!t.includes(":")) return e.preEventLines.push(t), {
		eventFields: r,
		cue: null
	};
	let i = t.indexOf(":"), a = t.slice(0, i).trim(), o = t.slice(i + 1).trim(), s = Df(r, e), c = Of(s, o);
	return a === "Comment" ? (e.commentLines.push(t), {
		eventFields: s,
		cue: null
	}) : a === "Dialogue" ? {
		eventFields: s,
		cue: Af(n, c)
	} : (e.preEventLines.push(t), {
		eventFields: s,
		cue: null
	});
}, Mf = (e) => {
	let t = ef(e).split("\n"), n = [], r = 0, i = 0;
	for (; r < t.length;) {
		for (; r < t.length && t[r].trim() === "";) r += 1;
		if (r >= t.length) break;
		let e = gf(t, r), a = _f(t, e);
		if (!a) {
			r += 1;
			continue;
		}
		let o = vf(t, e + 1);
		r = o.nextCursor;
		let s = o.rawText, c = Jd(s);
		n.push(yf(i, {
			rawText: s,
			startMs: a.startMs,
			endMs: a.endMs,
			speakerId: "0",
			displayModel: c
		})), i += 1;
	}
	return {
		format: "srt",
		subtitles: df(n)
	};
}, Nf = (e, t, n) => e.format === n ? t.metadata?.rawText ?? t.text : n === "ass" ? t.text.replaceAll("\n", "\\N") : t.text, Pf = (e) => e.subtitles.map((t, n) => {
	let r = Nf(e, t, "srt"), i = lf(t);
	return [
		String(n + 1),
		`${rf(t.startMs, {
			delimiter: ",",
			allowOptionalHours: !1,
			fractionDigits: 3
		})} --> ${rf(i, {
			delimiter: ",",
			allowOptionalHours: !1,
			fractionDigits: 3
		})}`,
		r
	].join("\n");
}).join("\n\n"), Ff = (e, t, n) => {
	e.push({
		cueIndex: t,
		lines: n
	});
}, If = (e) => {
	let t = ef(e).split("\n"), n = t[0] ?? "";
	if (!n.startsWith("WEBVTT")) return bf();
	let r = {
		headerText: n.slice(6).trim(),
		blocks: []
	}, i = [], a = 1;
	for (; a < t.length;) {
		for (; a < t.length && t[a].trim() === "";) a += 1;
		if (a >= t.length) break;
		if (xf(t[a])) {
			let e = Sf(t, a);
			a = e.nextCursor, Ff(r.blocks, i.length, e.blockLines);
			continue;
		}
		let e = Cf(t, a), n = wf(t[e.timingCursor] ?? "");
		if (!n) {
			a += 1;
			continue;
		}
		let o = Tf(t, e.timingCursor + 1);
		a = o.nextCursor;
		let s = o.payloadLines, c = s.join("\n"), l = Jd(c), u = mf(c);
		i.push({
			index: i.length,
			line: yf(i.length, {
				rawText: c,
				startMs: n.startMs,
				endMs: n.endMs,
				speakerId: u ?? "0",
				displayModel: l,
				metadata: { vtt: {
					cueId: e.cueId,
					settings: pf(n.settingsRaw),
					voice: u,
					rawPayload: s
				} }
			}).line
		});
	}
	return {
		format: "vtt",
		subtitles: df(i),
		metadata: { vtt: r }
	};
}, Lf = (e) => {
	let t = lf(e), n = e.metadata?.vtt?.settings?.raw, r = n ? ` ${n}` : "";
	return `${rf(e.startMs, {
		delimiter: ".",
		allowOptionalHours: !0,
		fractionDigits: 3
	})} --> ${rf(t, {
		delimiter: ".",
		allowOptionalHours: !0,
		fractionDigits: 3
	})}${r}`;
}, Rf = (e) => {
	let t = e.metadata?.vtt, n = [`WEBVTT${t?.headerText ? ` ${t.headerText}` : ""}`], r = /* @__PURE__ */ new Map();
	for (let e of t?.blocks ?? []) {
		let t = r.get(e.cueIndex) ?? [];
		t.push(e.lines), r.set(e.cueIndex, t);
	}
	let i = (e) => {
		for (let t of r.get(e) ?? []) n.push(t.join("\n"));
	};
	return i(0), e.subtitles.forEach((t, r) => {
		let a = t.metadata?.vtt?.cueId, o = [
			...a ? [a] : [],
			Lf(t),
			(e.format === "vtt" ? t.metadata?.vtt?.rawPayload : t.text.split("\n"))?.join("\n") ?? t.text
		];
		n.push(o.join("\n")), i(r + 1);
	}), n.filter(Boolean).join("\n\n");
}, zf = (e, t) => {
	if (t <= 1) return [e];
	let n = [], r = 0;
	for (let i = 0; i < t - 1; i += 1) {
		let t = e.indexOf(",", r);
		if (t < 0) {
			n.push(e.slice(r).trim()), r = e.length;
			break;
		}
		n.push(e.slice(r, t).trim()), r = t + 1;
	}
	return n.push(e.slice(r).trim()), n;
}, Bf = () => ({
	scriptInfoLines: [],
	styleFormat: "",
	styleLines: [],
	eventFormat: "",
	preEventLines: [],
	commentLines: []
}), Vf = (e = "Exported subtitles") => ({
	scriptInfoLines: [
		`Title: ${e}`,
		"ScriptType: v4.00+",
		"WrapStyle: 0",
		"ScaledBorderAndShadow: yes"
	],
	styleFormat: "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
	styleLines: ["Style: Default,Arial,42,&H00FFFFFF,&H000000FF,&H00000000,&H64000000,0,0,0,0,100,100,0,0,1,2,0,2,20,20,20,1"],
	eventFormat: "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
	preEventLines: [],
	commentLines: []
}), Hf = (e) => {
	let t = ef(e).split("\n"), n = Bf(), r = [], i = "", a = [];
	return t.forEach((e, t) => {
		let o = e.trim();
		if (!o) return;
		let s = /^\[(.+)\]$/u.exec(o);
		if (s) {
			i = s[1];
			return;
		}
		if (i === "Script Info") {
			n.scriptInfoLines.push(e);
			return;
		}
		if (i === "V4+ Styles" || i === "V4 Styles") {
			kf(n, e);
			return;
		}
		if (i === "Events") {
			e.startsWith("Format:") && (n.eventFormat = e);
			let i = jf(n, e, t, a);
			a = i.eventFields, i.cue && r.push(i.cue);
		}
	}), {
		format: "ass",
		subtitles: df(r),
		metadata: { ass: n }
	};
}, Uf = (e) => {
	let t = e.metadata?.ass, n = lf(e), r = t?.rawText ?? e.metadata?.rawText ?? e.text.replaceAll("\n", "\\N");
	return [
		t?.kind === "comment" ? "Comment" : "Dialogue",
		": ",
		[
			t?.layer ?? "0",
			of(e.startMs),
			of(n),
			t?.style ?? "Default",
			t?.name ?? "",
			t?.marginL ?? "0",
			t?.marginR ?? "0",
			t?.marginV ?? "0",
			t?.effect ?? "",
			r
		].join(",")
	].join("");
}, Wf = (e, t) => {
	if (!t) return e;
	let n = `Title: ${t}`, r = [...e.scriptInfoLines], i = r.findIndex((e) => e.startsWith("Title:"));
	return i >= 0 ? r[i] === "Title: Exported subtitles" && (r[i] = n) : r.unshift(n), {
		...e,
		scriptInfoLines: r
	};
}, Gf = (e, t) => {
	let n = e.metadata?.ass, r = Wf(n && n.scriptInfoLines.length > 0 && n.styleFormat && n.styleLines.length > 0 && n.eventFormat ? n : Vf(t?.assTitle), t?.assTitle);
	return [
		"[Script Info]",
		...r.scriptInfoLines,
		"",
		"[V4+ Styles]",
		r.styleFormat,
		...r.styleLines,
		...r.preEventLines,
		"",
		"[Events]",
		r.eventFormat,
		...r.commentLines,
		...e.subtitles.map((t) => Uf({
			...t,
			metadata: e.format === "ass" ? t.metadata : {
				...t.metadata,
				rawText: Nf(e, t, "ass")
			}
		}))
	].join("\n").trim();
}, Kf = (e, t) => t === "srt" ? Mf(e) : t === "vtt" ? If(e) : Hf(e), qf = (e) => ({
	...e,
	subtitles: df(e.subtitles.map((e, t) => ({
		index: t,
		line: e
	})))
}), Jf = (e) => {
	let t = e.subtitles.map((e) => ({
		text: e.text,
		startMs: e.startMs,
		durationMs: e.durationMs,
		speakerId: e.speakerId,
		tokens: e.tokens.map((e) => ({
			text: e.text,
			startMs: e.startMs,
			durationMs: e.durationMs
		}))
	}));
	return {
		containsTokens: t.some((e) => e.tokens.length > 0),
		subtitles: t
	};
}, Yf = (e, t, n) => t === "json" ? Jf(e) : t === "srt" ? Pf(e) : t === "vtt" ? Rf(e) : Gf(e, n);
//#endregion
//#region src/utils/download.ts
function Xf(e) {
	return new Uint8Array([
		e >>> 24 & 255,
		e >>> 16 & 255,
		e >>> 8 & 255,
		e & 255
	]);
}
function Zf(e) {
	return new Uint8Array([
		e >>> 21 & 127,
		e >>> 14 & 127,
		e >>> 7 & 127,
		e & 127
	]);
}
function Qf(e, t) {
	let n = new TextEncoder().encode(t), r = new Uint8Array(n.length + 1);
	r[0] = 3, r.set(n, 1);
	let i = new Uint8Array(10 + r.length);
	i.set([
		84,
		73,
		84,
		50
	], 0), i.set(Xf(r.length), 4), i.set(r, 10);
	let a = new Uint8Array(10);
	a.set([
		73,
		68,
		51,
		3,
		0,
		0
	], 0), a.set(Zf(i.length), 6);
	let o = new Uint8Array(e), s = new Uint8Array(a.length + i.length + o.length);
	return s.set(a, 0), s.set(i, a.length), s.set(o, a.length + i.length), new Blob([s], { type: "audio/mpeg" });
}
function $f(e, t, n) {
	let r = n + t.byteLength, i = e;
	if (r > i.length) {
		let e = new Uint8Array(Math.max(r, i.length * 2));
		e.set(i.subarray(0, n)), i = e;
	}
	return i.set(t, n), {
		out: i,
		loaded: r
	};
}
function ep(e, t) {
	let n = new Uint8Array(t), r = 0;
	for (let t of e) n.set(t, r), r += t.byteLength;
	return n.buffer;
}
async function tp(e, t) {
	let n = Number(e.headers.get("Content-Length") ?? 0);
	if (!e.body) return e.arrayBuffer();
	let r = e.body.getReader(), i = 0, a = n > 0 ? new Uint8Array(n) : null, o = [];
	for (;;) {
		let { done: e, value: s } = await r.read();
		if (e) break;
		if (!(!s || s.byteLength === 0)) {
			if (a) {
				let e = $f(a, s, i);
				a = e.out, i = e.loaded;
			} else o.push(s), i += s.byteLength;
			n > 0 && t(R(Math.round(i / n * 100)));
		}
	}
	return a ? a.buffer.slice(0, i) : ep(o, i);
}
async function np(e, t, n = () => {}, r = {}) {
	return await Bi(await rp(e, t, n), `${t}.mp3`, r);
}
async function rp(e, t, n = () => {}) {
	let r = await tp(e, n);
	return n(100), Qf(r, t);
}
//#endregion
//#region src/ui/mount.ts
function ip(e, t) {
	return e.root === t.root && e.portalContainer === t.portalContainer && e.subtitlesMountContainer === t.subtitlesMountContainer && e.tooltipLayoutRoot === t.tooltipLayoutRoot;
}
function ap(e, t, n) {
	return ip(e, t) ? e : (n(t), t);
}
function op(e, t) {
	return e.root !== t.root || e.tooltipLayoutRoot !== t.tooltipLayoutRoot;
}
//#endregion
//#region src/ui/translationCommands.ts
function sp(e) {
	return e instanceof Error && e.name === "AbortError";
}
async function cp(e) {
	if (!e.videoData?.videoId || (lp(e) && (e.videoData = await e.getVideoData()), !e.videoData?.videoId)) throw new U("VOTNoVideoIDFound");
	return e.videoData;
}
function lp(e) {
	return e.site.host === "vk" && e.site.additionalData === "clips" || e.site.host === "douyin";
}
async function up(e) {
	let t = e.videoHandler;
	if (t) {
		if (L.log("[handleTranslationBtnClick] click translationBtn"), t.hasActiveSource()) {
			L.log("[handleTranslationBtnClick] video has active source"), await t.stopTranslation();
			return;
		}
		if (e.currentStatus === "error" && !e.currentLoading && e.transformBtn("none", V.get("translateVideo")), e.currentStatus !== "none" || e.currentLoading) {
			L.log("[handleTranslationBtnClick] translationBtn isn't in none state"), t.actionsAbortController.abort(), await t.stopTranslation();
			return;
		}
		try {
			L.log("[handleTranslationBtnClick] trying execute translation");
			let e = await cp(t);
			await t.videoManager.ensureDetectedLanguageForTranslation(e), L.log("[handleTranslationBtnClick] Run translateFunc", e.videoId), await t.translateFunc(e.videoId, e.isStream, e.detectedLanguage, e.responseLanguage, e.translationHelp);
		} catch (t) {
			if (sp(t)) {
				e.transformBtn("none", V.get("translateVideo"));
				return;
			}
			if (console.error("[VOT]", t), !(t instanceof Error)) {
				e.transformBtn("error", String(t));
				return;
			}
			let n = t.name === "VOTLocalizedError" ? t.localizedMessage : t.message;
			e.transformBtn("error", n);
		}
	}
}
//#endregion
//#region src/ui/icons.ts
var dp = G`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <path
    id="vot-translate-icon"
    fill-rule="evenodd"
    d="M15.778 18.95L14.903 21.375C14.8364 21.5583 14.7197 21.7083 14.553 21.825C14.3864 21.9417 14.203 22 14.003 22C13.6697 22 13.3989 21.8625 13.1905 21.5875C12.9822 21.3125 12.9447 21.0083 13.078 20.675L16.878 10.625C16.9614 10.4417 17.0864 10.2917 17.253 10.175C17.4197 10.0583 17.603 10 17.803 10H18.553C18.753 10 18.9364 10.0583 19.103 10.175C19.2697 10.2917 19.3947 10.4417 19.478 10.625L23.278 20.7C23.4114 21.0167 23.378 21.3125 23.178 21.5875C22.978 21.8625 22.7114 22 22.378 22C22.1614 22 21.9739 21.9375 21.8155 21.8125C21.6572 21.6875 21.5364 21.525 21.453 21.325L20.628 18.95H15.778ZM19.978 17.2H16.378L18.228 12.25L19.978 17.2Z"
  ></path>
  <path
    d="M9 14L4.7 18.3C4.51667 18.4833 4.28333 18.575 4 18.575C3.71667 18.575 3.48333 18.4833 3.3 18.3C3.11667 18.1167 3.025 17.8833 3.025 17.6C3.025 17.3167 3.11667 17.0833 3.3 16.9L7.65 12.55C7.01667 11.85 6.4625 11.125 5.9875 10.375C5.5125 9.625 5.1 8.83333 4.75 8H6.85C7.15 8.6 7.47083 9.14167 7.8125 9.625C8.15417 10.1083 8.56667 10.6167 9.05 11.15C9.78333 10.35 10.3917 9.52917 10.875 8.6875C11.3583 7.84583 11.7667 6.95 12.1 6H2C1.71667 6 1.47917 5.90417 1.2875 5.7125C1.09583 5.52083 1 5.28333 1 5C1 4.71667 1.09583 4.47917 1.2875 4.2875C1.47917 4.09583 1.71667 4 2 4H8V3C8 2.71667 8.09583 2.47917 8.2875 2.2875C8.47917 2.09583 8.71667 2 9 2C9.28333 2 9.52083 2.09583 9.7125 2.2875C9.90417 2.47917 10 2.71667 10 3V4H16C16.2833 4 16.5208 4.09583 16.7125 4.2875C16.9042 4.47917 17 4.71667 17 5C17 5.28333 16.9042 5.52083 16.7125 5.7125C16.5208 5.90417 16.2833 6 16 6H14.1C13.75 7.18333 13.275 8.33333 12.675 9.45C12.075 10.5667 11.3333 11.6167 10.45 12.6L12.85 15.05L12.1 17.1L9 14Z"
  ></path>
  <path
    id="vot-loading-icon"
    style="display:none"
    d="M19.8081 16.3697L18.5842 15.6633V13.0832C18.5842 12.9285 18.5228 12.7801 18.4134 12.6707C18.304 12.5613 18.1556 12.4998 18.0009 12.4998C17.8462 12.4998 17.6978 12.5613 17.5884 12.6707C17.479 12.7801 17.4176 12.9285 17.4176 13.0832V15.9998C17.4176 16.1022 17.4445 16.2028 17.4957 16.2915C17.5469 16.3802 17.6205 16.4538 17.7092 16.505L19.2247 17.38C19.2911 17.4189 19.3645 17.4443 19.4407 17.4547C19.5169 17.4652 19.5945 17.4604 19.6688 17.4407C19.7432 17.4211 19.813 17.3869 19.8741 17.3402C19.9352 17.2934 19.9864 17.2351 20.0249 17.1684C20.0634 17.1018 20.0883 17.0282 20.0982 16.952C20.1081 16.8757 20.1028 16.7982 20.0827 16.7239C20.0625 16.6497 20.0279 16.5802 19.9808 16.5194C19.9336 16.4586 19.8749 16.4077 19.8081 16.3697ZM18.0015 10C16.8478 10 15.6603 10.359 14.7011 11C13.7418 11.641 12.9415 12.4341 12.5 13.5C12.0585 14.5659 11.8852 16.0369 12.1103 17.1684C12.3353 18.3 12.8736 19.4942 13.6894 20.31C14.5053 21.1258 15.8684 21.7749 17 22C18.1316 22.2251 19.4341 21.9415 20.5 21.5C21.5659 21.0585 22.359 20.2573 23 19.298C23.641 18.3387 24.0015 17.1537 24.0015 16C23.9998 14.4534 23.5951 13.0936 22.5015 12C21.4079 10.9064 19.5481 10.0017 18.0015 10ZM18.0009 20.6665C17.0779 20.6665 16.1757 20.3928 15.4082 19.88C14.6408 19.3672 14.0427 18.6384 13.6894 17.7857C13.3362 16.933 13.2438 15.9947 13.4239 15.0894C13.604 14.1842 14.0484 13.3527 14.7011 12.7C15.3537 12.0474 16.1852 11.6029 17.0905 11.4228C17.9957 11.2428 18.934 11.3352 19.7867 11.6884C20.6395 12.0416 21.3683 12.6397 21.8811 13.4072C22.3939 14.1746 22.6676 15.0769 22.6676 15.9998C22.666 17.237 22.1738 18.4231 21.299 19.298C20.4242 20.1728 19.2381 20.665 18.0009 20.6665Z"
  ></path>
</svg>`, fp = G`<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24">
  <path
    d="M120-520q-17 0-28.5-11.5T80-560q0-17 11.5-28.5T120-600h104L80-743q-12-12-12-28.5T80-800q12-12 28.5-12t28.5 12l143 144v-104q0-17 11.5-28.5T320-800q17 0 28.5 11.5T360-760v200q0 17-11.5 28.5T320-520H120Zm40 360q-33 0-56.5-23.5T80-240v-160q0-17 11.5-28.5T120-440q17 0 28.5 11.5T160-400v160h280q17 0 28.5 11.5T480-200q0 17-11.5 28.5T440-160H160Zm680-280q-17 0-28.5-11.5T800-480v-240H480q-17 0-28.5-11.5T440-760q0-17 11.5-28.5T480-800h320q33 0 56.5 23.5T880-720v240q0 17-11.5 28.5T840-440ZM600-160q-17 0-28.5-11.5T560-200v-120q0-17 11.5-28.5T600-360h240q17 0 28.5 11.5T880-320v120q0 17-11.5 28.5T840-160H600Z"
  />
</svg>`, pp = G`<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24">
  <path
    d="M480-160q-33 0-56.5-23.5T400-240q0-33 23.5-56.5T480-320q33 0 56.5 23.5T560-240q0 33-23.5 56.5T480-160Zm0-240q-33 0-56.5-23.5T400-480q0-33 23.5-56.5T480-560q33 0 56.5 23.5T560-480q0 33-23.5 56.5T480-400Zm0-240q-33 0-56.5-23.5T400-720q0-33 23.5-56.5T480-800q33 0 56.5 23.5T560-720q0 33-23.5 56.5T480-640Z"
  />
</svg>`, mp = G`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="100%" viewBox="0 0 24 24" class="vot-loader" id="vot-loader-download">
  <path class="vot-loader-main" d="M12 15.575C11.8667 15.575 11.7417 15.5542 11.625 15.5125C11.5083 15.4708 11.4 15.4 11.3 15.3L7.7 11.7C7.5 11.5 7.40417 11.2667 7.4125 11C7.42083 10.7333 7.51667 10.5 7.7 10.3C7.9 10.1 8.1375 9.99583 8.4125 9.9875C8.6875 9.97917 8.925 10.075 9.125 10.275L11 12.15V5C11 4.71667 11.0958 4.47917 11.2875 4.2875C11.4792 4.09583 11.7167 4 12 4C12.2833 4 12.5208 4.09583 12.7125 4.2875C12.9042 4.47917 13 4.71667 13 5V12.15L14.875 10.275C15.075 10.075 15.3125 9.97917 15.5875 9.9875C15.8625 9.99583 16.1 10.1 16.3 10.3C16.4833 10.5 16.5792 10.7333 16.5875 11C16.5958 11.2667 16.5 11.5 16.3 11.7L12.7 15.3C12.6 15.4 12.4917 15.4708 12.375 15.5125C12.2583 15.5542 12.1333 15.575 12 15.575ZM6 20C5.45 20 4.97917 19.8042 4.5875 19.4125C4.19583 19.0208 4 18.55 4 18V16C4 15.7167 4.09583 15.4792 4.2875 15.2875C4.47917 15.0958 4.71667 15 5 15C5.28333 15 5.52083 15.0958 5.7125 15.2875C5.90417 15.4792 6 15.7167 6 16V18H18V16C18 15.7167 18.0958 15.4792 18.2875 15.2875C18.4792 15.0958 18.7167 15 19 15C19.2833 15 19.5208 15.0958 19.7125 15.2875C19.9042 15.4792 20 15.7167 20 16V18C20 18.55 19.8042 19.0208 19.4125 19.4125C19.0208 19.8042 18.55 20 18 20H6Z"/>
  <circle class="vot-loader-progress" cx="12" cy="12" r="9"></circle>
</svg>`, hp = G`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="100%" viewBox="0 0 24 24">
  <path d="M4 20q-.825 0-1.413-.588T2 18V6q0-.825.588-1.413T4 4h16q.825 0 1.413.588T22 6v12q0 .825-.588 1.413T20 20H4Zm2-4h8v-2H6v2Zm10 0h2v-2h-2v2ZM6 12h2v-2H6v2Zm4 0h8v-2h-8v2Z"/>
</svg>`, gp = G`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="100%" viewBox="0 -960 960 960">
  <path d="M555-80H405q-15 0-26-10t-13-25l-12-93q-13-5-24.5-12T307-235l-87 36q-14 5-28 1t-22-17L96-344q-8-13-5-28t15-24l75-57q-1-7-1-13.5v-27q0-6.5 1-13.5l-75-57q-12-9-15-24t5-28l74-129q7-14 21.5-17.5T220-761l87 36q11-8 23-15t24-12l12-93q2-15 13-25t26-10h150q15 0 26 10t13 25l12 93q13 5 24.5 12t22.5 15l87-36q14-5 28-1t22 17l74 129q8 13 5 28t-15 24l-75 57q1 7 1 13.5v27q0 6.5-2 13.5l75 57q12 9 15 24t-5 28l-74 128q-8 13-22.5 17.5T738-199l-85-36q-11 8-23 15t-24 12l-12 93q-2 15-13 25t-26 10Zm-73-260q58 0 99-41t41-99q0-58-41-99t-99-41q-59 0-99.5 41T342-480q0 58 40.5 99t99.5 41Zm0-80q-25 0-42.5-17.5T422-480q0-25 17.5-42.5T482-540q25 0 42.5 17.5T542-480q0 25-17.5 42.5T482-420Zm-2-60Zm-40 320h79l14-106q31-8 57.5-23.5T639-327l99 41 39-68-86-65q5-14 7-29.5t2-31.5q0-16-2-31.5t-7-29.5l86-65-39-68-99 42q-22-23-48.5-38.5T533-694l-13-106h-79l-14 106q-31 8-57.5 23.5T321-633l-99-41-39 68 86 64q-5 15-7 30t-2 32q0 16 2 31t7 30l-86 65 39 68 99-42q22 23 48.5 38.5T427-266l13 106Z"/>
</svg>`, _p = G`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" >
  <path
    d="M12 14.975q-.2 0-.375-.062T11.3 14.7l-4.6-4.6q-.275-.275-.275-.7t.275-.7q.275-.275.7-.275t.7.275l3.9 3.9l3.9-3.9q.275-.275.7-.275t.7.275q.275.275.275.7t-.275.7l-4.6 4.6q-.15.15-.325.213t-.375.062Z"
  />
</svg>`, vp = G`<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24">
  <path
    d="M647-440H200q-17 0-28.5-11.5T160-480q0-17 11.5-28.5T200-520h447L451-716q-12-12-11.5-28t12.5-28q12-11 28-11.5t28 11.5l264 264q6 6 8.5 13t2.5 15q0 8-2.5 15t-8.5 13L508-188q-11 11-27.5 11T452-188q-12-12-12-28.5t12-28.5l195-195Z"
  />
</svg>`, yp = G`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="100%" viewBox="0 -960 960 960">
  <path d="M480-424 284-228q-11 11-28 11t-28-11q-11-11-11-28t11-28l196-196-196-196q-11-11-11-28t11-28q11-11 28-11t28 11l196 196 196-196q11-11 28-11t28 11q11 11 11 28t-11 28L536-480l196 196q11 11 11 28t-11 28q-11 11-28 11t-28-11L480-424Z"/>
</svg>`, bp = G`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <g fill="none">
    <path d="m12.593 23.258l-.011.002l-.071.035l-.02.004l-.014-.004l-.071-.035q-.016-.005-.024.005l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427q-.004-.016-.017-.018m.265-.113l-.013.002l-.185.093l-.01.01l-.003.011l.018.43l.005.012l.008.007l.201.093q.019.005.029-.008l.004-.014l-.034-.614q-.005-.018-.02-.022m-.715.002a.02.02 0 0 0-.027.006l-.006.014l-.034.614q.001.018.017.024l.015-.002l.201-.093l.01-.008l.004-.011l.017-.43l-.003-.012l-.01-.01z"/><path fill="currentColor" d="M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12S6.477 2 12 2m0 2a8 8 0 1 0 0 16a8 8 0 0 0 0-16m0 11a1 1 0 1 1 0 2a1 1 0 0 1 0-2m0-9a1 1 0 0 1 1 1v6a1 1 0 1 1-2 0V7a1 1 0 0 1 1-1"/>
  </g>
</svg>`, xp = G`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <g fill="none">
    <path d="m12.593 23.258l-.011.002l-.071.035l-.02.004l-.014-.004l-.071-.035q-.016-.005-.024.005l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427q-.004-.016-.017-.018m.265-.113l-.013.002l-.185.093l-.01.01l-.003.011l.018.43l.005.012l.008.007l.201.093q.019.005.029-.008l.004-.014l-.034-.614q-.005-.018-.02-.022m-.715.002a.02.02 0 0 0-.027.006l-.006.014l-.034.614q.001.018.017.024l.015-.002l.201-.093l.01-.008l.004-.011l.017-.43l-.003-.012l-.01-.01z"/><path fill="currentColor" d="M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12S6.477 2 12 2m0 2a8 8 0 1 0 0 16a8 8 0 0 0 0-16m0 12a1 1 0 1 1 0 2a1 1 0 0 1 0-2m0-9.5a3.625 3.625 0 0 1 1.348 6.99a.8.8 0 0 0-.305.201c-.044.05-.051.114-.05.18L13 14a1 1 0 0 1-1.993.117L11 14v-.25c0-1.153.93-1.845 1.604-2.116a1.626 1.626 0 1 0-2.229-1.509a1 1 0 1 1-2 0A3.625 3.625 0 0 1 12 6.5"/>
  </g>
</svg>`, Sp = G`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <g fill="none">
    <path d="m12.594 23.258l-.012.002l-.071.035l-.02.004l-.014-.004l-.071-.036q-.016-.004-.024.006l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427q-.004-.016-.016-.018m.264-.113l-.014.002l-.184.093l-.01.01l-.003.011l.018.43l.005.012l.008.008l.201.092q.019.005.029-.008l.004-.014l-.034-.614q-.005-.019-.02-.022m-.715.002a.02.02 0 0 0-.027.006l-.006.014l-.034.614q.001.018.017.024l.015-.002l.201-.093l.01-.008l.003-.011l.018-.43l-.003-.012l-.01-.01z"/>
    <path fill="currentColor" d="M20 9a1 1 0 0 1 1 1v1a8 8 0 0 1-8 8H9.414l.793.793a1 1 0 0 1-1.414 1.414l-2.496-2.496a1 1 0 0 1-.287-.567L6 17.991a1 1 0 0 1 .237-.638l.056-.06l2.5-2.5a1 1 0 0 1 1.414 1.414L9.414 17H13a6 6 0 0 0 6-6v-1a1 1 0 0 1 1-1m-4.793-6.207l2.5 2.5a1 1 0 0 1 0 1.414l-2.5 2.5a1 1 0 1 1-1.414-1.414L14.586 7H11a6 6 0 0 0-6 6v1a1 1 0 1 1-2 0v-1a8 8 0 0 1 8-8h3.586l-.793-.793a1 1 0 0 1 1.414-1.414"/>
  </g>
</svg>`, Cp = G`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <path fill="currentColor" d="M7 15q1.25 0 2.125-.875T10 12t-.875-2.125T7 9t-2.125.875T4 12t.875 2.125T7 15m0 3q-2.5 0-4.25-1.75T1 12t1.75-4.25T7 6q2.025 0 3.538 1.15T12.65 10h8.375L23 11.975l-3.5 4L17 14l-2 2l-2-2h-.35q-.625 1.8-2.175 2.9T7 18"/>
  </svg>`;
//#endregion
//#region src/ui/components/componentShared.ts
function wp(e, t, n) {
	e[t].addListener(n);
}
function Tp(e, t, n) {
	e[t].removeListener(n);
}
function X(e, t) {
	e.hidden = t;
}
function Z(e) {
	return e.hidden;
}
//#endregion
//#region src/ui/components/downloadButton.ts
var Ep = class {
	button;
	loaderMain;
	loaderCircle;
	onClick = new H();
	events = { click: this.onClick };
	_progress = 0;
	constructor() {
		let e = this.createElements();
		this.button = e.button, this.loaderMain = e.loaderMain, this.loaderCircle = e.loaderCircle, this.progress = 0;
	}
	createElements() {
		let e = J.createIconButton(mp, { ariaLabel: "Download translation" }), t = e.querySelector(".vot-loader-main");
		if (!t) throw Error("[VOT] DownloadButton loader main element not found");
		let n = e.querySelector(".vot-loader-progress");
		if (!n) throw Error("[VOT] DownloadButton loader circle element not found");
		return e.addEventListener("click", () => {
			this.onClick.dispatch();
		}), {
			button: e,
			loaderMain: t,
			loaderCircle: n
		};
	}
	addEventListener(e, t) {
		return wp(this.events, "click", t), this;
	}
	removeEventListener(e, t) {
		return Tp(this.events, "click", t), this;
	}
	get progress() {
		return this._progress;
	}
	set progress(e) {
		let t = Dp(e);
		this._progress = t;
		let n = this.getCircleCircumference();
		this.loaderCircle.style.strokeDasharray = `${n}`;
		let r = n * (1 - t / 100);
		this.loaderCircle.style.strokeDashoffset = `${r}`, this.loaderMain.style.opacity = t === 0 ? "1" : "0", this.loaderCircle.style.opacity = t === 0 ? "0" : "1";
	}
	getCircleCircumference() {
		let e = this.loaderCircle.r?.baseVal?.value ?? 0;
		return 2 * Math.PI * e;
	}
	set hidden(e) {
		X(this.button, e);
	}
	get hidden() {
		return Z(this.button);
	}
};
function Dp(e) {
	if (!Number.isFinite(e)) return 0;
	let t = e < 1 ? e * 100 : e;
	return Math.max(0, Math.min(100, Math.round(t)));
}
//#endregion
//#region src/ui/components/label.ts
var Op = class {
	container;
	icon;
	text;
	_labelText;
	_icon;
	constructor({ labelText: e, icon: t }) {
		this._labelText = e, this._icon = t;
		let n = this.createElements();
		this.container = n.container, this.icon = n.icon, this.text = n.text;
	}
	createElements() {
		let e = J.createEl("vot-block", ["vot-label"]), t = J.createEl("span", ["vot-label-text"]);
		t.textContent = this._labelText;
		let n = J.createEl("span", ["vot-label-icon"]);
		return this._icon ? q(this._icon, n) : n.hidden = !0, e.append(t, n), {
			container: e,
			icon: n,
			text: t
		};
	}
	set hidden(e) {
		X(this.container, e);
	}
	get hidden() {
		return Z(this.container);
	}
}, kp = class {
	container;
	backdrop;
	box;
	contentWrapper;
	headerContainer;
	titleContainer;
	title;
	closeButton;
	bodyContainer;
	footerContainer;
	onClose = new H();
	events = { close: this.onClose };
	previouslyFocused = null;
	keydownListener;
	adaptiveAlignObserver;
	adaptiveAlignRaf = null;
	handleViewportChange = () => {
		this.scheduleAdaptiveVerticalAlign();
	};
	titleId = typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `vot-dialog-title-${Math.random().toString(36).slice(2)}`;
	_titleHtml;
	_isTemp;
	constructor({ titleHtml: e, isTemp: t = !1 }) {
		this._titleHtml = e, this._isTemp = t;
		let n = this.createElements();
		this.container = n.container, this.backdrop = n.backdrop, this.box = n.box, this.contentWrapper = n.contentWrapper, this.headerContainer = n.headerContainer, this.titleContainer = n.titleContainer, this.title = n.title, this.closeButton = n.closeButton, this.bodyContainer = n.bodyContainer, this.footerContainer = n.footerContainer;
	}
	createElements() {
		let e = J.createEl("vot-block", ["vot-dialog-container"]);
		this._isTemp && e.classList.add("vot-dialog-temp"), e.hidden = !this._isTemp, e.setAttribute("aria-hidden", e.hidden ? "true" : "false"), e.toggleAttribute("inert", e.hidden);
		let t = J.createEl("vot-block", ["vot-dialog-backdrop"]), n = J.createEl("vot-block", ["vot-dialog"]);
		n.dataset.verticalAlign = "center", n.setAttribute("role", "dialog"), n.setAttribute("aria-modal", "true"), n.tabIndex = -1;
		let r = J.createEl("vot-block", ["vot-dialog-content-wrapper"]), i = J.createEl("vot-block", ["vot-dialog-header-container"]), a = J.createEl("vot-block", ["vot-dialog-title-container"]), o = J.createEl("vot-block", ["vot-dialog-title"]);
		o.id = this.titleId, o.append(this._titleHtml), a.appendChild(o), n.setAttribute("aria-labelledby", this.titleId);
		let s = J.createIconButton(yp, { ariaLabel: "Close" });
		s.classList.add("vot-dialog-close-button"), t.addEventListener("click", () => {
			this.close();
		}), s.addEventListener("click", () => {
			this.close();
		}), i.append(a, s);
		let c = J.createEl("vot-block", ["vot-dialog-body-container"]), l = J.createEl("vot-block", ["vot-dialog-footer-container"]);
		return r.append(i, c, l), n.appendChild(r), e.append(t, n), n.addEventListener("click", (e) => {
			e.stopPropagation();
		}), {
			container: e,
			backdrop: t,
			box: n,
			contentWrapper: r,
			headerContainer: i,
			titleContainer: a,
			title: o,
			closeButton: s,
			bodyContainer: c,
			footerContainer: l
		};
	}
	addEventListener(e, t) {
		return wp(this.events, "close", t), this;
	}
	removeEventListener(e, t) {
		return Tp(this.events, "close", t), this;
	}
	open() {
		return this.previouslyFocused ??= document.activeElement, this.hidden = !1, this.attachKeydownTrap(), this.attachAdaptiveVerticalAlign(), queueMicrotask(() => this.focusFirst()), this;
	}
	remove() {
		return this.detachAdaptiveVerticalAlign(), this.detachKeydownTrap(), this.container.remove(), this.restoreFocus(), this.onClose.dispatch(), this;
	}
	close() {
		return this._isTemp ? this.remove() : (this.detachAdaptiveVerticalAlign(), this.detachKeydownTrap(), this.hidden = !0, this.restoreFocus(), this.onClose.dispatch(), this);
	}
	attachAdaptiveVerticalAlign() {
		if (this.adaptiveAlignObserver) {
			this.scheduleAdaptiveVerticalAlign();
			return;
		}
		typeof ResizeObserver < "u" && (this.adaptiveAlignObserver = new ResizeObserver(() => {
			this.scheduleAdaptiveVerticalAlign();
		}), this.adaptiveAlignObserver.observe(this.contentWrapper)), globalThis.addEventListener("resize", this.handleViewportChange, { passive: !0 }), globalThis.visualViewport && (globalThis.visualViewport.addEventListener("resize", this.handleViewportChange, { passive: !0 }), globalThis.visualViewport.addEventListener("scroll", this.handleViewportChange, { passive: !0 })), this.scheduleAdaptiveVerticalAlign();
	}
	detachAdaptiveVerticalAlign() {
		this.adaptiveAlignObserver &&= (this.adaptiveAlignObserver.disconnect(), void 0), globalThis.removeEventListener("resize", this.handleViewportChange), globalThis.visualViewport?.removeEventListener("resize", this.handleViewportChange), globalThis.visualViewport?.removeEventListener("scroll", this.handleViewportChange), this.adaptiveAlignRaf !== null && (cancelAnimationFrame(this.adaptiveAlignRaf), this.adaptiveAlignRaf = null);
	}
	scheduleAdaptiveVerticalAlign() {
		this.adaptiveAlignRaf !== null && cancelAnimationFrame(this.adaptiveAlignRaf), this.adaptiveAlignRaf = requestAnimationFrame(() => {
			this.adaptiveAlignRaf = null, this.updateAdaptiveVerticalAlign();
		});
	}
	updateAdaptiveVerticalAlign() {
		let e = globalThis.visualViewport?.height ?? globalThis.innerHeight;
		if (!e || e <= 0) return;
		let t = Math.max(160, Math.round(e * .75)), n = Math.max(160, Math.round(e - 32)), r = this.contentWrapper.scrollHeight, i = this.box.dataset.verticalAlign === "top", a = t - 8, o = Math.round(e * .6);
		(i ? r > o : r >= a) ? (this.box.dataset.verticalAlign = "top", this.box.style.setProperty("--vot-dialog-max-height", `${n}px`)) : (this.box.dataset.verticalAlign = "center", this.box.style.setProperty("--vot-dialog-max-height", `${t}px`));
	}
	restoreFocus() {
		let e = this.previouslyFocused;
		this.previouslyFocused = null, e && e instanceof HTMLElement && document.contains(e) && e.focus();
	}
	getFocusableElements() {
		return Array.from(this.container.querySelectorAll([
			"button:not([disabled])",
			"[href]",
			"input:not([disabled])",
			"select:not([disabled])",
			"textarea:not([disabled])",
			"[tabindex]:not([tabindex='-1'])",
			"[role='button']:not([aria-disabled='true'])"
		].join(","))).filter((e) => !e.hidden && e.getClientRects().length > 0);
	}
	focusFirst() {
		(this.getFocusableElements()[0] ?? this.closeButton ?? this.box).focus?.();
	}
	attachKeydownTrap() {
		this.keydownListener || (this.keydownListener = (e) => {
			if (e.key === "Escape") {
				e.preventDefault(), this.close();
				return;
			}
			if (e.key !== "Tab") return;
			let t = this.getFocusableElements();
			if (!t.length) {
				e.preventDefault(), this.box.focus();
				return;
			}
			let n = t[0], r = t.at(-1) ?? n, i = document.activeElement;
			e.shiftKey ? (i === n || i === this.box) && (e.preventDefault(), r.focus()) : i === r && (e.preventDefault(), n.focus());
		}, this.container.addEventListener("keydown", this.keydownListener));
	}
	detachKeydownTrap() {
		this.keydownListener &&= (this.container.removeEventListener("keydown", this.keydownListener), void 0);
	}
	set hidden(e) {
		X(this.container, e), this.container.setAttribute("aria-hidden", e ? "true" : "false"), this.container.toggleAttribute("inert", e);
	}
	get hidden() {
		return Z(this.container);
	}
	get isDialogOpen() {
		return !this.container.hidden;
	}
}, Ap = class {
	container;
	input;
	label;
	onInput = new H();
	onChange = new H();
	events = {
		input: this.onInput,
		change: this.onChange
	};
	_labelHtml;
	_multiline;
	_placeholder;
	_value;
	constructor({ labelHtml: e = "", placeholder: t = "", value: n = "", multiline: r = !1 }) {
		this._labelHtml = e, this._multiline = r, this._placeholder = t, this._value = n;
		let i = this.createElements();
		this.container = i.container, this.input = i.input, this.label = i.label;
	}
	createElements() {
		let e = J.createEl("vot-block", ["vot-textfield"]), t = document.createElement(this._multiline ? "textarea" : "input");
		this._labelHtml || t.classList.add("vot-show-placeholer", "vot-show-placeholder"), t.placeholder = this._placeholder, t.value = this._value;
		let n = J.createEl("span");
		return n.append(this._labelHtml), e.append(t, n), t.addEventListener("input", () => {
			this._value = this.input.value, this.onInput.dispatch(this._value);
		}), t.addEventListener("change", () => {
			this._value = this.input.value, this.onChange.dispatch(this._value);
		}), {
			container: e,
			label: n,
			input: t
		};
	}
	addEventListener(e, t) {
		return wp(this.events, e, t), this;
	}
	removeEventListener(e, t) {
		return Tp(this.events, e, t), this;
	}
	get value() {
		return this._value;
	}
	set value(e) {
		this._value !== e && (this.input.value = this._value = e, this.onChange.dispatch(this._value));
	}
	get placeholder() {
		return this._placeholder;
	}
	set placeholder(e) {
		this.input.placeholder = this._placeholder = e;
	}
	get disabled() {
		return this.input.disabled;
	}
	set disabled(e) {
		this.input.disabled = e;
	}
	set hidden(e) {
		X(this.container, e);
	}
	get hidden() {
		return Z(this.container);
	}
}, Q = class {
	container;
	outer;
	arrowIcon;
	title;
	dialogParent;
	labelElement;
	_selectTitle;
	_dialogTitle;
	multiSelect;
	baseItems;
	_items;
	searchItemsProvider;
	isLoading = !1;
	isDialogOpen = !1;
	searchRequestId = 0;
	onSelectItem = new H();
	onBeforeOpen = new H();
	events = {
		selectItem: this.onSelectItem,
		beforeOpen: this.onBeforeOpen
	};
	contentList;
	contentItemSearchDatasetKey = "votSearchLabel";
	contentItemIndexDatasetKey = "votIndex";
	selectedItems = [];
	selectedValues;
	constructor({ selectTitle: e, dialogTitle: t, items: n, searchItemsProvider: r, labelElement: i, dialogParent: a = document.documentElement, multiSelect: o }) {
		this._selectTitle = e, this._dialogTitle = t, this.baseItems = this.cloneItems(n), this._items = this.cloneItems(n), this.searchItemsProvider = r, this.multiSelect = o ?? !1, this.labelElement = i, this.dialogParent = a, this.selectedValues = this.calcSelectedValues();
		let s = this.createElements();
		this.container = s.container, this.outer = s.outer, this.arrowIcon = s.arrowIcon, this.title = s.title;
	}
	cloneItems(e) {
		return e.map((e) => ({ ...e }));
	}
	static genLanguageItems(e, t) {
		return e.map((e) => {
			let n = `langs.${e}`, r = V.get(n);
			return {
				label: r === n ? e.toUpperCase() : r,
				value: e,
				selected: t === e
			};
		});
	}
	multiSelectItemHandle = (e) => {
		let t = e.value;
		this.selectedValues.has(t) && this.selectedValues.size > 1 ? this.selectedValues.delete(t) : this.selectedValues.add(t), this.syncItemsSelectionState(), this.syncItemsSelectionState(this.baseItems), this.updateSelectedState(), this.onSelectItem.dispatch(Array.from(this.selectedValues));
	};
	singleSelectItemHandle = (e) => {
		let t = e.value;
		this.selectedValues = new Set([t]), this.syncItemsSelectionState(), this.syncItemsSelectionState(this.baseItems), this.updateSelectedState(), this.onSelectItem.dispatch(t);
	};
	onContentItemClick = (e) => {
		if (!(e.target instanceof HTMLElement)) return;
		let t = e.target.closest(".vot-select-content-item");
		if (!t || t.inert || !this.contentList?.contains(t)) return;
		let n = t.dataset[this.contentItemIndexDatasetKey];
		if (!n) return;
		let r = this._items[Number(n)];
		if (r) {
			if (this.multiSelect) {
				this.multiSelectItemHandle(r);
				return;
			}
			this.singleSelectItemHandle(r);
		}
	};
	syncItemsSelectionState(e = this._items) {
		for (let t of e) t.selected = this.selectedValues.has(t.value);
	}
	restoreBaseItems() {
		this._items = this.cloneItems(this.baseItems), this.syncItemsSelectionState(), this.updateSelectedState();
	}
	createDialogContentList() {
		let e = J.createEl("vot-block", ["vot-select-content-list"]);
		for (let [t, n] of this._items.entries()) {
			let r = J.createEl("vot-block", ["vot-select-content-item"]);
			r.textContent = n.label, r.dataset.votSelected = n.selected === !0 ? "true" : "false", r.dataset.votValue = n.value, r.dataset[this.contentItemSearchDatasetKey] = n.label.toLowerCase(), r.dataset[this.contentItemIndexDatasetKey] = String(t), n.disabled && (r.inert = !0), e.appendChild(r);
		}
		return e.addEventListener("click", this.onContentItemClick), this.selectedItems = Array.from(e.children), e;
	}
	createElements() {
		let e = J.createEl("vot-block", ["vot-select"]);
		this.labelElement ? (e.classList.add("vot-select--labeled"), e.append(this.labelElement)) : e.classList.add("vot-select--control-only");
		let t = J.createEl("vot-block", ["vot-select-outer"]);
		J.makeButtonLike(t), t.setAttribute("aria-haspopup", "dialog"), t.setAttribute("aria-expanded", "false");
		let n = J.createEl("vot-block", ["vot-select-title"]);
		n.textContent = this.visibleText;
		let r = J.createEl("vot-block", ["vot-select-arrow-icon"]);
		return q(_p, r), t.append(n, r), t.addEventListener("click", () => {
			if (!this.disabled && !(this.isLoading || this.isDialogOpen)) try {
				this.isLoading = !0;
				let e = new kp({
					titleHtml: this._dialogTitle,
					isTemp: !0
				});
				this.onBeforeOpen.dispatch(e), this.dialogParent.appendChild(e.container), this.isDialogOpen = !0, t.setAttribute("aria-expanded", "true");
				let n = new Ap({ labelHtml: V.get("searchField") });
				n.addEventListener("input", async (e) => {
					let t = ++this.searchRequestId;
					if (this.searchItemsProvider) {
						let n = await this.searchItemsProvider(e);
						if (t !== this.searchRequestId) return;
						this.updateItems(n, { persist: !1 });
					}
					let n = e.toLowerCase();
					for (let e of this.selectedItems) e.hidden = !(e.dataset[this.contentItemSearchDatasetKey] ?? "").includes(n);
				}), this.contentList = this.createDialogContentList(), e.bodyContainer.append(n.container, this.contentList), e.addEventListener("close", () => {
					this.isDialogOpen = !1, this.restoreBaseItems(), this.selectedItems = [], this.contentList = void 0, t.setAttribute("aria-expanded", "false");
				}), e.open();
			} finally {
				this.isLoading = !1;
			}
		}), e.appendChild(t), {
			container: e,
			outer: t,
			arrowIcon: r,
			title: n
		};
	}
	calcSelectedValues() {
		return new Set(this._items.filter((e) => e.selected).map((e) => e.value));
	}
	addEventListener(e, t) {
		return wp(this.events, e, t), this;
	}
	removeEventListener(e, t) {
		return Tp(this.events, e, t), this;
	}
	updateTitle() {
		return this.title.textContent = this.visibleText, this;
	}
	updateSelectedState() {
		if (this.selectedItems.length > 0) for (let e of this.selectedItems) {
			let t = e.dataset.votValue;
			t !== void 0 && (e.dataset.votSelected = this.selectedValues.has(t).toString());
		}
		return this.updateTitle(), this;
	}
	setSelectedValue(e) {
		let t = Array.isArray(e) ? e : [e], n;
		return n = this.multiSelect ? t : t.length > 0 ? [t[0]] : [], this.selectedValues = new Set(n), this.syncItemsSelectionState(), this.syncItemsSelectionState(this.baseItems), this.updateSelectedState(), this;
	}
	updateItems(e, t = {}) {
		let { persist: n = !0 } = t, r = this.cloneItems(e);
		n && (this.baseItems = this.cloneItems(r)), this._items = r, this.selectedValues = this.calcSelectedValues(), this.updateSelectedState();
		let i = this.contentList?.parentElement;
		if (!this.contentList || !i) return this;
		let a = this.contentList;
		return this.contentList = this.createDialogContentList(), i.replaceChild(this.contentList, a), this;
	}
	get visibleText() {
		return this.multiSelect ? this._items.filter((e) => this.selectedValues.has(e.value)).map((e) => e.label).join(", ") || this._selectTitle : this._items.find((e) => e.selected)?.label ?? this._selectTitle;
	}
	set selectTitle(e) {
		this._selectTitle = e, this.updateTitle();
	}
	set hidden(e) {
		X(this.container, e);
	}
	get hidden() {
		return Z(this.container);
	}
	get disabled() {
		return this.outer.getAttribute("disabled") === "true" || this.outer.getAttribute("aria-disabled") === "true";
	}
	set disabled(e) {
		if (e) {
			this.outer.setAttribute("disabled", "true");
			return;
		}
		this.outer.removeAttribute("disabled");
	}
}, jp = class {
	container;
	fromSelect;
	directionIcon;
	toSelect;
	dialogParent;
	_fromSelectTitle;
	_fromDialogTitle;
	_fromItems;
	_toSelectTitle;
	_toDialogTitle;
	_toItems;
	constructor({ from: { selectTitle: e = V.get("videoLanguage"), dialogTitle: t = V.get("videoLanguage"), items: n }, to: { selectTitle: r = V.get("translationLanguage"), dialogTitle: i = V.get("translationLanguage"), items: a }, dialogParent: o = document.documentElement }) {
		this._fromSelectTitle = e, this._fromDialogTitle = t, this._fromItems = n, this._toSelectTitle = r, this._toDialogTitle = i, this._toItems = a, this.dialogParent = o;
		let s = this.createElements();
		this.container = s.container, this.fromSelect = s.fromSelect, this.directionIcon = s.directionIcon, this.toSelect = s.toSelect;
	}
	createElements() {
		let e = J.createEl("vot-block", ["vot-lang-select"]), t = new Q({
			selectTitle: this._fromSelectTitle,
			dialogTitle: this._fromDialogTitle,
			items: this._fromItems,
			dialogParent: this.dialogParent
		}), n = J.createEl("vot-block", ["vot-lang-select-icon"]);
		q(vp, n);
		let r = new Q({
			selectTitle: this._toSelectTitle,
			dialogTitle: this._toDialogTitle,
			items: this._toItems,
			dialogParent: this.dialogParent
		});
		return e.append(t.container, n, r.container), {
			container: e,
			fromSelect: t,
			directionIcon: n,
			toSelect: r
		};
	}
	setSelectedValues(e, t) {
		return this.fromSelect.setSelectedValue(e), this.toSelect.setSelectedValue(t), this;
	}
	updateItems(e, t) {
		return this._fromItems = e, this._toItems = t, this.fromSelect = this.fromSelect.updateItems(e), this.toSelect = this.toSelect.updateItems(t), this;
	}
}, Mp = class {
	container;
	input;
	label;
	onInput = new H();
	_labelHtml;
	_value;
	_min;
	_max;
	_step;
	constructor({ labelHtml: e, value: t = 50, min: n = 0, max: r = 100, step: i = 1 }) {
		this._labelHtml = e, this._value = t, this._min = n, this._max = r, this._step = i;
		let a = this.createElements();
		this.container = a.container, this.input = a.input, this.label = a.label, this.update();
	}
	updateProgress() {
		let e = this._max - this._min, t = e <= 0 ? 0 : (this._value - this._min) / e, n = Math.max(0, Math.min(1, t));
		return this.container.style.setProperty("--vot-progress", n.toString()), this;
	}
	update() {
		return this._value = this.input.valueAsNumber, this._min = +this.input.min, this._max = +this.input.max, this.updateProgress(), this;
	}
	createElements() {
		let e = J.createEl("vot-block", ["vot-slider"]), t = document.createElement("input");
		t.type = "range", t.min = this._min.toString(), t.max = this._max.toString(), t.step = this._step.toString(), t.value = this._value.toString();
		let n = J.createEl("span");
		return q(this._labelHtml, n), e.append(t, n), t.addEventListener("input", () => {
			this.update(), this.onInput.dispatch(this._value, !1);
		}), {
			container: e,
			label: n,
			input: t
		};
	}
	addEventListener(e, t) {
		return this.onInput.addListener(t), this;
	}
	removeEventListener(e, t) {
		return this.onInput.removeListener(t), this;
	}
	get value() {
		return this._value;
	}
	set value(e) {
		this._value = Np(e, this._min, this._max), this.input.value = this._value.toString(), this.updateProgress(), this.onInput.dispatch(this._value, !0);
	}
	get min() {
		return this._min;
	}
	set min(e) {
		this._min = e, this.input.min = this._min.toString(), this._value = Np(this._value, this._min, this._max), this.input.value = this._value.toString(), this.updateProgress();
	}
	get max() {
		return this._max;
	}
	set max(e) {
		this._max = e, this.input.max = this._max.toString(), this._value = Np(this._value, this._min, this._max), this.input.value = this._value.toString(), this.updateProgress();
	}
	get step() {
		return this._step;
	}
	set step(e) {
		this._step = e, this.input.step = this._step.toString();
	}
	get disabled() {
		return this.input.disabled;
	}
	set disabled(e) {
		this.input.disabled = e;
	}
	set hidden(e) {
		X(this.container, e);
	}
	get hidden() {
		return Z(this.container);
	}
};
function Np(e, t, n) {
	return !Number.isFinite(e) || n < t ? t : Math.max(t, Math.min(n, e));
}
//#endregion
//#region src/ui/components/sliderLabel.ts
var Pp = class {
	container;
	strong;
	text;
	_labelText;
	_labelEOL;
	_value;
	_symbol;
	constructor({ labelText: e, labelEOL: t = "", value: n = 50, symbol: r = "%" }) {
		this._labelText = e, this._labelEOL = t, this._value = n, this._symbol = r;
		let i = this.createElements();
		this.container = i.container, this.strong = i.strong, this.text = i.text;
	}
	createElements() {
		let e = J.createEl("vot-block", ["vot-slider-label"]), t = J.createEl("span", ["vot-slider-label-text"]);
		t.textContent = this.labelText;
		let n = J.createEl("span", ["vot-slider-label-value"]);
		return n.textContent = this.valueText, e.append(t, n), {
			container: e,
			strong: n,
			text: t
		};
	}
	get labelText() {
		return `${this._labelText}${this._labelEOL}`;
	}
	get valueText() {
		return `${this._value}${this._symbol}`;
	}
	get value() {
		return this._value;
	}
	set value(e) {
		this._value = e, this.strong.textContent = this.valueText;
	}
	set hidden(e) {
		X(this.container, e);
	}
	get hidden() {
		return Z(this.container);
	}
}, Fp = class {
	container;
	translateButton;
	separator;
	pipButton;
	separator2;
	menuButton;
	label;
	_opacity = 1;
	_position;
	_direction;
	_status;
	_labelText;
	constructor({ position: e = "default", direction: t = "default", status: n = "none", labelHtml: r = "" }) {
		this._position = e, this._direction = t, this._status = n, this._labelText = r;
		let i = this.createElements();
		this.container = i.container, this.translateButton = i.translateButton, this.separator = i.separator, this.pipButton = i.pipButton, this.separator2 = i.separator2, this.menuButton = i.menuButton, this.label = i.label;
	}
	static calcPosition(e, t) {
		return t ? e <= 44 ? "left" : e >= 66 ? "right" : "default" : "default";
	}
	static calcDirection(e) {
		return ["default", "top"].includes(e) ? "row" : "column";
	}
	createElements() {
		let e = J.createEl("vot-block", ["vot-segmented-button"]);
		e.dataset.position = this._position, e.dataset.direction = this._direction, e.dataset.status = this._status;
		let t = J.createEl("vot-block", ["vot-segment", "vot-translate-button"]);
		t.setAttribute("role", "button"), t.tabIndex = 0, t.setAttribute("aria-label", this._labelText || "Translate"), q(dp, t);
		let n = J.createEl("span", ["vot-segment-label"]);
		n.textContent = this._labelText, t.appendChild(n);
		let r = J.createEl("vot-block", ["vot-separator"]), i = J.createEl("vot-block", ["vot-segment-only-icon"]);
		i.setAttribute("role", "button"), i.tabIndex = 0, i.setAttribute("aria-label", "Picture in picture"), q(fp, i);
		let a = J.createEl("vot-block", ["vot-separator"]), o = J.createEl("vot-block", ["vot-segment-only-icon"]);
		return o.setAttribute("role", "button"), o.tabIndex = 0, o.setAttribute("aria-label", "Menu"), o.setAttribute("aria-haspopup", "dialog"), o.setAttribute("aria-expanded", "false"), q(pp, o), e.append(t, r, i, a, o), {
			container: e,
			translateButton: t,
			separator: r,
			pipButton: i,
			separator2: a,
			menuButton: o,
			label: n
		};
	}
	showPiPButton(e) {
		return this.separator2.hidden = this.pipButton.hidden = !e, this;
	}
	setText(e) {
		return this._labelText = e, this.label.textContent = e, this.translateButton.setAttribute("aria-label", e || "Translate"), this;
	}
	remove() {
		return this.container.remove(), this;
	}
	get tooltipPos() {
		switch (this.position) {
			case "left": return "right";
			case "right": return "left";
			default: return "bottom";
		}
	}
	set status(e) {
		this._status = this.container.dataset.status = e;
	}
	get status() {
		return this._status;
	}
	set loading(e) {
		this.container.dataset.loading = e.toString();
	}
	get loading() {
		return this.container.dataset.loading === "true";
	}
	set hidden(e) {
		X(this.container, e);
	}
	get hidden() {
		return Z(this.container);
	}
	get position() {
		return this._position;
	}
	set position(e) {
		this._position = this.container.dataset.position = e;
	}
	get direction() {
		return this._direction;
	}
	set direction(e) {
		this._direction = this.container.dataset.direction = e;
	}
	set opacity(e) {
		let t = Number.isFinite(e) ? e : 1;
		this._opacity = t;
		let n = t <= .01;
		this.container.classList.toggle("vot-segmented-button--hidden", n);
	}
	get opacity() {
		return this._opacity;
	}
}, Ip = class {
	container;
	contentWrapper;
	headerContainer;
	bodyContainer;
	footerContainer;
	titleContainer;
	title;
	_position;
	_titleHtml;
	menuId = typeof crypto < "u" && "randomUUID" in crypto ? `vot-menu-${crypto.randomUUID()}` : `vot-menu-${Math.random().toString(36).slice(2)}`;
	titleId = typeof crypto < "u" && "randomUUID" in crypto ? `vot-menu-title-${crypto.randomUUID()}` : `vot-menu-title-${Math.random().toString(36).slice(2)}`;
	constructor({ position: e = "default", titleHtml: t = "" }) {
		this._position = e, this._titleHtml = t;
		let n = this.createElements();
		this.container = n.container, this.contentWrapper = n.contentWrapper, this.headerContainer = n.headerContainer, this.bodyContainer = n.bodyContainer, this.footerContainer = n.footerContainer, this.titleContainer = n.titleContainer, this.title = n.title;
	}
	createElements() {
		let e = J.createEl("vot-block", ["vot-menu"]);
		e.hidden = !0, e.id = this.menuId, e.dataset.position = this._position, e.setAttribute("role", "dialog"), e.setAttribute("aria-modal", "false"), e.setAttribute("aria-hidden", "true"), e.toggleAttribute("inert", !0);
		let t = J.createEl("vot-block", ["vot-menu-content-wrapper"]);
		e.appendChild(t);
		let n = J.createEl("vot-block", ["vot-menu-header-container"]), r = J.createEl("vot-block", ["vot-menu-title-container"]);
		n.appendChild(r);
		let i = J.createEl("vot-block", ["vot-menu-title"]);
		i.id = this.titleId, i.append(this._titleHtml), r.appendChild(i), e.setAttribute("aria-labelledby", this.titleId);
		let a = J.createEl("vot-block", ["vot-menu-body-container"]), o = J.createEl("vot-block", ["vot-menu-footer-container"]);
		return t.append(n, a, o), {
			container: e,
			contentWrapper: t,
			headerContainer: n,
			bodyContainer: a,
			footerContainer: o,
			titleContainer: r,
			title: i
		};
	}
	setText(e) {
		return this._titleHtml = this.title.textContent = e, this;
	}
	remove() {
		return this.container.remove(), this;
	}
	set hidden(e) {
		X(this.container, e), this.container.setAttribute("aria-hidden", e ? "true" : "false"), this.container.toggleAttribute("inert", e);
	}
	get hidden() {
		return Z(this.container);
	}
	get position() {
		return this._position;
	}
	set position(e) {
		this._position = this.container.dataset.position = e;
	}
}, Lp = class e {
	static BIG_CONTAINER_WIDTH_PX = 550;
	mount;
	globalPortal;
	abortController = null;
	defaultVolumePersistTimer;
	defaultVolumePersistDelayMs = 250;
	dragging = !1;
	dragCandidate = !1;
	dragDirty = !1;
	dragStartX = 0;
	dragStartY = 0;
	currentClientX = 0;
	activePointerId = null;
	dragThresholdPx = 6;
	containerRect = null;
	dragIsBigContainer = null;
	checkerUnsubscribe = null;
	initialized = !1;
	data;
	videoHandler;
	intervalIdleChecker;
	events = {
		"click:settings": new H(),
		"click:pip": new H(),
		"click:downloadTranslation": new H(),
		"click:downloadSubtitles": new H(),
		"click:translate": new H(),
		"input:videoVolume": new H(),
		"input:translationVolume": new H(),
		"select:fromLanguage": new H(),
		"select:toLanguage": new H(),
		"select:subtitles": new H()
	};
	votButton;
	votButtonTooltip;
	votMenu;
	downloadTranslationButton;
	downloadSubtitlesButton;
	openSettingsButton;
	languagePairSelect;
	subtitlesSelectLabel;
	subtitlesSelect;
	videoVolumeSliderLabel;
	videoVolumeSlider;
	translationVolumeSliderLabel;
	translationVolumeSlider;
	constructor({ mount: e, globalPortal: t, data: n = {}, videoHandler: r, intervalIdleChecker: i }) {
		this.mount = e, this.globalPortal = t, this.data = n, this.videoHandler = r, this.intervalIdleChecker = i;
	}
	get root() {
		return this.mount.root;
	}
	get portalContainer() {
		return this.mount.portalContainer;
	}
	get tooltipLayoutRoot() {
		return this.mount.tooltipLayoutRoot;
	}
	updateMount(e) {
		let t = this.mount.root, n = e.root, r = this.mount.tooltipLayoutRoot, i = e.tooltipLayoutRoot;
		return this.mount = e, this.isInitialized() ? (t !== n && (this.votButton && n.appendChild(this.votButton.container), this.votMenu && n.appendChild(this.votMenu.container)), this.votButtonTooltip && op({
			root: t,
			portalContainer: this.mount.portalContainer,
			subtitlesMountContainer: this.mount.subtitlesMountContainer,
			tooltipLayoutRoot: r
		}, e) && this.votButtonTooltip.updateMount({ layoutRoot: i ?? document.documentElement }), this) : this;
	}
	isInitialized() {
		return this.initialized;
	}
	calcButtonLayout(e) {
		return this.isBigContainer && Rp(e) ? {
			direction: "column",
			position: e
		} : {
			direction: "row",
			position: "default"
		};
	}
	addEventListener(e, t) {
		return this.events[e].addListener(t), this;
	}
	removeEventListener(e, t) {
		return this.events[e].removeListener(t), this;
	}
	scheduleDefaultVolumePersist() {
		this.defaultVolumePersistTimer !== void 0 && globalThis.clearTimeout(this.defaultVolumePersistTimer), this.defaultVolumePersistTimer = globalThis.setTimeout(() => {
			this.defaultVolumePersistTimer = void 0, this.flushDefaultVolumePersist();
		}, this.defaultVolumePersistDelayMs);
	}
	flushDefaultVolumePersist() {
		this.defaultVolumePersistTimer !== void 0 && (globalThis.clearTimeout(this.defaultVolumePersistTimer), this.defaultVolumePersistTimer = void 0), typeof this.data.defaultVolume == "number" && B.set("defaultVolume", this.data.defaultVolume);
	}
	initUI(e = "default") {
		if (this.isInitialized()) throw Error("[VOT] OverlayView is already initialized");
		this.initialized = !0;
		let { position: t, direction: n } = this.calcButtonLayout(e);
		this.votButton = new Fp({
			position: t,
			direction: n,
			status: "none",
			labelHtml: V.get("translateVideo")
		}), this.votButton.opacity = 0, this.pipButtonVisible || this.votButton.showPiPButton(!1), this.root.appendChild(this.votButton.container), this.votButtonTooltip = new Y({
			target: this.votButton.translateButton,
			content: V.get("translateVideo"),
			position: this.votButton.tooltipPos,
			autoLayout: !1,
			hidden: n === "row",
			bordered: !1,
			parentElement: this.globalPortal,
			layoutRoot: this.tooltipLayoutRoot
		}), this.votMenu = new Ip({
			titleHtml: V.get("VOTSettings"),
			position: t
		}), this.root.appendChild(this.votMenu.container), this.votButton.menuButton.setAttribute("aria-controls", this.votMenu.container.id), this.downloadTranslationButton = new Ep(), this.downloadTranslationButton.hidden = !0, this.downloadSubtitlesButton = J.createIconButton(hp, { ariaLabel: "Download subtitles" }), this.downloadSubtitlesButton.hidden = !0, this.openSettingsButton = J.createIconButton(gp, { ariaLabel: V.get("VOTSettings") }), this.votMenu.headerContainer.append(this.downloadTranslationButton.button, this.downloadSubtitlesButton, this.openSettingsButton);
		let r = this.videoHandler?.videoData?.detectedLanguage ?? "en", i = this.data.responseLanguage ?? "ru";
		this.languagePairSelect = new jp({
			from: {
				selectTitle: V.get(`langs.${r}`),
				items: Q.genLanguageItems(dn, r)
			},
			to: {
				selectTitle: V.get(`langs.${i}`),
				items: Q.genLanguageItems(fn, i)
			},
			dialogParent: this.globalPortal
		}), this.subtitlesSelectLabel = new Op({ labelText: V.get("VOTSubtitles") }), this.subtitlesSelect = new Q({
			selectTitle: V.get("VOTSubtitlesDisabled"),
			dialogTitle: V.get("VOTSubtitles"),
			labelElement: this.subtitlesSelectLabel.container,
			dialogParent: this.globalPortal,
			items: [{
				label: V.get("VOTSubtitlesDisabled"),
				value: "disabled",
				selected: !0
			}]
		});
		let a = this.videoHandler ? this.videoHandler.getVideoVolume() * 100 : 100;
		this.videoVolumeSliderLabel = new Pp({
			labelText: V.get("VOTVolume"),
			value: a
		}), this.videoVolumeSlider = new Mp({
			labelHtml: this.videoVolumeSliderLabel.container,
			value: a
		}), this.videoVolumeSlider.hidden = !this.data.showVideoSlider || this.votButton.status !== "success";
		let o = this.data.defaultVolume ?? 100;
		return this.translationVolumeSliderLabel = new Pp({
			labelText: V.get("VOTVolumeTranslation"),
			value: o
		}), this.translationVolumeSlider = new Mp({
			labelHtml: this.translationVolumeSliderLabel.container,
			value: o,
			max: this.data.audioBooster && !this.data.syncVolume ? 900 : 100
		}), this.translationVolumeSlider.hidden = this.votButton.status !== "success", this.votMenu.bodyContainer.append(this.languagePairSelect.container, this.subtitlesSelect.container, this.videoVolumeSlider.container, this.translationVolumeSlider.container), this;
	}
	initUIEvents() {
		if (!this.isInitialized()) throw Error("[VOT] OverlayView isn't initialized");
		this.abortController = new AbortController();
		let e = this.abortController.signal;
		this.checkerUnsubscribe?.(), this.checkerUnsubscribe = this.intervalIdleChecker.subscribe(() => {
			this.onCheckerTick();
		}), this.votButton.container.addEventListener("click", (e) => {
			e.preventDefault(), e.stopPropagation(), e.stopImmediatePropagation();
		}, { signal: e });
		let t = (e) => (t) => {
			(t.key === "Enter" || t.key === " ") && (t.preventDefault(), e());
		}, n = (e) => e.isPrimary && e.button === 0, r = (e, { returnFocusToToggle: t = !1 } = {}) => {
			this.isInitialized() && (this.votMenu.hidden = !e, this.votButton.menuButton.setAttribute("aria-expanded", e.toString()), this.votButtonTooltip && (this.votButtonTooltip.hidden = e || this.votButton.direction === "row"), e ? queueMicrotask(() => this.openSettingsButton?.focus?.()) : t ? queueMicrotask(() => this.votButton.menuButton.focus?.()) : this.votButton.menuButton.blur());
		}, i = () => r(this.votMenu.hidden), a = (e = !1) => r(!1, { returnFocusToToggle: e });
		this.votButton.translateButton.addEventListener("pointerdown", (e) => {
			n(e) && (a(), this.events["click:translate"].dispatch());
		}, { signal: e }), this.votButton.translateButton.addEventListener("keydown", t(() => {
			a(), this.events["click:translate"].dispatch();
		}), { signal: e }), this.votButton.pipButton.addEventListener("pointerdown", (e) => {
			n(e) && (a(), this.events["click:pip"].dispatch());
		}, { signal: e }), this.votButton.pipButton.addEventListener("keydown", t(() => {
			a(), this.events["click:pip"].dispatch();
		}), { signal: e }), this.votButton.menuButton.addEventListener("pointerdown", (e) => {
			n(e) && (e.preventDefault(), i());
		}, { signal: e }), this.votButton.menuButton.addEventListener("keydown", t(i), { signal: e });
		let o = "none";
		this.votButton.container.style.touchAction = o, this.votButton.translateButton.style.touchAction = o, this.votButton.pipButton.style.touchAction = o, this.votButton.menuButton.style.touchAction = o, this.votButton.container.addEventListener("pointerdown", this.onDragStart, { signal: e }), this.votButton.container.addEventListener("pointermove", this.onPointerMove, { signal: e }), this.votButton.container.addEventListener("pointerup", this.onDragEnd, { signal: e }), this.votButton.container.addEventListener("pointercancel", this.onDragEnd, { signal: e }), this.votButton.container.addEventListener("lostpointercapture", this.onDragEnd, { signal: e }), this.votMenu.container.addEventListener("click", (e) => {
			e.preventDefault(), e.stopPropagation(), e.stopImmediatePropagation();
		}, { signal: e });
		for (let t of ["pointerdown", "mousedown"]) this.votMenu.container.addEventListener(t, (e) => {
			e.stopImmediatePropagation();
		}, { signal: e });
		return document.addEventListener("pointerdown", (e) => {
			if (this.votMenu.hidden) return;
			let t = e.target, n = typeof e.composedPath == "function" ? e.composedPath() : [], r = t && this.votMenu.container.contains(t) || n.includes(this.votMenu.container), i = t && this.votButton.menuButton.contains(t) || n.includes(this.votButton.menuButton), o = t && this.votButton.container.contains(t) || n.includes(this.votButton.container), s = t instanceof HTMLElement && !!t.closest(".vot-dialog-container");
			r || i || o || s || a(!1);
		}, {
			signal: e,
			capture: !0,
			passive: !0
		}), this.votMenu.container.addEventListener("keydown", (e) => {
			if (e.key !== "Escape") return;
			let t = document.documentElement.classList.contains("vot-keyboard-nav");
			e.preventDefault(), e.stopPropagation(), a(t), this.votButton.container.matches(":hover") || this.votMenu.container.matches(":hover") || this.videoHandler?.overlayVisibility?.queueAutoHide?.();
		}, { signal: e }), this.downloadTranslationButton.addEventListener("click", () => {
			this.events["click:downloadTranslation"].dispatch();
		}), this.downloadSubtitlesButton.addEventListener("click", () => {
			this.events["click:downloadSubtitles"].dispatch();
		}, { signal: e }), this.openSettingsButton.addEventListener("click", () => {
			a(), this.events["click:settings"].dispatch();
		}, { signal: e }), this.languagePairSelect.fromSelect.addEventListener("selectItem", (e) => {
			this.videoHandler?.videoData && (this.videoHandler.videoData.detectedLanguage = e, this.videoHandler.videoManager.rememberUserLanguageSelection(this.videoHandler.videoData.videoId, e)), this.events["select:fromLanguage"].dispatch(e);
		}), this.languagePairSelect.toSelect.addEventListener("selectItem", async (e) => {
			this.videoHandler?.videoData && (this.videoHandler.translateToLang = this.videoHandler.videoData.responseLanguage = e);
			let t = this.data.responseLanguage;
			t !== e && (this.data.responseLanguage = e, await B.set("responseLanguage", this.data.responseLanguage)), this.data.enabledDontTranslateLanguages && Array.isArray(this.data.dontTranslateLanguages) && this.data.dontTranslateLanguages.length === 1 && t !== e && typeof t == "string" && this.data.dontTranslateLanguages[0] === t && (this.data.dontTranslateLanguages = [e], await B.set("dontTranslateLanguages", this.data.dontTranslateLanguages)), this.events["select:toLanguage"].dispatch(e);
		}), this.subtitlesSelect.addEventListener("beforeOpen", async (e) => {
			if (!this.videoHandler?.videoData) return;
			let t = this.videoHandler.getPreferredSubtitlesLanguage(this.videoHandler.videoData.detectedLanguage, this.videoHandler.videoData.responseLanguage);
			if (!t) return;
			let n = this.videoHandler.getSubtitlesCacheKey(this.videoHandler.videoData.videoId, this.videoHandler.videoData.detectedLanguage, t);
			if (this.videoHandler.subtitlesCacheKey === n) return;
			if (this.videoHandler.cacheManager.getSubtitles(n) !== void 0) {
				await this.videoHandler.ensureSubtitlesForCurrentLangPair();
				return;
			}
			let r = this.votButton?.loading ?? !1;
			this.votButton && (this.votButton.loading = !0);
			let i = J.createInlineLoader();
			i.style.margin = "0 auto", e.footerContainer.appendChild(i);
			try {
				await this.videoHandler.ensureSubtitlesForCurrentLangPair();
			} finally {
				i.remove(), this.votButton && (this.votButton.loading = r);
			}
		}), this.subtitlesSelect.addEventListener("selectItem", (e) => {
			this.events["select:subtitles"].dispatch(e);
		}), this.videoVolumeSlider.addEventListener("input", (e, t) => {
			this.videoVolumeSliderLabel && (this.videoVolumeSliderLabel.value = e), !t && this.events["input:videoVolume"].dispatch(e);
		}), this.translationVolumeSlider.addEventListener("input", (e, t) => {
			this.translationVolumeSliderLabel && (this.translationVolumeSliderLabel.value = e), this.data.defaultVolume !== e && (this.data.defaultVolume = e, this.scheduleDefaultVolumePersist()), !t && this.events["input:translationVolume"].dispatch(e);
		}), this;
	}
	updateButtonLayout(e, t) {
		return this.isInitialized() ? (this.votMenu.position = e, this.votButton.position = e, this.votButton.direction = t, this.votButtonTooltip.hidden = t === "row", this.votButtonTooltip.setPosition(this.votButton.tooltipPos), this) : this;
	}
	moveButton(e) {
		if (!this.isInitialized()) return this;
		let t = this.dragIsBigContainer ?? this.isBigContainer, n = Fp.calcPosition(e, t);
		if (n === this.votButton.position) return this;
		let r = Fp.calcDirection(n);
		return this.data.buttonPos = n, this.updateButtonLayout(n, r), this;
	}
	startDragSession(e, t, n) {
		this.dragCandidate = !0, this.dragging = !1, this.dragStartX = e, this.dragStartY = t, this.currentClientX = e, this.containerRect = this.root.getBoundingClientRect(), this.dragIsBigContainer = this.isBigContainer, this.dragDirty = !1, this.intervalIdleChecker.markActivity(n), this.intervalIdleChecker.requestImmediateTick();
	}
	queueDragTick(e) {
		this.dragDirty || (this.dragDirty = !0, this.intervalIdleChecker.markActivity(e), this.intervalIdleChecker.requestImmediateTick());
	}
	updateDragFromMove(e, t, n) {
		this.currentClientX = e, this.dragCandidate && (this.dragging || Math.abs(this.currentClientX - this.dragStartX) + Math.abs(t - this.dragStartY) >= this.dragThresholdPx && (this.dragging = !0), this.dragging && this.queueDragTick(n));
	}
	onDragStart = (e) => {
		!e.isPrimary || e.button !== 0 || (e.preventDefault(), this.activePointerId = e.pointerId, this.startDragSession(e.clientX, e.clientY, "overlay-pointer-down"));
	};
	onPointerMove = (e) => {
		if (this.activePointerId !== e.pointerId) return;
		let t = this.dragging;
		if (this.updateDragFromMove(e.clientX, e.clientY, "overlay-pointer-move"), !t && this.dragging) try {
			this.votButton?.container.setPointerCapture(e.pointerId);
		} catch {}
		this.dragging && e.preventDefault();
	};
	applyDragFromState = () => {
		if (!this.dragging || !this.dragDirty || !this.containerRect) return;
		let e = this.containerRect.width;
		if (!(e > 0 && Number.isFinite(e))) return;
		this.dragDirty = !1;
		let t = this.currentClientX - this.containerRect.left, n = Math.max(0, Math.min(t, e)) / e * 100;
		this.moveButton(n);
	};
	onCheckerTick = () => {
		this.applyDragFromState();
	};
	onDragEnd = (e) => {
		if (e && this.activePointerId !== null && e.pointerId !== this.activePointerId) return;
		let t = this.activePointerId;
		if (t !== null) try {
			this.votButton?.container.hasPointerCapture(t) && this.votButton.container.releasePointerCapture(t);
		} catch {}
		this.applyDragFromState();
		let n = this.dragIsBigContainer ?? this.isBigContainer;
		this.dragging && n && this.data.buttonPos && B.set("buttonPos", this.data.buttonPos), this.dragging = !1, this.dragCandidate = !1, this.dragDirty = !1, this.containerRect = null, this.dragIsBigContainer = null, this.activePointerId = null;
	};
	updateButtonOpacity(e) {
		return !this.isInitialized() || !this.votMenu.hidden || Math.abs(this.votButton.opacity - e) > .01 && (this.votButton.opacity = e), this;
	}
	doReleaseUI() {
		this.votButton?.remove(), this.votMenu?.remove(), this.votButtonTooltip?.release();
	}
	doReleaseUIEvents() {
		this.abortController?.abort(), this.abortController = null, this.checkerUnsubscribe?.(), this.checkerUnsubscribe = null, this.onDragEnd(), this.flushDefaultVolumePersist();
		for (let e of Object.values(this.events)) e.clear();
	}
	release() {
		return this.isInitialized() ? (this.doReleaseUIEvents(), this.doReleaseUI(), this.initialized = !1, this) : this;
	}
	get isBigContainer() {
		let t = this.videoHandler?.video?.getBoundingClientRect?.().width;
		if (typeof t == "number" && Number.isFinite(t)) return t > e.BIG_CONTAINER_WIDTH_PX;
		let n = this.videoHandler?.container?.getBoundingClientRect?.().width;
		return typeof n == "number" && Number.isFinite(n) ? n > e.BIG_CONTAINER_WIDTH_PX : this.root.clientWidth > e.BIG_CONTAINER_WIDTH_PX;
	}
	get pipButtonVisible() {
		return Ii() && !!this.data.showPiPButton;
	}
};
function Rp(e) {
	return e === "left" || e === "right";
}
//#endregion
//#region src/types/components/votButton.ts
var zp = [
	"default",
	"top",
	"left",
	"right"
], Bp = (/* @__PURE__ */ c((/* @__PURE__ */ o(((e, t) => {
	(function(n, r) {
		typeof e == "object" && typeof t == "object" ? t.exports = r() : typeof define == "function" && define.amd ? define([], r) : typeof e == "object" ? e.bowser = r() : n.bowser = r();
	})(e, (function() {
		return function(e) {
			var t = {};
			function n(r) {
				if (t[r]) return t[r].exports;
				var i = t[r] = {
					i: r,
					l: !1,
					exports: {}
				};
				return e[r].call(i.exports, i, i.exports, n), i.l = !0, i.exports;
			}
			return n.m = e, n.c = t, n.d = function(e, t, r) {
				n.o(e, t) || Object.defineProperty(e, t, {
					enumerable: !0,
					get: r
				});
			}, n.r = function(e) {
				typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e, "__esModule", { value: !0 });
			}, n.t = function(e, t) {
				if (1 & t && (e = n(e)), 8 & t || 4 & t && typeof e == "object" && e && e.__esModule) return e;
				var r = Object.create(null);
				if (n.r(r), Object.defineProperty(r, "default", {
					enumerable: !0,
					value: e
				}), 2 & t && typeof e != "string") for (var i in e) n.d(r, i, function(t) {
					return e[t];
				}.bind(null, i));
				return r;
			}, n.n = function(e) {
				var t = e && e.__esModule ? function() {
					return e.default;
				} : function() {
					return e;
				};
				return n.d(t, "a", t), t;
			}, n.o = function(e, t) {
				return Object.prototype.hasOwnProperty.call(e, t);
			}, n.p = "", n(n.s = 90);
		}({
			17: function(e, t, n) {
				t.__esModule = !0, t.default = void 0;
				var r = n(18);
				t.default = function() {
					function e() {}
					return e.getFirstMatch = function(e, t) {
						var n = t.match(e);
						return n && n.length > 0 && n[1] || "";
					}, e.getSecondMatch = function(e, t) {
						var n = t.match(e);
						return n && n.length > 1 && n[2] || "";
					}, e.matchAndReturnConst = function(e, t, n) {
						if (e.test(t)) return n;
					}, e.getWindowsVersionName = function(e) {
						switch (e) {
							case "NT": return "NT";
							case "XP": return "XP";
							case "NT 5.0": return "2000";
							case "NT 5.1": return "XP";
							case "NT 5.2": return "2003";
							case "NT 6.0": return "Vista";
							case "NT 6.1": return "7";
							case "NT 6.2": return "8";
							case "NT 6.3": return "8.1";
							case "NT 10.0": return "10";
							default: return;
						}
					}, e.getMacOSVersionName = function(e) {
						var t = e.split(".").splice(0, 2).map((function(e) {
							return parseInt(e, 10) || 0;
						}));
						t.push(0);
						var n = t[0], r = t[1];
						if (n === 10) switch (r) {
							case 5: return "Leopard";
							case 6: return "Snow Leopard";
							case 7: return "Lion";
							case 8: return "Mountain Lion";
							case 9: return "Mavericks";
							case 10: return "Yosemite";
							case 11: return "El Capitan";
							case 12: return "Sierra";
							case 13: return "High Sierra";
							case 14: return "Mojave";
							case 15: return "Catalina";
							default: return;
						}
						switch (n) {
							case 11: return "Big Sur";
							case 12: return "Monterey";
							case 13: return "Ventura";
							case 14: return "Sonoma";
							case 15: return "Sequoia";
							default: return;
						}
					}, e.getAndroidVersionName = function(e) {
						var t = e.split(".").splice(0, 2).map((function(e) {
							return parseInt(e, 10) || 0;
						}));
						if (t.push(0), !(t[0] === 1 && t[1] < 5)) return t[0] === 1 && t[1] < 6 ? "Cupcake" : t[0] === 1 && t[1] >= 6 ? "Donut" : t[0] === 2 && t[1] < 2 ? "Eclair" : t[0] === 2 && t[1] === 2 ? "Froyo" : t[0] === 2 && t[1] > 2 ? "Gingerbread" : t[0] === 3 ? "Honeycomb" : t[0] === 4 && t[1] < 1 ? "Ice Cream Sandwich" : t[0] === 4 && t[1] < 4 ? "Jelly Bean" : t[0] === 4 && t[1] >= 4 ? "KitKat" : t[0] === 5 ? "Lollipop" : t[0] === 6 ? "Marshmallow" : t[0] === 7 ? "Nougat" : t[0] === 8 ? "Oreo" : t[0] === 9 ? "Pie" : void 0;
					}, e.getVersionPrecision = function(e) {
						return e.split(".").length;
					}, e.compareVersions = function(t, n, r) {
						r === void 0 && (r = !1);
						var i = e.getVersionPrecision(t), a = e.getVersionPrecision(n), o = Math.max(i, a), s = 0, c = e.map([t, n], (function(t) {
							var n = o - e.getVersionPrecision(t), r = t + Array(n + 1).join(".0");
							return e.map(r.split("."), (function(e) {
								return Array(20 - e.length).join("0") + e;
							})).reverse();
						}));
						for (r && (s = o - Math.min(i, a)), --o; o >= s;) {
							if (c[0][o] > c[1][o]) return 1;
							if (c[0][o] === c[1][o]) {
								if (o === s) return 0;
								--o;
							} else if (c[0][o] < c[1][o]) return -1;
						}
					}, e.map = function(e, t) {
						var n, r = [];
						if (Array.prototype.map) return Array.prototype.map.call(e, t);
						for (n = 0; n < e.length; n += 1) r.push(t(e[n]));
						return r;
					}, e.find = function(e, t) {
						var n, r;
						if (Array.prototype.find) return Array.prototype.find.call(e, t);
						for (n = 0, r = e.length; n < r; n += 1) {
							var i = e[n];
							if (t(i, n)) return i;
						}
					}, e.assign = function(e) {
						for (var t, n, r = e, i = arguments.length, a = Array(i > 1 ? i - 1 : 0), o = 1; o < i; o++) a[o - 1] = arguments[o];
						if (Object.assign) return Object.assign.apply(Object, [e].concat(a));
						var s = function() {
							var e = a[t];
							typeof e == "object" && e && Object.keys(e).forEach((function(t) {
								r[t] = e[t];
							}));
						};
						for (t = 0, n = a.length; t < n; t += 1) s();
						return e;
					}, e.getBrowserAlias = function(e) {
						return r.BROWSER_ALIASES_MAP[e];
					}, e.getBrowserTypeByAlias = function(e) {
						return r.BROWSER_MAP[e] || "";
					}, e;
				}(), e.exports = t.default;
			},
			18: function(e, t, n) {
				t.__esModule = !0, t.ENGINE_MAP = t.OS_MAP = t.PLATFORMS_MAP = t.BROWSER_MAP = t.BROWSER_ALIASES_MAP = void 0, t.BROWSER_ALIASES_MAP = {
					AmazonBot: "amazonbot",
					"Amazon Silk": "amazon_silk",
					"Android Browser": "android",
					BaiduSpider: "baiduspider",
					Bada: "bada",
					BingCrawler: "bingcrawler",
					Brave: "brave",
					BlackBerry: "blackberry",
					"ChatGPT-User": "chatgpt_user",
					Chrome: "chrome",
					ClaudeBot: "claudebot",
					Chromium: "chromium",
					Diffbot: "diffbot",
					DuckDuckBot: "duckduckbot",
					DuckDuckGo: "duckduckgo",
					Electron: "electron",
					Epiphany: "epiphany",
					FacebookExternalHit: "facebookexternalhit",
					Firefox: "firefox",
					Focus: "focus",
					Generic: "generic",
					"Google Search": "google_search",
					Googlebot: "googlebot",
					GPTBot: "gptbot",
					"Internet Explorer": "ie",
					InternetArchiveCrawler: "internetarchivecrawler",
					"K-Meleon": "k_meleon",
					LibreWolf: "librewolf",
					Linespider: "linespider",
					Maxthon: "maxthon",
					"Meta-ExternalAds": "meta_externalads",
					"Meta-ExternalAgent": "meta_externalagent",
					"Meta-ExternalFetcher": "meta_externalfetcher",
					"Meta-WebIndexer": "meta_webindexer",
					"Microsoft Edge": "edge",
					"MZ Browser": "mz",
					"NAVER Whale Browser": "naver",
					"OAI-SearchBot": "oai_searchbot",
					Omgilibot: "omgilibot",
					Opera: "opera",
					"Opera Coast": "opera_coast",
					"Pale Moon": "pale_moon",
					PerplexityBot: "perplexitybot",
					"Perplexity-User": "perplexity_user",
					PhantomJS: "phantomjs",
					PingdomBot: "pingdombot",
					Puffin: "puffin",
					QQ: "qq",
					QQLite: "qqlite",
					QupZilla: "qupzilla",
					Roku: "roku",
					Safari: "safari",
					Sailfish: "sailfish",
					"Samsung Internet for Android": "samsung_internet",
					SlackBot: "slackbot",
					SeaMonkey: "seamonkey",
					Sleipnir: "sleipnir",
					"Sogou Browser": "sogou",
					Swing: "swing",
					Tizen: "tizen",
					"UC Browser": "uc",
					Vivaldi: "vivaldi",
					"WebOS Browser": "webos",
					WeChat: "wechat",
					YahooSlurp: "yahooslurp",
					"Yandex Browser": "yandex",
					YandexBot: "yandexbot",
					YouBot: "youbot"
				}, t.BROWSER_MAP = {
					amazonbot: "AmazonBot",
					amazon_silk: "Amazon Silk",
					android: "Android Browser",
					baiduspider: "BaiduSpider",
					bada: "Bada",
					bingcrawler: "BingCrawler",
					blackberry: "BlackBerry",
					brave: "Brave",
					chatgpt_user: "ChatGPT-User",
					chrome: "Chrome",
					claudebot: "ClaudeBot",
					chromium: "Chromium",
					diffbot: "Diffbot",
					duckduckbot: "DuckDuckBot",
					duckduckgo: "DuckDuckGo",
					edge: "Microsoft Edge",
					electron: "Electron",
					epiphany: "Epiphany",
					facebookexternalhit: "FacebookExternalHit",
					firefox: "Firefox",
					focus: "Focus",
					generic: "Generic",
					google_search: "Google Search",
					googlebot: "Googlebot",
					gptbot: "GPTBot",
					ie: "Internet Explorer",
					internetarchivecrawler: "InternetArchiveCrawler",
					k_meleon: "K-Meleon",
					librewolf: "LibreWolf",
					linespider: "Linespider",
					maxthon: "Maxthon",
					meta_externalads: "Meta-ExternalAds",
					meta_externalagent: "Meta-ExternalAgent",
					meta_externalfetcher: "Meta-ExternalFetcher",
					meta_webindexer: "Meta-WebIndexer",
					mz: "MZ Browser",
					naver: "NAVER Whale Browser",
					oai_searchbot: "OAI-SearchBot",
					omgilibot: "Omgilibot",
					opera: "Opera",
					opera_coast: "Opera Coast",
					pale_moon: "Pale Moon",
					perplexitybot: "PerplexityBot",
					perplexity_user: "Perplexity-User",
					phantomjs: "PhantomJS",
					pingdombot: "PingdomBot",
					puffin: "Puffin",
					qq: "QQ Browser",
					qqlite: "QQ Browser Lite",
					qupzilla: "QupZilla",
					roku: "Roku",
					safari: "Safari",
					sailfish: "Sailfish",
					samsung_internet: "Samsung Internet for Android",
					seamonkey: "SeaMonkey",
					slackbot: "SlackBot",
					sleipnir: "Sleipnir",
					sogou: "Sogou Browser",
					swing: "Swing",
					tizen: "Tizen",
					uc: "UC Browser",
					vivaldi: "Vivaldi",
					webos: "WebOS Browser",
					wechat: "WeChat",
					yahooslurp: "YahooSlurp",
					yandex: "Yandex Browser",
					yandexbot: "YandexBot",
					youbot: "YouBot"
				}, t.PLATFORMS_MAP = {
					bot: "bot",
					desktop: "desktop",
					mobile: "mobile",
					tablet: "tablet",
					tv: "tv"
				}, t.OS_MAP = {
					Android: "Android",
					Bada: "Bada",
					BlackBerry: "BlackBerry",
					ChromeOS: "Chrome OS",
					HarmonyOS: "HarmonyOS",
					iOS: "iOS",
					Linux: "Linux",
					MacOS: "macOS",
					PlayStation4: "PlayStation 4",
					Roku: "Roku",
					Tizen: "Tizen",
					WebOS: "WebOS",
					Windows: "Windows",
					WindowsPhone: "Windows Phone"
				}, t.ENGINE_MAP = {
					Blink: "Blink",
					EdgeHTML: "EdgeHTML",
					Gecko: "Gecko",
					Presto: "Presto",
					Trident: "Trident",
					WebKit: "WebKit"
				};
			},
			90: function(e, t, n) {
				t.__esModule = !0, t.default = void 0;
				var r, i = (r = n(91)) && r.__esModule ? r : { default: r }, a = n(18);
				function o(e, t) {
					for (var n = 0; n < t.length; n++) {
						var r = t[n];
						r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r);
					}
				}
				t.default = function() {
					function e() {}
					var t, n, r;
					return e.getParser = function(e, t, n) {
						if (t === void 0 && (t = !1), n === void 0 && (n = null), typeof e != "string") throw Error("UserAgent should be a string");
						return new i.default(e, t, n);
					}, e.parse = function(e, t) {
						return t === void 0 && (t = null), new i.default(e, t).getResult();
					}, t = e, r = [
						{
							key: "BROWSER_MAP",
							get: function() {
								return a.BROWSER_MAP;
							}
						},
						{
							key: "ENGINE_MAP",
							get: function() {
								return a.ENGINE_MAP;
							}
						},
						{
							key: "OS_MAP",
							get: function() {
								return a.OS_MAP;
							}
						},
						{
							key: "PLATFORMS_MAP",
							get: function() {
								return a.PLATFORMS_MAP;
							}
						}
					], (n = null) && o(t.prototype, n), r && o(t, r), e;
				}(), e.exports = t.default;
			},
			91: function(e, t, n) {
				t.__esModule = !0, t.default = void 0;
				var r = c(n(92)), i = c(n(93)), a = c(n(94)), o = c(n(95)), s = c(n(17));
				function c(e) {
					return e && e.__esModule ? e : { default: e };
				}
				t.default = function() {
					function e(e, t, n) {
						if (t === void 0 && (t = !1), n === void 0 && (n = null), e == null || e === "") throw Error("UserAgent parameter can't be empty");
						this._ua = e;
						var r = !1;
						typeof t == "boolean" ? (r = t, this._hints = n) : this._hints = typeof t == "object" && t ? t : null, this.parsedResult = {}, !0 !== r && this.parse();
					}
					var t = e.prototype;
					return t.getHints = function() {
						return this._hints;
					}, t.hasBrand = function(e) {
						if (!this._hints || !Array.isArray(this._hints.brands)) return !1;
						var t = e.toLowerCase();
						return this._hints.brands.some((function(e) {
							return e.brand && e.brand.toLowerCase() === t;
						}));
					}, t.getBrandVersion = function(e) {
						if (this._hints && Array.isArray(this._hints.brands)) {
							var t = e.toLowerCase(), n = this._hints.brands.find((function(e) {
								return e.brand && e.brand.toLowerCase() === t;
							}));
							return n ? n.version : void 0;
						}
					}, t.getUA = function() {
						return this._ua;
					}, t.test = function(e) {
						return e.test(this._ua);
					}, t.parseBrowser = function() {
						var e = this;
						this.parsedResult.browser = {};
						var t = s.default.find(r.default, (function(t) {
							if (typeof t.test == "function") return t.test(e);
							if (Array.isArray(t.test)) return t.test.some((function(t) {
								return e.test(t);
							}));
							throw Error("Browser's test function is not valid");
						}));
						return t && (this.parsedResult.browser = t.describe(this.getUA(), this)), this.parsedResult.browser;
					}, t.getBrowser = function() {
						return this.parsedResult.browser ? this.parsedResult.browser : this.parseBrowser();
					}, t.getBrowserName = function(e) {
						return e ? String(this.getBrowser().name).toLowerCase() || "" : this.getBrowser().name || "";
					}, t.getBrowserVersion = function() {
						return this.getBrowser().version;
					}, t.getOS = function() {
						return this.parsedResult.os ? this.parsedResult.os : this.parseOS();
					}, t.parseOS = function() {
						var e = this;
						this.parsedResult.os = {};
						var t = s.default.find(i.default, (function(t) {
							if (typeof t.test == "function") return t.test(e);
							if (Array.isArray(t.test)) return t.test.some((function(t) {
								return e.test(t);
							}));
							throw Error("Browser's test function is not valid");
						}));
						return t && (this.parsedResult.os = t.describe(this.getUA())), this.parsedResult.os;
					}, t.getOSName = function(e) {
						var t = this.getOS().name;
						return e ? String(t).toLowerCase() || "" : t || "";
					}, t.getOSVersion = function() {
						return this.getOS().version;
					}, t.getPlatform = function() {
						return this.parsedResult.platform ? this.parsedResult.platform : this.parsePlatform();
					}, t.getPlatformType = function(e) {
						e === void 0 && (e = !1);
						var t = this.getPlatform().type;
						return e ? String(t).toLowerCase() || "" : t || "";
					}, t.parsePlatform = function() {
						var e = this;
						this.parsedResult.platform = {};
						var t = s.default.find(a.default, (function(t) {
							if (typeof t.test == "function") return t.test(e);
							if (Array.isArray(t.test)) return t.test.some((function(t) {
								return e.test(t);
							}));
							throw Error("Browser's test function is not valid");
						}));
						return t && (this.parsedResult.platform = t.describe(this.getUA())), this.parsedResult.platform;
					}, t.getEngine = function() {
						return this.parsedResult.engine ? this.parsedResult.engine : this.parseEngine();
					}, t.getEngineName = function(e) {
						return e ? String(this.getEngine().name).toLowerCase() || "" : this.getEngine().name || "";
					}, t.parseEngine = function() {
						var e = this;
						this.parsedResult.engine = {};
						var t = s.default.find(o.default, (function(t) {
							if (typeof t.test == "function") return t.test(e);
							if (Array.isArray(t.test)) return t.test.some((function(t) {
								return e.test(t);
							}));
							throw Error("Browser's test function is not valid");
						}));
						return t && (this.parsedResult.engine = t.describe(this.getUA())), this.parsedResult.engine;
					}, t.parse = function() {
						return this.parseBrowser(), this.parseOS(), this.parsePlatform(), this.parseEngine(), this;
					}, t.getResult = function() {
						return s.default.assign({}, this.parsedResult);
					}, t.satisfies = function(e) {
						var t = this, n = {}, r = 0, i = {}, a = 0;
						if (Object.keys(e).forEach((function(t) {
							var o = e[t];
							typeof o == "string" ? (i[t] = o, a += 1) : typeof o == "object" && (n[t] = o, r += 1);
						})), r > 0) {
							var o = Object.keys(n), c = s.default.find(o, (function(e) {
								return t.isOS(e);
							}));
							if (c) {
								var l = this.satisfies(n[c]);
								if (l !== void 0) return l;
							}
							var u = s.default.find(o, (function(e) {
								return t.isPlatform(e);
							}));
							if (u) {
								var d = this.satisfies(n[u]);
								if (d !== void 0) return d;
							}
						}
						if (a > 0) {
							var f = Object.keys(i), p = s.default.find(f, (function(e) {
								return t.isBrowser(e, !0);
							}));
							if (p !== void 0) return this.compareVersion(i[p]);
						}
					}, t.isBrowser = function(e, t) {
						t === void 0 && (t = !1);
						var n = this.getBrowserName().toLowerCase(), r = e.toLowerCase(), i = s.default.getBrowserTypeByAlias(r);
						return t && i && (r = i.toLowerCase()), r === n;
					}, t.compareVersion = function(e) {
						var t = [0], n = e, r = !1, i = this.getBrowserVersion();
						if (typeof i == "string") return e[0] === ">" || e[0] === "<" ? (n = e.substr(1), e[1] === "=" ? (r = !0, n = e.substr(2)) : t = [], e[0] === ">" ? t.push(1) : t.push(-1)) : e[0] === "=" ? n = e.substr(1) : e[0] === "~" && (r = !0, n = e.substr(1)), t.indexOf(s.default.compareVersions(i, n, r)) > -1;
					}, t.isOS = function(e) {
						return this.getOSName(!0) === String(e).toLowerCase();
					}, t.isPlatform = function(e) {
						return this.getPlatformType(!0) === String(e).toLowerCase();
					}, t.isEngine = function(e) {
						return this.getEngineName(!0) === String(e).toLowerCase();
					}, t.is = function(e, t) {
						return t === void 0 && (t = !1), this.isBrowser(e, t) || this.isOS(e) || this.isPlatform(e);
					}, t.some = function(e) {
						var t = this;
						return e === void 0 && (e = []), e.some((function(e) {
							return t.is(e);
						}));
					}, e;
				}(), e.exports = t.default;
			},
			92: function(e, t, n) {
				t.__esModule = !0, t.default = void 0;
				var r, i = (r = n(17)) && r.__esModule ? r : { default: r }, a = /version\/(\d+(\.?_?\d+)+)/i;
				t.default = [
					{
						test: [/gptbot/i],
						describe: function(e) {
							var t = { name: "GPTBot" }, n = i.default.getFirstMatch(/gptbot\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/chatgpt-user/i],
						describe: function(e) {
							var t = { name: "ChatGPT-User" }, n = i.default.getFirstMatch(/chatgpt-user\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/oai-searchbot/i],
						describe: function(e) {
							var t = { name: "OAI-SearchBot" }, n = i.default.getFirstMatch(/oai-searchbot\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [
							/claudebot/i,
							/claude-web/i,
							/claude-user/i,
							/claude-searchbot/i
						],
						describe: function(e) {
							var t = { name: "ClaudeBot" }, n = i.default.getFirstMatch(/(?:claudebot|claude-web|claude-user|claude-searchbot)\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/omgilibot/i, /webzio-extended/i],
						describe: function(e) {
							var t = { name: "Omgilibot" }, n = i.default.getFirstMatch(/(?:omgilibot|webzio-extended)\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/diffbot/i],
						describe: function(e) {
							var t = { name: "Diffbot" }, n = i.default.getFirstMatch(/diffbot\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/perplexitybot/i],
						describe: function(e) {
							var t = { name: "PerplexityBot" }, n = i.default.getFirstMatch(/perplexitybot\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/perplexity-user/i],
						describe: function(e) {
							var t = { name: "Perplexity-User" }, n = i.default.getFirstMatch(/perplexity-user\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/youbot/i],
						describe: function(e) {
							var t = { name: "YouBot" }, n = i.default.getFirstMatch(/youbot\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/meta-webindexer/i],
						describe: function(e) {
							var t = { name: "Meta-WebIndexer" }, n = i.default.getFirstMatch(/meta-webindexer\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/meta-externalads/i],
						describe: function(e) {
							var t = { name: "Meta-ExternalAds" }, n = i.default.getFirstMatch(/meta-externalads\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/meta-externalagent/i],
						describe: function(e) {
							var t = { name: "Meta-ExternalAgent" }, n = i.default.getFirstMatch(/meta-externalagent\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/meta-externalfetcher/i],
						describe: function(e) {
							var t = { name: "Meta-ExternalFetcher" }, n = i.default.getFirstMatch(/meta-externalfetcher\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/googlebot/i],
						describe: function(e) {
							var t = { name: "Googlebot" }, n = i.default.getFirstMatch(/googlebot\/(\d+(\.\d+))/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/linespider/i],
						describe: function(e) {
							var t = { name: "Linespider" }, n = i.default.getFirstMatch(/(?:linespider)(?:-[-\w]+)?[\s/](\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/amazonbot/i],
						describe: function(e) {
							var t = { name: "AmazonBot" }, n = i.default.getFirstMatch(/amazonbot\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/bingbot/i],
						describe: function(e) {
							var t = { name: "BingCrawler" }, n = i.default.getFirstMatch(/bingbot\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/baiduspider/i],
						describe: function(e) {
							var t = { name: "BaiduSpider" }, n = i.default.getFirstMatch(/baiduspider\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/duckduckbot/i],
						describe: function(e) {
							var t = { name: "DuckDuckBot" }, n = i.default.getFirstMatch(/duckduckbot\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/ia_archiver/i],
						describe: function(e) {
							var t = { name: "InternetArchiveCrawler" }, n = i.default.getFirstMatch(/ia_archiver\/(\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/facebookexternalhit/i, /facebookcatalog/i],
						describe: function() {
							return { name: "FacebookExternalHit" };
						}
					},
					{
						test: [/slackbot/i, /slack-imgProxy/i],
						describe: function(e) {
							var t = { name: "SlackBot" }, n = i.default.getFirstMatch(/(?:slackbot|slack-imgproxy)(?:-[-\w]+)?[\s/](\d+(\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/yahoo!?[\s/]*slurp/i],
						describe: function() {
							return { name: "YahooSlurp" };
						}
					},
					{
						test: [/yandexbot/i, /yandexmobilebot/i],
						describe: function() {
							return { name: "YandexBot" };
						}
					},
					{
						test: [/pingdom/i],
						describe: function() {
							return { name: "PingdomBot" };
						}
					},
					{
						test: [/opera/i],
						describe: function(e) {
							var t = { name: "Opera" }, n = i.default.getFirstMatch(a, e) || i.default.getFirstMatch(/(?:opera)[\s/](\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/opr\/|opios/i],
						describe: function(e) {
							var t = { name: "Opera" }, n = i.default.getFirstMatch(/(?:opr|opios)[\s/](\S+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/SamsungBrowser/i],
						describe: function(e) {
							var t = { name: "Samsung Internet for Android" }, n = i.default.getFirstMatch(a, e) || i.default.getFirstMatch(/(?:SamsungBrowser)[\s/](\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/Whale/i],
						describe: function(e) {
							var t = { name: "NAVER Whale Browser" }, n = i.default.getFirstMatch(a, e) || i.default.getFirstMatch(/(?:whale)[\s/](\d+(?:\.\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/PaleMoon/i],
						describe: function(e) {
							var t = { name: "Pale Moon" }, n = i.default.getFirstMatch(a, e) || i.default.getFirstMatch(/(?:PaleMoon)[\s/](\d+(?:\.\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/MZBrowser/i],
						describe: function(e) {
							var t = { name: "MZ Browser" }, n = i.default.getFirstMatch(/(?:MZBrowser)[\s/](\d+(?:\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/focus/i],
						describe: function(e) {
							var t = { name: "Focus" }, n = i.default.getFirstMatch(/(?:focus)[\s/](\d+(?:\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/swing/i],
						describe: function(e) {
							var t = { name: "Swing" }, n = i.default.getFirstMatch(/(?:swing)[\s/](\d+(?:\.\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/coast/i],
						describe: function(e) {
							var t = { name: "Opera Coast" }, n = i.default.getFirstMatch(a, e) || i.default.getFirstMatch(/(?:coast)[\s/](\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/opt\/\d+(?:.?_?\d+)+/i],
						describe: function(e) {
							var t = { name: "Opera Touch" }, n = i.default.getFirstMatch(/(?:opt)[\s/](\d+(\.?_?\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/yabrowser/i],
						describe: function(e) {
							var t = { name: "Yandex Browser" }, n = i.default.getFirstMatch(/(?:yabrowser)[\s/](\d+(\.?_?\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/ucbrowser/i],
						describe: function(e) {
							var t = { name: "UC Browser" }, n = i.default.getFirstMatch(a, e) || i.default.getFirstMatch(/(?:ucbrowser)[\s/](\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/Maxthon|mxios/i],
						describe: function(e) {
							var t = { name: "Maxthon" }, n = i.default.getFirstMatch(a, e) || i.default.getFirstMatch(/(?:Maxthon|mxios)[\s/](\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/epiphany/i],
						describe: function(e) {
							var t = { name: "Epiphany" }, n = i.default.getFirstMatch(a, e) || i.default.getFirstMatch(/(?:epiphany)[\s/](\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/puffin/i],
						describe: function(e) {
							var t = { name: "Puffin" }, n = i.default.getFirstMatch(a, e) || i.default.getFirstMatch(/(?:puffin)[\s/](\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/sleipnir/i],
						describe: function(e) {
							var t = { name: "Sleipnir" }, n = i.default.getFirstMatch(a, e) || i.default.getFirstMatch(/(?:sleipnir)[\s/](\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/k-meleon/i],
						describe: function(e) {
							var t = { name: "K-Meleon" }, n = i.default.getFirstMatch(a, e) || i.default.getFirstMatch(/(?:k-meleon)[\s/](\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/micromessenger/i],
						describe: function(e) {
							var t = { name: "WeChat" }, n = i.default.getFirstMatch(/(?:micromessenger)[\s/](\d+(\.?_?\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/qqbrowser/i],
						describe: function(e) {
							var t = { name: /qqbrowserlite/i.test(e) ? "QQ Browser Lite" : "QQ Browser" }, n = i.default.getFirstMatch(/(?:qqbrowserlite|qqbrowser)[/](\d+(\.?_?\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/msie|trident/i],
						describe: function(e) {
							var t = { name: "Internet Explorer" }, n = i.default.getFirstMatch(/(?:msie |rv:)(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/\sedg\//i],
						describe: function(e) {
							var t = { name: "Microsoft Edge" }, n = i.default.getFirstMatch(/\sedg\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/edg([ea]|ios)/i],
						describe: function(e) {
							var t = { name: "Microsoft Edge" }, n = i.default.getSecondMatch(/edg([ea]|ios)\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/vivaldi/i],
						describe: function(e) {
							var t = { name: "Vivaldi" }, n = i.default.getFirstMatch(/vivaldi\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/seamonkey/i],
						describe: function(e) {
							var t = { name: "SeaMonkey" }, n = i.default.getFirstMatch(/seamonkey\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/sailfish/i],
						describe: function(e) {
							var t = { name: "Sailfish" }, n = i.default.getFirstMatch(/sailfish\s?browser\/(\d+(\.\d+)?)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/silk/i],
						describe: function(e) {
							var t = { name: "Amazon Silk" }, n = i.default.getFirstMatch(/silk\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/phantom/i],
						describe: function(e) {
							var t = { name: "PhantomJS" }, n = i.default.getFirstMatch(/phantomjs\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/slimerjs/i],
						describe: function(e) {
							var t = { name: "SlimerJS" }, n = i.default.getFirstMatch(/slimerjs\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/blackberry|\bbb\d+/i, /rim\stablet/i],
						describe: function(e) {
							var t = { name: "BlackBerry" }, n = i.default.getFirstMatch(a, e) || i.default.getFirstMatch(/blackberry[\d]+\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/(web|hpw)[o0]s/i],
						describe: function(e) {
							var t = { name: "WebOS Browser" }, n = i.default.getFirstMatch(a, e) || i.default.getFirstMatch(/w(?:eb)?[o0]sbrowser\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/bada/i],
						describe: function(e) {
							var t = { name: "Bada" }, n = i.default.getFirstMatch(/dolfin\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/tizen/i],
						describe: function(e) {
							var t = { name: "Tizen" }, n = i.default.getFirstMatch(/(?:tizen\s?)?browser\/(\d+(\.?_?\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/qupzilla/i],
						describe: function(e) {
							var t = { name: "QupZilla" }, n = i.default.getFirstMatch(/(?:qupzilla)[\s/](\d+(\.?_?\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/librewolf/i],
						describe: function(e) {
							var t = { name: "LibreWolf" }, n = i.default.getFirstMatch(/(?:librewolf)[\s/](\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/firefox|iceweasel|fxios/i],
						describe: function(e) {
							var t = { name: "Firefox" }, n = i.default.getFirstMatch(/(?:firefox|iceweasel|fxios)[\s/](\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/electron/i],
						describe: function(e) {
							var t = { name: "Electron" }, n = i.default.getFirstMatch(/(?:electron)\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [
							/sogoumobilebrowser/i,
							/metasr/i,
							/se 2\.[x]/i
						],
						describe: function(e) {
							var t = { name: "Sogou Browser" }, n = i.default.getFirstMatch(/(?:sogoumobilebrowser)[\s/](\d+(\.?_?\d+)+)/i, e), r = i.default.getFirstMatch(/(?:chrome|crios|crmo)\/(\d+(\.?_?\d+)+)/i, e), a = i.default.getFirstMatch(/se ([\d.]+)x/i, e), o = n || r || a;
							return o && (t.version = o), t;
						}
					},
					{
						test: [/MiuiBrowser/i],
						describe: function(e) {
							var t = { name: "Miui" }, n = i.default.getFirstMatch(/(?:MiuiBrowser)[\s/](\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: function(e) {
							return !!e.hasBrand("DuckDuckGo") || e.test(/\sDdg\/[\d.]+$/i);
						},
						describe: function(e, t) {
							var n = { name: "DuckDuckGo" };
							if (t) {
								var r = t.getBrandVersion("DuckDuckGo");
								if (r) return n.version = r, n;
							}
							var a = i.default.getFirstMatch(/\sDdg\/([\d.]+)$/i, e);
							return a && (n.version = a), n;
						}
					},
					{
						test: function(e) {
							return e.hasBrand("Brave");
						},
						describe: function(e, t) {
							var n = { name: "Brave" };
							if (t) {
								var r = t.getBrandVersion("Brave");
								if (r) return n.version = r, n;
							}
							return n;
						}
					},
					{
						test: [/chromium/i],
						describe: function(e) {
							var t = { name: "Chromium" }, n = i.default.getFirstMatch(/(?:chromium)[\s/](\d+(\.?_?\d+)+)/i, e) || i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/chrome|crios|crmo/i],
						describe: function(e) {
							var t = { name: "Chrome" }, n = i.default.getFirstMatch(/(?:chrome|crios|crmo)\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/GSA/i],
						describe: function(e) {
							var t = { name: "Google Search" }, n = i.default.getFirstMatch(/(?:GSA)\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: function(e) {
							var t = !e.test(/like android/i), n = e.test(/android/i);
							return t && n;
						},
						describe: function(e) {
							var t = { name: "Android Browser" }, n = i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/playstation 4/i],
						describe: function(e) {
							var t = { name: "PlayStation 4" }, n = i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/safari|applewebkit/i],
						describe: function(e) {
							var t = { name: "Safari" }, n = i.default.getFirstMatch(a, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/.*/i],
						describe: function(e) {
							var t = e.search("\\(") === -1 ? /^(.*)\/(.*) / : /^(.*)\/(.*)[ \t]\((.*)/;
							return {
								name: i.default.getFirstMatch(t, e),
								version: i.default.getSecondMatch(t, e)
							};
						}
					}
				], e.exports = t.default;
			},
			93: function(e, t, n) {
				t.__esModule = !0, t.default = void 0;
				var r, i = (r = n(17)) && r.__esModule ? r : { default: r }, a = n(18);
				t.default = [
					{
						test: [/Roku\/DVP/],
						describe: function(e) {
							var t = i.default.getFirstMatch(/Roku\/DVP-(\d+\.\d+)/i, e);
							return {
								name: a.OS_MAP.Roku,
								version: t
							};
						}
					},
					{
						test: [/windows phone/i],
						describe: function(e) {
							var t = i.default.getFirstMatch(/windows phone (?:os)?\s?(\d+(\.\d+)*)/i, e);
							return {
								name: a.OS_MAP.WindowsPhone,
								version: t
							};
						}
					},
					{
						test: [/windows /i],
						describe: function(e) {
							var t = i.default.getFirstMatch(/Windows ((NT|XP)( \d\d?.\d)?)/i, e), n = i.default.getWindowsVersionName(t);
							return {
								name: a.OS_MAP.Windows,
								version: t,
								versionName: n
							};
						}
					},
					{
						test: [/Macintosh(.*?) FxiOS(.*?)\//],
						describe: function(e) {
							var t = { name: a.OS_MAP.iOS }, n = i.default.getSecondMatch(/(Version\/)(\d[\d.]+)/, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/macintosh/i],
						describe: function(e) {
							var t = i.default.getFirstMatch(/mac os x (\d+(\.?_?\d+)+)/i, e).replace(/[_\s]/g, "."), n = i.default.getMacOSVersionName(t), r = {
								name: a.OS_MAP.MacOS,
								version: t
							};
							return n && (r.versionName = n), r;
						}
					},
					{
						test: [/(ipod|iphone|ipad)/i],
						describe: function(e) {
							var t = i.default.getFirstMatch(/os (\d+([_\s]\d+)*) like mac os x/i, e).replace(/[_\s]/g, ".");
							return {
								name: a.OS_MAP.iOS,
								version: t
							};
						}
					},
					{
						test: [/OpenHarmony/i],
						describe: function(e) {
							var t = i.default.getFirstMatch(/OpenHarmony\s+(\d+(\.\d+)*)/i, e);
							return {
								name: a.OS_MAP.HarmonyOS,
								version: t
							};
						}
					},
					{
						test: function(e) {
							var t = !e.test(/like android/i), n = e.test(/android/i);
							return t && n;
						},
						describe: function(e) {
							var t = i.default.getFirstMatch(/android[\s/-](\d+(\.\d+)*)/i, e), n = i.default.getAndroidVersionName(t), r = {
								name: a.OS_MAP.Android,
								version: t
							};
							return n && (r.versionName = n), r;
						}
					},
					{
						test: [/(web|hpw)[o0]s/i],
						describe: function(e) {
							var t = i.default.getFirstMatch(/(?:web|hpw)[o0]s\/(\d+(\.\d+)*)/i, e), n = { name: a.OS_MAP.WebOS };
							return t && t.length && (n.version = t), n;
						}
					},
					{
						test: [/blackberry|\bbb\d+/i, /rim\stablet/i],
						describe: function(e) {
							var t = i.default.getFirstMatch(/rim\stablet\sos\s(\d+(\.\d+)*)/i, e) || i.default.getFirstMatch(/blackberry\d+\/(\d+([_\s]\d+)*)/i, e) || i.default.getFirstMatch(/\bbb(\d+)/i, e);
							return {
								name: a.OS_MAP.BlackBerry,
								version: t
							};
						}
					},
					{
						test: [/bada/i],
						describe: function(e) {
							var t = i.default.getFirstMatch(/bada\/(\d+(\.\d+)*)/i, e);
							return {
								name: a.OS_MAP.Bada,
								version: t
							};
						}
					},
					{
						test: [/tizen/i],
						describe: function(e) {
							var t = i.default.getFirstMatch(/tizen[/\s](\d+(\.\d+)*)/i, e);
							return {
								name: a.OS_MAP.Tizen,
								version: t
							};
						}
					},
					{
						test: [/linux/i],
						describe: function() {
							return { name: a.OS_MAP.Linux };
						}
					},
					{
						test: [/CrOS/],
						describe: function() {
							return { name: a.OS_MAP.ChromeOS };
						}
					},
					{
						test: [/PlayStation 4/],
						describe: function(e) {
							var t = i.default.getFirstMatch(/PlayStation 4[/\s](\d+(\.\d+)*)/i, e);
							return {
								name: a.OS_MAP.PlayStation4,
								version: t
							};
						}
					}
				], e.exports = t.default;
			},
			94: function(e, t, n) {
				t.__esModule = !0, t.default = void 0;
				var r, i = (r = n(17)) && r.__esModule ? r : { default: r }, a = n(18);
				t.default = [
					{
						test: [/googlebot/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Google"
							};
						}
					},
					{
						test: [/linespider/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Line"
							};
						}
					},
					{
						test: [/amazonbot/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Amazon"
							};
						}
					},
					{
						test: [/gptbot/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "OpenAI"
							};
						}
					},
					{
						test: [/chatgpt-user/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "OpenAI"
							};
						}
					},
					{
						test: [/oai-searchbot/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "OpenAI"
							};
						}
					},
					{
						test: [/baiduspider/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Baidu"
							};
						}
					},
					{
						test: [/bingbot/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Bing"
							};
						}
					},
					{
						test: [/duckduckbot/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "DuckDuckGo"
							};
						}
					},
					{
						test: [
							/claudebot/i,
							/claude-web/i,
							/claude-user/i,
							/claude-searchbot/i
						],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Anthropic"
							};
						}
					},
					{
						test: [/omgilibot/i, /webzio-extended/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Webz.io"
							};
						}
					},
					{
						test: [/diffbot/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Diffbot"
							};
						}
					},
					{
						test: [/perplexitybot/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Perplexity AI"
							};
						}
					},
					{
						test: [/perplexity-user/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Perplexity AI"
							};
						}
					},
					{
						test: [/youbot/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "You.com"
							};
						}
					},
					{
						test: [/ia_archiver/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Internet Archive"
							};
						}
					},
					{
						test: [/meta-webindexer/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Meta"
							};
						}
					},
					{
						test: [/meta-externalads/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Meta"
							};
						}
					},
					{
						test: [/meta-externalagent/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Meta"
							};
						}
					},
					{
						test: [/meta-externalfetcher/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Meta"
							};
						}
					},
					{
						test: [/facebookexternalhit/i, /facebookcatalog/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Meta"
							};
						}
					},
					{
						test: [/slackbot/i, /slack-imgProxy/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Slack"
							};
						}
					},
					{
						test: [/yahoo/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Yahoo"
							};
						}
					},
					{
						test: [/yandexbot/i, /yandexmobilebot/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Yandex"
							};
						}
					},
					{
						test: [/pingdom/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.bot,
								vendor: "Pingdom"
							};
						}
					},
					{
						test: [/huawei/i],
						describe: function(e) {
							var t = i.default.getFirstMatch(/(can-l01)/i, e) && "Nova", n = {
								type: a.PLATFORMS_MAP.mobile,
								vendor: "Huawei"
							};
							return t && (n.model = t), n;
						}
					},
					{
						test: [/nexus\s*(?:7|8|9|10).*/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.tablet,
								vendor: "Nexus"
							};
						}
					},
					{
						test: [/ipad/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.tablet,
								vendor: "Apple",
								model: "iPad"
							};
						}
					},
					{
						test: [/Macintosh(.*?) FxiOS(.*?)\//],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.tablet,
								vendor: "Apple",
								model: "iPad"
							};
						}
					},
					{
						test: [/kftt build/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.tablet,
								vendor: "Amazon",
								model: "Kindle Fire HD 7"
							};
						}
					},
					{
						test: [/silk/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.tablet,
								vendor: "Amazon"
							};
						}
					},
					{
						test: [/tablet(?! pc)/i],
						describe: function() {
							return { type: a.PLATFORMS_MAP.tablet };
						}
					},
					{
						test: function(e) {
							var t = e.test(/ipod|iphone/i), n = e.test(/like (ipod|iphone)/i);
							return t && !n;
						},
						describe: function(e) {
							var t = i.default.getFirstMatch(/(ipod|iphone)/i, e);
							return {
								type: a.PLATFORMS_MAP.mobile,
								vendor: "Apple",
								model: t
							};
						}
					},
					{
						test: [/nexus\s*[0-6].*/i, /galaxy nexus/i],
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.mobile,
								vendor: "Nexus"
							};
						}
					},
					{
						test: [/Nokia/i],
						describe: function(e) {
							var t = i.default.getFirstMatch(/Nokia\s+([0-9]+(\.[0-9]+)?)/i, e), n = {
								type: a.PLATFORMS_MAP.mobile,
								vendor: "Nokia"
							};
							return t && (n.model = t), n;
						}
					},
					{
						test: [/[^-]mobi/i],
						describe: function() {
							return { type: a.PLATFORMS_MAP.mobile };
						}
					},
					{
						test: function(e) {
							return e.getBrowserName(!0) === "blackberry";
						},
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.mobile,
								vendor: "BlackBerry"
							};
						}
					},
					{
						test: function(e) {
							return e.getBrowserName(!0) === "bada";
						},
						describe: function() {
							return { type: a.PLATFORMS_MAP.mobile };
						}
					},
					{
						test: function(e) {
							return e.getBrowserName() === "windows phone";
						},
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.mobile,
								vendor: "Microsoft"
							};
						}
					},
					{
						test: function(e) {
							var t = Number(String(e.getOSVersion()).split(".")[0]);
							return e.getOSName(!0) === "android" && t >= 3;
						},
						describe: function() {
							return { type: a.PLATFORMS_MAP.tablet };
						}
					},
					{
						test: function(e) {
							return e.getOSName(!0) === "android";
						},
						describe: function() {
							return { type: a.PLATFORMS_MAP.mobile };
						}
					},
					{
						test: [/smart-?tv|smarttv/i],
						describe: function() {
							return { type: a.PLATFORMS_MAP.tv };
						}
					},
					{
						test: [/netcast/i],
						describe: function() {
							return { type: a.PLATFORMS_MAP.tv };
						}
					},
					{
						test: function(e) {
							return e.getOSName(!0) === "macos";
						},
						describe: function() {
							return {
								type: a.PLATFORMS_MAP.desktop,
								vendor: "Apple"
							};
						}
					},
					{
						test: function(e) {
							return e.getOSName(!0) === "windows";
						},
						describe: function() {
							return { type: a.PLATFORMS_MAP.desktop };
						}
					},
					{
						test: function(e) {
							return e.getOSName(!0) === "linux";
						},
						describe: function() {
							return { type: a.PLATFORMS_MAP.desktop };
						}
					},
					{
						test: function(e) {
							return e.getOSName(!0) === "playstation 4";
						},
						describe: function() {
							return { type: a.PLATFORMS_MAP.tv };
						}
					},
					{
						test: function(e) {
							return e.getOSName(!0) === "roku";
						},
						describe: function() {
							return { type: a.PLATFORMS_MAP.tv };
						}
					}
				], e.exports = t.default;
			},
			95: function(e, t, n) {
				t.__esModule = !0, t.default = void 0;
				var r, i = (r = n(17)) && r.__esModule ? r : { default: r }, a = n(18);
				t.default = [
					{
						test: function(e) {
							return e.getBrowserName(!0) === "microsoft edge";
						},
						describe: function(e) {
							if (/\sedg\//i.test(e)) return { name: a.ENGINE_MAP.Blink };
							var t = i.default.getFirstMatch(/edge\/(\d+(\.?_?\d+)+)/i, e);
							return {
								name: a.ENGINE_MAP.EdgeHTML,
								version: t
							};
						}
					},
					{
						test: [/trident/i],
						describe: function(e) {
							var t = { name: a.ENGINE_MAP.Trident }, n = i.default.getFirstMatch(/trident\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: function(e) {
							return e.test(/presto/i);
						},
						describe: function(e) {
							var t = { name: a.ENGINE_MAP.Presto }, n = i.default.getFirstMatch(/presto\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: function(e) {
							var t = e.test(/gecko/i), n = e.test(/like gecko/i);
							return t && !n;
						},
						describe: function(e) {
							var t = { name: a.ENGINE_MAP.Gecko }, n = i.default.getFirstMatch(/gecko\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					},
					{
						test: [/(apple)?webkit\/537\.36/i],
						describe: function() {
							return { name: a.ENGINE_MAP.Blink };
						}
					},
					{
						test: [/(apple)?webkit/i],
						describe: function(e) {
							var t = { name: a.ENGINE_MAP.WebKit }, n = i.default.getFirstMatch(/webkit\/(\d+(\.?_?\d+)+)/i, e);
							return n && (t.version = n), t;
						}
					}
				], e.exports = t.default;
			}
		});
	}));
})))(), 1)).default.getParser(globalThis.navigator.userAgent).getResult(), Vp = "unknown", Hp = (...e) => e.filter(Boolean).join(" ").trim() || Vp;
function Up() {
	return typeof document < "u" && document.hidden;
}
function Wp() {
	return {
		os: Hp(Bp.os?.name, Bp.os?.version),
		browser: Hp(Bp.browser?.name, Bp.browser?.version),
		loader: (() => {
			let e = GM_info?.scriptHandler, t = GM_info?.version;
			return e && t ? `${e} v${t}` : e || t || Vp;
		})(),
		scriptVersion: GM_info?.script?.version ?? Vp,
		scriptName: GM_info?.script?.name ?? Vp,
		url: globalThis?.location?.href ?? Vp
	};
}
//#endregion
//#region src/ui/components/accountButton.ts
var Gp = class {
	container;
	accountWrapper;
	buttons;
	usernameEl;
	avatarEl;
	avatarImg;
	actionButton;
	refreshButton;
	tokenButton;
	onClick = new H();
	onRefresh = new H();
	onClickSecret = new H();
	events = {
		click: this.onClick,
		"click:secret": this.onClickSecret,
		refresh: this.onRefresh
	};
	_loggedIn;
	_username;
	_avatarId;
	constructor({ loggedIn: e = !1, username: t = "unnamed", avatarId: n = "0/0-0" } = {}) {
		this._loggedIn = e, this._username = t, this._avatarId = n;
		let r = this.createElements();
		this.container = r.container, this.accountWrapper = r.accountWrapper, this.buttons = r.buttons, this.usernameEl = r.usernameEl, this.avatarEl = r.avatarEl, this.avatarImg = r.avatarImg, this.actionButton = r.actionButton, this.refreshButton = r.refreshButton, this.tokenButton = r.tokenButton;
	}
	createElements() {
		let e = J.createEl("vot-block", ["vot-account"]), t = J.createEl("vot-block", ["vot-account-wrapper"]);
		t.hidden = !this._loggedIn;
		let n = J.createEl("img", ["vot-account-avatar-img"]);
		n.src = `${li}/${this._avatarId}/islands-retina-middle`, n.loading = "lazy", n.alt = "user avatar";
		let r = J.createEl("vot-block", ["vot-account-avatar"], n), i = J.createEl("vot-block", ["vot-account-username"]);
		i.textContent = this._username, t.append(r, i);
		let a = J.createEl("vot-block", ["vot-account-buttons"]), o = J.createOutlinedButton(this.buttonText);
		o.addEventListener("click", () => {
			this.onClick.dispatch();
		});
		let s = J.createIconButton(Cp, { ariaLabel: V.get("VOTLoginViaToken") });
		s.hidden = this._loggedIn, s.addEventListener("click", () => {
			this.onClickSecret.dispatch();
		});
		let c = J.createIconButton(Sp, { ariaLabel: V.get("VOTRefresh") });
		return c.addEventListener("click", () => {
			this.onRefresh.dispatch();
		}), a.append(o, s, c), e.append(t, a), {
			container: e,
			accountWrapper: t,
			buttons: a,
			usernameEl: i,
			avatarImg: n,
			avatarEl: r,
			actionButton: o,
			refreshButton: c,
			tokenButton: s
		};
	}
	addEventListener(e, t) {
		return wp(this.events, e, t), this;
	}
	removeEventListener(e, t) {
		return Tp(this.events, e, t), this;
	}
	get buttonText() {
		return this._loggedIn ? V.get("VOTLogout") : V.get("VOTLogin");
	}
	get loggedIn() {
		return this._loggedIn;
	}
	set loggedIn(e) {
		this._loggedIn = e, this.accountWrapper.hidden = !this._loggedIn, this.actionButton.textContent = this.buttonText, this.tokenButton.hidden = this._loggedIn;
	}
	get avatarId() {
		return this._avatarId;
	}
	set avatarId(e) {
		this._avatarId = e ?? "0/0-0", this.avatarImg.src = `${li}/${this._avatarId}/islands-retina-middle`;
	}
	get username() {
		return this._username;
	}
	set username(e) {
		this._username = e ?? "unnamed", this.usernameEl.textContent = this._username;
	}
	set hidden(e) {
		X(this.container, e);
	}
	get hidden() {
		return Z(this.container);
	}
}, $ = class {
	container;
	input;
	label;
	onChange = new H();
	events = { change: this.onChange };
	_labelHtml;
	_checked;
	_isSubCheckbox;
	constructor({ labelHtml: e, checked: t = !1, isSubCheckbox: n = !1 }) {
		this._labelHtml = e, this._checked = t, this._isSubCheckbox = n;
		let r = this.createElements();
		this.container = r.container, this.input = r.input, this.label = r.label;
	}
	createElements() {
		let e = J.createEl("label", ["vot-checkbox"]);
		this._isSubCheckbox && e.classList.add("vot-checkbox-sub");
		let t = document.createElement("input");
		t.type = "checkbox", t.checked = this._checked, t.addEventListener("change", () => {
			this._checked = t.checked, this.onChange.dispatch(this._checked);
		});
		let n = J.createEl("span");
		return q(this._labelHtml, n), e.append(t, n), {
			container: e,
			input: t,
			label: n
		};
	}
	addEventListener(e, t) {
		return wp(this.events, "change", t), this;
	}
	removeEventListener(e, t) {
		return Tp(this.events, "change", t), this;
	}
	set hidden(e) {
		X(this.container, e);
	}
	get hidden() {
		return Z(this.container);
	}
	get disabled() {
		return this.input.disabled;
	}
	set disabled(e) {
		this.input.disabled = e;
	}
	get checked() {
		return this._checked;
	}
	set checked(e) {
		this._checked !== e && (this._checked = this.input.checked = e, this.onChange.dispatch(this._checked));
	}
}, Kp = class {
	container;
	header;
	arrowIcon;
	onClick = new H();
	events = { click: this.onClick };
	_titleHtml;
	constructor({ titleHtml: e }) {
		this._titleHtml = e;
		let t = this.createElements();
		this.container = t.container, this.header = t.header, this.arrowIcon = t.arrowIcon;
	}
	createElements() {
		let e = J.createEl("vot-block", ["vot-details"]);
		J.makeButtonLike(e);
		let t = J.createEl("vot-block");
		t.append(this._titleHtml);
		let n = J.createEl("vot-block", ["vot-details-arrow-icon"]);
		return q(_p, n), e.append(t, n), e.addEventListener("click", () => {
			this.onClick.dispatch();
		}), {
			container: e,
			header: t,
			arrowIcon: n
		};
	}
	addEventListener(e, t) {
		return wp(this.events, "click", t), this;
	}
	removeEventListener(e, t) {
		return Tp(this.events, "click", t), this;
	}
	set hidden(e) {
		X(this.container, e);
	}
	get hidden() {
		return Z(this.container);
	}
}, qp = class {
	container;
	button;
	onChange = new H();
	events = { change: this.onChange };
	_labelHtml;
	_key;
	pressedKeys;
	comboKeys;
	recording = !1;
	constructor({ labelHtml: e, key: t = null }) {
		this._labelHtml = e, this._key = t, this.pressedKeys = /* @__PURE__ */ new Set(), this.comboKeys = /* @__PURE__ */ new Set();
		let n = this.createElements();
		this.container = n.container, this.button = n.button;
	}
	stopRecordingKeys() {
		this.recording = !1, document.removeEventListener("keydown", this.keydownHandle), document.removeEventListener("keyup", this.keyupOrBlurHandle), globalThis.removeEventListener("blur", this.blurHandle), delete this.button.dataset.status, this.pressedKeys.clear(), this.comboKeys.clear();
	}
	keydownHandle = (e) => {
		if (!(!this.recording || e.repeat)) {
			if (e.preventDefault(), e.code === "Escape") {
				this.key = null, this.button.textContent = this.keyText, this.stopRecordingKeys();
				return;
			}
			this.pressedKeys.add(e.code), this.comboKeys.add(e.code), this.button.textContent = Yp(this.pressedKeys);
		}
	};
	keyupOrBlurHandle = (e) => {
		this.recording && (e && (this.pressedKeys.delete(e.code), this.button.textContent = this.pressedKeys.size ? Yp(this.pressedKeys) : Yp(this.comboKeys), this.pressedKeys.size) || (this.key = this.comboKeys.size ? Jp(this.comboKeys) : null, this.stopRecordingKeys()));
	};
	blurHandle = () => {
		this.keyupOrBlurHandle();
	};
	createElements() {
		let e = J.createEl("vot-block", ["vot-hotkey"]), t = J.createEl("vot-block", ["vot-hotkey-label"]);
		t.textContent = this._labelHtml;
		let n = J.createEl("vot-block", ["vot-hotkey-button"]);
		return J.makeButtonLike(n), n.textContent = this.keyText, n.addEventListener("click", () => {
			if (this.recording) {
				this.stopRecordingKeys(), this.button.textContent = this.keyText;
				return;
			}
			n.dataset.status = "active", this.recording = !0, this.pressedKeys.clear(), this.comboKeys.clear(), this.button.textContent = V.get("PressTheKeyCombination"), document.addEventListener("keydown", this.keydownHandle), document.addEventListener("keyup", this.keyupOrBlurHandle), globalThis.addEventListener("blur", this.blurHandle);
		}), e.append(t, n), {
			container: e,
			button: n,
			label: t
		};
	}
	addEventListener(e, t) {
		return wp(this.events, "change", t), this;
	}
	removeEventListener(e, t) {
		return Tp(this.events, "change", t), this;
	}
	set hidden(e) {
		X(this.container, e);
	}
	get hidden() {
		return Z(this.container);
	}
	get key() {
		return this._key;
	}
	get keyText() {
		return this._key ? Yp(this._key) : V.get("None");
	}
	set key(e) {
		this._key !== e && (this._key = e, this.button.textContent = this.keyText, this.onChange.dispatch(this._key));
	}
};
function Jp(e) {
	return (Array.isArray(e) ? e : Array.from(e)).map((e) => e.replace("Key", "").replace("Digit", "")).join("+");
}
function Yp(e) {
	let t;
	t = typeof e == "string" ? e.split("+").filter(Boolean) : Array.isArray(e) ? e : Array.from(e);
	let n = (e) => {
		switch (e) {
			case "ControlLeft":
			case "ControlRight":
			case "Control": return "Ctrl";
			case "ShiftLeft":
			case "ShiftRight":
			case "Shift": return "Shift";
			case "AltLeft":
			case "AltRight":
			case "Alt": return "Alt";
			case "MetaLeft":
			case "MetaRight":
			case "Meta": return "Meta";
			case "Space": return "Space";
			case "ArrowUp": return "↑";
			case "ArrowDown": return "↓";
			case "ArrowLeft": return "←";
			case "ArrowRight": return "→";
			default: return e.replace("Key", "").replace("Digit", "");
		}
	}, r = (e) => {
		let t = n(e);
		return t === "Ctrl" ? 0 : t === "Alt" ? 1 : t === "Shift" ? 2 : t === "Meta" ? 3 : 10;
	};
	return t.slice().sort((e, t) => r(e) - r(t)).map(n).join("+");
}
//#endregion
//#region src/ui/views/settings.ts
var Xp = [
	"click:bugReport",
	"click:resetSettings",
	"update:account",
	"change:autoTranslate",
	"change:autoSubtitles",
	"change:showVideoVolume",
	"change:audioBooster",
	"change:syncVolume",
	"change:useLivelyVoice",
	"change:subtitlesHighlightWords",
	"change:subtitlesSmartLayout",
	"select:responseLanguageSubtitles",
	"select:subtitlesFontFamily",
	"change:proxyWorkerHost",
	"change:useNewAudioPlayer",
	"change:onlyBypassMediaCSP",
	"change:showPiPButton",
	"input:subtitlesMaxLength",
	"input:subtitlesFontSize",
	"input:subtitlesBackgroundOpacity",
	"input:autoHideButtonDelay",
	"select:proxyTranslationStatus",
	"select:translationTextService",
	"select:buttonPosition",
	"select:menuLanguage"
];
function Zp() {
	let e = {};
	for (let t of Xp) e[t] = new H();
	return e;
}
var Qp = 30, [$p, em] = vi, tm = {
	"default-sans": "Default Sans",
	arial: "Arial",
	helvetica: "Helvetica",
	roboto: "Roboto",
	verdana: "Verdana",
	"open-sans": "Open Sans",
	poppins: "Poppins",
	lato: "Lato",
	montserrat: "Montserrat",
	barlow: "Barlow"
};
function nm(e) {
	return Xl(e) ? tm[e] : au(e) ?? "Default Sans";
}
function rm() {
	return Object.keys(V.defaultLocale).filter((e) => e.startsWith("langs.") && e !== "langs.auto").map((e) => e.slice(6)).sort((e, t) => V.getLangLabel(e).localeCompare(V.getLangLabel(t)));
}
function im(e) {
	return e === em ? V.get("VOTOriginalVideoLanguage") : V.getLangLabel(e);
}
function am(e) {
	return [
		{
			label: im($p),
			value: $p,
			selected: e === $p
		},
		{
			label: im(em),
			value: em,
			selected: e === em
		},
		...rm().map((t) => ({
			label: im(t),
			value: t,
			selected: e === t
		}))
	];
}
var om = class e {
	static PERSIST_DELAY_MS = 250;
	globalPortal;
	initialized = !1;
	data;
	videoHandler;
	suppressSubtitlesSmartLayoutCheckboxChange = !1;
	events = Zp();
	persistTimerIds = {};
	onAuthRefreshMessage = (e) => {
		Xa(e.data) && this.refreshAccountFromStorage();
	};
	dialog;
	accountButton;
	accountButtonRefreshTooltip;
	accountButtonTokenTooltip;
	accountStorageListenerCleanup;
	autoTranslateCheckbox;
	autoSubtitlesCheckbox;
	dontTranslateLanguagesCheckbox;
	dontTranslateLanguagesSelect;
	autoSetVolumeSliderLabel;
	autoSetVolumeCheckbox;
	smartDuckingCheckbox;
	autoSetVolumeSlider;
	showVideoVolumeSliderCheckbox;
	audioBoosterCheckbox;
	audioBoosterTooltip;
	syncVolumeCheckbox;
	downloadWithNameCheckbox;
	sendNotifyOnCompleteCheckbox;
	useLivelyVoiceCheckbox;
	useLivelyVoiceTooltip;
	useAudioDownloadCheckbox;
	useAudioDownloadCheckboxLabel;
	useAudioDownloadCheckboxTooltip;
	responseLanguageSubtitlesSelectLabel;
	responseLanguageSubtitlesSelect;
	subtitlesDownloadFormatSelectLabel;
	subtitlesDownloadFormatSelect;
	subtitlesHighlightWordsCheckbox;
	subtitlesSmartLayoutCheckbox;
	subtitlesMaxLengthSliderLabel;
	subtitlesMaxLengthSlider;
	subtitlesFontSizeSliderLabel;
	subtitlesFontSizeSlider;
	subtitlesFontFamilySelectLabel;
	subtitlesFontFamilySelect;
	subtitlesBackgroundOpacitySliderLabel;
	subtitlesBackgroundOpacitySlider;
	translateHotkeyButton;
	subtitlesHotkeyButton;
	proxyWorkerHostTextfield;
	proxyTranslationStatusSelectLabel;
	proxyTranslationStatusSelectTooltip;
	proxyTranslationStatusSelect;
	translateAPIErrorsCheckbox;
	useNewAudioPlayerCheckbox;
	useNewAudioPlayerTooltip;
	onlyBypassMediaCSPCheckbox;
	onlyBypassMediaCSPTooltip;
	translationTextServiceLabel;
	translationTextServiceSelect;
	translationTextServiceTooltip;
	detectServiceLabel;
	detectServiceSelect;
	showPiPButtonCheckbox;
	autoHideButtonDelaySliderLabel;
	autoHideButtonDelaySlider;
	buttonPositionSelectLabel;
	buttonPositionSelect;
	buttonPositionTooltip;
	menuLanguageSelectLabel;
	menuLanguageSelect;
	bugReportButton;
	resetSettingsButton;
	constructor({ globalPortal: e, data: t = {}, videoHandler: n }) {
		this.globalPortal = e, this.data = t, this.videoHandler = n;
	}
	isInitialized() {
		return this.initialized;
	}
	createAccordionSection(e, t = {}) {
		let n = J.createEl("vot-block", ["vot-settings-section"]), r = new Kp({ titleHtml: e });
		r.container.classList.add("vot-settings-section-header");
		let i = typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`, a = `vot-settings-section-header-${i}`, o = `vot-settings-section-content-${i}`;
		r.container.id = a;
		let s = J.createEl("vot-block", ["vot-settings-section-content"]);
		s.id = o, s.setAttribute("role", "region"), s.setAttribute("aria-labelledby", a), r.container.setAttribute("aria-controls", o);
		let c = (e) => {
			r.container.dataset.open = e ? "true" : "false", r.container.setAttribute("aria-expanded", e ? "true" : "false"), s.hidden = !e;
		};
		return c(!!t.open), r.addEventListener("click", () => {
			c(r.container.dataset.open !== "true");
		}), n.append(r.container, s), {
			title: e,
			container: n,
			header: r.container,
			content: s,
			setOpen: c,
			getOpen: () => r.container.dataset.open === "true"
		};
	}
	setSubtitlesSmartLayout(e) {
		this.data.subtitlesSmartLayout = e, B.set("subtitlesSmartLayout", e), L.log("subtitlesSmartLayout value changed. New value:", e), this.subtitlesSmartLayoutCheckbox?.checked !== e && (this.suppressSubtitlesSmartLayoutCheckboxChange = !0, this.subtitlesSmartLayoutCheckbox.checked = e, this.suppressSubtitlesSmartLayoutCheckboxChange = !1), this.events["change:subtitlesSmartLayout"].dispatch(e);
	}
	scheduleStoragePersist(t, n) {
		let r = this.persistTimerIds[t];
		r !== void 0 && globalThis.clearTimeout(r), this.persistTimerIds[t] = globalThis.setTimeout(() => {
			this.persistTimerIds[t] = void 0, B.set(t, n);
		}, e.PERSIST_DELAY_MS);
	}
	flushStoragePersists() {
		for (let e of Object.keys(this.persistTimerIds)) {
			let t = this.persistTimerIds[e];
			if (t === void 0) continue;
			globalThis.clearTimeout(t), this.persistTimerIds[e] = void 0;
			let n = this.data[e];
			typeof n == "number" && B.set(e, n);
		}
	}
	bindPersistedSetting({ control: e, event: t, apply: n, storageKey: r, readPersistedValue: i, logLabel: a, dispatch: o, afterPersist: s }) {
		e.addEventListener(t, async (e) => {
			n(e), await B.set(r, i()), L.log(`${a} value changed. New value:`, e), s && await s(e), o?.(e);
		});
	}
	createSettingsSections() {
		let e = [
			this.createAccordionSection(V.get("VOTMyAccount"), { open: !0 }),
			this.createAccordionSection(V.get("translationSettings"), { open: !0 }),
			this.createAccordionSection(V.get("subtitlesSettings")),
			this.createAccordionSection(V.get("hotkeysSettings")),
			this.createAccordionSection(V.get("proxySettings")),
			this.createAccordionSection(V.get("miscSettings")),
			this.createAccordionSection(V.get("appearance")),
			this.createAccordionSection(V.get("aboutExtension"))
		];
		return {
			accountSection: e[0],
			translationSection: e[1],
			subtitlesSection: e[2],
			hotkeysSection: e[3],
			proxySection: e[4],
			miscSection: e[5],
			appearanceSection: e[6],
			aboutSection: e[7],
			sections: e
		};
	}
	initAccountControls() {
		this.accountButton = new Gp({
			avatarId: this.data.account?.avatarId,
			username: this.data.account?.username,
			loggedIn: !!this.data.account?.token
		}), B.isSupportOnlyLS ? (this.accountButton.refreshButton.setAttribute("disabled", "true"), this.accountButton.actionButton.setAttribute("disabled", "true")) : this.accountButtonRefreshTooltip = new Y({
			target: this.accountButton.refreshButton,
			content: V.get("VOTRefresh"),
			position: "bottom",
			backgroundColor: "var(--vot-helper-ondialog)",
			parentElement: this.globalPortal
		}), this.accountButtonTokenTooltip = new Y({
			target: this.accountButton.tokenButton,
			content: V.get("VOTLoginViaToken"),
			position: "bottom",
			backgroundColor: "var(--vot-helper-ondialog)",
			parentElement: this.globalPortal
		});
	}
	bindAccountStorageListener() {
		this.accountStorageListenerCleanup?.(), this.accountStorageListenerCleanup = B.addValueChangeListener("account", (e, t, n) => {
			this.data.account = n ?? {}, !(!this.isInitialized() || !this.accountButton) && this.updateAccountInfo();
		});
	}
	async refreshAccountFromStorage() {
		B.isSupportOnlyLS || (this.data.account = await B.get("account", {}), !(!this.isInitialized() || !this.accountButton) && this.updateAccountInfo());
	}
	buildSubtitleFontItems(e, t = []) {
		let n = Wl.map((t) => ({
			label: tm[t],
			value: t,
			selected: t === e
		})), r = t.filter((e) => {
			let t = e.toLowerCase();
			return !n.some((e) => e.label.toLowerCase() === t);
		}).map((t) => {
			let n = iu(t);
			return {
				label: t,
				value: n,
				selected: n === e
			};
		});
		if (!Xl(e) && !r.some((t) => t.value === e)) {
			let t = au(e);
			t && r.unshift({
				label: t,
				value: e,
				selected: !0
			});
		}
		return [...n, ...r];
	}
	async searchSubtitleFontItems(e, t) {
		let n = Array.from(this.subtitlesFontFamilySelect?.selectedValues ?? [])[0] ?? t, r = e.trim().toLowerCase();
		if (!r) return this.buildSubtitleFontItems(n);
		let i = (await uu()).filter((e) => e.toLowerCase().includes(r)).slice(0, Qp);
		return this.buildSubtitleFontItems(n, i);
	}
	initUI() {
		if (this.isInitialized()) throw Error("[VOT] SettingsView is already initialized");
		this.dialog = new kp({ titleHtml: V.get("VOTSettings") }), this.globalPortal.appendChild(this.dialog.container);
		let { accountSection: e, translationSection: t, subtitlesSection: n, hotkeysSection: r, proxySection: i, miscSection: a, appearanceSection: o, aboutSection: s, sections: c } = this.createSettingsSections();
		this.dialog.bodyContainer.append(...c.map((e) => e.container)), this.initAccountControls(), this.autoTranslateCheckbox = new $({
			labelHtml: V.get("VOTAutoTranslate"),
			checked: this.data.autoTranslate
		}), this.autoSubtitlesCheckbox = new $({
			labelHtml: V.get("VOTAutoSubtitles"),
			checked: this.data.autoSubtitles
		});
		let l = this.data.dontTranslateLanguages ?? [];
		this.dontTranslateLanguagesCheckbox = new $({
			labelHtml: V.get("DontTranslateSelectedLanguages"),
			checked: this.data.enabledDontTranslateLanguages
		}), this.dontTranslateLanguagesSelect = new Q({
			dialogParent: this.globalPortal,
			dialogTitle: V.get("DontTranslateSelectedLanguages"),
			selectTitle: l.map((e) => V.get(`langs.${e}`)).join(", ") || V.get("DontTranslateSelectedLanguages"),
			items: Q.genLanguageItems(dn).map((e) => ({
				...e,
				selected: l.includes(e.value)
			})),
			multiSelect: !0,
			labelElement: this.dontTranslateLanguagesCheckbox.container
		}), this.dontTranslateLanguagesSelect.disabled = !this.dontTranslateLanguagesCheckbox.checked;
		let u = this.data.autoVolume ?? 15;
		this.autoSetVolumeSliderLabel = new Pp({
			labelText: V.get("VOTAutoSetVolume"),
			value: u
		}), this.autoSetVolumeCheckbox = new $({
			labelHtml: this.autoSetVolumeSliderLabel.container,
			checked: this.data.enabledAutoVolume ?? !0
		}), this.autoSetVolumeSlider = new Mp({
			labelHtml: this.autoSetVolumeCheckbox.container,
			value: u,
			min: 0
		});
		let d = !!this.data.syncVolume;
		this.autoSetVolumeSlider.disabled = !this.autoSetVolumeCheckbox.checked, this.smartDuckingCheckbox = new $({
			labelHtml: V.get("smartDucking"),
			checked: this.data.enabledSmartDucking ?? !0
		}), this.smartDuckingCheckbox.disabled = d || !this.autoSetVolumeCheckbox.checked, this.showVideoVolumeSliderCheckbox = new $({
			labelHtml: V.get("showVideoVolumeSlider"),
			checked: this.data.showVideoSlider
		}), this.audioBoosterCheckbox = new $({
			labelHtml: V.get("VOTAudioBooster"),
			checked: this.data.audioBooster
		}), this.videoHandler?.isAudioContextSupported || (this.audioBoosterCheckbox.disabled = !0, this.audioBoosterTooltip = new Y({
			target: this.audioBoosterCheckbox.container,
			content: V.get("VOTNeedWebAudioAPI"),
			position: "bottom",
			backgroundColor: "var(--vot-helper-ondialog)",
			parentElement: this.globalPortal
		})), this.syncVolumeCheckbox = new $({
			labelHtml: V.get("VOTSyncVolume"),
			checked: this.data.syncVolume
		}), this.downloadWithNameCheckbox = new $({
			labelHtml: V.get("VOTDownloadWithName"),
			checked: this.data.downloadWithName
		}), this.downloadWithNameCheckbox.disabled = !Ea, this.sendNotifyOnCompleteCheckbox = new $({
			labelHtml: V.get("VOTSendNotifyOnComplete"),
			checked: this.data.sendNotifyOnComplete
		}), this.useLivelyVoiceCheckbox = new $({
			labelHtml: V.get("VOTUseLivelyVoice"),
			checked: this.data.useLivelyVoice
		}), this.useLivelyVoiceTooltip = new Y({
			target: this.useLivelyVoiceCheckbox.container,
			content: V.get("VOTAccountRequired"),
			position: "bottom",
			backgroundColor: "var(--vot-helper-ondialog)",
			parentElement: this.globalPortal,
			hidden: !!this.data.account?.token
		}), this.data.account?.token || (this.useLivelyVoiceCheckbox.disabled = !0), this.useAudioDownloadCheckboxLabel = new Op({
			labelText: V.get("VOTUseAudioDownload"),
			icon: bp
		}), this.useAudioDownloadCheckbox = new $({
			labelHtml: this.useAudioDownloadCheckboxLabel.container,
			checked: this.data.useAudioDownload
		}), Ea || (this.useAudioDownloadCheckbox.disabled = !0), this.useAudioDownloadCheckboxTooltip = new Y({
			target: this.useAudioDownloadCheckboxLabel.container,
			content: V.get("VOTUseAudioDownloadWarning"),
			position: "bottom",
			backgroundColor: "var(--vot-helper-ondialog)",
			parentElement: this.globalPortal
		}), e.content.append(this.accountButton.container), t.content.append(this.autoTranslateCheckbox.container, this.autoSubtitlesCheckbox.container, this.dontTranslateLanguagesSelect.container, this.autoSetVolumeSlider.container, this.smartDuckingCheckbox.container, this.showVideoVolumeSliderCheckbox.container, this.audioBoosterCheckbox.container, this.syncVolumeCheckbox.container, this.downloadWithNameCheckbox.container, this.sendNotifyOnCompleteCheckbox.container, this.useLivelyVoiceCheckbox.container, this.useAudioDownloadCheckbox.container), this.subtitlesDownloadFormatSelectLabel = new Op({ labelText: V.get("VOTSubtitlesDownloadFormat") }), this.subtitlesDownloadFormatSelect = new Q({
			selectTitle: this.data.subtitlesDownloadFormat ?? V.get("VOTSubtitlesDownloadFormat"),
			dialogTitle: V.get("VOTSubtitlesDownloadFormat"),
			dialogParent: this.globalPortal,
			labelElement: this.subtitlesDownloadFormatSelectLabel.container,
			items: Ul.map((e) => ({
				label: e.toUpperCase(),
				value: e,
				selected: e === this.data.subtitlesDownloadFormat
			}))
		});
		let f = this.data.responseLanguageSubtitles ?? $p;
		this.responseLanguageSubtitlesSelectLabel = new Op({ labelText: V.get("VOTDefaultSubtitlesLanguage") }), this.responseLanguageSubtitlesSelect = new Q({
			selectTitle: im(f),
			dialogTitle: V.get("VOTDefaultSubtitlesLanguage"),
			dialogParent: this.globalPortal,
			labelElement: this.responseLanguageSubtitlesSelectLabel.container,
			items: am(f)
		}), this.subtitlesHighlightWordsCheckbox = new $({
			labelHtml: V.get("VOTHighlightWords"),
			checked: this.data.highlightWords
		});
		let p = this.data.subtitlesSmartLayout ?? !0;
		this.subtitlesSmartLayoutCheckbox = new $({
			labelHtml: V.get("subtitlesSmartLayout"),
			checked: p
		});
		let m = this.data.subtitlesMaxLength ?? 300;
		this.subtitlesMaxLengthSliderLabel = new Pp({
			labelText: V.get("VOTSubtitlesMaxLength"),
			labelEOL: ":",
			value: m,
			symbol: ""
		}), this.subtitlesMaxLengthSlider = new Mp({
			labelHtml: this.subtitlesMaxLengthSliderLabel.container,
			value: m,
			min: 50,
			max: 300
		});
		let h = this.data.subtitlesFontSize ?? 20;
		this.subtitlesFontSizeSliderLabel = new Pp({
			labelText: V.get("VOTSubtitlesFontSize"),
			labelEOL: ":",
			value: h,
			symbol: "px"
		}), this.subtitlesFontSizeSlider = new Mp({
			labelHtml: this.subtitlesFontSizeSliderLabel.container,
			value: h,
			min: 8,
			max: 50
		});
		let g = typeof this.data.subtitlesFontFamily == "string" ? this.data.subtitlesFontFamily : void 0, _ = g && (Xl(g) || au(g)) ? g : "default-sans";
		this.subtitlesFontFamilySelectLabel = new Op({ labelText: V.get("VOTSubtitlesFont") }), this.subtitlesFontFamilySelect = new Q({
			selectTitle: nm(_),
			dialogTitle: V.get("VOTSubtitlesFont"),
			dialogParent: this.globalPortal,
			labelElement: this.subtitlesFontFamilySelectLabel.container,
			items: this.buildSubtitleFontItems(_),
			searchItemsProvider: (e) => this.searchSubtitleFontItems(e, _)
		}), this.subtitlesFontFamilySelect.addEventListener("selectItem", (e) => {
			this.subtitlesFontFamilySelect && (this.subtitlesFontFamilySelect.updateItems(this.buildSubtitleFontItems(e)), this.subtitlesFontFamilySelect.selectTitle = nm(e));
		});
		let v = this.data.subtitlesOpacity ?? 20;
		this.subtitlesBackgroundOpacitySliderLabel = new Pp({
			labelText: V.get("VOTSubtitlesOpacity"),
			labelEOL: ":",
			value: v,
			symbol: "%"
		}), this.subtitlesBackgroundOpacitySlider = new Mp({
			labelHtml: this.subtitlesBackgroundOpacitySliderLabel.container,
			value: v,
			min: 0,
			max: 100
		}), n.content.append(this.responseLanguageSubtitlesSelect.container, this.subtitlesDownloadFormatSelect.container, this.subtitlesFontFamilySelect.container, this.subtitlesHighlightWordsCheckbox.container, this.subtitlesSmartLayoutCheckbox.container, this.subtitlesMaxLengthSlider.container, this.subtitlesFontSizeSlider.container, this.subtitlesBackgroundOpacitySlider.container), this.translateHotkeyButton = new qp({
			labelHtml: V.get("translateVideo"),
			key: this.data.translationHotkey
		}), this.subtitlesHotkeyButton = new qp({
			labelHtml: V.get("VOTSubtitles"),
			key: this.data.subtitlesHotkey
		}), r.content.append(this.translateHotkeyButton.container, this.subtitlesHotkeyButton.container), this.proxyWorkerHostTextfield = new Ap({
			labelHtml: V.get("VOTProxyWorkerHost"),
			value: this.data.proxyWorkerHost,
			placeholder: ii
		});
		let ee = [
			V.get("VOTTranslateProxyDisabled"),
			V.get("VOTTranslateProxyEnabled"),
			V.get("VOTTranslateProxyEverything")
		], te = this.data.translateProxyEnabled ?? 0, ne = Hg && hi.includes(Hg);
		this.proxyTranslationStatusSelectLabel = new Op({
			icon: ne ? bp : void 0,
			labelText: V.get("VOTTranslateProxyStatus")
		}), ne && (this.proxyTranslationStatusSelectTooltip = new Y({
			target: this.proxyTranslationStatusSelectLabel.icon,
			content: V.get("VOTTranslateProxyStatusDefault"),
			position: "bottom",
			backgroundColor: "var(--vot-helper-ondialog)",
			parentElement: this.globalPortal
		})), this.proxyTranslationStatusSelect = new Q({
			selectTitle: ee[te],
			dialogTitle: V.get("VOTTranslateProxyStatus"),
			dialogParent: this.globalPortal,
			labelElement: this.proxyTranslationStatusSelectLabel.container,
			items: ee.map((e, t) => ({
				label: e,
				value: t.toString(),
				selected: t === te,
				disabled: t === 0 && !1
			}))
		}), i.content.append(this.proxyWorkerHostTextfield.container, this.proxyTranslationStatusSelect.container), this.translateAPIErrorsCheckbox = new $({
			labelHtml: V.get("VOTTranslateAPIErrors"),
			checked: this.data.translateAPIErrors ?? !0
		}), this.translateAPIErrorsCheckbox.hidden = V.lang === "ru", this.useNewAudioPlayerCheckbox = new $({
			labelHtml: V.get("VOTNewAudioPlayer"),
			checked: this.data.newAudioPlayer
		}), this.videoHandler?.isAudioContextSupported || (this.useNewAudioPlayerCheckbox.disabled = !0, this.useNewAudioPlayerTooltip = new Y({
			target: this.useNewAudioPlayerCheckbox.container,
			content: V.get("VOTNeedWebAudioAPI"),
			position: "bottom",
			backgroundColor: "var(--vot-helper-ondialog)",
			parentElement: this.globalPortal
		})), this.onlyBypassMediaCSPCheckbox = new $({
			labelHtml: this.videoHandler?.site.needBypassCSP ? `${V.get("VOTOnlyBypassMediaCSP")} (${V.get("VOTMediaCSPEnabledOnSite")})` : V.get("VOTOnlyBypassMediaCSP"),
			checked: this.data.onlyBypassMediaCSP,
			isSubCheckbox: !0
		}), this.videoHandler?.isAudioContextSupported || (this.onlyBypassMediaCSPTooltip = new Y({
			target: this.onlyBypassMediaCSPCheckbox.container,
			content: V.get("VOTNeedWebAudioAPI"),
			position: "bottom",
			backgroundColor: "var(--vot-helper-ondialog)",
			parentElement: this.globalPortal
		})), this.onlyBypassMediaCSPCheckbox.disabled = !this.data.newAudioPlayer && !!this.videoHandler?.isAudioContextSupported, this.data.newAudioPlayer || (this.onlyBypassMediaCSPCheckbox.hidden = !0), this.translationTextServiceLabel = new Op({
			labelText: V.get("VOTTranslationTextService"),
			icon: xp
		});
		let y = this.data.translationService ?? "yandexbrowser";
		this.translationTextServiceSelect = new Q({
			selectTitle: V.get(`services.${y}`),
			dialogTitle: V.get("VOTTranslationTextService"),
			dialogParent: this.globalPortal,
			labelElement: this.translationTextServiceLabel.container,
			items: ac.map((e) => ({
				label: V.get(`services.${e}`),
				value: e,
				selected: e === y
			}))
		}), this.translationTextServiceTooltip = new Y({
			target: this.translationTextServiceLabel.icon,
			content: V.get("VOTNotAffectToVoice"),
			position: "bottom",
			backgroundColor: "var(--vot-helper-ondialog)",
			parentElement: this.globalPortal
		}), this.detectServiceLabel = new Op({ labelText: V.get("VOTDetectService") });
		let re = this.data.detectService ?? "yandexbrowser";
		this.detectServiceSelect = new Q({
			selectTitle: V.get(`services.${re}`),
			dialogTitle: V.get("VOTDetectService"),
			dialogParent: this.globalPortal,
			labelElement: this.detectServiceLabel.container,
			items: uc.map((e) => ({
				label: V.get(`services.${e}`),
				value: e,
				selected: e === re
			}))
		}), this.showPiPButtonCheckbox = new $({
			labelHtml: V.get("VOTShowPiPButton"),
			checked: this.data.showPiPButton
		}), this.showPiPButtonCheckbox.hidden = !Ii();
		let ie = Math.round((this.data.autoHideButtonDelay ?? 1e3) / 1e3 * 10) / 10;
		this.autoHideButtonDelaySliderLabel = new Pp({
			labelText: V.get("autoHideButtonDelay"),
			labelEOL: ":",
			value: ie,
			symbol: ` ${V.get("secs")}`
		}), this.autoHideButtonDelaySlider = new Mp({
			labelHtml: this.autoHideButtonDelaySliderLabel.container,
			value: ie,
			min: .1,
			max: 3,
			step: .1
		}), this.buttonPositionSelectLabel = new Op({
			labelText: V.get("buttonPosition"),
			icon: xp
		});
		let ae = this.data.buttonPos ?? "default";
		this.buttonPositionSelect = new Q({
			selectTitle: V.get(`position.${ae}`),
			dialogTitle: V.get("buttonPosition"),
			labelElement: this.buttonPositionSelectLabel.container,
			dialogParent: this.globalPortal,
			items: zp.map((e) => ({
				label: V.get(`position.${e}`),
				value: e,
				selected: e === ae
			}))
		}), this.buttonPositionTooltip = new Y({
			target: this.buttonPositionSelectLabel.icon,
			content: V.get("minButtonPositionContainer"),
			position: "bottom",
			backgroundColor: "var(--vot-helper-ondialog)",
			parentElement: this.globalPortal
		}), this.menuLanguageSelectLabel = new Op({ labelText: V.get("VOTMenuLanguage") }), this.menuLanguageSelect = new Q({
			selectTitle: V.get(`langs.${V.langOverride}`),
			dialogTitle: V.get("VOTMenuLanguage"),
			labelElement: this.menuLanguageSelectLabel.container,
			dialogParent: this.globalPortal,
			items: Q.genLanguageItems(V.getAvailableLangs(), V.langOverride)
		}), this.bugReportButton = J.createOutlinedButton(V.get("VOTBugReport")), this.resetSettingsButton = J.createButton(V.get("resetSettings")), a.content.append(this.translateAPIErrorsCheckbox.container, this.useNewAudioPlayerCheckbox.container, this.onlyBypassMediaCSPCheckbox.container), t.content.append(this.translationTextServiceSelect.container, this.detectServiceSelect.container), o.content.append(this.showPiPButtonCheckbox.container, this.autoHideButtonDelaySlider.container, this.buttonPositionSelect.container, this.menuLanguageSelect.container);
		let oe = Wp(), se = J.createInformation(`${V.get("VOTVersion")}:`, oe.scriptVersion || GM_info.script.version || V.get("notFound")), ce = J.createInformation(`${V.get("VOTAuthors")}:`, GM_info.script.author || "Toil, SashaXser, MrSoczekXD, mynovelhost, sodapng"), b = J.createInformation(`${V.get("VOTLoader")}:`, oe.loader), x = J.createInformation(`${V.get("VOTBrowser")}:`, `${oe.browser} (${oe.os})`), le = (/* @__PURE__ */ new Date((this.data.localeUpdatedAt ?? 0) * 1e3)).toLocaleString(), ue = ml`${this.data.localeHash ?? V.get("notFound")}<br />(${V.get("VOTUpdatedAt")}
      ${le})`, de = J.createInformation(`${V.get("VOTLocaleHash")}:`, ue), S = J.createOutlinedButton(V.get("VOTUpdateLocaleFiles"));
		return S.addEventListener("click", async () => {
			await B.set("localeHash", ""), await V.update(!0), globalThis.location.reload();
		}), s.content.append(se.container, ce.container, b.container, x.container, de.container, S), this.dialog.footerContainer.append(this.bugReportButton, this.resetSettingsButton), this.initialized = !0, this;
	}
	initUIEvents() {
		if (!this.isInitialized()) throw Error("[VOT] SettingsView isn't initialized");
		return globalThis.addEventListener("message", this.onAuthRefreshMessage), this.accountButton.addEventListener("click", async () => {
			if (!B.isSupportOnlyLS) {
				if (this.accountButton.loggedIn) return await B.delete("account"), this.data.account = {}, this.updateAccountInfo();
				globalThis.open(ci, "_blank")?.focus();
			}
		}), this.accountButton.addEventListener("click:secret", async () => {
			let e = new kp({
				titleHtml: V.get("VOTLoginViaToken"),
				isTemp: !0
			});
			this.globalPortal.appendChild(e.container);
			let t = J.createEl("vot-block", void 0, V.get("VOTYandexTokenInfo")), n = new Ap({
				labelHtml: V.get("VOTYandexToken"),
				value: this.data.account?.token
			});
			n.addEventListener("change", async (e) => {
				this.data.account = e ? {
					expires: Date.now() + 3153418e4,
					token: e
				} : {}, await B.set("account", this.data.account), this.updateAccountInfo();
			}), e.bodyContainer.append(t, n.container), e.open();
		}), this.accountButton.addEventListener("refresh", async () => {
			await this.refreshAccountFromStorage();
		}), this.bindAccountStorageListener(), this.bindPersistedSetting({
			control: this.autoTranslateCheckbox,
			event: "change",
			apply: (e) => {
				this.data.autoTranslate = e;
			},
			storageKey: "autoTranslate",
			readPersistedValue: () => this.data.autoTranslate,
			logLabel: "autoTranslate",
			dispatch: (e) => this.events["change:autoTranslate"].dispatch(e)
		}), this.bindPersistedSetting({
			control: this.autoSubtitlesCheckbox,
			event: "change",
			apply: (e) => {
				this.data.autoSubtitles = e;
			},
			storageKey: "autoSubtitles",
			readPersistedValue: () => this.data.autoSubtitles,
			logLabel: "autoSubtitles",
			dispatch: (e) => this.events["change:autoSubtitles"].dispatch(e)
		}), this.dontTranslateLanguagesCheckbox.addEventListener("change", async (e) => {
			this.data.enabledDontTranslateLanguages = e, this.dontTranslateLanguagesSelect.disabled = !e, await B.set("enabledDontTranslateLanguages", this.data.enabledDontTranslateLanguages), L.log("enabledDontTranslateLanguages value changed. New value:", e);
		}), this.dontTranslateLanguagesSelect.addEventListener("selectItem", async (e) => {
			this.data.dontTranslateLanguages = e, await B.set("dontTranslateLanguages", this.data.dontTranslateLanguages), L.log("dontTranslateLanguages value changed. New value:", e);
		}), this.bindPersistedSetting({
			control: this.autoSetVolumeCheckbox,
			event: "change",
			apply: (e) => {
				this.data.enabledAutoVolume = e, this.autoSetVolumeSlider.disabled = !e, this.smartDuckingCheckbox.disabled = !e || !!this.syncVolumeCheckbox?.checked;
			},
			storageKey: "enabledAutoVolume",
			readPersistedValue: () => this.data.enabledAutoVolume,
			logLabel: "enabledAutoVolume",
			afterPersist: async () => this.videoHandler?.setupAudioSettings?.()
		}), this.bindPersistedSetting({
			control: this.smartDuckingCheckbox,
			event: "change",
			apply: (e) => {
				this.data.enabledSmartDucking = e;
			},
			storageKey: "enabledSmartDucking",
			readPersistedValue: () => this.data.enabledSmartDucking,
			logLabel: "enabledSmartDucking",
			afterPersist: async () => this.videoHandler?.setupAudioSettings?.()
		}), this.bindPersistedSetting({
			control: this.autoSetVolumeSlider,
			event: "input",
			apply: (e) => {
				this.data.autoVolume = this.autoSetVolumeSliderLabel.value = e;
			},
			storageKey: "autoVolume",
			readPersistedValue: () => this.data.autoVolume,
			logLabel: "autoVolume"
		}), this.bindPersistedSetting({
			control: this.showVideoVolumeSliderCheckbox,
			event: "change",
			apply: (e) => {
				this.data.showVideoSlider = e;
			},
			storageKey: "showVideoSlider",
			readPersistedValue: () => this.data.showVideoSlider,
			logLabel: "showVideoVolumeSlider",
			dispatch: (e) => this.events["change:showVideoVolume"].dispatch(e)
		}), this.bindPersistedSetting({
			control: this.audioBoosterCheckbox,
			event: "change",
			apply: (e) => {
				this.data.audioBooster = e;
			},
			storageKey: "audioBooster",
			readPersistedValue: () => this.data.audioBooster,
			logLabel: "audioBooster",
			dispatch: (e) => this.events["change:audioBooster"].dispatch(e)
		}), this.bindPersistedSetting({
			control: this.syncVolumeCheckbox,
			event: "change",
			apply: (e) => {
				this.data.syncVolume = e, this.autoSetVolumeSlider.disabled = !this.autoSetVolumeCheckbox?.checked, this.smartDuckingCheckbox.disabled = e || !this.autoSetVolumeCheckbox?.checked, e && this.smartDuckingCheckbox?.checked && (this.smartDuckingCheckbox.checked = !1);
			},
			storageKey: "syncVolume",
			readPersistedValue: () => this.data.syncVolume,
			logLabel: "syncVolume",
			dispatch: (e) => this.events["change:syncVolume"].dispatch(e)
		}), this.bindPersistedSetting({
			control: this.downloadWithNameCheckbox,
			event: "change",
			apply: (e) => {
				this.data.downloadWithName = e;
			},
			storageKey: "downloadWithName",
			readPersistedValue: () => this.data.downloadWithName,
			logLabel: "downloadWithName"
		}), this.bindPersistedSetting({
			control: this.sendNotifyOnCompleteCheckbox,
			event: "change",
			apply: (e) => {
				this.data.sendNotifyOnComplete = e;
			},
			storageKey: "sendNotifyOnComplete",
			readPersistedValue: () => this.data.sendNotifyOnComplete,
			logLabel: "sendNotifyOnComplete"
		}), this.bindPersistedSetting({
			control: this.useLivelyVoiceCheckbox,
			event: "change",
			apply: (e) => {
				this.data.useLivelyVoice = e;
			},
			storageKey: "useLivelyVoice",
			readPersistedValue: () => this.data.useLivelyVoice,
			logLabel: "useLivelyVoice",
			dispatch: (e) => this.events["change:useLivelyVoice"].dispatch(e)
		}), this.bindPersistedSetting({
			control: this.useAudioDownloadCheckbox,
			event: "change",
			apply: (e) => {
				this.data.useAudioDownload = e;
			},
			storageKey: "useAudioDownload",
			readPersistedValue: () => this.data.useAudioDownload,
			logLabel: "useAudioDownload"
		}), this.bindPersistedSetting({
			control: this.responseLanguageSubtitlesSelect,
			event: "selectItem",
			apply: (e) => {
				this.data.responseLanguageSubtitles = e, this.responseLanguageSubtitlesSelect?.updateItems(am(e)), this.responseLanguageSubtitlesSelect && (this.responseLanguageSubtitlesSelect.selectTitle = im(e));
			},
			storageKey: "responseLanguageSubtitles",
			readPersistedValue: () => this.data.responseLanguageSubtitles,
			logLabel: "responseLanguageSubtitles",
			dispatch: (e) => this.events["select:responseLanguageSubtitles"].dispatch(e)
		}), this.bindPersistedSetting({
			control: this.subtitlesDownloadFormatSelect,
			event: "selectItem",
			apply: (e) => {
				this.data.subtitlesDownloadFormat = e;
			},
			storageKey: "subtitlesDownloadFormat",
			readPersistedValue: () => this.data.subtitlesDownloadFormat,
			logLabel: "subtitlesDownloadFormat"
		}), this.bindPersistedSetting({
			control: this.subtitlesHighlightWordsCheckbox,
			event: "change",
			apply: (e) => {
				this.data.highlightWords = e;
			},
			storageKey: "highlightWords",
			readPersistedValue: () => this.data.highlightWords,
			logLabel: "highlightWords",
			dispatch: (e) => this.events["change:subtitlesHighlightWords"].dispatch(e)
		}), this.subtitlesSmartLayoutCheckbox?.addEventListener("change", (e) => {
			this.suppressSubtitlesSmartLayoutCheckboxChange || this.setSubtitlesSmartLayout(e);
		}), this.subtitlesMaxLengthSlider.addEventListener("input", (e) => {
			this.subtitlesMaxLengthSliderLabel.value = e, (this.data.subtitlesSmartLayout ?? !0) === !0 && this.setSubtitlesSmartLayout(!1), this.data.subtitlesMaxLength = e, this.scheduleStoragePersist("subtitlesMaxLength", this.data.subtitlesMaxLength), L.log("subtitlesMaxLength value changed. New value:", e), this.events["input:subtitlesMaxLength"].dispatch(e);
		}), this.subtitlesFontSizeSlider.addEventListener("input", (e) => {
			this.subtitlesFontSizeSliderLabel.value = e, (this.data.subtitlesSmartLayout ?? !0) === !0 && this.setSubtitlesSmartLayout(!1), this.data.subtitlesFontSize = e, this.scheduleStoragePersist("subtitlesFontSize", this.data.subtitlesFontSize), L.log("subtitlesFontSize value changed. New value:", e), this.events["input:subtitlesFontSize"].dispatch(e);
		}), this.subtitlesBackgroundOpacitySlider.addEventListener("input", (e) => {
			this.subtitlesBackgroundOpacitySliderLabel.value = e, this.data.subtitlesOpacity = e, this.scheduleStoragePersist("subtitlesOpacity", this.data.subtitlesOpacity), L.log("subtitlesOpacity value changed. New value:", e), this.events["input:subtitlesBackgroundOpacity"].dispatch(e);
		}), this.bindPersistedSetting({
			control: this.subtitlesFontFamilySelect,
			event: "selectItem",
			apply: (e) => {
				this.data.subtitlesFontFamily = e;
			},
			storageKey: "subtitlesFontFamily",
			readPersistedValue: () => this.data.subtitlesFontFamily,
			logLabel: "subtitlesFontFamily",
			dispatch: (e) => this.events["select:subtitlesFontFamily"].dispatch(e)
		}), this.bindPersistedSetting({
			control: this.translateHotkeyButton,
			event: "change",
			apply: (e) => {
				this.data.translationHotkey = e;
			},
			storageKey: "translationHotkey",
			readPersistedValue: () => this.data.translationHotkey,
			logLabel: "translationHotkey"
		}), this.bindPersistedSetting({
			control: this.subtitlesHotkeyButton,
			event: "change",
			apply: (e) => {
				this.data.subtitlesHotkey = e;
			},
			storageKey: "subtitlesHotkey",
			readPersistedValue: () => this.data.subtitlesHotkey,
			logLabel: "subtitlesHotkey"
		}), this.proxyWorkerHostTextfield.addEventListener("change", async (e) => {
			this.data.proxyWorkerHost = e || "vot-worker.kload.workers.dev", await B.set("proxyWorkerHost", this.data.proxyWorkerHost), L.log("proxyWorkerHost value changed. New value:", this.data.proxyWorkerHost), this.events["change:proxyWorkerHost"].dispatch(e);
		}), this.proxyTranslationStatusSelect.addEventListener("selectItem", async (e) => {
			this.data.translateProxyEnabled = Number.parseInt(e, 10), await B.set("translateProxyEnabled", this.data.translateProxyEnabled), await B.set("translateProxyEnabledDefault", !1), L.log("translateProxyEnabled value changed. New value:", this.data.translateProxyEnabled), this.events["select:proxyTranslationStatus"].dispatch(e);
		}), this.bindPersistedSetting({
			control: this.translateAPIErrorsCheckbox,
			event: "change",
			apply: (e) => {
				this.data.translateAPIErrors = e;
			},
			storageKey: "translateAPIErrors",
			readPersistedValue: () => this.data.translateAPIErrors,
			logLabel: "translateAPIErrors"
		}), this.bindPersistedSetting({
			control: this.useNewAudioPlayerCheckbox,
			event: "change",
			apply: (e) => {
				this.data.newAudioPlayer = e, this.onlyBypassMediaCSPCheckbox.disabled = this.onlyBypassMediaCSPCheckbox.hidden = !e;
			},
			storageKey: "newAudioPlayer",
			readPersistedValue: () => this.data.newAudioPlayer,
			logLabel: "newAudioPlayer",
			dispatch: (e) => this.events["change:useNewAudioPlayer"].dispatch(e)
		}), this.bindPersistedSetting({
			control: this.onlyBypassMediaCSPCheckbox,
			event: "change",
			apply: (e) => {
				this.data.onlyBypassMediaCSP = e;
			},
			storageKey: "onlyBypassMediaCSP",
			readPersistedValue: () => this.data.onlyBypassMediaCSP,
			logLabel: "onlyBypassMediaCSP",
			dispatch: (e) => this.events["change:onlyBypassMediaCSP"].dispatch(e)
		}), this.bindPersistedSetting({
			control: this.translationTextServiceSelect,
			event: "selectItem",
			apply: (e) => {
				this.data.translationService = e;
			},
			storageKey: "translationService",
			readPersistedValue: () => this.data.translationService,
			logLabel: "translationService",
			dispatch: (e) => this.events["select:translationTextService"].dispatch(e)
		}), this.bindPersistedSetting({
			control: this.detectServiceSelect,
			event: "selectItem",
			apply: (e) => {
				this.data.detectService = e;
			},
			storageKey: "detectService",
			readPersistedValue: () => this.data.detectService,
			logLabel: "detectService"
		}), this.bindPersistedSetting({
			control: this.showPiPButtonCheckbox,
			event: "change",
			apply: (e) => {
				this.data.showPiPButton = e;
			},
			storageKey: "showPiPButton",
			readPersistedValue: () => this.data.showPiPButton,
			logLabel: "showPiPButton",
			dispatch: (e) => this.events["change:showPiPButton"].dispatch(e)
		}), this.autoHideButtonDelaySlider.addEventListener("input", (e) => {
			this.autoHideButtonDelaySliderLabel.value = e;
			let t = Math.round(e * 1e3);
			L.log("autoHideButtonDelay value changed. New value:", t), this.data.autoHideButtonDelay = t, this.scheduleStoragePersist("autoHideButtonDelay", this.data.autoHideButtonDelay), this.events["input:autoHideButtonDelay"].dispatch(e);
		}), this.bindPersistedSetting({
			control: this.buttonPositionSelect,
			event: "selectItem",
			apply: (e) => {
				this.data.buttonPos = e;
			},
			storageKey: "buttonPos",
			readPersistedValue: () => this.data.buttonPos,
			logLabel: "buttonPos",
			dispatch: (e) => this.events["select:buttonPosition"].dispatch(e)
		}), this.menuLanguageSelect.addEventListener("selectItem", async (e) => {
			await V.changeLang(e) && (this.data.localeUpdatedAt = await B.get("localeUpdatedAt", 0), this.events["select:menuLanguage"].dispatch(e));
		}), this.bugReportButton.addEventListener("click", () => this.events["click:bugReport"].dispatch()), this.resetSettingsButton.addEventListener("click", () => this.events["click:resetSettings"].dispatch()), this;
	}
	addEventListener(e, t) {
		return this.events[e].addListener(t), this;
	}
	removeEventListener(e, t) {
		return this.events[e].removeListener(t), this;
	}
	doReleaseUI() {
		this.dialog?.remove();
		for (let e of [
			this.accountButtonRefreshTooltip,
			this.accountButtonTokenTooltip,
			this.audioBoosterTooltip,
			this.useLivelyVoiceTooltip,
			this.useAudioDownloadCheckboxTooltip,
			this.useNewAudioPlayerTooltip,
			this.onlyBypassMediaCSPTooltip,
			this.translationTextServiceTooltip,
			this.proxyTranslationStatusSelectTooltip,
			this.buttonPositionTooltip
		]) e?.release();
	}
	doReleaseUIEvents() {
		this.accountStorageListenerCleanup?.(), this.accountStorageListenerCleanup = void 0, globalThis.removeEventListener("message", this.onAuthRefreshMessage), this.flushStoragePersists();
		for (let e of Object.values(this.events)) e.clear();
	}
	release() {
		return this.isInitialized() ? (this.doReleaseUIEvents(), this.doReleaseUI(), this.initialized = !1, this) : this;
	}
	updateAccountInfo() {
		if (!this.isInitialized()) throw Error("[VOT] SettingsView isn't initialized");
		let e = !!this.data.account?.token;
		return this.accountButton.avatarId = this.data.account?.avatarId, this.useLivelyVoiceTooltip.hidden = this.accountButton.loggedIn = e, this.accountButton.username = this.data.account?.username, this.useLivelyVoiceCheckbox.disabled = !e, this.events["update:account"].dispatch(this.data.account), this;
	}
	open() {
		if (!this.isInitialized()) throw Error("[VOT] SettingsView isn't initialized");
		return this.dialog.open();
	}
	close() {
		if (!this.isInitialized()) throw Error("[VOT] SettingsView isn't initialized");
		return this.dialog.close();
	}
}, sm = class {
	mount;
	initialized = !1;
	videoHandler;
	intervalIdleChecker;
	data;
	votGlobalPortal;
	votOverlayView;
	votSettingsView;
	constructor({ mount: e, data: t = {}, videoHandler: n, intervalIdleChecker: r }) {
		this.mount = e, this.videoHandler = n, this.data = t, this.intervalIdleChecker = r;
	}
	get root() {
		return this.mount.root;
	}
	get portalContainer() {
		return this.mount.portalContainer;
	}
	get tooltipLayoutRoot() {
		return this.mount.tooltipLayoutRoot;
	}
	isInitialized() {
		return this.initialized;
	}
	initUI() {
		if (this.isInitialized()) throw Error("[VOT] UIManager is already initialized");
		return this.initialized = !0, this.votGlobalPortal = J.createPortal(), this.getGlobalPortalHost(this.mount).appendChild(this.votGlobalPortal), this.votOverlayView = new Lp({
			mount: this.mount,
			globalPortal: this.votGlobalPortal,
			data: this.data,
			videoHandler: this.videoHandler,
			intervalIdleChecker: this.intervalIdleChecker
		}), this.votOverlayView.initUI(this.data.buttonPos ?? "default"), this.votSettingsView = new om({
			globalPortal: this.votGlobalPortal,
			data: this.data,
			videoHandler: this.videoHandler
		}), this.votSettingsView.initUI(), this;
	}
	updateMount(e) {
		let t = this.getGlobalPortalHost(e);
		return this.votGlobalPortal?.parentElement !== t && t.appendChild(this.votGlobalPortal), this.mount = ap(this.mount, e, (e) => {
			this.votOverlayView?.updateMount(e);
		}), this.videoHandler?.subtitlesWidget?.updateMount({
			container: e.subtitlesMountContainer,
			tooltipLayoutRoot: e.tooltipLayoutRoot
		}), this;
	}
	getGlobalPortalHost(e) {
		let t = document;
		return Co(t.fullscreenElement ?? t.webkitFullscreenElement, [e.root], { allowDocumentViewport: !0 }) ? e.root : document.documentElement;
	}
	initUIEvents() {
		if (!this.isInitialized()) throw Error("[VOT] UIManager isn't initialized");
		this.votOverlayView.initUIEvents(), this.bindOverlayViewEvents(), this.votSettingsView.initUIEvents(), this.bindSettingsViewEvents();
	}
	bindOverlayViewEvents() {
		let e = this.votOverlayView;
		e && e.addEventListener("click:translate", async () => {
			await this.handleTranslationBtnClick();
		}).addEventListener("click:pip", async () => {
			if (this.videoHandler) try {
				await (this.videoHandler.video === document.pictureInPictureElement ? document.exitPictureInPicture() : this.videoHandler.video.requestPictureInPicture());
			} catch (e) {
				L.warn("[VOT] Failed to toggle Picture-in-Picture", e);
			}
		}).addEventListener("click:settings", async () => {
			this.videoHandler?.subtitlesWidget?.releaseTooltip(), this.videoHandler?.overlayVisibility?.cancel(), this.videoHandler?.overlayVisibility?.show(), this.votSettingsView.open();
		}).addEventListener("click:downloadTranslation", async () => {
			await this.handleDownloadTranslationClick();
		}).addEventListener("click:downloadSubtitles", async () => {
			await this.handleDownloadSubtitlesClick();
		}).addEventListener("input:videoVolume", (e) => {
			if (!this.videoHandler) return;
			let t = e / 100;
			if (this.videoHandler.setVideoVolume(t), this.videoHandler.applyManualVideoVolumeOverride(t), !this.data.syncVolume) {
				this.videoHandler.onVideoVolumeSliderSynced(e);
				return;
			}
			this.videoHandler.syncVolumeWrapper("video", e);
		}).addEventListener("input:translationVolume", (e) => {
			if (!this.videoHandler) return;
			let t = e ?? this.data.defaultVolume ?? 100;
			if (this.videoHandler.audioPlayer.player.volume = t / 100, !this.data.syncVolume) {
				this.videoHandler.onTranslationVolumeSliderSynced(t);
				return;
			}
			this.videoHandler.syncVolumeWrapper("translation", t);
		}).addEventListener("select:subtitles", (e) => {
			this.videoHandler && this.runDetached(this.videoHandler.changeSubtitlesLang(e), "Failed to change subtitles language");
		});
	}
	bindSettingsViewEvents() {
		let e = this.votSettingsView;
		e && e.addEventListener("update:account", async (e) => {
			this.videoHandler && (this.videoHandler.votClient.apiToken = e?.token);
		}).addEventListener("change:autoTranslate", async (e) => {
			let t = this.videoHandler;
			e && t && !t.hasActiveSource() && await this.handleTranslationBtnClick();
		}).addEventListener("change:autoSubtitles", async (e) => {
			!e || !this.videoHandler?.videoData?.videoId || await this.videoHandler.enableSubtitlesForCurrentLangPair();
		}).addEventListener("select:responseLanguageSubtitles", async () => {
			!this.videoHandler?.data.autoSubtitles || !this.videoHandler.videoData || await this.videoHandler.enableSubtitlesForCurrentLangPair();
		}).addEventListener("change:showVideoVolume", () => {
			this.withInitializedOverlayView((e) => {
				!e.videoVolumeSlider || !e.votButton || (e.videoVolumeSlider.container.hidden = !this.data.showVideoSlider || e.votButton.status !== "success");
			});
		}).addEventListener("change:audioBooster", async () => {
			this.withInitializedOverlayView((e) => {
				if (!e.translationVolumeSlider) return;
				let t = e.translationVolumeSlider.value, n = this.data.audioBooster && !this.data.syncVolume ? 900 : 100;
				e.translationVolumeSlider.max = n;
				let r = R(t, 0, n);
				e.translationVolumeSlider.value = r, this.videoHandler?.onTranslationVolumeSliderSynced(r);
			});
		}).addEventListener("change:syncVolume", (e) => {
			this.videoHandler && (this.videoHandler.setupAudioSettings(), this.withInitializedOverlayView((t) => {
				let n = t.videoVolumeSlider, r = t.translationVolumeSlider;
				if (!n || !r) return;
				let i = this.data.audioBooster && !e ? 900 : 100;
				r.max = i;
				let a = R(r.value, 0, i);
				r.value = a, this.videoHandler.onTranslationVolumeSliderSynced(a), e && this.videoHandler.resetVolumeLinkState(Number(n.value), a);
			}));
		}).addEventListener("change:useLivelyVoice", () => {
			this.videoHandler && this.runDetached(this.videoHandler.stopTranslate(), "Failed to stop translation after voice mode change");
		}).addEventListener("change:subtitlesHighlightWords", (e) => {
			this.updateSubtitlesWidgetSetting(e, this.data.highlightWords, (e, t) => {
				e.setHighlightWords(t);
			});
		}).addEventListener("change:subtitlesSmartLayout", (e) => {
			this.updateSubtitlesWidgetSetting(e, this.data.subtitlesSmartLayout, (e, t) => {
				e.setSmartLayout(t);
			});
		}).addEventListener("input:subtitlesMaxLength", (e) => {
			this.updateSubtitlesWidgetSetting(e, this.data.subtitlesMaxLength, (e, t) => {
				e.setMaxLength(t);
			});
		}).addEventListener("input:subtitlesFontSize", (e) => {
			this.updateSubtitlesWidgetSetting(e, this.data.subtitlesFontSize, (e, t) => {
				e.setFontSize(t);
			});
		}).addEventListener("select:subtitlesFontFamily", (e) => {
			this.updateSubtitlesWidgetSetting(e, this.data.subtitlesFontFamily, (e, t) => {
				e.setFontFamily(t);
			});
		}).addEventListener("input:subtitlesBackgroundOpacity", (e) => {
			this.updateSubtitlesWidgetSetting(e, this.data.subtitlesOpacity, (e, t) => {
				e.setOpacity(t);
			});
		}).addEventListener("change:proxyWorkerHost", (e) => {
			this.videoHandler && this.runDetached(this.videoHandler.handleProxySettingsChanged("proxyWorkerHost"), "Failed to apply proxyWorkerHost change");
		}).addEventListener("select:proxyTranslationStatus", () => {
			this.videoHandler && this.runDetached(this.videoHandler.handleProxySettingsChanged("proxyTranslationStatus"), "Failed to apply proxyTranslationStatus change");
		}).addEventListener("change:useNewAudioPlayer", () => {
			this.restartAudioPlayer();
		}).addEventListener("change:onlyBypassMediaCSP", () => {
			this.restartAudioPlayer();
		}).addEventListener("select:translationTextService", () => {
			this.withSubtitlesWidget((e) => {
				e.resetTranslationContext(!0);
			});
		}).addEventListener("change:showPiPButton", () => {
			this.withInitializedOverlayView((e) => {
				e.votButton && (e.votButton.pipButton.hidden = e.votButton.separator2.hidden = !e.pipButtonVisible);
			});
		}).addEventListener("select:buttonPosition", (e) => {
			this.withInitializedOverlayView((t) => {
				let n = this.data.buttonPos ?? e, { position: r, direction: i } = t.calcButtonLayout(n);
				t.updateButtonLayout(r, i);
			});
		}).addEventListener("select:menuLanguage", async () => {
			await this.reloadMenu();
		}).addEventListener("click:bugReport", () => {
			if (!this.videoHandler) return;
			let e = new URLSearchParams(this.videoHandler.collectReportInfo()).toString();
			globalThis.open(`${fi}/issues/new?${e}`, "_blank")?.focus();
		}).addEventListener("click:resetSettings", async () => {
			let e = await B.list();
			await Promise.all(e.map((e) => B.delete(e))), await B.set("compatVersion", _i), globalThis.location.reload();
		});
	}
	async handleDownloadTranslationClick() {
		let e = this.votOverlayView, t = this.videoHandler;
		if (!e?.isInitialized() || !t?.downloadTranslationUrl || !t.videoData) return;
		let n = e.downloadTranslationButton, r = t.downloadTranslationUrl, i = this.data.downloadWithName ? Hi(t.videoData.downloadTitle) : `translation_${t.videoData.videoId}`, a = { preferShare: this.isLikelyMobileDownloadContext() }, o = (e) => {
			n && (n.progress = e);
		};
		o(0);
		try {
			await this.downloadTranslationAudio(r, i, o, a);
		} catch (e) {
			console.error("[VOT] Download translation failed:", e), this.triggerUrlDownload(r, `${i}.mp3`) || globalThis.open(r, "_blank")?.focus();
		} finally {
			o(0);
		}
	}
	async downloadTranslationAudio(e, t, n, r) {
		let i = await z(e, { timeout: 0 });
		if (!i.ok) throw Error(`HTTP ${i.status}`);
		await np(i, t, n, r);
	}
	async handleDownloadSubtitlesClick() {
		let e = this.videoHandler;
		if (!e?.yandexSubtitles || !e.videoData) return;
		let t = this.data.subtitlesDownloadFormat ?? "json", n = Yf(e.yandexSubtitles, t, { assTitle: e.videoData.localizedTitle ?? e.videoData.title ?? e.videoData.downloadTitle });
		await Bi(new Blob([t === "json" ? JSON.stringify(n) : n], { type: "text/plain" }), `${this.data.downloadWithName ? Hi(e.videoData.downloadTitle) : `subtitles_${e.videoData.videoId}`}.${t}`, { preferShare: this.isLikelyMobileDownloadContext() });
	}
	async reloadMenu() {
		if (!this.votOverlayView?.isInitialized()) throw Error("[VOT] OverlayView isn't initialized");
		let e = this.votOverlayView.votButton.opacity, t = this.votOverlayView.votButton.container.hidden, n = this.votOverlayView.votMenu.hidden, r = this.data.buttonPos ?? "default", i = this.votSettingsView?.dialog?.container?.hidden === !1;
		if (await this.videoHandler?.stopTranslation(), this.release(), this.initUI(), this.initUIEvents(), !this.videoHandler) return this;
		try {
			let { position: i, direction: a } = this.votOverlayView.calcButtonLayout(r);
			this.votOverlayView.updateButtonLayout(i, a), this.votOverlayView.votMenu.hidden = n, this.votOverlayView.votButton.container.hidden = t, this.votOverlayView.votButton.opacity = e;
		} catch (e) {
			L.warn("[VOT] Failed to restore overlay state after menu reload", e);
		}
		try {
			this.videoHandler.rebindOverlayVisibilityTargets();
		} catch (e) {
			L.warn("[VOT] Failed to rebind overlay visibility targets", e);
		}
		if (i) try {
			this.votSettingsView?.open();
		} catch (e) {
			L.warn("[VOT] Failed to reopen settings after menu reload", e);
		}
		await this.videoHandler.updateSubtitlesLangSelect();
		let a = this.videoHandler.subtitlesWidget;
		return a && a.resetTranslationContext(!0), this;
	}
	async handleTranslationBtnClick() {
		if (!this.votOverlayView?.isInitialized()) throw Error("[VOT] OverlayView isn't initialized");
		return await up({
			videoHandler: this.videoHandler,
			currentStatus: this.votOverlayView.votButton.status,
			currentLoading: this.votOverlayView.votButton.loading,
			transformBtn: (e, t) => {
				this.transformBtn(e, t);
			}
		}), this;
	}
	isLoadingText(e) {
		let t = V.get("TranslationDelayed");
		return typeof e == "string" && (e.includes(V.get("translationTake")) || (t ? e.includes(t) : !1));
	}
	transformBtn(e, t) {
		if (!this.votOverlayView?.isInitialized()) throw Error("[VOT] OverlayView isn't initialized");
		return this.votOverlayView.votButton.status = e, this.votOverlayView.votButton.loading = e === "error" && this.isLoadingText(t), this.votOverlayView.votButton.setText(t), this.votOverlayView.votButtonTooltip.setContent(t), this;
	}
	release() {
		return this.isInitialized() ? (this.votOverlayView.release(), this.votSettingsView.release(), this.votGlobalPortal.remove(), this.initialized = !1, this) : this;
	}
	withInitializedOverlayView(e) {
		this.votOverlayView?.isInitialized() && e(this.votOverlayView);
	}
	withSubtitlesWidget(e) {
		let t = this.videoHandler?.subtitlesWidget;
		t && e(t);
	}
	updateSubtitlesWidgetSetting(e, t, n) {
		this.withSubtitlesWidget((r) => {
			n(r, t ?? e);
		});
	}
	runDetached(e, t) {
		e.catch((e) => {
			L.warn(`[VOT] ${t}`, e);
		});
	}
	triggerUrlDownload(e, t) {
		try {
			let n = document.createElement("a");
			return n.href = e, n.download = t, n.target = "_blank", n.rel = "noopener noreferrer", n.style.display = "none", document.body.appendChild(n), n.click(), n.remove(), !0;
		} catch {
			return !1;
		}
	}
	isLikelyMobileDownloadContext() {
		return this.videoHandler?.site.additionalData === "mobile" ? !0 : typeof matchMedia == "function" && matchMedia("(pointer: coarse)").matches;
	}
	restartAudioPlayer() {
		this.restartAudioPlayerSafely();
	}
	async restartAudioPlayerSafely() {
		let e = this.videoHandler;
		if (e) try {
			await e.stopTranslate(), e.createPlayer();
		} catch (e) {
			L.warn("[VOT] Failed to restart audio player", e);
		}
	}
}, cm = class {
	deps;
	hideDeadlineMs = 0;
	hideArmed = !1;
	unsubscribeChecker;
	constructor(e) {
		this.deps = e, this.unsubscribeChecker = this.deps.checker.subscribe(() => {
			this.onCheckerTick();
		});
	}
	show() {
		let e = this.getView();
		return e ? (e.updateButtonOpacity(1), e) : null;
	}
	cancel() {
		this.hideDeadlineMs = 0, this.hideArmed = !1;
	}
	release() {
		this.cancel(), this.unsubscribeChecker();
	}
	queueAutoHide() {
		if (!this.show()) return;
		let e = this.deps.getAutoHideDelay();
		this.hideDeadlineMs = this.nowMs() + Math.max(0, e), this.hideArmed = !0, this.deps.checker.markActivity("overlay-queue-hide"), this.deps.checker.requestImmediateTick();
	}
	handleOverlayInteraction(e) {
		let t = e?.type;
		if (t) {
			if (t === "focusin") {
				this.handleFocusIn();
				return;
			}
			if (t.startsWith("pointer")) {
				this.cancel(), this.show(), this.deps.checker.markActivity("overlay-interaction"), e.stopPropagation?.();
				return;
			}
			this.handleHostInteraction(e);
		}
	}
	handleHostInteraction(e) {
		let t = e?.type;
		if (t) {
			if (t === "focusin") {
				this.handleFocusIn();
				return;
			}
			if (t.startsWith("pointer")) {
				let t = e.target;
				this.deps.isInteractiveNode(t) && e.stopPropagation?.(), this.deps.checker.markActivity("overlay-host-pointer");
			}
			this.queueAutoHide();
		}
	}
	scheduleHide(e) {
		if (!this.getView()) return;
		let t = e?.currentTarget, n = e?.relatedTarget ?? null;
		!n && typeof e?.composedPath == "function" && (n = e.composedPath()[1] ?? null);
		let r = n instanceof Node ? n : null, i = t instanceof Node ? t : null;
		r && (i?.contains(r) || this.deps.isInteractiveNode(r)) || this.queueAutoHide();
	}
	onCheckerTick() {
		if (!this.hideArmed || this.hideDeadlineMs <= 0 || this.nowMs() + 2 < this.hideDeadlineMs) return;
		this.hideArmed = !1;
		let e = null;
		if (typeof document < "u" && typeof document.hasFocus == "function" && document.hasFocus() && (e = document.activeElement), e && this.deps.isInteractiveNode(e)) {
			L.log("[OverlayVisibility] skip hide (focus inside overlay)");
			return;
		}
		this.getView()?.updateButtonOpacity(0);
	}
	handleFocusIn() {
		this.cancel(), this.show(), this.deps.checker.markActivity("overlay-focus-in");
	}
	getView() {
		let e = this.deps.getOverlayView();
		return e?.isInitialized() ? e : null;
	}
	nowMs() {
		return this.deps.nowMs ? this.deps.nowMs() : typeof performance < "u" && typeof performance.now == "function" ? performance.now() : Date.now();
	}
}, lm = {
	checkIntervalMs: 250,
	idleAfterMs: 180
};
function um(e, t) {
	return typeof e != "number" || !Number.isFinite(e) ? t : Math.max(1, Math.trunc(e));
}
function dm(e, t) {
	return typeof e != "number" || !Number.isFinite(e) ? t : Math.max(0, Math.trunc(e));
}
function fm(e = {}) {
	return {
		checkIntervalMs: um(e.checkIntervalMs, lm.checkIntervalMs),
		idleAfterMs: dm(e.idleAfterMs, lm.idleAfterMs)
	};
}
function pm() {
	return {
		nowMs: () => typeof performance < "u" && typeof performance.now == "function" ? performance.now() : Date.now(),
		setInterval: globalThis.setInterval.bind(globalThis),
		clearInterval: globalThis.clearInterval.bind(globalThis),
		queueMicrotask: (e) => {
			if (typeof globalThis.queueMicrotask == "function") {
				globalThis.queueMicrotask(e);
				return;
			}
			Promise.resolve().then(e);
		},
		onVisibilityChange: (e) => typeof document > "u" || typeof document.addEventListener != "function" ? () => void 0 : (document.addEventListener("visibilitychange", e), () => {
			typeof document.removeEventListener == "function" && document.removeEventListener("visibilitychange", e);
		})
	};
}
var mm = class {
	profile;
	runtime;
	subscribers = /* @__PURE__ */ new Set();
	intervalId = null;
	unsubscribeVisibilityChange = null;
	running = !1;
	destroyed = !1;
	immediateQueued = !1;
	currentMode = "active";
	lastActivityAt;
	onVisibilityChangeHandler = () => {
		this.destroyed || !this.running || (Up() ? this.clearIntervalTimer() : this.armInterval(), this.requestImmediateTick());
	};
	constructor(e = {}) {
		this.profile = fm(e.profile), this.runtime = {
			...pm(),
			...e.runtime
		}, this.lastActivityAt = this.runtime.nowMs();
	}
	start() {
		this.destroyed || this.running || (this.running = !0, this.lastActivityAt = this.runtime.nowMs(), this.subscribeVisibilityChange(), this.armInterval(), this.runTick("start"));
	}
	stop() {
		this.running && (this.running = !1, this.clearIntervalTimer(), this.immediateQueued = !1, this.unsubscribeFromVisibilityChange());
	}
	destroy() {
		this.destroyed ||= (this.stop(), this.subscribers.clear(), !0);
	}
	subscribe(e) {
		return this.destroyed ? () => void 0 : (this.subscribers.add(e), () => {
			this.subscribers.delete(e);
		});
	}
	markActivity(e) {
		if (this.destroyed || (this.lastActivityAt = this.runtime.nowMs(), !this.running)) return;
		let t = this.resolveMode(this.lastActivityAt);
		t !== this.currentMode && (this.currentMode = t);
	}
	requestImmediateTick() {
		this.destroyed || !this.running || this.immediateQueued || (this.immediateQueued = !0, this.runtime.queueMicrotask(() => {
			this.immediateQueued = !1, !(this.destroyed || !this.running) && this.runTick("immediate");
		}));
	}
	resolveMode(e) {
		return Up() ? "hidden" : e - this.lastActivityAt >= this.profile.idleAfterMs ? "idle" : "active";
	}
	clearIntervalTimer() {
		this.intervalId !== null && (this.runtime.clearInterval(this.intervalId), this.intervalId = null);
	}
	armInterval() {
		this.intervalId === null && (this.intervalId = this.runtime.setInterval(() => {
			this.runTick("interval");
		}, this.profile.checkIntervalMs));
	}
	runTick(e) {
		if (this.destroyed || !this.running || this.subscribers.size === 0) return;
		let t = this.runtime.nowMs(), n = this.resolveMode(t);
		n !== this.currentMode && (this.currentMode = n);
		let r = {
			nowMs: t,
			mode: n,
			source: e
		};
		for (let e of this.subscribers) try {
			e(r);
		} catch {}
	}
	subscribeVisibilityChange() {
		this.unsubscribeVisibilityChange === null && (this.unsubscribeVisibilityChange = this.runtime.onVisibilityChange(this.onVisibilityChangeHandler));
	}
	unsubscribeFromVisibilityChange() {
		this.unsubscribeVisibilityChange !== null && (this.unsubscribeVisibilityChange(), this.unsubscribeVisibilityChange = null);
	}
};
function hm(e) {
	return new mm({ profile: e });
}
//#endregion
//#region src/utils/notify.ts
var gm = () => Date.now();
function _m() {
	return GM_info?.script?.name || "VOT";
}
function vm(e, t) {
	try {
		return V?.get?.(e) || t;
	} catch {
		return t;
	}
}
function ym(e, t, n) {
	if (!n) return !0;
	let r = e.get(t) ?? 0;
	return gm() - r >= n;
}
function bm(e, t) {
	e.set(t, gm());
}
function xm(e) {
	let t = e.trim();
	if (!t) return null;
	try {
		let e = V.get(t), n = V.getDefault(t);
		return e !== t || n !== t ? e || n || t : null;
	} catch {
		return null;
	}
}
function Sm(e) {
	if (!e || typeof e != "object") return null;
	let t = e;
	return t.name === "VOTLocalizedError" ? typeof t.localizedMessage == "string" && t.localizedMessage.trim() ? t.localizedMessage : typeof t.unlocalizedMessage == "string" ? xm(t.unlocalizedMessage) : null : null;
}
function Cm(e) {
	let t = fa(e);
	return t ? xm(t) || t : null;
}
function wm(e) {
	let t = Sm(e);
	if (t) return t;
	if (typeof e == "string") {
		let t = xm(e);
		if (t) return t;
	}
	return Cm(e) || vm("requestTranslationFailed", "Translation failed");
}
function Tm(e) {
	try {
		if (typeof GM_notification == "function") return GM_notification(e), !0;
		let t = globalThis.GM;
		if (t !== void 0 && typeof t.notification == "function") {
			let n = {
				text: e.text,
				title: e.title,
				image: e.image,
				onclick: e.onclick,
				ondone: e.ondone
			};
			return t.notification(n), !0;
		}
	} catch (e) {
		L.log("[notify] userscript api error", e);
	}
	return !1;
}
var Em = class {
	lastSentAt = /* @__PURE__ */ new Map();
	send(e, t = {}) {
		try {
			let n = t.key || e.tag || `${e.title ?? ""}|${e.text ?? ""}`, r = t.cooldownMs ?? 0;
			if (!ym(this.lastSentAt, n, r)) return;
			let i = {
				...e,
				title: e.title ?? _m()
			};
			Tm(i) ? bm(this.lastSentAt, n) : L.log("[notify] unavailable", i);
		} catch (e) {
			L.log("[notify] send error", e);
		}
	}
	translationCompleted(e) {
		let t = vm("VOTTranslationCompletedNotify", "The translation on the {0} has been completed!").replace("{0}", e);
		this.send({
			text: t,
			title: _m(),
			timeout: 5e3,
			silent: !0,
			tag: "VOTTranslationCompleted",
			onclick: () => {
				try {
					globalThis.focus();
				} catch {}
			}
		}, {
			key: `translation_completed_${e}`,
			cooldownMs: 1e4
		});
	}
	translationFailed(e) {
		let { videoId: t, message: n } = e;
		if (pa(n)) return;
		let r = wm(n), i = _m();
		this.send({
			text: r,
			title: i,
			timeout: 8e3,
			silent: !0,
			tag: `VOTtranslationFailed_${t || "unknown"}`,
			onclick: () => {
				try {
					globalThis.focus();
				} catch {}
			}
		}, {
			key: `translation_failed_${t || "unknown"}`,
			cooldownMs: 3e4
		});
	}
}, Dm = [
	"class",
	"id",
	"title"
], Om = new RegExp([
	"advertise",
	"advertisement",
	"promo",
	"sponsor",
	"banner",
	"commercial",
	"preroll",
	"midroll",
	"postroll",
	"ad-container",
	"sponsored"
].map((e) => e.replaceAll(/[.*+?^${}()|[\]\\]/g, String.raw`\$&`)).join("|")), km = Symbol.for("vot.attachShadowHook");
function Am() {
	let e = Object.getOwnPropertyDescriptor(Element.prototype, "attachShadow");
	return !e || typeof e.value != "function" ? null : e;
}
function jm() {
	let e = globalThis, t = e[km];
	if (t?.descriptor && t.subscribers instanceof Set) return t;
	let n = Am();
	if (!n) return null;
	let r = n.value, i = {
		descriptor: n,
		subscribers: /* @__PURE__ */ new Set()
	}, a = function(e) {
		let t = r.call(this, e);
		for (let e of i.subscribers) try {
			e(t);
		} catch (e) {
			L.error("attachShadow subscriber failed", e);
		}
		return t;
	};
	try {
		Object.defineProperty(Element.prototype, "attachShadow", {
			...n,
			value: a
		});
	} catch {
		return null;
	}
	return e[km] = i, i;
}
function Mm(e) {
	let t = globalThis, n = t[km];
	if (n && (n.subscribers.delete(e), !(n.subscribers.size > 0))) {
		try {
			Object.defineProperty(Element.prototype, "attachShadow", n.descriptor);
		} catch {
			let e = n.descriptor.value;
			typeof e == "function" && (Element.prototype.attachShadow = e);
		}
		delete t[km];
	}
}
var Nm = class e {
	seenVideos = /* @__PURE__ */ new WeakSet();
	activeVideos = /* @__PURE__ */ new WeakSet();
	observedRoots = /* @__PURE__ */ new WeakSet();
	videoListenerControllers = /* @__PURE__ */ new Map();
	pendingAdded = /* @__PURE__ */ new Set();
	pendingRemoved = /* @__PURE__ */ new Set();
	flushPending = !1;
	static MAX_FLUSH_BUDGET_MS = 6;
	static MAX_NODES_PER_SLICE = 120;
	onVideoAdded = new H();
	onVideoRemoved = new H();
	observer = new MutationObserver((e) => this.onMutations(e));
	intervalIdleChecker;
	checkerUnsubscribe = null;
	enabled = !1;
	attachShadowSubscriber = null;
	onDocumentReady = null;
	onPageShow = () => {
		let e = document.documentElement;
		e && (this.pendingAdded.add(e), this.scheduleFlush());
	};
	constructor(e = hm()) {
		this.intervalIdleChecker = e;
	}
	static containsAdKeyword(e) {
		return e.length > 0 && Om.test(e);
	}
	isAdRelated(t) {
		for (let n of Dm) {
			let r = t.getAttribute(n);
			if (r && e.containsAdKeyword(r.toLowerCase())) return !0;
		}
		return !1;
	}
	isInsideAd(e) {
		for (let t = e.parentElement; t; t = t.parentElement) if (this.isAdRelated(t)) return !0;
		return !1;
	}
	getCapturedAudioTrackCount(e) {
		let t = e, n = t.captureStream ?? t.mozCaptureStream;
		if (typeof n != "function") return null;
		try {
			return n.call(e).getAudioTracks().length;
		} catch {
			return null;
		}
	}
	isLikelySilentDecorativeVideo(e) {
		if (!(e.muted || e.defaultMuted) || !e.autoplay || !e.loop || e.controls) return !1;
		let t = e;
		if (typeof t.mozHasAudio == "boolean") return !t.mozHasAudio;
		if ("audioTracks" in t && typeof t.audioTracks?.length == "number") {
			if (t.audioTracks.length > 0) return !1;
			let n = this.getCapturedAudioTrackCount(e);
			return n === null ? !0 : n === 0;
		}
		let n = this.getCapturedAudioTrackCount(e);
		return n === null ? !1 : n === 0;
	}
	hasAudio(e) {
		let t = e;
		return e.srcObject instanceof MediaStream ? e.srcObject.getAudioTracks().length > 0 : typeof t.mozHasAudio == "boolean" ? t.mozHasAudio : typeof t.webkitAudioDecodedByteCount == "number" && t.webkitAudioDecodedByteCount > 0 || "audioTracks" in t && typeof t.audioTracks?.length == "number" && t.audioTracks.length > 0 ? !0 : !this.isLikelySilentDecorativeVideo(e);
	}
	isValidVideo(e) {
		return this.isAdRelated(e) || this.isInsideAd(e) ? !1 : this.hasAudio(e) ? !0 : (L.log("Ignoring video without audio:", e), !1);
	}
	observeRoot(e) {
		this.observedRoots.has(e) || (this.observedRoots.add(e), this.observer.observe(e, {
			childList: !0,
			subtree: !0
		}));
	}
	scan(e) {
		if (e instanceof HTMLVideoElement) {
			this.trackVideo(e);
			return;
		}
		if (e.nodeType !== Node.ELEMENT_NODE && e.nodeType !== Node.DOCUMENT_FRAGMENT_NODE && e.nodeType !== Node.DOCUMENT_NODE) return;
		let t = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, { acceptNode: (e) => {
			let t = e, n = t.tagName === "VIDEO", r = !!t.shadowRoot;
			return n || r ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
		} });
		for (; t.nextNode();) {
			let e = t.currentNode;
			if (e instanceof HTMLVideoElement) {
				this.trackVideo(e);
				continue;
			}
			let n = e.shadowRoot;
			n && (this.observeRoot(n), this.scan(n));
		}
	}
	getVideoListenerSignal(e) {
		let t = this.videoListenerControllers.get(e);
		t && t.abort();
		let n = new AbortController();
		return this.videoListenerControllers.set(e, n), n.signal;
	}
	cleanupVideoListeners(e) {
		let t = this.videoListenerControllers.get(e);
		t && (t.abort(), this.videoListenerControllers.delete(e));
	}
	cleanupAllVideoListeners() {
		for (let e of this.videoListenerControllers.values()) e.abort();
		this.videoListenerControllers.clear();
	}
	trackVideo(e) {
		if (this.seenVideos.has(e)) return;
		this.seenVideos.add(e);
		let t = this.getVideoListenerSignal(e), n = () => {
			this.isValidVideo(e) && (this.activeVideos.has(e) || (this.activeVideos.add(e), this.onVideoAdded.dispatch(e)));
		};
		e.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA ? n() : (e.addEventListener("loadeddata", n, {
			once: !0,
			signal: t
		}), e.addEventListener("play", () => {
			e.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && n();
		}, {
			once: !0,
			passive: !0,
			signal: t
		})), e.addEventListener("emptied", () => {
			e.isConnected || this.untrackVideo(e);
		}, {
			passive: !0,
			signal: t
		});
	}
	untrackVideo(e) {
		this.cleanupVideoListeners(e), this.activeVideos.has(e) && (this.onVideoRemoved.dispatch(e), this.activeVideos.delete(e)), this.seenVideos.delete(e);
	}
	collectVideos(e) {
		let t = /* @__PURE__ */ new Set(), n = (e) => {
			for (let n of e) t.add(n);
		};
		if (e instanceof HTMLVideoElement && t.add(e), (e instanceof Document || e instanceof DocumentFragment || e instanceof Element) && n(e.querySelectorAll("video")), e instanceof Element) {
			let t = e.shadowRoot;
			t && n(t.querySelectorAll("video"));
		}
		return Array.from(t);
	}
	getNowMs() {
		return typeof performance < "u" && typeof performance.now == "function" ? performance.now() : Date.now();
	}
	isSliceBudgetReached(t, n) {
		return n >= e.MAX_NODES_PER_SLICE ? !0 : this.getNowMs() - t >= e.MAX_FLUSH_BUDGET_MS;
	}
	processPendingAdded(e) {
		let t = 0;
		for (; this.pendingAdded.size > 0;) {
			let n = this.pendingAdded.values().next();
			if (n.done || (this.pendingAdded.delete(n.value), this.scan(n.value), t += 1, this.isSliceBudgetReached(e, t))) break;
		}
		return t;
	}
	processPendingRemoved(e, t) {
		let n = t;
		for (; this.pendingRemoved.size > 0 && !this.isSliceBudgetReached(e, n);) {
			let e = this.pendingRemoved.values().next();
			if (e.done) break;
			this.pendingRemoved.delete(e.value);
			for (let t of this.collectVideos(e.value)) t.isConnected || this.untrackVideo(t);
			n += 1;
		}
		return n;
	}
	flushSlice = () => {
		if (!this.enabled) {
			this.pendingAdded.clear(), this.pendingRemoved.clear(), this.flushPending = !1;
			return;
		}
		let e = this.getNowMs(), t = this.processPendingAdded(e);
		this.processPendingRemoved(e, t), this.flushPending = this.pendingAdded.size > 0 || this.pendingRemoved.size > 0, this.flushPending && this.intervalIdleChecker.requestImmediateTick();
	};
	onCheckerTick = () => {
		this.flushPending && this.flushSlice();
	};
	scheduleFlush = () => {
		this.enabled && (this.flushPending = !0, this.intervalIdleChecker.requestImmediateTick());
	};
	installAttachShadowHook() {
		if (this.attachShadowSubscriber) return;
		let e = jm();
		if (!e) return;
		let t = (e) => {
			this.enabled && (this.observeRoot(e), this.pendingAdded.add(e), this.scheduleFlush());
		};
		e.subscribers.add(t), this.attachShadowSubscriber = t;
	}
	uninstallAttachShadowHook() {
		this.attachShadowSubscriber &&= (Mm(this.attachShadowSubscriber), null);
	}
	enqueueAddedNode(e) {
		if (e.nodeType === Node.ELEMENT_NODE) {
			let t = e.shadowRoot;
			t && this.observeRoot(t);
		}
		this.pendingAdded.add(e);
	}
	enqueueMutation(e) {
		for (let t of e.addedNodes) this.enqueueAddedNode(t);
		for (let t of e.removedNodes) this.pendingRemoved.add(t);
	}
	onMutations(e) {
		for (let t of e) t.type === "childList" && this.enqueueMutation(t);
		(this.pendingAdded.size > 0 || this.pendingRemoved.size > 0) && this.scheduleFlush();
	}
	enable() {
		if (this.enabled) return;
		this.enabled = !0, this.checkerUnsubscribe?.(), this.checkerUnsubscribe = this.intervalIdleChecker.subscribe(this.onCheckerTick), this.intervalIdleChecker.start(), this.intervalIdleChecker.markActivity("video-observer-enable"), this.installAttachShadowHook(), globalThis.addEventListener("pageshow", this.onPageShow, { passive: !0 });
		let e = document.documentElement;
		if (e) {
			this.observeRoot(e), this.scan(e);
			return;
		}
		let t = () => {
			let e = document.documentElement;
			e && (document.removeEventListener("readystatechange", t), this.onDocumentReady = null, this.enabled && (this.observeRoot(e), this.scan(e)));
		};
		this.onDocumentReady = t, document.addEventListener("readystatechange", t), typeof queueMicrotask == "function" ? queueMicrotask(t) : Promise.resolve().then(t);
	}
	disable() {
		this.enabled && (this.enabled = !1, globalThis.removeEventListener("pageshow", this.onPageShow), this.onDocumentReady &&= (document.removeEventListener("readystatechange", this.onDocumentReady), null), this.uninstallAttachShadowHook(), this.observer.disconnect(), this.cleanupAllVideoListeners(), this.flushPending = !1, this.checkerUnsubscribe?.(), this.checkerUnsubscribe = null, this.intervalIdleChecker.stop(), this.pendingAdded.clear(), this.pendingRemoved.clear(), this.seenVideos = /* @__PURE__ */ new WeakSet(), this.activeVideos = /* @__PURE__ */ new WeakSet(), this.observedRoots = /* @__PURE__ */ new WeakSet());
	}
};
//#endregion
//#region src/utils/volumeLink.ts
function Pm(e, t) {
	e.lastVideoPercent = W(t);
}
function Fm(e, t) {
	e.lastTranslationPercent = W(t);
}
function Im(e, t) {
	let n = W(e);
	return {
		min: n,
		max: W(Math.min(100, t), n, 100)
	};
}
function Lm({ state: e, fromType: t, newVolume: n, currentVideo: r, currentTranslation: i, translationMin: a, translationMax: o }) {
	let s = Im(a, o);
	if (e.initialized ||= (e.lastVideoPercent = W(r), e.lastTranslationPercent = gc(Number(i), s.min, s.max), !0), t === "video") {
		let t = W(n), r = t - W(e.lastVideoPercent);
		e.lastVideoPercent = t;
		let i = gc(e.lastTranslationPercent + r, s.min, s.max);
		return e.lastTranslationPercent = i, { nextTranslation: i };
	}
	let c = gc(Number.isFinite(n) ? n : i, s.min, s.max), l = c - e.lastTranslationPercent;
	e.lastTranslationPercent = c;
	let u = W(e.lastVideoPercent + l);
	return e.lastVideoPercent = u, { nextVideo: u };
}
//#endregion
//#region src/utils/platformEvents.ts
var Rm = {
	allowTouchMoveHandler: !0,
	disableContainerDrag: !1
}, zm = {
	xvideos: { allowTouchMoveHandler: !1 },
	youtube: { disableContainerDrag: !0 }
};
function Bm(e) {
	if (!e) return Rm;
	let t = zm[e] ?? {};
	return {
		...Rm,
		...t
	};
}
//#endregion
//#region src/videoHandler/modules/ducking.ts
var Vm = 0, Hm = 1, Um = Object.freeze({
	tickMs: 50,
	thresholdOnRms: .012,
	thresholdOffRms: .009,
	rmsAttackTauMs: 60,
	rmsReleaseTauMs: 240,
	holdMs: 520,
	attackTauMs: 110,
	releaseTauMs: 600,
	maxDownPerSec: 3.5,
	maxUpPerSec: .9,
	rmsMissingGraceMs: 200,
	maxDtMs: 250,
	externalBaselineDelta01: .02,
	unduckTolerance01: .01,
	volumeStep01: pc,
	applyDeltaThreshold01: pc / 2
});
function Wm(e) {
	return {
		isDucked: !1,
		speechGateOpen: !1,
		rmsEnvelope: 0,
		baseline: $m(e),
		lastApplied: void 0,
		lastTickAt: 0,
		lastSoundAt: 0,
		rmsMissingSinceAt: null
	};
}
function Gm() {
	return Wm();
}
function Km(e, t, n, r, i) {
	let a = t.speechGateOpen;
	return e.smartEnabled ? e.audioIsPlaying && !i ? (t.rmsMissingSinceAt ??= r, a && (t.lastSoundAt = r), t.rmsMissingSinceAt !== null && r - t.rmsMissingSinceAt >= n.rmsMissingGraceMs ? (t.lastSoundAt = r, !0) : a) : (t.rmsMissingSinceAt = null, e.audioIsPlaying && (!a && t.rmsEnvelope >= n.thresholdOnRms || a && t.rmsEnvelope >= n.thresholdOffRms) ? (t.lastSoundAt = r, !0) : a && r - t.lastSoundAt <= n.holdMs) : (t.lastSoundAt = r, t.rmsMissingSinceAt = null, !0);
}
function qm(e, t, n, r) {
	e.isDucked && eh(e.lastApplied) && Math.abs(t - e.lastApplied) > r.externalBaselineDelta01 && (e.baseline = t), e.isDucked || (e.baseline = t);
	let i = e.baseline ?? n ?? t;
	return e.baseline = i, i;
}
function Jm(e, t, n, r, i, a) {
	let o = Math.min(r, i);
	return t ? (e.isDucked = !0, o) : (e.isDucked && Math.abs(r - n) < a.unduckTolerance01 && (e.isDucked = !1), r);
}
function Ym(e, t, n, r, i) {
	let a = e < t ? i.attackTauMs : i.releaseTauMs, o = a > 0 ? -Math.expm1(-n / a) : 1, s = t + (e - t) * o, c = (e < t ? i.maxDownPerSec : i.maxUpPerSec) * r;
	return c > 0 && (s = R(s, t - c, t + c)), R(s, Vm, Hm);
}
function Xm(e, t, n, r) {
	return Math.abs(n - t) < r ? (e.lastApplied = n, {
		kind: "noop",
		runtime: e
	}) : !eh(e.lastApplied) || Math.abs(n - e.lastApplied) >= r ? (e.lastApplied = n, {
		kind: "apply",
		runtime: e,
		volume01: n
	}) : {
		kind: "noop",
		runtime: e
	};
}
function Zm(e, t, n = Um) {
	let r = Qm(t), i = $m(e.volumeOnStart);
	if (!e.translationActive || !e.enabledAutoVolume) return {
		kind: "stop",
		runtime: r,
		restoreVolume: r.baseline ?? i
	};
	let a = Number.isFinite(e.nowMs) ? e.nowMs : Date.now(), o = R(a - (r.lastTickAt || a), 0, n.maxDtMs), s = o / 1e3;
	r.lastTickAt = a;
	let c = eh(e.rms), l = c ? R(e.rms, Vm, Hm) : 0, u = r.rmsEnvelope, d = l > u ? n.rmsAttackTauMs : n.rmsReleaseTauMs, f = d > 0 ? -Math.expm1(-o / d) : 1;
	r.rmsEnvelope = R(u + (l - u) * f, Vm, Hm);
	let p = Km(e, r, n, a, c);
	r.speechGateOpen = p;
	let m = $m(e.currentVideoVolume);
	if (!eh(m)) return {
		kind: "noop",
		runtime: r
	};
	let h = qm(r, m, i, n);
	if (!e.hostVideoActive) return r.lastApplied = m, {
		kind: "noop",
		runtime: r
	};
	let g = Jm(r, p, m, h, $m(e.duckingTarget01) ?? h, n), _ = xc(Ym(g, m, o, s, n), m, g, n.volumeStep01), v = n.applyDeltaThreshold01;
	return Xm(r, m, _, v);
}
function Qm(e) {
	return {
		isDucked: !!e.isDucked,
		speechGateOpen: !!e.speechGateOpen,
		rmsEnvelope: $m(e.rmsEnvelope) ?? 0,
		baseline: $m(e.baseline),
		lastApplied: $m(e.lastApplied),
		lastTickAt: eh(e.lastTickAt) ? e.lastTickAt : 0,
		lastSoundAt: eh(e.lastSoundAt) ? e.lastSoundAt : 0,
		rmsMissingSinceAt: eh(e.rmsMissingSinceAt) ? e.rmsMissingSinceAt : null
	};
}
function $m(e) {
	if (eh(e)) return R(e, Vm, Hm);
}
function eh(e) {
	return typeof e == "number" && Number.isFinite(e);
}
//#endregion
//#region src/videoHandler/modules/smartDuckingRuntime.ts
var th = Um.tickMs, nh = /* @__PURE__ */ new WeakMap();
function rh(e) {
	if (!e || typeof e != "object") return !1;
	let t = e;
	return typeof t.connect == "function" && typeof t.disconnect == "function";
}
function ih(e) {
	return e?.audio ?? e?.audioElement;
}
function ah() {
	return typeof performance < "u" && typeof performance.now == "function" ? performance.now() : Date.now();
}
function oh(e) {
	return e.data?.enabledAutoVolume ? e.data?.syncVolume ? "classic" : e.data?.enabledSmartDucking ?? !0 ? "smart" : "classic" : "off";
}
function sh(e) {
	return e.audioPlayer?.audioContext ?? e.audioContext;
}
function ch(e) {
	if (e.connectedInputNode && e.analyser) try {
		e.connectedInputNode.disconnect(e.analyser);
	} catch {}
	if (e.connectedInputNode = void 0, e.createdMediaSource) try {
		e.createdMediaSource.disconnect();
	} catch {}
	if (e.createdMediaSource = void 0, e.analyser) try {
		e.analyser.disconnect();
	} catch {}
	e.analyser = void 0, e.analyserFloatData = void 0, e.analyserData = void 0, e.mediaElement = void 0, e.audioContext = void 0, e.mediaSourceCreationFailed = !1;
}
function lh(e) {
	let t = nh.get(e);
	t && (ch(t), nh.delete(e));
}
function uh(e, t, n, r) {
	if (rh(e?.gainNode)) return e.gainNode;
	if (rh(e?.audioSource)) return e.audioSource;
	if (rh(e?.mediaElementSource)) return e.mediaElementSource;
	if (!(r.mediaSourceCreationFailed && r.mediaElement === t && r.audioContext === n)) {
		if (r.createdMediaSource && r.mediaElement === t && r.audioContext === n) return r.createdMediaSource;
		try {
			let e = n.createMediaElementSource(t);
			return r.createdMediaSource = e, r.mediaSourceCreationFailed = !1, e;
		} catch (e) {
			r.mediaSourceCreationFailed = !0, L.log("[SmartDucking] failed to create media source", e);
			return;
		}
	}
}
function dh(e, t, n) {
	let r = sh(e);
	if (!r) return;
	let i = nh.get(e);
	if (i || (i = {}, nh.set(e, i)), (i.mediaElement && i.mediaElement !== n || i.audioContext && i.audioContext !== r) && ch(i), i.mediaElement = n, i.audioContext = r, !i.analyser) {
		let e = r.createAnalyser();
		e.fftSize = 512, i.analyser = e;
	}
	let a = uh(t, n, r, i), o = i.analyser;
	if (!(!a || !o)) {
		if (i.connectedInputNode !== a) {
			if (i.connectedInputNode) try {
				i.connectedInputNode.disconnect(o);
			} catch {}
			try {
				a.connect(o), i.connectedInputNode = a;
			} catch (e) {
				L.log("[SmartDucking] failed to connect analyser", e);
				return;
			}
		}
		return {
			analyser: o,
			state: i
		};
	}
}
function fh(e) {
	return {
		isDucked: e.smartVolumeIsDucked,
		speechGateOpen: e.smartVolumeSpeechGateOpen,
		rmsEnvelope: e.smartVolumeRmsEnvelope,
		baseline: e.smartVolumeDuckingBaseline,
		lastApplied: e.smartVolumeLastApplied,
		lastTickAt: e.smartVolumeLastTickAt,
		lastSoundAt: e.smartVolumeLastSoundAt,
		rmsMissingSinceAt: e.smartVolumeRmsMissingSinceAt
	};
}
function ph(e, t) {
	e.smartVolumeIsDucked = t.isDucked, e.smartVolumeSpeechGateOpen = t.speechGateOpen, e.smartVolumeRmsEnvelope = t.rmsEnvelope, e.smartVolumeDuckingBaseline = t.baseline, e.smartVolumeLastApplied = t.lastApplied, e.smartVolumeLastTickAt = t.lastTickAt, e.smartVolumeLastSoundAt = t.lastSoundAt, e.smartVolumeRmsMissingSinceAt = t.rmsMissingSinceAt;
}
function mh(e, t = {}) {
	let { restoreVolume: n } = t;
	e.smartVolumeDuckingInterval !== void 0 && (clearTimeout(e.smartVolumeDuckingInterval), e.smartVolumeDuckingInterval = void 0);
	let r = typeof n == "number" ? n : e.smartVolumeDuckingBaseline ?? e.volumeOnStart;
	if (typeof r == "number" && (typeof n == "number" || e.smartVolumeIsDucked)) try {
		e.setVideoVolume(r);
	} catch {}
	lh(e), ph(e, Gm());
}
function hh(e) {
	typeof globalThis > "u" || e.smartVolumeDuckingInterval !== void 0 && (e.smartVolumeDuckingInterval = globalThis.setTimeout(() => {
		if (e.smartVolumeDuckingInterval !== void 0) {
			try {
				vh(e);
			} catch (t) {
				L.log("[SmartDucking] tick failed, stopping smart ducking", t), mh(e);
				return;
			}
			e.smartVolumeDuckingInterval !== void 0 && hh(e);
		}
	}, th));
}
function gh(e) {
	if (typeof globalThis > "u" || e.smartVolumeDuckingInterval !== void 0 || oh(e) !== "smart") return;
	let t = e.getVideoVolume(), n = typeof e.smartVolumeDuckingBaseline == "number" ? e.smartVolumeDuckingBaseline : t, r = Wm(n);
	if (Number.isFinite(t) && Number.isFinite(n) && t < n - Um.externalBaselineDelta01) {
		let e = ah();
		r.isDucked = !0, r.speechGateOpen = !0, r.lastApplied = t, r.lastSoundAt = e;
	}
	ph(e, r), e.smartVolumeDuckingInterval = globalThis.setTimeout(() => {}, 0), clearTimeout(e.smartVolumeDuckingInterval), hh(e);
}
function _h(e, t) {
	let n = e.audioPlayer?.player, r = dh(e, n, t);
	if (!r) return;
	let { analyser: i, state: a } = r;
	try {
		if (typeof i.getFloatTimeDomainData == "function") {
			let e = a.analyserFloatData;
			e?.length !== i.fftSize && (e = new Float32Array(i.fftSize), a.analyserFloatData = e), i.getFloatTimeDomainData(e);
			let t = 0;
			for (let n of e) t += n * n;
			return R(Math.sqrt(t / e.length), 0, 1);
		}
		let e = a.analyserData;
		e?.length !== i.fftSize && (e = new Uint8Array(i.fftSize), a.analyserData = e), i.getByteTimeDomainData(e);
		let t = 0;
		for (let n of e) {
			let e = (n - 128) / 128;
			t += e * e;
		}
		return R(Math.sqrt(t / e.length), 0, 1);
	} catch {
		return;
	}
}
function vh(e) {
	if (oh(e) !== "smart") {
		yh.call(e);
		return;
	}
	let t = e.audioPlayer?.player, n = ih(t), r = !!n && !n.paused && !n.muted && (n.volume ?? 1) > .001, i = ah(), a = e.getVideoVolume(), o = e.video, s = !(o && (o.paused || o.ended)), c = R(e.data?.autoVolume ?? 15, 0, 100) / 100;
	e.smartVolumeDuckingTarget = c;
	let l = r && n ? _h(e, n) : 0, u = Zm({
		nowMs: i,
		translationActive: e.hasActiveSource(),
		enabledAutoVolume: !0,
		smartEnabled: !0,
		audioIsPlaying: r,
		rms: l,
		currentVideoVolume: a,
		hostVideoActive: s,
		duckingTarget01: c,
		volumeOnStart: e.volumeOnStart
	}, fh(e), Um);
	switch (u.kind) {
		case "stop":
			mh(e, { restoreVolume: u.restoreVolume });
			return;
		case "apply":
			e.setVideoVolume(u.volume01), ph(e, u.runtime);
			return;
		case "noop":
			ph(e, u.runtime);
			return;
		default: throw TypeError("Unhandled smart ducking decision");
	}
}
function yh() {
	typeof this.data?.defaultVolume == "number" && (this.audioPlayer.player.volume = this.data.defaultVolume / 100);
	let e = oh(this);
	if (e === "off") {
		mh(this, { restoreVolume: this.smartVolumeDuckingBaseline ?? this.volumeOnStart });
		return;
	}
	let t = R(this.data.autoVolume ?? 15, 0, 100) / 100;
	if (this.smartVolumeDuckingTarget = t, !this.hasActiveSource()) return;
	if (e === "smart") {
		gh(this);
		return;
	}
	this.smartVolumeDuckingInterval !== void 0 && (clearTimeout(this.smartVolumeDuckingInterval), this.smartVolumeDuckingInterval = void 0), typeof this.smartVolumeDuckingBaseline != "number" && (this.smartVolumeDuckingBaseline = this.getVideoVolume());
	let n = this.smartVolumeDuckingBaseline ?? this.getVideoVolume();
	this.setVideoVolume(Math.min(n, t)), ph(this, Wm(this.smartVolumeDuckingBaseline)), this.smartVolumeIsDucked = !0;
}
function bh(e) {
	if (!this.data?.enabledAutoVolume || !this.hasActiveSource()) return;
	let t = bc(e);
	this.smartVolumeDuckingTarget = t, this.smartVolumeDuckingBaseline = t, this.smartVolumeLastApplied = t;
}
//#endregion
//#region src/videoHandler/modules/proxyShared.ts
var xh = "https://vtrans.s3-private.mds.yandex.net/tts/prod/", Sh = "/video-translation/audio-proxy/", Ch = "https://brosubs.s3-private.mds.yandex.net/vtrans/", wh = "/video-subtitles/subtitles-proxy/";
function Th(e) {
	return e ?? "vot-worker.kload.workers.dev";
}
function Eh(e) {
	return !!e.translateProxyEnabled;
}
function Dh(e) {
	return e.translateProxyEnabled === 2;
}
function Oh(e) {
	return !!(e.gmXhrSupported && Eh(e));
}
function kh(e, t) {
	return !Dh(t) || !e.startsWith(xh) ? e : e.replace(xh, `https://${Th(t.proxyWorkerHost)}${Sh}`);
}
function Ah(e) {
	let t = String(e || "");
	if (!t) return t;
	try {
		let e = new URL(t);
		return e.pathname.startsWith(Sh) ? (e.host = "vtrans.s3-private.mds.yandex.net", e.pathname = `/tts/prod/${e.pathname.slice(31).replace(/^\/+/, "")}`, e.protocol = "https:", e.toString()) : t;
	} catch {
		return t;
	}
}
function jh(e, t) {
	return e.startsWith(xh) || e.startsWith(`https://${Th(t.proxyWorkerHost)}${Sh}`);
}
function Mh(e, t) {
	if (!Dh(t) || !e.startsWith(Ch)) return e;
	let n = e.slice(49);
	return `https://${Th(t.proxyWorkerHost)}${wh}${n}`;
}
//#endregion
//#region src/videoHandler/modules/subtitlesShared.ts
var Nh = "disabled", Ph = /^\d+$/u, [Fh, Ih] = vi;
function Lh(e) {
	let t = [];
	for (let n = 0; n < e.length; n += 1) {
		let r = Yl(e[n]);
		r && t.push({
			descriptor: r,
			index: n
		});
	}
	return t;
}
function Rh(e) {
	if (!Ph.test(e)) return null;
	let t = Number(e);
	return Number.isSafeInteger(t) ? t : null;
}
function zh(e, t) {
	return !Number.isInteger(t) || t < 0 || t >= e.length ? null : Yl(e[t]);
}
function Bh() {
	return {
		label: V.get("VOTSubtitlesDisabled"),
		value: Nh,
		selected: !0,
		disabled: !1
	};
}
function Vh(e) {
	return `${V.getLangLabel(e.language)}${e.translatedFromLanguage ? ` ${V.get("VOTTranslatedFrom")} ${V.getLangLabel(e.translatedFromLanguage)}` : ""}${e.source === "yandex" ? "" : `, ${globalThis.location.hostname}`}${e.isAutoGenerated ? ` (${V.get("VOTAutogenerated")})` : ""}`;
}
function Hh(e) {
	let t = [Bh()];
	for (let { descriptor: n, index: r } of e) t.push({
		label: Vh(n),
		value: String(r),
		selected: !1,
		disabled: !1
	});
	return t;
}
function Uh(e) {
	let t = e[Symbol.iterator]().next();
	return t.done ? void 0 : t.value;
}
function Wh(e) {
	return (e ?? "").toLowerCase();
}
function Gh(e) {
	return Wh(e).split(/[-_]/)[0];
}
function Kh(e, t) {
	if (!e || !t) return !1;
	let n = Wh(e), r = Wh(t);
	return n === r || Gh(n) === Gh(r);
}
function qh(e, t, n) {
	if (e === Ih) {
		let e = Wh(t);
		return e && e !== Fh ? e : void 0;
	}
	return typeof e == "string" && e && e !== Fh ? Wh(e) : Wh(n) || Wh(t);
}
function Jh(e, t, n) {
	if (!e.length) return null;
	let r = Wh(t), i = Wh(n), a = r === "auto" || r === "", o = Gh(r), s = Gh(i), c = (e) => e.source === "yandex", l = (e) => !!e.isAutoGenerated, u = (e, t, n) => Kh(e.language, n) ? a ? !0 : Kh(e.translatedFromLanguage, t) : !1, d = (e, t) => Kh(e.language, t) ? e.translatedFromLanguage ? Kh(e.translatedFromLanguage, t) : !0 : !1, f = (t) => e.find(({ descriptor: e }) => t(e))?.index ?? null, p = () => f((e) => !c(e) && Kh(e.language, i) && !l(e)) ?? f((e) => !c(e) && Kh(e.language, i) && l(e));
	if (!a && o && s && o === s) {
		let e = f((e) => d(e, i) && !l(e));
		if (e != null) return e;
		let t = f((e) => d(e, i) && l(e));
		if (t != null) return t;
		let n = p();
		if (n != null) return n;
		let r = f((e) => c(e) && Kh(e.language, i));
		if (r != null) return r;
	}
	return f((e) => c(e) && u(e, r, i)) ?? f((e) => c(e) && Kh(e.language, i)) ?? f((e) => !c(e) && u(e, r, i)) ?? p() ?? null;
}
//#endregion
//#region src/videoHandler/modules/translationPlayback.ts
var Yh = 5e3, Xh = 150, Zh = 2;
async function Qh(e) {
	let t = e.audioPlayer?.audioContext;
	if (!t || t.state !== "suspended") return "not-needed";
	let n = (async () => {
		try {
			return await t.resume(), "resumed";
		} catch (e) {
			return L.log("[updateTranslation] Failed to resume AudioContext", e), "failed";
		}
	})(), r, i = new Promise((e) => {
		r = setTimeout(() => e("timeout"), 1500);
	}), a = await Promise.race([n, i]);
	return r !== void 0 && clearTimeout(r), a === "resumed" ? L.log("[updateTranslation] AudioContext resumed") : a === "timeout" && L.log("[updateTranslation] AudioContext resume timeout"), a;
}
async function $h(e, t) {
	if (!t || !e.audioPlayer) return;
	let n = e.audioPlayer.player, r = String(n.currentSrc || n.src || "");
	if (e.proxifyAudio(e.unproxifyAudio(r)) === e.proxifyAudio(e.unproxifyAudio(t))) try {
		await n.clear(), n.src = "", L.log("[updateTranslation] cleared stale partially-applied source");
	} catch (e) {
		L.log("[updateTranslation] failed to clear stale source", e);
	}
}
function eg(e, t) {
	return e <= 0 || t.aborted ? Promise.resolve() : new Promise((n) => {
		let r = setTimeout(() => {
			t.removeEventListener("abort", i), n();
		}, e), i = () => {
			clearTimeout(r), t.removeEventListener("abort", i), n();
		};
		t.addEventListener("abort", i, { once: !0 });
	});
}
async function tg(e, t, n) {
	let r = e.actionsAbortController.signal, i = {
		headers: { range: "bytes=0-0" },
		signal: r,
		timeout: Yh
	};
	for (let a = 1; a <= Zh; a++) {
		if (ng(e, n, r)) return !1;
		try {
			let o = await z(t, i);
			if (ng(e, n, r)) return !1;
			if (L.log("[validateAudioUrl] probe response", {
				audioUrl: t,
				attempt: a,
				ok: o.ok,
				status: o.status
			}), o.ok) return !0;
		} catch (i) {
			if (ng(e, n, r)) return !1;
			L.log("[validateAudioUrl] probe error", {
				audioUrl: t,
				attempt: a,
				err: i
			});
		}
		if (!await rg(a, e, n, r)) return !1;
	}
	return !1;
}
function ng(e, t, n) {
	return e.isActionStale(t) || n.aborted;
}
async function rg(e, t, n, r) {
	return e >= Zh ? !0 : ng(t, n, r) ? !1 : (await eg(Xh, r), !ng(t, n, r));
}
async function ig(e, t) {
	if (this.isActionStale(t) || await tg(this, e, t)) return e;
	let n = this.unproxifyAudio(e);
	return n !== e && await tg(this, n, t) ? (L.log("[validateAudioUrl] switching to direct audio URL after probe"), n) : e;
}
function ag() {
	!this.videoData || this.videoData.isStream || this.hasActiveSource() && this.refreshTranslationAudio().catch((e) => {
		L.log("[scheduleTranslationRefresh] refresh failed", e);
	});
}
async function og() {
	if (!this.videoData || this.videoData.isStream || !this.hasActiveSource()) return;
	let e = this.videoData.videoId;
	if (!e) return;
	let t = Ds(this.videoData.translationHelp), n = this.getTranslationCacheKey(e, this.translateFromLang, this.translateToLang, t);
	this.cacheManager.getTranslation(n)?.url || (L.log("[scheduleTranslationRefresh] translation cache expired after resume, refreshing now"), await this.refreshTranslationAudio());
}
async function sg(e, t) {
	let n = await js({
		requester: e.translationHandler,
		request: {
			videoData: t.videoData,
			requestLang: t.requestLang,
			responseLang: t.responseLang,
			translationHelp: t.translationHelp,
			useAudioDownload: !!e.data?.useAudioDownload,
			signal: e.actionsAbortController.signal
		},
		actionContext: t.actionContext,
		isActionStale: (t) => e.isActionStale(t),
		updateTranslation: (t, n) => e.updateTranslation(t, n)
	});
	return n ? (t.onBeforeCache && await t.onBeforeCache(n), Ms({
		cacheKey: t.cacheKey,
		setTranslation: (t, n) => e.cacheManager.setTranslation(t, n),
		videoId: t.cacheVideoId,
		requestLang: t.cacheRequestLang,
		responseLang: t.cacheResponseLang,
		fallbackUrl: n.url,
		downloadTranslationUrl: e.downloadTranslationUrl,
		usedLivelyVoice: n.usedLivelyVoice
	}), n) : null;
}
async function cg() {
	if (!this.videoData || this.videoData.isStream || !this.hasActiveSource() || this.isRefreshingTranslation) return;
	let e = this.videoData.videoId;
	if (!e) return;
	this.actionsAbortController?.signal?.aborted && this.resetActionsAbortController("refreshTranslationAudio"), this.isRefreshingTranslation = !0;
	let t = {
		gen: this.actionsGeneration,
		videoId: e
	}, n = Ds(this.videoData.translationHelp);
	try {
		if (!await sg(this, {
			videoData: this.videoData,
			requestLang: this.translateFromLang,
			responseLang: this.translateToLang,
			translationHelp: n,
			actionContext: t,
			cacheKey: this.getTranslationCacheKey(e, this.translateFromLang, this.translateToLang, n),
			cacheVideoId: e,
			cacheRequestLang: this.translateFromLang,
			cacheResponseLang: this.translateToLang
		})) return;
	} finally {
		this.isRefreshingTranslation = !1;
	}
}
function lg(e) {
	let t = kh(e, {
		translateProxyEnabled: this.data?.translateProxyEnabled,
		proxyWorkerHost: this.data?.proxyWorkerHost
	});
	return t !== e && L.log(`[VOT] Audio proxied via ${t}`), t;
}
function ug(e) {
	return Ah(e);
}
async function dg(e = "proxySettingsChanged") {
	L.log(`[VOT] ${e}: clearing translation/subtitles cache`);
	try {
		this.cacheManager.clear(), this.activeTranslation = null;
	} catch {}
	try {
		await this.stopTranslation();
	} catch {}
	await this.initVOTClient();
}
function fg(e) {
	return jh(e, { proxyWorkerHost: this.data?.proxyWorkerHost });
}
function pg(e, t) {
	return e.proxifyAudio(e.unproxifyAudio(t));
}
async function mg(e, t, n) {
	let r = e.audioPlayer.player.src !== t, i = null;
	r && (e.audioPlayer.player.src = t, i = t);
	try {
		if (r && await e.audioPlayer.init(), e.isActionStale(n)) return await $h(e, i), {
			status: "stale",
			didSetSource: r,
			appliedSourceUrl: i
		};
		let t = await Qh(e);
		return t === "timeout" ? L.log("[updateTranslation] continuing after AudioContext resume timeout") : t === "failed" && L.log("[updateTranslation] AudioContext resume failed, continue without deferred resume"), e.isActionStale(n) ? (await $h(e, i), {
			status: "stale",
			didSetSource: r,
			appliedSourceUrl: i
		}) : (!e.video.paused && e.audioPlayer.player.src && e.audioPlayer.player.lipSync("play"), {
			status: "success",
			didSetSource: r,
			appliedSourceUrl: i
		});
	} catch (e) {
		return {
			status: "error",
			didSetSource: r,
			appliedSourceUrl: i,
			error: e
		};
	}
}
async function hg(e, t) {
	if (await this.waitForPendingStopTranslate(), this.isActionStale(t)) return;
	this.audioPlayer || this.createPlayer(), this.audioPlayer.audioContext?.state === "closed" && (L.log("[updateTranslation] AudioContext is closed, recreating player"), this.createPlayer());
	let n = pg(this, e), r = this.audioPlayer.player.currentSrc || this.audioPlayer.player.src || "", i = n === pg(this, r) ? n : await this.validateAudioUrl(n, t);
	if (this.isActionStale(t)) return;
	let a = await gg(this, i, t), o = a.nextAudioUrl, s = a.applyResult, c = s.appliedSourceUrl;
	if (s.status !== "stale") {
		if (s.status === "error") {
			L.log("this.audioPlayer.init() error", s.error), await $h(this, c);
			let e = da(s.error);
			this.transformBtn("error", e);
			return;
		}
		this.clearVolumeLinkState(), this.setupAudioSettings(), this.transformBtn("success", V.get("disableTranslate")), this.afterUpdateTranslation(o);
	}
}
async function gg(e, t, n) {
	let r = t, i = await mg(e, r, n);
	return _g(e, i, n, r) && await vg(e, r, i.appliedSourceUrl, n) || {
		nextAudioUrl: r,
		applyResult: i
	};
}
function _g(e, t, n, r) {
	return t.status === "error" && t.didSetSource && !e.isActionStale(n) && e.unproxifyAudio(r) !== r;
}
async function vg(e, t, n, r) {
	let i = e.unproxifyAudio(t);
	L.log("[updateTranslation] proxied audio init failed, retrying direct URL");
	try {
		let t = await e.validateAudioUrl(i, r);
		return e.isActionStale(r) ? (await $h(e, n), {
			nextAudioUrl: t,
			applyResult: {
				status: "stale",
				didSetSource: !0,
				appliedSourceUrl: n
			}
		}) : {
			nextAudioUrl: t,
			applyResult: await mg(e, t, r)
		};
	} catch (e) {
		return {
			nextAudioUrl: t,
			applyResult: {
				status: "error",
				didSetSource: !0,
				appliedSourceUrl: n,
				error: e
			}
		};
	}
}
async function yg(e, t, n, r, i) {
	await this.waitForPendingStopTranslate(), L.log("Run videoValidator"), await this.videoValidator(), this.actionsAbortController?.signal?.aborted && this.resetActionsAbortController("translateFunc");
	let a = this.uiManager.votOverlayView;
	if (!a?.votButton) {
		L.log("[translateFunc] Overlay view missing, skipping translation");
		return;
	}
	if (a.votButton.loading = !0, this.hadAsyncWait = !1, this.volumeOnStart = this.getVideoVolume(), !e) {
		L.log("Skip translation - no VIDEO_ID resolved yet"), await this.updateTranslationErrorMsg(new U("VOTNoVideoIDFound"), this.actionsAbortController.signal);
		return;
	}
	let o = this.videoData;
	if (!o) {
		await this.updateTranslationErrorMsg(new U("VOTNoVideoIDFound"), this.actionsAbortController.signal);
		return;
	}
	let s = Ds(i), c = this.getTranslationCacheKey(e, n, r, s), l = `video_${c}`;
	if (this.activeTranslation?.key === l) {
		L.log("[translateFunc] Reusing in-flight translation"), await this.activeTranslation.promise;
		return;
	}
	let u = {
		gen: this.actionsGeneration,
		videoId: e
	}, d = (async () => {
		if (this.isActionStale(u)) {
			L.log("[translateFunc] Stale translation task - skipping");
			return;
		}
		let t = n, i = r, a = async (e) => await this.updateTranslation(e, u), l = this.cacheManager.getTranslation(c);
		if (l?.url) {
			await a(l.url), L.log("[translateFunc] Cached translation was received");
			return;
		}
		let d = await sg(this, {
			videoData: o,
			requestLang: t,
			responseLang: i,
			translationHelp: s,
			actionContext: u,
			cacheKey: c,
			cacheVideoId: e,
			cacheRequestLang: n,
			cacheResponseLang: r,
			onBeforeCache: async () => {
				let t = this.getPreferredSubtitlesLanguage(o.detectedLanguage, o.responseLanguage);
				if (!t) return;
				let n = this.videoData ? this.getSubtitlesCacheKey(e, this.videoData.detectedLanguage, t) : null, r = n ? this.cacheManager.getSubtitles(n) : null;
				Array.isArray(r) && Jh(Lh(r), o.detectedLanguage, t) != null || (n && this.cacheManager.deleteSubtitles(n), this.subtitles = [], this.subtitlesCacheKey = null);
			}
		});
		L.log("[translateRes]", d), d || L.log("Skip translation");
	})();
	this.activeTranslation = {
		key: l,
		promise: d
	};
	try {
		return await d;
	} catch (t) {
		throw this.hadAsyncWait = Ns({
			aborted: this.actionsAbortController.signal.aborted,
			translateApiErrorsEnabled: !!this.data?.translateAPIErrors,
			hadAsyncWait: this.hadAsyncWait,
			videoId: e,
			error: t,
			notify: (e) => this.notifier.translationFailed(e)
		}), t;
	} finally {
		this.activeTranslation?.promise === d && (this.activeTranslation = null);
		let e = this.uiManager.votOverlayView?.votButton;
		!this.activeTranslation && e?.loading && !this.hasActiveSource() && (L.log("[translateFunc] clearing stale loading state"), this.transformBtn("none", V.get("translateVideo")));
	}
}
function bg() {
	return Ac(this.site.host);
}
//#endregion
//#region src/videoHandler/modules/events.ts
function xg(e, t) {
	if (!t || t === e || e.aborted) return e;
	if (t.aborted) return t;
	if (typeof AbortSignal < "u" && "any" in AbortSignal) return AbortSignal.any([e, t]);
	let n = new AbortController(), r = () => {
		e.removeEventListener("abort", i), t.removeEventListener("abort", a);
	}, i = () => {
		r(), n.abort(e.reason);
	}, a = () => {
		r(), n.abort(t.reason);
	};
	return e.addEventListener("abort", i, { once: !0 }), t.addEventListener("abort", a, { once: !0 }), n.signal;
}
function Sg(e) {
	let t = (t, n, r, i) => {
		let a = xg(e, i?.signal);
		if (!i) {
			t.addEventListener(n, r, { signal: a });
			return;
		}
		let { signal: o, ...s } = i;
		t.addEventListener(n, r, {
			...s,
			signal: a
		});
	};
	return {
		add: t,
		addMany: (e, n, r, i) => {
			for (let a of n) t(e, a, r, i);
		}
	};
}
function Cg(e, t, n) {
	e(t, ["pointerenter", "focusin"], (e) => n.handleOverlayInteraction(e)), e(t, ["pointermove"], (e) => n.handleOverlayInteraction(e), { passive: !0 }), e(t, ["pointerleave", "focusout"], (e) => n.scheduleHide(e));
}
function wg(e, t = 0) {
	let n = typeof e == "number" ? e : Number(e);
	return Number.isFinite(n) ? W(n) : t;
}
function Tg(e, t, n = {}) {
	n.skipYouTubeLikeHosts && Dc(e.site.host) || e.smartVolumeDuckingInterval === void 0 && (!e.data?.syncVolume || !e.audioPlayer?.player?.src || e.isLikelyInternalVideoVolumeChange(t) || e.syncVolumeWrapper("video", t));
}
function Eg(e, t, n) {
	let r = t.votMenu?.container;
	if (r) {
		let t = n ?? e.video.getBoundingClientRect().height;
		r.style.setProperty("--vot-container-height", `${t}px`);
	}
	let { position: i, direction: a } = t.calcButtonLayout(e.data?.buttonPos ?? "default");
	t.updateButtonLayout(i, a);
}
function Dg(e) {
	return e.replace("Key", "").replace("Digit", "");
}
function Og(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e) t.add(Dg(n));
	return t;
}
function kg(e, t) {
	if (!e) return null;
	let n = t.get(e);
	if (n) return n;
	let r = e.split("+").filter(Boolean).map(Dg), i = {
		parts: r,
		partsSet: new Set(r)
	};
	return t.set(e, i), i;
}
function Ag(e, t) {
	if (!t || e.size !== t.parts.length) return !1;
	for (let n of t.partsSet) if (!e.has(n)) return !1;
	return !0;
}
function jg(e) {
	let { self: t, overlayView: n, addMany: r } = e, i = () => {
		t.refreshOverlayMount(), Eg(t, n);
	};
	t.resizeObserver = new ResizeObserver((e) => {
		for (let r of e) Eg(t, n, r.contentRect.height);
	}), t.resizeObserver.observe(t.video), i(), r(document, ["fullscreenchange", "webkitfullscreenchange"], () => i()), r(t.video, ["webkitbeginfullscreen", "webkitendfullscreen"], () => i());
}
function Mg(e) {
	let { self: t } = e;
	if (!kc(t.site)) return;
	t.syncVolumeObserver = new MutationObserver((e) => {
		if (!t.audioPlayer?.player?.src) return;
		let n = !1, r = null;
		for (let t of e) {
			if (t.type !== "attributes" || t.attributeName !== "aria-valuenow") continue;
			n = !0;
			let e = t.target instanceof Element ? t.target.getAttribute("aria-valuenow") : null, i = e == null ? NaN : Number.parseFloat(e);
			Number.isFinite(i) && (r = i);
		}
		if (!n) return;
		let i;
		i = wg(r ?? (t.isMuted() ? 0 : t.getVideoVolume()) * 100), t.syncVideoVolumeSlider(), Tg(t, i);
	});
	let n = document.querySelector(".ytp-volume-panel");
	n && t.syncVolumeObserver.observe(n, {
		attributes: !0,
		subtree: !0,
		attributeFilter: ["aria-valuenow"]
	});
}
function Ng(e) {
	let { self: t } = e;
	if (t.site.host !== "youtube" || t.site.additionalData === "mobile") return;
	let n = async () => {
		try {
			if (!t.videoData) return;
			let e = F.getPlayer(), n = e?.getAvailableAudioTracks?.() ?? null;
			if (!Array.isArray(n) || n.length <= 1) return;
			let r = e?.getAudioTrack?.()?.getLanguageInfo?.()?.id, i = r && r !== "und" ? r.toLowerCase().split(/[-_.]/)[0] : void 0;
			if (!i || !dn.includes(i)) return;
			let a = i;
			if (a === t.videoData.detectedLanguage) return;
			if (t.videoManager.rememberDetectedLanguage(t.videoData.videoId, a), t.setSelectMenuValues(a, t.videoData.responseLanguage), t.data?.autoTranslate && a !== t.videoData.responseLanguage) {
				L.log(`[VOT] Audio track language changed to ${a}, triggering auto-translation`);
				try {
					await t.uiManager.handleTranslationBtnClick();
				} catch (e) {
					L.log("[VOT] Failed to trigger auto-translation on audio track change:", e);
				}
			}
		} catch (e) {
			L.log("[VOT] Failed to sync audio track language", e);
		}
	}, r = F.getPlayer(), i = ["onApiChange", "onStateChange"];
	if (r?.addEventListener) for (let e of i) try {
		r.addEventListener(e, n);
	} catch (t) {
		L.log(`[VOT] Failed to bind ${e}`, t);
	}
	n(), t.abortController.signal.addEventListener("abort", () => {
		if (r?.removeEventListener) for (let e of i) try {
			r.removeEventListener(e, n);
		} catch (t) {
			L.log(`[VOT] Failed to unbind ${e}`, t);
		}
	}, { once: !0 });
}
function Pg(e) {
	let { self: t, overlayView: n, add: r, addMany: i, platformConfig: a } = e;
	r(document, "click", (e) => {
		let r = e.target, i = n.votButton?.container, a = n.votMenu?.container, o = t.uiManager.votSettingsView?.dialog?.container, s = r && i ? i.contains(r) : !1, c = r && a ? a.contains(r) : !1, l = r ? t.container.contains(r) : !1, u = r && o ? o.contains(r) : !1, d = r instanceof Element && r.closest(".vot-dialog-temp") instanceof Element;
		L.log(`[document click] ${s} ${c} ${l} ${u} ${d}`), !(s || c || u || d) && (l || n.updateButtonOpacity(0), a && !a.hidden && (a.hidden = !0, t.overlayVisibility?.queueAutoHide()));
	});
	let o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Map(), c = () => o.clear(), l = (e, t) => {
		e().catch((e) => {
			L.log(`[VOT] ${t} hotkey action failed`, e);
		});
	};
	r(document, "keydown", (e) => {
		let n = e;
		if (n.repeat) return;
		o.add(n.code);
		let r = document.activeElement, i = r?.tagName?.toLowerCase?.() ?? "";
		if (["input", "textarea"].includes(i) || r?.isContentEditable) return;
		let a = Og(o);
		if (Ag(a, kg(t.data?.translationHotkey, s))) {
			c(), l(() => t.uiManager.handleTranslationBtnClick(), "Translation");
			return;
		}
		Ag(a, kg(t.data?.subtitlesHotkey, s)) && (c(), l(() => t.toggleSubtitlesForCurrentLangPair(), "Subtitles"));
	}), r(document, "keyup", (e) => o.delete(e.code)), r(document, "blur", c), r(document, "visibilitychange", () => {
		document.hidden && c();
	}), r(globalThis, "blur", c);
	let u = t.getEventContainer();
	u && (i(u, ["pointerenter", "pointerdown"], (e) => t.overlayVisibility.handleHostInteraction(e)), r(u, "pointermove", (e) => t.overlayVisibility.handleHostInteraction(e), { passive: !0 }), r(u, "pointerleave", (e) => t.overlayVisibility.scheduleHide(e))), t.rebindOverlayVisibilityTargets(), a.allowTouchMoveHandler && r(document, "touchmove", (e) => t.overlayVisibility.handleHostInteraction(e), { passive: !0 }), a.disableContainerDrag && (t.container.draggable = !1);
}
function Fg(e) {
	let { self: t, add: n } = e, r = !1, i = () => {
		r = !1;
	};
	n(t.video, "pause", () => {
		r = !0;
	}), n(t.video, "playing", () => {
		r && (r = !1, og.call(t).catch((e) => {
			L.log("[VOT] Failed to refresh translation after playback resumed", e);
		}));
	}), n(t.video, "loadstart", i), n(t.video, "emptied", i);
}
function Ig(e) {
	let { self: t, overlayView: n, add: r } = e, i = async () => {
		try {
			await t.setCanPlay();
		} catch (e) {
			L.log("[VOT] setCanPlay() failed", e);
		}
	}, a = !1, o = () => {
		a || (a = !0, queueMicrotask(async () => {
			a = !1, await i();
		}));
	};
	r(t.video, "canplay", () => {
		t.site.host === "rutube" && t.video.src || o();
	});
	let s = async () => {
		let e;
		try {
			e = await zr(t.site, {
				fetchFn: z,
				video: t.video
			});
		} catch (e) {
			L.log("[VOT] Failed to resolve video id on emptied", e);
		}
		t.videoData && e && e === t.videoData.videoId || (L.log("lipsync mode is emptied"), Vs(t, n, {
			clearVideoData: !0,
			hideMenu: !0
		}));
	};
	r(t.video, "emptied", () => {
		s().catch((e) => {
			L.log("[VOT] Failed to handle emptied lifecycle event", e);
		});
	}), Oc(t.site.host) || r(t.video, "volumechange", () => {
		t.syncVideoVolumeSlider();
		let e = t.uiManager.votOverlayView;
		e?.isInitialized() && Tg(t, wg(e.videoVolumeSlider.value), { skipYouTubeLikeHosts: !0 });
	}), t.site.host === "youtube" && !t.site.additionalData && r(document, "yt-page-data-updated", () => {
		L.log("yt-page-data-updated"), globalThis.location.pathname.startsWith("/shorts/") && o();
	});
}
function Lg() {
	let e = this.uiManager.votOverlayView;
	if (!e?.subtitlesSelect) return;
	let { add: t, addMany: n } = Sg(this.abortController.signal), r = {
		self: this,
		overlayView: e,
		platformConfig: Bm(this.site.host),
		add: t,
		addMany: n
	};
	Fg(r), jg(r), Mg(r), Ng(r), Pg(r), Ig(r);
}
function Rg() {
	this.overlayVisibilityTargetsAbortController?.abort(), this.overlayVisibilityTargetsAbortController = new AbortController();
	let { signal: e } = this.overlayVisibilityTargetsAbortController, t = this.uiManager?.votOverlayView?.votButton?.container, n = this.uiManager?.votOverlayView?.votMenu?.container;
	if (!t || !n || !this.overlayVisibility) return;
	let r = this.overlayVisibility, { addMany: i } = Sg(e);
	Cg(i, t, r), Cg(i, n, r);
}
function zg(e) {
	if (!(e instanceof Node)) return !1;
	let t = this.uiManager?.votOverlayView, n = t?.votButton?.container, r = t?.votMenu?.container;
	return n instanceof Node && n.contains(e) || r instanceof Node && r.contains(e);
}
function Bg() {
	let e = this.data?.autoHideButtonDelay;
	return typeof e == "number" && Number.isFinite(e) ? e : gi;
}
function Vg() {
	this.resizeObserver?.disconnect(), this.overlayVisibilityTargetsAbortController?.abort(), this.overlayVisibilityTargetsAbortController = void 0, kc(this.site) && this.syncVolumeObserver?.disconnect();
}
//#endregion
//#region src/videoHandler/shared.ts
var Hg;
function Ug(e) {
	Hg = e;
}
//#endregion
//#region src/videoHandler/modules/init.ts
var Wg = null;
async function Gg() {
	Hg || (Wg ??= (async () => {
		try {
			Ug((await (await z("https://cloudflare-dns.com/cdn-cgi/trace", { timeout: 7e3 })).text()).split("\n").find((e) => e.startsWith("loc="))?.slice(4, 6).toUpperCase());
		} catch (e) {
			console.error("[VOT] Error getting country:", e);
		}
	})().finally(() => {
		Wg = null;
	}), await Wg);
}
async function Kg() {
	if (this.initialized) return;
	let e = this.isAudioContextSupported;
	this.data = await B.getValues({
		autoTranslate: !1,
		autoSubtitles: !1,
		dontTranslateLanguages: [Ti],
		enabledDontTranslateLanguages: !0,
		enabledAutoVolume: !0,
		enabledSmartDucking: !0,
		autoVolume: 15,
		buttonPos: "default",
		showVideoSlider: !0,
		syncVolume: !1,
		downloadWithName: Ea,
		sendNotifyOnComplete: !1,
		subtitlesMaxLength: 300,
		subtitlesSmartLayout: !0,
		highlightWords: !1,
		subtitlesFontSize: 20,
		subtitlesFontFamily: "default-sans",
		subtitlesOpacity: 20,
		subtitlesDownloadFormat: "srt",
		responseLanguage: Ti,
		responseLanguageSubtitles: "auto",
		defaultVolume: 100,
		onlyBypassMediaCSP: e,
		newAudioPlayer: e,
		showPiPButton: !1,
		translateAPIErrors: !0,
		translationService: pi,
		detectService: mi,
		translationHotkey: null,
		subtitlesHotkey: null,
		m3u8ProxyHost: ni,
		proxyWorkerHost: ii,
		translateProxyEnabled: 0,
		translateProxyEnabledDefault: !0,
		audioBooster: !1,
		useLivelyVoice: !1,
		autoHideButtonDelay: gi,
		useAudioDownload: Ea,
		compatVersion: "",
		account: {},
		localeHash: "",
		localeUpdatedAt: 0
	}), this.data.compatVersion !== "2025-05-09" && (this.data = await Wa(this.data), await B.set("compatVersion", _i));
	try {
		if (Ti === "en" && this.data?.enabledDontTranslateLanguages && Array.isArray(this.data?.dontTranslateLanguages) && this.data.dontTranslateLanguages.length === 1 && this.data.dontTranslateLanguages[0] === "en" && typeof this.data.responseLanguage == "string" && this.data.responseLanguage !== "en") {
			let e = this.data.responseLanguage;
			this.data.dontTranslateLanguages = [e], await B.set("dontTranslateLanguages", this.data.dontTranslateLanguages);
		}
	} catch {}
	this.uiManager.data = this.data, console.log("[VOT] data from db:", this.data), this.data.translateProxyEnabled, await Gg(), Hg && hi.includes(Hg) && this.data.translateProxyEnabledDefault && (this.data.translateProxyEnabled = 2), L.log("translateProxyEnabled", this.data.translateProxyEnabled, this.data.translateProxyEnabledDefault), L.log("Extension compatibility passed..."), await this.initVOTClient(), this.uiManager.initUI(), this.uiManager.initUIEvents(), this.uiManager.votOverlayView?.votButton?.container && (this.uiManager.votOverlayView.votButton.container.hidden = !0), this.createPlayer(), this.translateToLang = this.data.responseLanguage ?? "ru", this.initExtraEvents(), this.initialized = !0;
}
//#endregion
//#region src/subtitles/segmenter.ts
var qg = "und", Jg = /* @__PURE__ */ new Map(), Yg = /* @__PURE__ */ new Map(), Xg = (e) => {
	if (e) try {
		return Intl.getCanonicalLocales(e)[0];
	} catch {
		return;
	}
}, Zg = (e) => {
	let t = Xg(e);
	if (t) return Intl.Segmenter.supportedLocalesOf([t])[0];
}, Qg = (e, t) => {
	let n = Zg(e), r = `${t}:${n ?? qg}`, i = t === "sentence" ? Yg : Jg, a = i.get(r);
	if (a) return a;
	let o = new Intl.Segmenter(n, { granularity: t });
	return i.set(r, o), o;
}, $g = (e, t) => e ? Array.from(Qg(t, "word").segment(e), (e) => ({
	text: e.segment,
	index: e.index,
	isWordLike: !!e.isWordLike
})) : [], e_ = (e, t) => e ? Array.from(Qg(t, "sentence").segment(e), (e) => ({
	text: e.segment,
	index: e.index
})) : [], t_ = /\s/u, n_ = /^[,.:;!?%)\]}>»]/u, r_ = /[([{<«'"-]$/u, i_ = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/u, a_ = (e, t) => {
	let n = e.at(-1) ?? "", r = t[0] ?? "";
	return !(!n || !r || t_.test(n) || t_.test(r) || r_.test(n) || n_.test(r) || i_.test(n) && i_.test(r));
}, o_ = /\s/u, s_ = (e) => !!e.trim(), c_ = (e) => {
	let t = "", n = "", r = [];
	for (let i of e) {
		let e = i.text.trim();
		if (!e) continue;
		t && a_(n, e) && (t += " ");
		let a = t.length;
		t += e;
		let o = t.length;
		r.push({
			line: {
				...i,
				text: e
			},
			text: e,
			start: a,
			end: o
		}), n = e;
	}
	return {
		streamText: t,
		spans: r
	};
}, l_ = (e, t, n) => {
	let r = t, i = n;
	for (; r < i && o_.test(e[r] ?? "");) r += 1;
	for (; i > r && o_.test(e[i - 1] ?? "");) --i;
	return r >= i ? null : {
		start: r,
		end: i
	};
}, u_ = (e, t, n) => {
	let r = Math.max(t, e.start), i = Math.min(n, e.end);
	if (r >= i) return null;
	let a = r - e.start, o = i - e.start, s = e.text.slice(a, o);
	if (!s) return null;
	let c = Math.max(e.text.length, 1), l = e.line.startMs + Math.round(e.line.durationMs * a / c), u = e.line.startMs + Math.round(e.line.durationMs * o / c);
	return {
		text: s,
		startMs: l,
		durationMs: Math.max(0, u - l),
		isWordLike: s_(s)
	};
}, d_ = (e, t, n) => {
	let r = n.index, i = l_(e, r, r + n.text.length);
	if (!i) return null;
	let a = e.slice(i.start, i.end);
	if (!s_(a)) return null;
	let o = [], s = "0";
	for (let e of t) {
		let t = u_(e, i.start, i.end);
		t && (o.length === 0 && (s = e.line.speakerId), o.push(t));
	}
	if (!o.length) return null;
	let c = Math.min(...o.map((e) => e.startMs)), l = Math.max(...o.map((e) => e.startMs + Math.max(0, e.durationMs)));
	return {
		text: a,
		startMs: c,
		durationMs: Math.max(0, l - c),
		speakerId: s,
		tokens: o
	};
}, f_ = (e, t) => {
	let { streamText: n, spans: r } = c_(e);
	if (!n || !r.length) return [];
	let i = e_(n, t).map((e) => d_(n, r, e)).filter((e) => e !== null);
	return i.length ? i : r.map(({ line: e }) => e);
}, p_ = (e) => typeof e == "number" && Number.isFinite(e) ? e : 0, m_ = (e) => Math.max(0, p_(e)), h_ = (e, t, n) => {
	let r = e.subtitles;
	if (!Array.isArray(r) || r.length === 0) return null;
	let i = t ?? n;
	if (i) {
		let e = r.find((e) => e.language === i && typeof e.translatedFromLanguage == "string");
		if (e) return e;
		let t = r.find((e) => e.language === i);
		if (t) return t;
	}
	return r[0] ?? null;
}, g_ = (e) => "host" in e && "videoId" in e && "detectedLanguage" in e && "duration" in e && typeof e.host == "string" && typeof e.videoId == "string" && typeof e.detectedLanguage == "string" && typeof e.duration == "number", __ = (e) => {
	let t = F.getPoToken();
	if (!t) return e;
	let n = t;
	for (let e = 0; e < 10; e += 1) {
		let e;
		try {
			e = decodeURIComponent(n);
		} catch {
			break;
		}
		if (e === n) break;
		n = e;
	}
	let r = F.getDeviceParams(), i = typeof r == "string" ? r.replace(/^[?&]+/u, "") : "";
	try {
		let t = new URL(e);
		if (t.searchParams.set("potc", "1"), t.searchParams.set("pot", n), i) {
			let e = new URLSearchParams(i);
			for (let [n, r] of e.entries()) t.searchParams.set(n, r);
		}
		return t.toString();
	} catch {
		let t = e.includes("?") ? "&" : "?", r = i ? `&${i}` : "";
		return `${e}${t}potc=1&pot=${encodeURIComponent(n)}${r}`;
	}
}, v_ = (e, t) => e - t, y_ = (e, t) => e < t ? -1 : e > t ? 1 : 0, b_ = (e, t) => {
	let n = Math.min(e.length, t.length);
	for (let r = 0; r < n; r += 1) {
		let n = e[r] - t[r];
		if (n !== 0) return n;
	}
	return e.length === t.length ? 0 : e.length - t.length;
}, x_ = (e, t, n) => e ? t === 0 ? n ? 1 : 0 : n ? 0 : 1 : 0, S_ = (e, t, n, r) => !e || !t || n === r ? 0 : 1, C_ = (e, t) => {
	let n = e.source === "yandex", r = n ? 0 : 1, i = e.language === wi ? 0 : 1, a = !!e.translatedFromLanguage, o = t && e.language === t ? 0 : 1;
	return [
		r,
		i,
		x_(n, o, a),
		S_(n, a, e.translatedFromLanguage, t),
		n && !a ? o : 0,
		n ? 0 : Number(!!e.isAutoGenerated)
	];
}, w_ = (e, t, n) => ({
	descriptor: e,
	index: t,
	rank: C_(e, n),
	language: e.language,
	translatedFromLanguage: e.translatedFromLanguage ?? "",
	source: e.source,
	url: e.url,
	isAutoGenerated: Number(!!e.isAutoGenerated)
}), T_ = (e, t) => {
	let n = e.map((e, n) => w_(e, n, t));
	return n.sort((e, t) => {
		let n = b_(e.rank, t.rank);
		if (n !== 0) return n;
		let r = y_(e.language, t.language) || y_(e.translatedFromLanguage, t.translatedFromLanguage) || y_(e.source, t.source) || y_(e.url, t.url) || v_(e.isAutoGenerated, t.isAutoGenerated);
		return r === 0 ? v_(e.index, t.index) : r;
	}), n.map((e) => e.descriptor);
}, E_ = (e, t) => typeof e == "boolean" ? e : !!t.trim(), D_ = (e) => {
	if (!e || typeof e != "object") return null;
	let t = e, n = m_(t.start), r = m_(t.end);
	return r <= n ? null : {
		start: n,
		end: r,
		style: yu(t.style)
	};
}, O_ = (e) => {
	if (!e || typeof e != "object") return;
	let t = e, n = {};
	typeof t.rawText == "string" && (n.rawText = t.rawText);
	let r = Array.isArray(t.styledSpans) ? t.styledSpans.map(D_).filter((e) => e !== null) : [];
	return r.length && (n.styledSpans = r), t.vtt && typeof t.vtt == "object" && (n.vtt = t.vtt), t.ass && typeof t.ass == "object" && (n.ass = t.ass), Object.keys(n).length ? n : void 0;
}, k_ = (e) => {
	if (!e || typeof e != "object") return {
		text: "",
		startMs: 0,
		durationMs: 0,
		isWordLike: !1
	};
	let t = e, n = typeof t.text == "string" ? t.text : "";
	return {
		text: n,
		startMs: m_(t.startMs),
		durationMs: m_(t.durationMs),
		isWordLike: E_(t.isWordLike, n),
		style: yu(t.style)
	};
}, A_ = (e) => {
	if (!e || typeof e != "object") return {
		text: "",
		startMs: 0,
		durationMs: 0,
		speakerId: "0",
		tokens: []
	};
	let t = e, n = Array.isArray(t.tokens) ? t.tokens.map(k_) : [];
	return {
		text: typeof t.text == "string" ? t.text : "",
		startMs: m_(t.startMs),
		durationMs: m_(t.durationMs),
		speakerId: typeof t.speakerId == "string" ? t.speakerId : "0",
		tokens: n,
		metadata: O_(t.metadata)
	};
}, j_ = (e) => {
	if (!e || typeof e != "object") return {
		format: "json",
		subtitles: []
	};
	let t = e, n = Array.isArray(t.subtitles) ? t.subtitles.map(A_) : [];
	return {
		format: t.format ?? "json",
		subtitles: n
	};
}, M_ = (e, t) => !t || e.tStartMs + e.dDurationMs <= t.tStartMs ? Math.max(0, e.dDurationMs) : Math.max(0, t.tStartMs - e.tStartMs), N_ = (e, t, n) => {
	let r = [], i = "", a = n, o = "";
	for (let s = 0; s < t.length; s += 1) {
		let c = t[s], l = typeof c.utf8 == "string" ? c.utf8 : "";
		if (!l) continue;
		let u = Math.max(0, c.tOffsetMs ?? 0), d = n, f = t[s + 1];
		if (f?.tOffsetMs !== void 0) {
			let e = Math.max(u, f.tOffsetMs);
			d = Math.max(0, e - u), a = Math.max(a - d, 0);
		}
		let p = Math.max(0, a);
		f && (p = Math.max(0, d)), i && a_(o, l) && (r.push({
			text: " ",
			startMs: e.tStartMs + u,
			durationMs: 0,
			isWordLike: !1
		}), i += " "), r.push({
			text: l,
			startMs: e.tStartMs + u,
			durationMs: p,
			isWordLike: !!l.trim()
		}), i += l, o = l;
	}
	return {
		text: i,
		sourceTokens: r
	};
}, P_ = (e) => e.durationMs > 0, F_ = (e) => e.text ? cf(e.text) : e.tokens.length ? cf(e.tokens.map((e) => e.text).join("")) : "", I_ = (e, t, n) => {
	if (!e.length) return [];
	let r = Math.max(0, n), i = e.map((e) => Math.max(e.length, 1)), a = i.reduce((e, t) => e + t, 0), o = Array(i.length + 1).fill(0);
	for (let e = 0; e < i.length; e += 1) o[e + 1] = o[e] + i[e];
	let s = [];
	for (let n = 0; n < e.length; n += 1) {
		let i = Math.round(r * o[n] / a), c = n === e.length - 1 ? r : Math.round(r * o[n + 1] / a);
		s.push({
			startMs: t + i,
			durationMs: Math.max(0, c - i)
		});
	}
	return s;
}, L_ = (e) => {
	let t = [], n = 0;
	for (let r = 0; r < e.length; r += 1) e[r] === "\n" && (n < r && t.push({
		text: e.slice(n, r),
		startOffset: n,
		endOffset: r
	}), t.push({
		text: "\n",
		startOffset: r,
		endOffset: r + 1
	}), n = r + 1);
	return n < e.length && t.push({
		text: e.slice(n),
		startOffset: n,
		endOffset: e.length
	}), t.length ? t : [{
		text: e,
		startOffset: 0,
		endOffset: e.length
	}];
}, R_ = (e) => cf(e.map((e) => e.text).join("")), z_ = (e) => {
	let t = [];
	for (let n of e) {
		if (!n.text.includes("\n")) {
			t.push(n);
			continue;
		}
		let e = L_(n.text), r = I_(e.map((e) => e.text === "\n" ? "" : e.text), n.startMs, n.durationMs);
		for (let i = 0; i < e.length; i += 1) {
			let a = e[i], o = a.text === "\n";
			t.push({
				...n,
				text: a.text,
				startMs: r[i]?.startMs ?? n.startMs,
				durationMs: o ? 0 : r[i]?.durationMs ?? 0,
				isWordLike: o ? !1 : n.isWordLike
			});
		}
	}
	return t;
}, B_ = (e, t, n) => !n || !e.tokens.length || t.source === "youtube" || e.metadata?.styledSpans?.length && !e.tokens.some((e) => e.style) ? !1 : R_(e.tokens) === n, V_ = (e, t) => {
	let n = [];
	for (let r of e) {
		let e = cf(r.text);
		if (!e || !P_(r)) continue;
		let i = $g(e, t).filter((e) => e.isWordLike && e.text.trim());
		if (!i.length) continue;
		let a = I_(i.map((e) => e.text), r.startMs, r.durationMs);
		n.push(...a);
	}
	return n;
}, H_ = (e, t, n, r) => ({
	text: e.text,
	startMs: t,
	durationMs: n,
	isWordLike: e.isWordLike,
	style: Yd(r, e.index, e.index + e.text.length)
}), U_ = (e, t, n, r) => {
	let i = L_(e.text);
	if (i.length === 1 && i[0].text === e.text) return [H_(e, t, n, r)];
	let a = I_(i.map((e) => e.text === "\n" ? "" : e.text), t, n);
	return i.map((n, i) => {
		let o = n.text === "\n";
		return {
			text: n.text,
			startMs: a[i]?.startMs ?? t,
			durationMs: o ? 0 : a[i]?.durationMs ?? 0,
			isWordLike: !o && e.isWordLike,
			style: o ? void 0 : Yd(r, e.index + n.startOffset, e.index + n.endOffset)
		};
	});
}, W_ = (e) => e.reduce((e, t, n) => (t.isWordLike && t.text.trim() && e.push(n), e), []), G_ = (e, t) => {
	if (!t.length) return e;
	let n = W_(e);
	if (!n.length) return e;
	let r = n.length;
	for (let i = 0; i < r; i += 1) {
		let a = n[i], o = Math.floor(i * t.length / r), s = t[Math.min(o, t.length - 1)];
		e[a] = {
			...e[a],
			startMs: s.startMs,
			durationMs: s.durationMs
		};
	}
	return e;
}, K_ = (e, t, n) => {
	if (!n) return [];
	if (B_(e, t, n)) return z_(e.tokens);
	let r = t.language, i = e.metadata?.styledSpans ?? Jd(e.metadata?.rawText ?? e.text ?? n).styledSpans, a = $g(n, r);
	if (!a.length) return [];
	let o = I_(a.map((e) => e.text), e.startMs, e.durationMs), s = [];
	for (let t = 0; t < a.length; t += 1) {
		let n = a[t], r = o[t]?.startMs ?? e.startMs, c = o[t]?.durationMs ?? 0;
		s.push(...U_(n, r, c, i));
	}
	return G_(s, V_(e.tokens, r));
}, q_ = async (e, t) => {
	let n = await z(e, { timeout: 7e3 });
	return t === "vtt" || t === "srt" || t === "ass" ? Kf(await n.text(), t) : n.json();
}, J_ = (e, t) => t.source === "youtube" ? Z_.formatYoutubeSubtitles(e, !!t.isAutoGenerated) : (t.format === "srt" || t.format === "vtt" || t.format, qf(j_(e))), Y_ = (e, t) => {
	let n = Z_.autoMerge(e, t);
	return {
		...n,
		subtitles: Z_.processTokens(n, t)
	};
}, X_ = (e) => {
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r of e.subtitles ?? []) r.language && !n.has(r.language) && (n.add(r.language), t.push({
		source: "yandex",
		format: "json",
		language: r.language,
		url: r.url
	})), r.translatedLanguage && t.push({
		source: "yandex",
		format: "json",
		language: r.translatedLanguage,
		translatedFromLanguage: r.language,
		url: r.translatedUrl ?? r.url
	});
	return t;
}, Z_ = {
	processTokens(e, t) {
		let n = [];
		for (let r of e.subtitles) {
			let e = F_(r), i = K_(r, t, e);
			n.push({
				...r,
				text: e,
				tokens: i
			});
		}
		return n;
	},
	formatYoutubeSubtitles(e, t = !1) {
		let n = e.events ?? [];
		if (!n.length) return console.error("[VOT] Invalid YouTube subtitles format:", e), {
			format: "json",
			subtitles: []
		};
		let r = [];
		for (let e = 0; e < n.length; e += 1) {
			let i = n[e], a = i.segs;
			if (!a?.length) continue;
			let o = n[e + 1], s = M_(i, o), { text: c, sourceTokens: l } = N_(i, a, s), u = c.trim();
			u && r.push({
				text: u,
				startMs: i.tStartMs,
				durationMs: s,
				speakerId: "0",
				tokens: t ? l : []
			});
		}
		return {
			format: "json",
			subtitles: r
		};
	},
	autoMerge(e, t) {
		return !t.isAutoGenerated || e.subtitles.length < 2 || !e.subtitles.some((e) => e.tokens.length > 0) ? e : {
			...e,
			subtitles: f_(e.subtitles, t.language)
		};
	},
	async fetchSubtitles(e, t, n) {
		let r = Yl(e);
		if (!r && g_(e) && (r = h_(e, t, n)), !r) return {
			format: "json",
			subtitles: []
		};
		let { source: i, format: a } = r, { url: o } = r;
		i === "youtube" && (o = __(o));
		try {
			let e = Y_(J_(await q_(o, a), r), r);
			return L.log("[VOT] Processed subtitles:", e), e;
		} catch (e) {
			return console.error("[VOT] Failed to process subtitles:", e), {
				format: "json",
				subtitles: []
			};
		}
	},
	async getSubtitles(e, t) {
		let { host: n, url: r, detectedLanguage: i, videoId: a, duration: o, subtitles: s = [] } = t;
		try {
			let t = {
				videoData: {
					host: n,
					url: r,
					videoId: a,
					duration: o
				},
				requestLang: i
			}, c = await Promise.race([e.getSubtitles(t), new Promise((e, t) => {
				setTimeout(() => t(/* @__PURE__ */ Error("Timeout")), 5e3);
			})]);
			return L.log("[VOT] Subtitles response:", c), c.waiting && console.error("[VOT] Failed to get Yandex subtitles"), T_([...X_(c), ...s], i);
		} catch (e) {
			let t = "Error in getSubtitles function";
			throw e instanceof Error && e.message === "Timeout" && (t = "Failed to get Yandex subtitles: timeout"), console.error(`[VOT] ${t}`, e), e;
		}
	}
}, Q_ = /* @__PURE__ */ new WeakMap();
function $_(e) {
	let t = e.videoData;
	return e.getPreferredSubtitlesLanguage(t?.detectedLanguage, t?.responseLanguage);
}
function ev(e) {
	let t = e.videoData;
	if (!t?.videoId) return null;
	let n = t.detectedLanguage?.toLowerCase();
	if (!n || n === "auto") return null;
	let r = $_(e);
	return r ? e.getSubtitlesCacheKey(t.videoId, n, r) : null;
}
async function tv(e) {
	if (!e.videoData?.videoId) return !1;
	await e.videoManager.ensureDetectedLanguageForTranslation(e.videoData);
	let t = e.videoData.detectedLanguage?.toLowerCase();
	return !!(t && t !== "auto");
}
function nv(e) {
	return [
		e.source,
		e.format,
		e.language,
		e.translatedFromLanguage ?? "",
		e.isAutoGenerated ? "1" : "0",
		e.url
	].join("|");
}
function rv(e) {
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r of e) {
		let e = nv(r);
		t.has(e) || (t.add(e), n.push(r));
	}
	return n;
}
function iv(e, t) {
	let n = e.videoData;
	if (!n) throw Error("Video data is required to load subtitles");
	if (e.site.host !== "youtube" || !t) return n;
	let r = F.getSubtitles(t);
	return r.length ? {
		...n,
		subtitles: rv([...Array.isArray(n.subtitles) ? n.subtitles : [], ...r])
	} : n;
}
function av(e) {
	let t = (Q_.get(e) ?? 0) + 1;
	return Q_.set(e, t), t;
}
function ov(e, t) {
	return Q_.get(e) === t;
}
function sv(e, t) {
	return e.hasSubtitlesWidget() && e.subtitlesWidget?.setContent(null), t.downloadSubtitlesButton.hidden = !0, e.yandexSubtitles = null, e;
}
async function cv(e) {
	L.log("[onchange] subtitles", e);
	let t = av(this), n = this.uiManager.votOverlayView;
	if (!n?.subtitlesSelect || !n.downloadSubtitlesButton) return this;
	if (n.subtitlesSelect.setSelectedValue(e), e === "disabled") return sv(this, n);
	let r = Rh(e);
	if (r == null) return sv(this, n);
	let i = zh(this.subtitles, r);
	if (!i) return sv(this, n);
	let a = { ...i }, o = Mh(a.url, {
		translateProxyEnabled: this.data?.translateProxyEnabled,
		proxyWorkerHost: this.data?.proxyWorkerHost
	});
	o !== a.url && (a = {
		...a,
		url: o
	}, console.log(`[VOT] Subs proxied via ${a.url}`));
	let s = await Z_.fetchSubtitles(a);
	return ov(this, t) ? (this.yandexSubtitles = s, this.getSubtitlesWidget().setContent(this.yandexSubtitles, a.language), n.downloadSubtitlesButton.hidden = !1, this) : this;
}
async function lv() {
	let e = this.uiManager.votOverlayView;
	if (!e?.subtitlesSelect) return;
	let t = Hh(Lh(this.subtitles));
	e.subtitlesSelect.updateItems(t), await this.changeSubtitlesLang(Nh);
}
async function uv() {
	if (!await tv(this)) return (this.subtitlesCacheKey !== null || this.subtitles.length > 0) && (this.subtitles = [], this.subtitlesCacheKey = null, await this.updateSubtitlesLangSelect()), this;
	let e = ev(this);
	if (!e) return (this.subtitlesCacheKey !== null || this.subtitles.length > 0) && (this.subtitles = [], this.subtitlesCacheKey = null, await this.updateSubtitlesLangSelect()), this;
	if (this.subtitlesCacheKey === e) {
		let t = this.cacheManager.getSubtitles(e) !== void 0;
		if (this.subtitles.length > 0 || t) return this;
	}
	let t = this.cacheManager.getSubtitles(e);
	return t === void 0 ? (await this.loadSubtitles(), this) : (this.subtitles = Array.isArray(t) ? t : [], this.subtitlesCacheKey = e, await this.updateSubtitlesLangSelect(), this);
}
async function dv() {
	let e = this.uiManager.votOverlayView;
	if (!e?.subtitlesSelect) return this;
	try {
		await uv.call(this);
	} catch {
		return this;
	}
	let t = this.videoData?.detectedLanguage ?? this.translateFromLang, n = $_(this);
	if (!n) return this;
	let r = Jh(Lh(this.subtitles), t, n);
	return r == null || Uh(e.subtitlesSelect.selectedValues) === String(r) || await this.changeSubtitlesLang(String(r)), this;
}
async function fv() {
	let e = this.uiManager.votOverlayView;
	if (!e?.subtitlesSelect) return this;
	let t = Uh(e.subtitlesSelect.selectedValues);
	return t && t !== "disabled" ? (await this.changeSubtitlesLang(Nh), this) : (await this.enableSubtitlesForCurrentLangPair(), this);
}
async function pv() {
	if (!this.videoData?.videoId) {
		console.error(`[VOT] ${V.getDefault("VOTNoVideoIDFound")}`), this.subtitles = [], this.subtitlesCacheKey = null;
		return;
	}
	if (!await tv(this)) {
		this.subtitles = [], this.subtitlesCacheKey = null, await this.updateSubtitlesLangSelect();
		return;
	}
	let e = $_(this);
	if (!e) {
		this.subtitles = [], this.subtitlesCacheKey = null, await this.updateSubtitlesLangSelect();
		return;
	}
	let t = this.getSubtitlesCacheKey(this.videoData.videoId, this.videoData.detectedLanguage, e);
	try {
		let n = this.cacheManager.getSubtitles(t);
		if (!n) {
			let r = this.subtitlesLoadPromises.get(t);
			if (r === void 0) {
				let n = iv(this, e);
				r = Z_.getSubtitles(this.votClient, n), this.subtitlesLoadPromises.set(t, r);
			}
			try {
				n = await r, n = Array.isArray(n) ? n : [], this.cacheManager.setSubtitles(t, n);
			} finally {
				this.subtitlesLoadPromises.get(t) === r && this.subtitlesLoadPromises.delete(t);
			}
		}
		this.subtitles = Array.isArray(n) ? n : [], this.subtitlesCacheKey = t;
	} catch (e) {
		console.error("[VOT] Failed to load subtitles:", e), this.subtitles = [], this.subtitlesCacheKey = null;
	}
	await this.updateSubtitlesLangSelect();
}
//#endregion
//#region src/index.ts
new Set(fn);
var mv = Promise.resolve(), hv = class {
	video;
	container;
	site;
	translateFromLang = "auto";
	translateToLang = Ti;
	data;
	videoData;
	firstPlay = !0;
	audioContext;
	votClient;
	audioPlayer;
	abortController;
	actionsAbortController;
	actionsGeneration = 0;
	notifier = new Em();
	cacheManager;
	votSessionStorage = new ra();
	subtitlesLoadPromises = /* @__PURE__ */ new Map();
	downloadTranslationUrl = null;
	isRefreshingTranslation = !1;
	autoRetry;
	votOpts;
	volumeOnStart;
	volumeLinkState = {
		initialized: !1,
		lastVideoPercent: 0,
		lastTranslationPercent: 0
	};
	internalVideoVolumeSetAt = 0;
	internalVideoVolumeSetPercent = null;
	internalVideoVolumeSuppressionMs = 250;
	internalVideoVolumeSetHistory = [];
	internalVideoVolumeSetHistoryLimit = 48;
	smartVolumeDuckingInterval;
	smartVolumeDuckingTarget = .2;
	smartVolumeDuckingBaseline;
	smartVolumeLastApplied;
	smartVolumeLastTickAt = 0;
	smartVolumeLastSoundAt = 0;
	smartVolumeRmsMissingSinceAt = null;
	smartVolumeRmsEnvelope = 0;
	smartVolumeSpeechGateOpen = !1;
	smartVolumeIsDucked = !1;
	longWaitingResCount = 0;
	hadAsyncWait = !1;
	subtitles = [];
	subtitlesCacheKey = null;
	subtitlesWidget;
	activeTranslation = null;
	stopTranslatePromise = null;
	interactionChecker;
	uiManager;
	overlayVisibility;
	overlayVisibilityTargetsAbortController;
	translationOrchestrator;
	lifecycleController;
	translationHandler;
	videoManager;
	yandexSubtitles = null;
	resizeObserver;
	syncVolumeObserver;
	initialized = !1;
	mountCache;
	errorTranslationCache = /* @__PURE__ */ new Map();
	getFullscreenOverlayRoot() {
		let e = document;
		return Co(e.fullscreenElement ?? e.webkitFullscreenElement, [this.container]);
	}
	getOverlayMountPoints(e = this.container) {
		let t = this.getFullscreenOverlayRoot(), { base: n, root: r, portalContainer: i, subtitlesMountContainer: a } = Ao({
			container: e,
			site: this.site,
			fullscreenRoot: t
		}), o = this.mountCache;
		return o?.container === e && o.base === n && o.subtitlesMountContainer === a && o.fullscreenRoot === t && (o.root.isConnected ?? document.documentElement.contains(o.root)) ? {
			root: o.root,
			portalContainer: o.portalContainer,
			subtitlesMountContainer: o.subtitlesMountContainer,
			fullscreenRoot: o.fullscreenRoot
		} : (this.mountCache = {
			container: e,
			base: n,
			root: r,
			portalContainer: i,
			subtitlesMountContainer: a,
			fullscreenRoot: t
		}, {
			root: r,
			portalContainer: i,
			subtitlesMountContainer: a,
			fullscreenRoot: t
		});
	}
	getOverlayMount(e = this.container) {
		let { root: t, portalContainer: n, subtitlesMountContainer: r, fullscreenRoot: i } = this.getOverlayMountPoints(e);
		return {
			root: t,
			portalContainer: n,
			subtitlesMountContainer: r,
			tooltipLayoutRoot: i ?? this.tooltipLayoutRoot
		};
	}
	getTranslationCacheKey(e, t, n, r) {
		let i = this.getRequestLangForTranslation(t, n), a = this.isLivelyVoiceAllowed(i, n) && this.data?.useLivelyVoice, o = r == null ? "" : Pi(r);
		return `${e}_${i}_${n}_${a}_${o ? Fi(o) : "0"}`;
	}
	getSubtitlesCacheKey(e, t, n) {
		return `${e}_${t}_${n}_${!!this.data?.useLivelyVoice}`;
	}
	getPreferredSubtitlesLanguage(e = this.videoData?.detectedLanguage ?? "auto", t = this.videoData?.responseLanguage ?? this.translateToLang, n = this.data?.responseLanguageSubtitles) {
		return qh(n, e, t);
	}
	isActionStale(e) {
		return e ? this.actionsGeneration !== e.gen || this.videoData?.videoId !== e.videoId : !1;
	}
	updateVOTClientRequestSignal() {
		this.votClient && (this.votClient.fetchOpts = {
			...this.votClient.fetchOpts,
			signal: this.actionsAbortController.signal
		});
	}
	resetActionsAbortController(e) {
		try {
			this.actionsAbortController?.abort(e);
		} catch {}
		this.actionsAbortController = new AbortController(), this.actionsGeneration++, this.updateVOTClientRequestSignal();
	}
	constructor(e, t, n) {
		L.log("[VideoHandler] add video:", e, "container:", t, this), this.video = e, this.container = t, this.site = n, this.abortController = new AbortController(), this.actionsAbortController = new AbortController(), this.cacheManager = new ia(), this.interactionChecker = hm(), this.interactionChecker.start(), this.uiManager = new sm({
			mount: this.getOverlayMount(t),
			data: this.data,
			videoHandler: this,
			intervalIdleChecker: this.interactionChecker
		}), this.overlayVisibility = new cm({
			checker: this.interactionChecker,
			getOverlayView: () => this.uiManager.votOverlayView ?? null,
			getAutoHideDelay: () => this.getAutoHideDelay(),
			isInteractiveNode: (e) => this.isOverlayInteractiveNode(e)
		}), this.translationOrchestrator = new Rs({
			isFirstPlay: () => this.firstPlay,
			setFirstPlay: (e) => {
				this.firstPlay = e;
			},
			isAutoTranslateEnabled: () => !!this.data?.autoTranslate,
			getVideoId: () => this.videoData?.videoId,
			scheduleAutoTranslate: () => this.runAutoTranslate(),
			isMobileYouTubeMuted: () => this.site.host === "youtube" && this.site.additionalData === "mobile" && this.video.muted,
			setMuteWatcher: (e) => {
				let t = !1, n = () => {
					t || (t = !0, this.video.removeEventListener("volumechange", r), e());
				}, r = () => {
					this.video.muted || n();
				};
				this.video.addEventListener("volumechange", r, { signal: this.abortController.signal }), queueMicrotask(() => {
					this.video.muted || n();
				});
			}
		}), this.lifecycleController = new Hs(Us(this, (e) => this.getOverlayMount(e))), this.translationHandler = new Ls(this), this.videoManager = new Gc(this);
	}
	getSubtitlesWidget() {
		if (!this.subtitlesWidget) {
			let { subtitlesMountContainer: e } = this.getOverlayMountPoints();
			this.subtitlesWidget = new bd(this.video, e, this.interactionChecker, this.tooltipLayoutRoot), this.applySavedSubtitlesWidgetSettings(this.subtitlesWidget);
		}
		return this.subtitlesWidget;
	}
	applySavedSubtitlesWidgetSettings(e) {
		this.data && (e.setSmartLayout(typeof this.data.subtitlesSmartLayout == "boolean" ? this.data.subtitlesSmartLayout : !0), typeof this.data.subtitlesMaxLength == "number" && e.setMaxLength(this.data.subtitlesMaxLength), typeof this.data.highlightWords == "boolean" && e.setHighlightWords(this.data.highlightWords), typeof this.data.subtitlesFontSize == "number" && e.setFontSize(this.data.subtitlesFontSize), typeof this.data.subtitlesFontFamily == "string" && e.setFontFamily(this.data.subtitlesFontFamily), typeof this.data.subtitlesOpacity == "number" && e.setOpacity(this.data.subtitlesOpacity));
	}
	hasSubtitlesWidget() {
		return !!this.subtitlesWidget;
	}
	resetSubtitlesWidget() {
		this.hasSubtitlesWidget() && (this.subtitlesWidget?.release(), this.subtitlesWidget = void 0);
	}
	get uiRoot() {
		return this.getOverlayMountPoints().root;
	}
	get portalContainer() {
		return this.getOverlayMountPoints().portalContainer;
	}
	get tooltipLayoutRoot() {
		switch (this.site.host) {
			case "kickstarter": return document.getElementById("react-project-header") ?? void 0;
			case "custom": return;
			default: return this.container;
		}
	}
	getEventContainer() {
		return this.site.eventSelector ? document.querySelector(this.site.eventSelector) ?? this.container : this.container;
	}
	async runAutoTranslate() {
		await this.videoManager.videoValidator(), await this.uiManager.handleTranslationBtnClick();
	}
	getAudioContext() {
		if (this.audioContext) return this.audioContext;
		if (this.isAudioContextSupported) try {
			return this.audioContext = Ur(), this.audioContext;
		} catch (e) {
			console.warn("[VOT] Failed to init AudioContext, falling back:", e);
			return;
		}
	}
	get isAudioContextSupported() {
		return globalThis.AudioContext !== void 0 || globalThis.webkitAudioContext !== void 0;
	}
	getPreferAudio() {
		return !this.getAudioContext() || !this.data || !this.data.newAudioPlayer || this.videoData?.isStream ? !0 : this.data.newAudioPlayer && !this.data.onlyBypassMediaCSP ? !1 : !this.site.needBypassCSP;
	}
	createPlayer() {
		let e = this.getPreferAudio();
		return L.log("preferAudio:", e), this.audioPlayer = new Jr({
			video: this.video,
			debug: !1,
			fetchFn: z,
			fetchOpts: { timeout: 0 },
			preferAudio: e
		}), this;
	}
	isLikelyInternalVideoVolumeChange(e) {
		let t = Date.now(), n = this.internalVideoVolumeSetHistory;
		if (n.length > 0) {
			let r = 0, i = !1;
			for (let a of n) t - a.at > a.suppressMs || (n[r++] = a, !i && Math.abs(e - a.percent) <= 1 && (i = !0));
			return n.length = r, i;
		}
		return this.internalVideoVolumeSetPercent === null || t - this.internalVideoVolumeSetAt > this.internalVideoVolumeSuppressionMs ? !1 : Math.abs(e - this.internalVideoVolumeSetPercent) <= 1;
	}
	callModule(e, ...t) {
		return e.call(this, ...t);
	}
	callModuleAsync(e, ...t) {
		return e.call(this, ...t);
	}
	init() {
		return Kg.call(this);
	}
	async initVOTClient() {
		let e = Eh(this.data ?? {}), t = this.data?.translateProxyEnabled === 1 ? ri : e ? Th(this.data?.proxyWorkerHost) : ti;
		this.votOpts = {
			fetchFn: z,
			fetchOpts: {
				signal: this.actionsAbortController.signal,
				forceGmXhr: Oh({
					...this.data,
					gmXhrSupported: Ea
				})
			},
			apiToken: this.data?.account?.token,
			hostVOT: ai,
			host: t
		}, this.votClient = new (e ? Wt : Ut)(this.votOpts), this.votClient.sessions = await this.votSessionStorage.restore(t, this.votClient.sessions);
		let n = this.votClient.getSession.bind(this.votClient);
		return this.votClient.getSession = async (e) => {
			let r = await n(e);
			return await this.votSessionStorage.persist(t, this.votClient.sessions), r;
		}, this;
	}
	transformBtn(e, t) {
		return this.uiManager.transformBtn(e, t), this;
	}
	hasActiveSource() {
		return !!this.audioPlayer?.player?.src;
	}
	initExtraEvents() {
		return this.callModule(Lg);
	}
	refreshOverlayMount() {
		this.mountCache = void 0;
		let e = this.getOverlayMount(this.container), t = !ip(this.uiManager.mount, e);
		this.uiManager.updateMount(e), t && this.rebindOverlayVisibilityTargets();
	}
	rebindOverlayVisibilityTargets = Rg;
	setCanPlay() {
		return this.lifecycleController.setCanPlay();
	}
	isOverlayInteractiveNode(e) {
		return this.callModule(zg, e);
	}
	getAutoHideDelay() {
		return this.callModule(Bg);
	}
	changeSubtitlesLang = cv;
	updateSubtitlesLangSelect = lv;
	ensureSubtitlesForCurrentLangPair = uv;
	loadSubtitles = pv;
	enableSubtitlesForCurrentLangPair() {
		return this.callModuleAsync(dv);
	}
	toggleSubtitlesForCurrentLangPair() {
		return this.callModuleAsync(fv);
	}
	getRequestLangForTranslation(e, t) {
		return this.data?.useLivelyVoice && this.data?.account?.token && t === "ru" ? "en" : e;
	}
	isLivelyVoiceAllowed(e = this.videoData?.detectedLanguage ?? "auto", t = this.videoData?.responseLanguage ?? this.translateToLang) {
		return !(this.getRequestLangForTranslation(e, t) !== "en" || t !== "ru" || !this.data?.account?.token);
	}
	getVideoVolume() {
		return this.videoManager.getVideoVolume();
	}
	setVideoVolume(e, t = {}) {
		let n = bc(e), r = typeof t.suppressSyncMs == "number" && Number.isFinite(t.suppressSyncMs) ? Math.max(0, t.suppressSyncMs) : this.internalVideoVolumeSuppressionMs, i = Date.now(), a = _c(n);
		return this.internalVideoVolumeSetAt = i, this.internalVideoVolumeSetPercent = a, this.internalVideoVolumeSetHistory.push({
			at: i,
			percent: a,
			suppressMs: r
		}), this.internalVideoVolumeSetHistory.length > this.internalVideoVolumeSetHistoryLimit && this.internalVideoVolumeSetHistory.splice(0, this.internalVideoVolumeSetHistory.length - this.internalVideoVolumeSetHistoryLimit), this.videoManager.setVideoVolume(n), this;
	}
	onVideoVolumeSliderSynced(e) {
		let t = W(e);
		if (!this.volumeLinkState.initialized) {
			Pm(this.volumeLinkState, t);
			return;
		}
		this.data?.syncVolume && this.hasActiveSource() && !this.isLikelyInternalVideoVolumeChange(t) || Pm(this.volumeLinkState, t);
	}
	onTranslationVolumeSliderSynced(e) {
		if (!this.volumeLinkState.initialized) {
			Fm(this.volumeLinkState, e);
			return;
		}
		Fm(this.volumeLinkState, e);
	}
	resetVolumeLinkState(e, t) {
		Pm(this.volumeLinkState, e), Fm(this.volumeLinkState, t), this.volumeLinkState.initialized = !0;
	}
	clearVolumeLinkState() {
		this.volumeLinkState.initialized = !1, this.volumeLinkState.lastVideoPercent = 0, this.volumeLinkState.lastTranslationPercent = 0;
	}
	isMuted() {
		return this.videoManager.isMuted();
	}
	syncVideoVolumeSlider() {
		this.videoManager.syncVideoVolumeSlider();
	}
	setSelectMenuValues(e, t) {
		this.videoManager.setSelectMenuValues(e, t);
	}
	syncVolumeWrapper(e, t) {
		let n = this.uiManager.votOverlayView;
		if (!n?.isInitialized()) return;
		let r = n.videoVolumeSlider, i = n.translationVolumeSlider;
		if (!r || !i) return;
		let { nextVideo: a, nextTranslation: o } = Lm({
			state: this.volumeLinkState,
			fromType: e,
			newVolume: t,
			currentVideo: Number(r.value),
			currentTranslation: Number(i.value),
			translationMin: i.min,
			translationMax: i.max
		});
		if (typeof o == "number") {
			i.value = o, this.audioPlayer?.player && (this.audioPlayer.player.volume = o / 100);
			return;
		}
		typeof a == "number" && (r.value = a, this.setVideoVolume(a / 100));
	}
	getVideoData() {
		return this.videoManager.getVideoData();
	}
	videoValidator() {
		return this.videoManager.videoValidator();
	}
	stopTranslate() {
		if (this.stopTranslatePromise !== null) return this.stopTranslatePromise;
		let e = (async () => {
			if (this.audioPlayer?.player) {
				try {
					this.audioPlayer.player.removeVideoEvents(), this.audioPlayer.player.src = "", await this.audioPlayer.player.clear();
				} catch (e) {
					L.log("[stopTranslate] audioPlayer cleanup error", e);
				}
				L.log("audioPlayer after stopTranslate", this.audioPlayer);
			}
			this.activeTranslation = null;
			let e = this.uiManager.votOverlayView;
			e && (e.videoVolumeSlider && (e.videoVolumeSlider.hidden = !0), e.translationVolumeSlider && (e.translationVolumeSlider.hidden = !0), e.downloadTranslationButton && (e.downloadTranslationButton.hidden = !0)), this.downloadTranslationUrl = null, this.longWaitingResCount = 0, this.hadAsyncWait = !1, this.transformBtn("none", V.get("translateVideo")), L.log(`Volume on start: ${this.volumeOnStart}`);
			let t = typeof this.smartVolumeDuckingBaseline == "number" ? this.smartVolumeDuckingBaseline : this.volumeOnStart;
			mh(this, { restoreVolume: t }), this.volumeOnStart = void 0, this.autoRetry !== void 0 && (clearTimeout(this.autoRetry), this.autoRetry = void 0), this.resetActionsAbortController("stopTranslate");
		})().finally(() => {
			this.stopTranslatePromise === e && (this.stopTranslatePromise = null);
		});
		return this.stopTranslatePromise = e, e;
	}
	waitForPendingStopTranslate() {
		return this.stopTranslatePromise ?? mv;
	}
	async updateTranslationErrorMsg(e, t) {
		if (t?.aborted) return;
		let n = V.get("translationTake"), r = V.lang;
		this.longWaitingResCount = e === V.get("translationTakeAboutMinute") ? this.longWaitingResCount + 1 : 0, L.log("longWaitingResCount", this.longWaitingResCount), this.longWaitingResCount > 5 && (e = new U("TranslationDelayed")), L.log("updateTranslationErrorMsg message", e);
		let i = await this.resolveTranslationErrorDisplayMessage(e, n, r, t);
		t?.aborted || i === null || (this.transformBtn("error", i), !t?.aborted && [
			"Подготавливаем перевод",
			"Видео передано в обработку",
			"Ожидаем перевод видео",
			"Загружаем переведенное аудио"
		].includes(e) && this.uiManager.votOverlayView?.votButton && (this.uiManager.votOverlayView.votButton.loading = !0));
	}
	async resolveTranslationErrorDisplayMessage(e, t, n, r) {
		return e?.name === "VOTLocalizedError" ? e.localizedMessage : e instanceof Error ? e.message : this.shouldTranslateErrorMessage(e, t, n) ? await this.getTranslatedErrorMessage(e, n, r) : this.stringifyTranslationError(e);
	}
	shouldTranslateErrorMessage(e, t, n) {
		return !!this.data?.translateAPIErrors && n !== "ru" && !e?.includes(t);
	}
	stringifyTranslationError(e) {
		return Array.isArray(e) ? e.join("\n") : String(e ?? "");
	}
	async getTranslatedErrorMessage(e, t, n) {
		let r = this.uiManager.votOverlayView;
		if (!r?.votButton) return null;
		let i = Array.isArray(e) ? e.join(" ") : String(e), a = `${t}:${i}`, o = this.errorTranslationCache.get(a);
		if (o) return o;
		r.votButton.loading = !0;
		let s = await cc(i, "ru", t);
		if (n?.aborted) return null;
		let c = Array.isArray(s) ? s.join("\n") : String(s);
		return this.errorTranslationCache.set(a, c), this.trimErrorTranslationCache(), c;
	}
	trimErrorTranslationCache() {
		if (this.errorTranslationCache.size <= 50) return;
		let e = this.errorTranslationCache.keys().next().value;
		e && this.errorTranslationCache.delete(e);
	}
	afterUpdateTranslation(e) {
		let t = this.uiManager.votOverlayView;
		if (!t?.votButton) return;
		let n = t.votButton.container.dataset.status === "success";
		t.videoVolumeSlider && (t.videoVolumeSlider.hidden = !this.data?.showVideoSlider || !n), t.translationVolumeSlider && (t.translationVolumeSlider.hidden = !n), t.videoVolumeSlider && t.translationVolumeSlider ? (this.volumeLinkState.lastVideoPercent = Number(t.videoVolumeSlider.value), this.volumeLinkState.lastTranslationPercent = Number(t.translationVolumeSlider.value), this.volumeLinkState.initialized = !0) : this.volumeLinkState.initialized = !1, this.videoData && !this.videoData.isStream && (t.downloadTranslationButton && (t.downloadTranslationButton.hidden = !1), this.downloadTranslationUrl = e), L.log("afterUpdateTranslation downloadTranslationUrl", this.downloadTranslationUrl), this.data?.sendNotifyOnComplete && this.hadAsyncWait && n && (this.notifier.translationCompleted(globalThis.location.hostname), this.hadAsyncWait = !1);
	}
	validateAudioUrl(e, t) {
		return this.callModuleAsync(ig, e, t);
	}
	scheduleTranslationRefresh() {
		this.callModule(ag);
	}
	refreshTranslationAudio = cg;
	proxifyAudio(e) {
		return this.callModule(lg, e);
	}
	unproxifyAudio(e) {
		return this.callModule(ug, e);
	}
	handleProxySettingsChanged = dg;
	isMultiMethodS3(e) {
		return this.callModule(fg, e);
	}
	updateTranslation = hg;
	translateFunc(e, t, n, r, i) {
		return yg.call(this, e, t, n, r, i);
	}
	isYouTubeHosts() {
		return this.callModule(bg);
	}
	setupAudioSettings() {
		return this.callModule(yh);
	}
	applyManualVideoVolumeOverride(e) {
		return this.callModule(bh, e);
	}
	stopTranslation = async () => {
		this.translationOrchestrator?.reset(), this.overlayVisibility?.cancel(), await this.stopTranslate(), this.syncVideoVolumeSlider();
	};
	handleSrcChanged() {
		return this.lifecycleController.handleSrcChanged();
	}
	async release() {
		L.log("[VideoHandler] release"), this.initialized = !1;
		try {
			await this.stopTranslation();
		} catch (e) {
			L.log("[VideoHandler] stopTranslation failed during release", e);
		}
		this.lifecycleController?.teardown(), this.abortController?.abort(), this.abortController = new AbortController(), this.overlayVisibility?.release(), this.releaseExtraEvents(), this.hasSubtitlesWidget() && (this.subtitlesWidget?.release(), this.subtitlesWidget = void 0), this.interactionChecker?.destroy(), this.uiManager.release();
	}
	collectReportInfo() {
		let e = Wp(), t = this.videoData?.detectedLanguage ?? "unknown", n = this.videoData?.responseLanguage ?? "unknown", r = `<details>
<summary>Autogenerated by VOT:</summary>
<ul>
  <li>OS: ${e.os}</li>
  <li>Browser: ${e.browser}</li>
  <li>Loader: ${e.loader}</li>
  <li>Script version: ${e.scriptVersion}</li>
  <li>URL: <code>${e.url}</code></li>
  <li>Lang: <code>${t}</code> -> <code>${n}</code> (Lively voice: ${this.data?.useLivelyVoice ?? !1} | Audio download: ${this.data?.useAudioDownload ?? !1})</li>
  <li>Player: ${this.data?.newAudioPlayer ? "New" : "Old"} (CSP only: ${this.data?.onlyBypassMediaCSP ?? !1})</li>
  <li>Proxying mode: ${this.data?.translateProxyEnabled ?? 0}</li>
</ul>
</details>`;
		return {
			assignees: "ilyhalight",
			template: `1-bug-report-${V.lang === "ru" ? "ru" : "en"}.yml`,
			os: e.os,
			"script-version": e.scriptVersion,
			"additional-info": r
		};
	}
	releaseExtraEvents = Vg;
}, gv = new Nm(hm()), _v = /* @__PURE__ */ new WeakMap(), vv = null, yv = Qr();
function bv() {
	return {
		frame: fo() ? "iframe" : "top",
		host: globalThis.location.hostname || "unknown",
		path: globalThis.location.pathname || "/"
	};
}
function xv(e, t) {
	let n = bv(), r = {
		host: n.host,
		path: n.path
	};
	t && Object.assign(r, t), console.log(`[VOT][bootstrap][${n.frame}] ${e}`, r);
}
function Sv() {
	return vv ||= Rr(), vv;
}
function Cv(e, t) {
	if (L.log("findContainer", e, t), !e.selector) return L.log("findContainer without selector, using parentElement"), t.parentElement;
	let n = Oo(t, e.selector);
	return e.shadowRoot ? L.log("findContainer with site.shadowRoot", n) : L.log("findContainer without shadowRoot", n), n;
}
async function wv() {
	let e = yo({
		isIframe: fo(),
		href: String(globalThis.location.href || ""),
		origin: globalThis.location.origin,
		authOrigin: ci
	});
	if (e === "skip") {
		xv("Skipping bootstrap for non-runnable iframe");
		return;
	}
	ei(), xv("Loading extension", { mode: e }), e === "auth-eager" ? await ho("auth-page", xv) : xv("Lazy bootstrap enabled; waiting for video detection"), _o({
		videoObserver: gv,
		videosWrappers: _v,
		ensureRuntimeActivated: (e) => ho(e, xv),
		getServicesCached: Sv,
		findContainer: Cv,
		createVideoHandler: (e, t, n) => new hv(e, t, n)
	}), gv.enable();
}
function Tv() {
	return yv.status === "booting" || yv.status === "booted" ? (xv("bootstrap already initialized, skipping duplicate run", { status: yv.status }), yv.promise ?? Promise.resolve()) : (yv.status = "booting", yv.promise = (async () => {
		try {
			await wv(), yv.status = "booted";
		} catch (e) {
			yv.status = "failed", yv.error = e, console.error("[VOT]", e);
		}
	})(), yv.promise);
}
Tv();
//#endregion
export { hv as VideoHandler, Tv as bootstrapContentScript, Hg as countryCode, Wp as getEnvironmentInfo };
