//#region src/utils/debug.ts
var e = () => {}, t = {
	log: e,
	warn: e,
	error: e
};
//#endregion
//#region src/utils/errors.ts
function n(e) {
	let t = /* @__PURE__ */ new WeakSet();
	try {
		return JSON.stringify(e, (e, n) => typeof n != "object" || !n ? n : t.has(n) ? "[Circular]" : (t.add(n), n)) ?? null;
	} catch {
		return null;
	}
}
function r(e) {
	let t = [
		e?.data?.message,
		e?.error?.message,
		e?.message
	];
	for (let e of t) if (typeof e == "string" && e) return e;
	return null;
}
function i(e, t) {
	let i = r(e);
	if (i) return i;
	let a = n(e);
	if (a && a !== "{}") return a;
	let o = e.constructor?.name;
	return o ? `[${o}]` : t;
}
function a(e, t) {
	return typeof e == "number" || typeof e == "boolean" || typeof e == "bigint" ? `${e}` : typeof e == "symbol" ? e.description ? `Symbol(${e.description})` : "Symbol" : typeof e == "function" ? e.name ? `[Function ${e.name}]` : "[Function]" : t;
}
function o(e, t = "Unknown error") {
	return e instanceof Error ? e.message || t : typeof e == "string" ? e || t : e == null ? t : typeof e == "object" ? i(e, t) : a(e, t);
}
typeof Uint8Array.prototype.toBase64 == "function" && Uint8Array.prototype.toBase64;
var s = Uint8Array.fromBase64, ee = /[-_]/;
function c(e) {
	let t = String(e).replaceAll(/\s+/g, ""), n = t.length % 4;
	if (n === 1) throw TypeError("Invalid base64 input.");
	return n === 0 ? t : t + "=".repeat(4 - n);
}
function te(e) {
	let t = c(e), n = t.replaceAll("-", "+").replaceAll("_", "/");
	if (typeof s == "function") {
		let e = ee.test(t);
		return s(e ? n : t, e ? { alphabet: "base64" } : void 0);
	}
	let r = globalThis.atob;
	if (typeof r != "function") throw TypeError("Base64 decoder is not available in this environment.");
	let i = r(n), a = new Uint8Array(i.length);
	for (let e = 0; e < i.length; e += 1) a[e] = i.charCodeAt(e);
	return a;
}
var l = 1e7, ne = 12, u = 2;
function d(e) {
	return typeof e == "object" && !!e;
}
function f(e) {
	return p(e) === "[object Object]";
}
function p(e) {
	try {
		return Object.prototype.toString.call(e);
	} catch {
		return null;
	}
}
function m(e) {
	return p(e) === "[object ArrayBuffer]";
}
function re(e) {
	try {
		let t = e?.constructor?.name;
		return typeof t == "string" ? t : null;
	} catch {
		return null;
	}
}
function h(e, t) {
	try {
		let n = e?.[t];
		return typeof n == "string" ? n : null;
	} catch {
		return null;
	}
}
function ie(e) {
	if (p(e) === "[object Blob]") return !0;
	if (!e || typeof e != "object") return !1;
	try {
		let t = e, n = typeof t.arrayBuffer == "function", r = typeof t.slice == "function", i = typeof t.size == "number", a = typeof t.type == "string";
		return (n || r) && i && a;
	} catch {
		return !1;
	}
}
function g(e) {
	if (typeof e != "number" || !Number.isFinite(e)) return null;
	let t = Math.trunc(e);
	return t < 0 || t > l ? null : t;
}
function _(e) {
	return typeof e != "number" || !Number.isFinite(e) ? null : Math.trunc(e) & 255;
}
function v(e) {
	let t = e.length;
	if (t > l) return null;
	let n = new Uint8Array(t);
	for (let r = 0; r < t; r += 1) {
		let t = _(e[r]);
		if (t === null) return null;
		n[r] = t;
	}
	return n;
}
function ae(e) {
	return new Uint8Array(e.buffer, e.byteOffset, e.byteLength);
}
function oe(e) {
	return ae(e).slice();
}
function se(e) {
	if (e === "") return null;
	let t = Number(e);
	return !Number.isFinite(t) || !Number.isInteger(t) || t < 0 ? null : t;
}
function ce(e) {
	if (!d(e)) return !1;
	let t = e;
	return t.__votExtBody === !0 && typeof t.b64 == "string";
}
function y(e, t = 0) {
	if (t > u || !d(e)) return null;
	let n = e;
	if (m(e)) return new Uint8Array(e);
	try {
		if (ArrayBuffer.isView(e)) return oe(e);
	} catch {}
	return Array.isArray(e) ? v(e) : le(n) || ue(n) || de(n, e, t) || fe(n) || (f(e) ? pe(n) : null);
}
function le(e) {
	let t = [
		e.type === "Buffer" && Array.isArray(e.data) ? e.data : null,
		Array.isArray(e.data) ? e.data : null,
		Array.isArray(e.bytes) ? e.bytes : null
	];
	for (let e of t) {
		if (!e) continue;
		let t = v(e);
		if (t) return t;
	}
	return null;
}
function ue(e) {
	let t = [e.b64, e.base64];
	for (let e of t) if (typeof e == "string") try {
		return te(e);
	} catch {}
	return null;
}
function de(e, t, n) {
	let r = g(e.byteLength), i = g(e.byteOffset ?? 0);
	if (r === null || i === null) return null;
	let a = e.buffer;
	if (m(a)) try {
		return new Uint8Array(a, i, r).slice();
	} catch {}
	if (!a || a === t) return null;
	let o = y(a, n + 1);
	if (!o || i > o.byteLength) return null;
	let s = Math.min(o.byteLength, i + r);
	return o.slice(i, s);
}
function fe(e) {
	let t = g(e.length);
	if (t === null) return null;
	let n = e, r = new Uint8Array(t);
	for (let e = 0; e < t; e += 1) {
		let t = _(n[e]);
		if (t === null) return null;
		r[e] = t;
	}
	return r;
}
function pe(e) {
	let t = Object.keys(e);
	if (!t.length) return null;
	let n = Array(t.length), r = -1;
	for (let e = 0; e < t.length; e += 1) {
		let i = se(t[e]);
		if (i === null || i > l) return null;
		n[e] = i, i > r && (r = i);
	}
	let i = new Uint8Array(r + 1);
	for (let r = 0; r < t.length; r += 1) {
		let a = _(e[t[r]]);
		if (a === null) return null;
		i[n[r]] = a;
	}
	return i;
}
function b(e) {
	let t = e === null ? "null" : typeof e, n = p(e), r = re(e), i = me(e, t, n, r);
	if (i) return i;
	let a = he(e, t, n, r);
	if (a) return a;
	let o = ge(e, t, n, r);
	if (o) return o;
	let s = y(e);
	if (s) return {
		kind: "coerced-bytes",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: s.byteLength
	};
	if (d(e)) {
		let i = Object.keys(e);
		return {
			kind: "object",
			jsType: t,
			tag: n,
			ctor: r,
			keyCount: i.length,
			keys: i.slice(0, ne)
		};
	}
	return {
		kind: "primitive",
		jsType: t,
		tag: n,
		ctor: r
	};
}
function me(e, t, n, r) {
	return e == null ? {
		kind: "empty",
		jsType: t,
		tag: n,
		ctor: r
	} : typeof e == "string" ? {
		kind: "string",
		jsType: t,
		tag: n,
		ctor: r,
		textLength: e.length
	} : null;
}
function he(e, t, n, r) {
	return ce(e) ? {
		kind: `serialized:${typeof e.kind == "string" && e.kind ? e.kind : "bytes"}`,
		jsType: t,
		tag: n,
		ctor: r,
		base64Length: e.b64.length,
		mime: h(e, "mime")
	} : null;
}
function ge(e, t, n, r) {
	if (m(e)) return {
		kind: "ArrayBuffer",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: e.byteLength
	};
	try {
		if (ArrayBuffer.isView(e)) return {
			kind: r ? `TypedArray:${r}` : "TypedArray",
			jsType: t,
			tag: n,
			ctor: r,
			byteLength: e.byteLength
		};
	} catch {}
	return ie(e) ? {
		kind: "BlobLike",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: typeof e.size == "number" ? Number(e.size) : -1,
		mime: h(e, "type")
	} : null;
}
//#endregion
//#region src/extension/constants.ts
var _e = "__VOT_EXT_BRIDGE__", x = "VOT_EXT_REQ", ve = "VOT_EXT_RES", S = "VOT_EXT_XHR_START", C = "VOT_EXT_XHR_ABORT", w = "VOT_EXT_XHR_ACK", T = "VOT_EXT_XHR_EVENT", E = "VOT_EXT_NOTIFY", D = new Set([
	x,
	ve,
	E,
	S,
	C,
	w,
	T
]);
function O(e) {
	return !!(e && typeof e == "object" && e.__VOT_EXT_BRIDGE__ === !0 && typeof e.type == "string" && D.has(e.type));
}
//#endregion
//#region src/extension/bridgeTransport.ts
function k(e) {
	return {
		...e,
		[_e]: !0
	};
}
//#endregion
//#region src/extension/prelude.ts
var A = "__VOT_EXT_PRELUDE_BOOTED__", j = 1e3, M = 15e3, N = typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}`;
function P(e) {
	return e && typeof e == "object" ? e : {};
}
function F(e) {
	if (e == null) return;
	let t = Number(e);
	return Number.isFinite(t) ? t : void 0;
}
function I(e) {
	globalThis.postMessage(k(e), "*");
}
function L(e) {
	let t = P(e);
	return {
		title: t.title == null ? void 0 : String(t.title),
		text: t.text == null ? void 0 : String(t.text),
		image: t.image == null ? void 0 : String(t.image),
		silent: !!t.silent,
		timeout: F(t.timeout),
		tag: t.tag == null ? void 0 : String(t.tag)
	};
}
var R = 0, z = /* @__PURE__ */ new Map();
function B() {
	return R += 1, `${N}_${R.toString(36)}`;
}
function V(e, n = {}) {
	let r = B();
	return new Promise((i, a) => {
		let o = globalThis.setTimeout(() => {
			z.delete(r), t.warn("[VOT EXT][prelude] GM API timeout", {
				requestId: r,
				action: e
			}), a(/* @__PURE__ */ Error(`VOT bridge timeout for ${e}`));
		}, M);
		t.log("[VOT EXT][prelude] GM API request", {
			requestId: r,
			action: e,
			payload: n
		}), z.set(r, {
			action: e,
			resolve: (e) => i(e),
			reject: a,
			timeoutId: o
		}), I({
			type: x,
			id: r,
			action: e,
			payload: n
		});
	});
}
var H = /* @__PURE__ */ new Map();
function U(e, t) {
	try {
		typeof e == "function" && e(t);
	} catch (e) {
		console.error("[VOT Extension] GM_xmlhttpRequest callback error", e);
	}
}
function W(e, t, n, r, i) {
	return (a) => {
		if (U(t[e], a), !n.isSettled) {
			if (n.isSettled = !0, e === "onload") {
				r(a);
				return;
			}
			i(a);
		}
	};
}
function G(e) {
	let t = H.get(e);
	return t ? (t.settled = !0, H.delete(e), t.timeoutId !== null && clearTimeout(t.timeoutId), t.callbacks) : null;
}
function K(e, n) {
	n.timeoutId !== null && (clearTimeout(n.timeoutId), n.timeoutId = null), !(n.settled || !n.acknowledged || !Number.isFinite(n.timeoutMs) || n.timeoutMs <= 0) && (n.timeoutId = globalThis.setTimeout(() => {
		let n = H.get(e);
		if (!n || n.settled) return;
		t.warn("[VOT EXT][prelude] GM_xmlhttpRequest timeout fallback fired", {
			requestId: e,
			timeoutMs: n.timeoutMs,
			state: "terminal",
			lastBridgeEventAt: n.lastBridgeEventAt || null
		});
		let r = G(e);
		if (r) {
			try {
				I({
					type: C,
					requestId: e
				});
			} catch {}
			U(r.ontimeout, {
				finalUrl: String(n.callbacks.url || ""),
				readyState: 4,
				status: 0,
				statusText: "",
				responseHeaders: "",
				response: null,
				responseText: "",
				error: "Timeout"
			});
		}
	}, n.timeoutMs + j));
}
function q(e) {
	return {
		method: e.method,
		url: e.url,
		headers: e.headers,
		data: b(e.data),
		timeout: e.timeout,
		responseType: e.responseType,
		anonymous: e.anonymous,
		withCredentials: e.withCredentials
	};
}
function ye(e) {
	return t.log("[VOT EXT][prelude] GM_xmlhttpRequest body passthrough", {
		url: e.url,
		method: e.method,
		body: b(e.data)
	}), {
		method: e.method,
		url: e.url,
		headers: e.headers,
		data: e.data,
		timeout: e.timeout,
		responseType: e.responseType,
		anonymous: e.anonymous,
		withCredentials: e.withCredentials
	};
}
function J(e) {
	let t = P(e);
	return {
		status: t.status ?? null,
		statusText: t.statusText ?? null,
		readyState: t.readyState ?? null,
		finalUrl: t.finalUrl ?? null
	};
}
function be(e, t) {
	return {
		finalUrl: String(e.url ?? ""),
		readyState: 4,
		status: 0,
		statusText: "",
		responseHeaders: "",
		response: null,
		responseText: "",
		error: t
	};
}
function Y() {
	globalThis.GM_notification = (e) => {
		try {
			I({
				type: E,
				details: L(e)
			});
		} catch {}
	}, globalThis.GM_addStyle = (e) => {
		let t = document.createElement("style");
		return t.textContent = String(e ?? ""), (document.head || document.documentElement).appendChild(t), t;
	}, globalThis.GM_xmlhttpRequest = (e) => {
		let n = B(), r = P(e), i = Number(r.timeout ?? 0), a = {
			callbacks: r,
			timeoutId: null,
			timeoutMs: Number.isFinite(i) ? i : 0,
			acknowledged: !1,
			settled: !1,
			lastBridgeEventAt: 0
		};
		H.set(n, a);
		let s = !0;
		return t.log("[VOT EXT][prelude] GM_xmlhttpRequest", {
			requestId: n,
			state: "created",
			timeoutMs: a.timeoutMs,
			details: q(r)
		}), (() => {
			try {
				if (!s || !H.has(n)) return;
				let e = ye(r);
				t.log("[VOT EXT][prelude] GM_xmlhttpRequest post TYPE_XHR_START", {
					requestId: n,
					details: q(r)
				}), I({
					type: S,
					requestId: n,
					details: e
				});
			} catch (e) {
				if (!s || !H.has(n)) return;
				s = !1;
				let i = o(e);
				t.log("[VOT EXT][prelude] GM_xmlhttpRequest start error", {
					requestId: n,
					error: i
				}), U(G(n)?.onerror, be(r, i));
			}
		})(), { abort: () => {
			s && (s = !1, t.warn("[VOT EXT][prelude] GM_xmlhttpRequest abort called", { requestId: n }), G(n), I({
				type: C,
				requestId: n
			}));
		} };
	};
	let e = (e) => {
		let t = P(e), n = null, r = new Promise((e, r) => {
			let i = { ...t }, a = { isSettled: !1 };
			i.onload = W("onload", t, a, e, r), i.onerror = W("onerror", t, a, e, r), i.ontimeout = W("ontimeout", t, a, e, r), i.onabort = W("onabort", t, a, e, r);
			let o = globalThis.GM_xmlhttpRequest(i);
			n = o && typeof o.abort == "function" ? o.abort.bind(o) : null;
		});
		return r.abort = () => {
			try {
				n?.();
			} catch {}
		}, r;
	};
	globalThis.GM = {
		getValue: (e, t) => V("gm_getValue", {
			key: e,
			def: t
		}),
		setValue: (e, t) => V("gm_setValue", {
			key: e,
			value: t
		}),
		deleteValue: (e) => V("gm_deleteValue", { key: e }),
		listValues: () => V("gm_listValues"),
		getValues: (e) => V("gm_getValues", { defaults: e }),
		notification: (e) => {
			I({
				type: E,
				details: L(e)
			});
		},
		xmlHttpRequest: (t) => e(t)
	}, globalThis.GM_info = {
		script: {
			name: "VOT Extension",
			version: "0.0.0"
		},
		scriptHandler: "VOT Extension",
		version: "0.0.0"
	};
}
function X() {
	globalThis.addEventListener("message", (e) => {
		if (e.source !== globalThis.window) return;
		let t = e.data;
		O(t) && (xe(t) || Se(t) || Z(t));
	});
}
function xe(e) {
	if (e.type !== "VOT_EXT_RES") return !1;
	let n = String(e.id ?? ""), r = z.get(n);
	if (!r) return !0;
	if (z.delete(n), clearTimeout(r.timeoutId), e.ok) t.log("[VOT EXT][prelude] GM API response", {
		requestId: n,
		action: r.action,
		ok: !0,
		resultType: Array.isArray(e.result) ? "array" : typeof e.result
	}), r.resolve(e.result);
	else {
		let i = o(e.error ?? "Bridge error");
		t.warn("[VOT EXT][prelude] GM API response", {
			requestId: n,
			action: r.action,
			ok: !1,
			error: i
		}), r.reject(Error(i));
	}
	return !0;
}
function Se(e) {
	if (e.type !== "VOT_EXT_XHR_ACK") return !1;
	let n = String(e.requestId ?? ""), r = H.get(n);
	return r ? (r.acknowledged = !0, r.lastBridgeEventAt = Date.now(), K(n, r), t.log("[VOT EXT][prelude] XHR acknowledged", {
		requestId: n,
		state: "acknowledged",
		timeoutMs: r.timeoutMs,
		payload: e.payload ?? null
	}), !0) : !0;
}
function Ce(e, n, r) {
	t.log("[VOT EXT][prelude] XHR event", {
		requestId: e,
		state: n === "progress" ? "in_flight" : "terminal",
		kind: n,
		...J(r.response ?? r.error ?? r.progress)
	});
}
function we(e, n, r) {
	t.log("[VOT EXT][prelude] XHR terminal load", {
		requestId: e,
		state: "terminal",
		...J(r.response)
	}), U(n.onload, r.response), G(e);
}
function Te(e, n, r, i) {
	let a = i === "error" ? t.error : t.warn, o = {
		error: "onerror",
		timeout: "ontimeout",
		abort: "onabort"
	}[i];
	a(`[VOT EXT][prelude] XHR terminal ${i}`, {
		requestId: e,
		state: "terminal",
		...J(r.error),
		error: r?.error?.error ?? null
	}), U(n[o], r.error), G(e);
}
function Z(e) {
	if (e.type !== "VOT_EXT_XHR_EVENT") return;
	let n = String(e.requestId ?? ""), r = H.get(n);
	if (!r) return;
	let i = r.callbacks, a = P(e.payload), o = String(a.type ?? "");
	if (Ce(n, o, a), o === "progress") {
		r.lastBridgeEventAt = Date.now(), K(n, r), U(i.onprogress, a.progress);
		return;
	}
	if (o === "load") {
		we(n, i, a);
		return;
	}
	if (o === "error" || o === "timeout" || o === "abort") {
		Te(n, i, a, o);
		return;
	}
	t.warn("[VOT EXT][prelude] unexpected XHR bridge event", {
		requestId: n,
		kind: o,
		payload: a
	});
}
async function Q() {
	Y(), X();
	try {
		let { manifest: e } = await V("handshake"), t = globalThis.GM_info;
		e?.name && (t.script.name = e.name), e?.version && (t.script.version = e.version, t.version = e.version);
	} catch {}
}
function $() {
	let e = globalThis;
	if (e[A]) {
		t.log("[VOT EXT][prelude] already initialized");
		return;
	}
	e[A] = !0, (async () => {
		try {
			await Q();
		} catch {}
	})();
}
$();
//#endregion
export { $ as bootstrapExtensionPrelude, Q as initializePrelude, Y as installPageGmPolyfills, X as wireMessageHandlers };
