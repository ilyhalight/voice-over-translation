const ve = (...e) => {
  console.log(
    "%c[VOT DEBUG]",
    "background: #3700ffff; color: #fff; padding: 5px;",
    ...e
  );
}, ke = (...e) => {
  console.warn(
    "%c[VOT DEBUG]",
    "background: #e1ff00ff; color: #fff; padding: 5px;",
    ...e
  );
}, Le = (...e) => {
  console.error(
    "%c[VOT DEBUG]",
    "background: #F2452D; color: #fff; padding: 5px;",
    ...e
  );
}, b = { log: ve, warn: ke, error: Le }, xe = {
  alphabet: "base64url"
}, ae = typeof Uint8Array.prototype.toBase64 == "function" ? Uint8Array.prototype.toBase64 : null, M = Uint8Array.fromBase64;
function Ne(e) {
  const t = String(e).replaceAll(/\s+/g, ""), r = t.length % 4;
  if (r === 1)
    throw new TypeError("Invalid base64 input.");
  return r === 0 ? t : t + "=".repeat(4 - r);
}
function Re(e) {
  let t = "";
  for (const r of e)
    t += String.fromCharCode(r);
  return t;
}
function Ue(e) {
  const t = globalThis.atob;
  if (typeof t != "function")
    throw new TypeError("Base64 decoder is not available in this environment.");
  const r = t(e), n = new Uint8Array(r.length);
  for (let o = 0; o < r.length; o += 1)
    n[o] = r.charCodeAt(o);
  return n;
}
function _e(e) {
  const t = globalThis.btoa;
  if (typeof t != "function")
    throw new TypeError("Base64 encoder is not available in this environment.");
  return t(Re(e));
}
function De(e) {
  const t = Ne(e), r = t.replaceAll("-", "+").replaceAll("_", "/");
  if (typeof M != "function")
    return Ue(r);
  const n = t.includes("-") || t.includes("_"), o = t.includes("+") || t.includes("/");
  return n && !o ? M(t, xe) : M(
    n && o ? r : t
  );
}
function he(e) {
  return typeof ae == "function" ? ae.call(e) : _e(e);
}
function je(e) {
  return he(new Uint8Array(e));
}
function U(e) {
  return De(e);
}
const W = 1e7, Ce = 12, Ie = 2;
function _(e) {
  return e !== null && typeof e == "object";
}
function Fe(e) {
  return D(e) === "[object Object]";
}
function D(e) {
  try {
    return Object.prototype.toString.call(e);
  } catch {
    return null;
  }
}
function $(e) {
  return D(e) === "[object ArrayBuffer]";
}
function He(e) {
  try {
    const t = e?.constructor?.name;
    return typeof t == "string" ? t : null;
  } catch {
    return null;
  }
}
function ce(e, t) {
  try {
    const r = e?.[t];
    return typeof r == "string" ? r : null;
  } catch {
    return null;
  }
}
function Ve(e) {
  if (D(e) === "[object Blob]") return !0;
  if (!e || typeof e != "object") return !1;
  try {
    const r = e, n = typeof r.arrayBuffer == "function", o = typeof r.slice == "function", s = typeof r.size == "number", i = typeof r.type == "string";
    return (n || o) && s && i;
  } catch {
    return !1;
  }
}
function Pe(e) {
  try {
    return JSON.stringify(e);
  } catch {
    return null;
  }
}
function X(e) {
  if (typeof e != "number" || !Number.isFinite(e)) return null;
  const t = Math.trunc(e);
  return t < 0 || t > W ? null : t;
}
function G(e) {
  return typeof e != "number" || !Number.isFinite(e) ? null : Math.trunc(e) & 255;
}
function R(e) {
  const t = e.length;
  if (t > W) return null;
  const r = new Uint8Array(t);
  for (let n = 0; n < t; n += 1) {
    const o = G(e[n]);
    if (o === null) return null;
    r[n] = o;
  }
  return r;
}
function Me(e) {
  return new Uint8Array(
    e.buffer,
    e.byteOffset,
    e.byteLength
  );
}
function Xe(e) {
  return Me(e).slice();
}
function ze(e) {
  if (e === "") return null;
  const t = Number(e);
  return !Number.isFinite(t) || !Number.isInteger(t) || t < 0 ? null : t;
}
function ge(e) {
  if (!_(e)) return !1;
  const t = e;
  return t.__votExtBody === !0 && typeof t.b64 == "string";
}
function be(e, t = 0) {
  if (t > Ie || !_(e)) return null;
  const r = e;
  if ($(e))
    return new Uint8Array(e);
  try {
    if (ArrayBuffer.isView(e))
      return Xe(e);
  } catch {
  }
  if (Array.isArray(e))
    return R(e);
  if (r.type === "Buffer" && Array.isArray(r.data)) {
    const i = R(r.data);
    if (i) return i;
  }
  if (Array.isArray(r.data)) {
    const i = R(r.data);
    if (i) return i;
  }
  if (Array.isArray(r.bytes)) {
    const i = R(r.bytes);
    if (i) return i;
  }
  if (typeof r.b64 == "string")
    try {
      return U(r.b64);
    } catch {
    }
  if (typeof r.base64 == "string")
    try {
      return U(r.base64);
    } catch {
    }
  const n = X(r.byteLength), o = X(r.byteOffset ?? 0);
  if (n !== null && o !== null) {
    const i = r.buffer;
    if ($(i))
      try {
        return new Uint8Array(
          i,
          o,
          n
        ).slice();
      } catch {
      }
    if (i && i !== e) {
      const c = be(
        i,
        t + 1
      );
      if (c) {
        if (o > c.byteLength) return null;
        const f = Math.min(
          c.byteLength,
          o + n
        );
        return c.slice(o, f);
      }
    }
  }
  const s = X(r.length);
  if (s !== null) {
    const i = r, c = new Uint8Array(s);
    for (let f = 0; f < s; f += 1) {
      const g = G(i[f]);
      if (g === null)
        return null;
      c[f] = g;
    }
    return c;
  }
  if (Fe(e)) {
    const i = Object.keys(r);
    if (!i.length) return null;
    const c = new Array(i.length);
    let f = -1;
    for (let w = 0; w < i.length; w += 1) {
      const a = ze(i[w]);
      if (a === null || a > W) return null;
      c[w] = a, a > f && (f = a);
    }
    const g = new Uint8Array(f + 1);
    for (let w = 0; w < i.length; w += 1) {
      const a = i[w], l = G(r[a]);
      if (l === null) return null;
      g[c[w]] = l;
    }
    return g;
  }
  return null;
}
function J(e) {
  return be(e);
}
function S(e) {
  const t = e === null ? "null" : typeof e, r = D(e), n = He(e);
  if (e == null)
    return { kind: "empty", jsType: t, tag: r, ctor: n };
  if (typeof e == "string")
    return { kind: "string", jsType: t, tag: r, ctor: n, textLength: e.length };
  if (ge(e))
    return {
      kind: `serialized:${typeof e.kind == "string" && e.kind ? e.kind : "bytes"}`,
      jsType: t,
      tag: r,
      ctor: n,
      base64Length: e.b64.length,
      mime: ce(e, "mime")
    };
  if ($(e))
    return {
      kind: "ArrayBuffer",
      jsType: t,
      tag: r,
      ctor: n,
      byteLength: e.byteLength
    };
  try {
    if (ArrayBuffer.isView(e)) {
      const s = e;
      return {
        kind: n ? `TypedArray:${n}` : "TypedArray",
        jsType: t,
        tag: r,
        ctor: n,
        byteLength: s.byteLength
      };
    }
  } catch {
  }
  if (Ve(e))
    return {
      kind: "BlobLike",
      jsType: t,
      tag: r,
      ctor: n,
      byteLength: typeof e.size == "number" ? Number(e.size) : -1,
      mime: ce(e, "type")
    };
  const o = J(e);
  if (o)
    return {
      kind: "coerced-bytes",
      jsType: t,
      tag: r,
      ctor: n,
      byteLength: o.byteLength
    };
  if (_(e)) {
    const s = Object.keys(e);
    return {
      kind: "object",
      jsType: t,
      tag: r,
      ctor: n,
      keyCount: s.length,
      keys: s.slice(0, Ce)
    };
  }
  return { kind: "primitive", jsType: t, tag: r, ctor: n };
}
function qe(e) {
  if (e == null) return;
  if (typeof e == "string") return e;
  if (ge(e)) {
    const r = U(e.b64);
    if ((typeof e.kind == "string" && e.kind ? e.kind : "bytes") === "blob") {
      const o = e.mime, s = r.buffer;
      return typeof o == "string" && o ? new Blob([s], { type: o }) : new Blob([s]);
    }
    return r;
  }
  const t = J(e);
  if (t)
    return t;
  if (_(e)) {
    const r = Pe(e);
    if (typeof r == "string") return r;
  }
  return String(e);
}
const $e = "vot_gm_xhr", Y = globalThis.browser, me = globalThis.chrome, h = Y ?? me ?? null, Ge = !!Y && h === Y;
function we() {
  const e = me?.runtime?.lastError ?? h?.runtime?.lastError;
  return e?.message ? String(e.message) : null;
}
async function j(e, t = [], r = {}) {
  if (typeof e != "function")
    throw new TypeError("WebExtension API is not available");
  const n = r.mapCbArgs, o = r.rejectOnLastError !== !1;
  return Ge ? await e(...t) : await new Promise((s, i) => {
    try {
      e(...t, (...c) => {
        const f = o ? we() : null;
        f ? i(new Error(f)) : s(n ? n(...c) : c[0]);
      });
    } catch (c) {
      i(c);
    }
  });
}
async function Ye(e, t) {
  const r = h?.notifications, n = r?.create;
  !r || typeof n != "function" || await j(n.bind(r), [e, t], {
    mapCbArgs: () => {
    }
  });
}
async function We(e) {
  const t = h?.notifications, r = t?.clear;
  !t || typeof r != "function" || await j(r.bind(t), [e], {
    mapCbArgs: () => {
    },
    rejectOnLastError: !1
  });
}
async function Je(e, t) {
  const r = h?.windows, n = r?.update;
  !r || typeof n != "function" || await j(n.bind(r), [e, t], {
    mapCbArgs: () => {
    },
    rejectOnLastError: !1
  });
}
async function Ke(e, t) {
  const r = h?.tabs, n = r?.update;
  !r || typeof n != "function" || await j(n.bind(r), [e, t], {
    mapCbArgs: () => {
    },
    rejectOnLastError: !1
  });
}
const Qe = "api.browser.yandex.ru", Ze = /* @__PURE__ */ new Set([
  "sec-ch-ua",
  "sec-ch-ua-mobile",
  "sec-ch-ua-platform",
  "sec-ch-ua-full-version-list"
]), Te = [
  "sec-ch-ua-full-version",
  "sec-ch-ua-platform-version",
  "sec-ch-ua-arch",
  "sec-ch-ua-bitness",
  "sec-ch-ua-model",
  "sec-ch-ua-wow64"
], et = new Set(Te);
function tt(e) {
  return String(e || "") === Qe;
}
function L(e) {
  return String(e || "").trim();
}
function rt(e) {
  const t = L(e).toLowerCase();
  return t ? !!(t === "origin" || t === "referer" || et.has(t) || t.startsWith("sec-ch-ua") && !Ze.has(t)) : !1;
}
function nt(e) {
  const t = {};
  for (const [r, n] of Object.entries(e || {})) {
    const o = L(r);
    o && (rt(o) || (t[o] = String(n)));
  }
  return t;
}
const ot = 512 * 1024, ue = 9001, le = 9002, fe = 9003, z = /* @__PURE__ */ new Map();
let q = Promise.resolve();
function K() {
  return !!h?.declarativeNetRequest?.updateSessionRules;
}
function it(e) {
  const r = h?.declarativeNetRequest?.updateSessionRules;
  if (typeof r != "function")
    return Promise.resolve();
  try {
    const n = r({
      addRules: e.addRules || [],
      removeRuleIds: e.removeRuleIds || []
    });
    if (n && typeof n.then == "function")
      return n;
  } catch {
  }
  return new Promise((n, o) => {
    try {
      r(
        {
          addRules: e.addRules || [],
          removeRuleIds: e.removeRuleIds || []
        },
        () => {
          const s = we();
          s ? o(new Error(s)) : n();
        }
      );
    } catch (s) {
      o(s);
    }
  });
}
function st(e) {
  const t = L(e).toLowerCase();
  return t ? !!(t.startsWith("sec-") || t.startsWith("proxy-") || t === "user-agent" || t === "origin" || t === "referer") : !1;
}
function Q(e) {
  const t = e.map(
    (r) => [
      `${L(String(r.header)).toLowerCase()}:${String(r.operation)}`,
      String("value" in r ? r.value : "")
    ]
  ).sort((r, n) => r[0].localeCompare(n[0]));
  return JSON.stringify(t);
}
function Z(e, t, r) {
  return t === z.get(e) ? Promise.resolve() : (q = q.catch(() => {
  }).then(async () => {
    t !== z.get(e) && (await it({
      removeRuleIds: [e],
      addRules: [r]
    }), z.set(e, t));
  }), q);
}
async function at(e, t) {
  if (!K()) return;
  let r = "";
  try {
    r = new URL(e).hostname;
  } catch {
    return;
  }
  if (!tt(r)) return;
  const n = [
    // Must be absent in the known-good request capture.
    { header: "Origin", operation: "remove" },
    // Not present in the capture; remove if added by caller/stack.
    { header: "Referer", operation: "remove" },
    ...Te.map(
      (c) => ({ header: c, operation: "remove" })
    )
  ], o = nt(t);
  for (const [c, f] of Object.entries(o))
    n.push({
      header: L(c),
      operation: "set",
      value: String(f)
    });
  const s = Q(n);
  await Z(ue, s, {
    id: ue,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: n
    },
    condition: {
      // Anchor at the URL start to avoid accidental matches.
      urlFilter: "|https://api.browser.yandex.ru/",
      // Extension-initiated fetch()/XHR can show up as "xmlhttprequest"
      // in Chromium.
      resourceTypes: ["xmlhttprequest"],
      // Only match requests not associated with a tab (service worker).
      tabIds: [-1]
    }
  });
}
function ct(e) {
  try {
    const t = new URL(e);
    return t.protocol === "https:" && t.hostname === "www.youtube.com" && t.pathname.startsWith("/youtubei/");
  } catch {
    return !1;
  }
}
function ut(e) {
  try {
    const t = new URL(e), r = t.hostname.toLowerCase();
    return t.protocol === "https:" && (r === "googlevideo.com" || r.endsWith(".googlevideo.com"));
  } catch {
    return !1;
  }
}
async function lt(e) {
  if (!K() || !ct(e)) return;
  const t = [
    { header: "Origin", operation: "remove" },
    { header: "x-client-data", operation: "remove" },
    { header: "x-goog-visitor-id", operation: "remove" }
  ], r = JSON.stringify({
    v: 2,
    headers: Q(t)
  });
  await Z(le, r, {
    id: le,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: t
    },
    condition: {
      urlFilter: "|https://www.youtube.com/youtubei/",
      resourceTypes: ["xmlhttprequest"],
      // Scope header mutations to service-worker initiated requests.
      tabIds: [-1]
    }
  });
}
async function ft(e) {
  if (!K() || !ut(e)) return;
  const t = [
    { header: "x-client-data", operation: "remove" }
  ], r = JSON.stringify({
    v: 1,
    headers: Q(t)
  });
  await Z(
    fe,
    r,
    {
      id: fe,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: t
      },
      condition: {
        urlFilter: "||googlevideo.com/",
        resourceTypes: ["xmlhttprequest"],
        // Scope header mutations to service-worker initiated requests.
        tabIds: [-1]
      }
    }
  );
}
function Se(e) {
  if (e instanceof Error) return e.message;
  if (e && typeof e == "object")
    try {
      return JSON.stringify(e);
    } catch {
      return Object.prototype.toString.call(e);
    }
  try {
    return String(e);
  } catch {
    return "Unknown error";
  }
}
function dt(e) {
  return Array.from(e.entries()).map(([t, r]) => `${t}: ${r}`).join(`\r
`);
}
function yt(e) {
  const t = {};
  if (!e) return t;
  for (const [r, n] of Object.entries(e))
    n !== void 0 && (typeof n == "string" || typeof n == "number" || typeof n == "boolean") && (t[String(r)] = String(n));
  return t;
}
function de(e, t) {
  return {
    finalUrl: e,
    readyState: 4,
    status: 0,
    statusText: "",
    responseHeaders: "",
    response: null,
    responseText: "",
    error: t
  };
}
function pt(e, t) {
  const r = t.toLowerCase();
  for (const [n, o] of Object.entries(e))
    if (String(n).toLowerCase() === r) return String(o);
}
function ht(e) {
  const t = String(e || "").toLowerCase();
  return t ? t.includes("application/x-protobuf") || t.includes("application/protobuf") || t.includes("application/octet-stream") : !1;
}
function gt(e) {
  const t = String(e || "");
  if (!t || /\s/.test(t) || !/^[A-Za-z0-9+/=_-]+$/.test(t) || !/[+/=_-]/.test(t)) return null;
  const r = t.replaceAll("-", "+").replaceAll("_", "/"), n = r.length % 4;
  if (n === 1) return null;
  const o = n === 0 ? r : `${r}${"=".repeat(4 - n)}`;
  try {
    return U(o);
  } catch {
    return null;
  }
}
function bt(e) {
  const t = String(e || ""), r = new Uint8Array(t.length);
  for (let n = 0; n < t.length; n += 1)
    r[n] = (t.codePointAt(n) ?? 0) & 255;
  return r;
}
function mt(e) {
  return /^\[object [^\]]+\]$/.test(String(e || "").trim());
}
let ye = 0;
h?.runtime?.onConnect?.addListener?.((e) => {
  if (!e || typeof e != "object") return;
  const t = e;
  if (t.name !== $e || typeof t.onDisconnect?.addListener != "function" || typeof t.onMessage?.addListener != "function" || typeof t.postMessage != "function")
    return;
  const r = (g) => {
    t.postMessage?.(g);
  };
  ye += 1;
  const n = ye;
  let o = null, s = null, i = !1, c = !1;
  const f = () => {
    s !== null && (clearTimeout(s), s = null);
  };
  t.onDisconnect.addListener(() => {
    f(), b.warn("[VOT EXT][background][xhr] port disconnected", {
      xhrSessionId: n
    });
    try {
      o?.abort();
    } catch {
    }
  }), t.onMessage.addListener(async (g) => {
    if (!g || typeof g != "object") return;
    if (g.type === "abort") {
      i = !0, b.warn("[VOT EXT][background][xhr] abort requested", {
        xhrSessionId: n
      });
      try {
        o?.abort();
      } catch {
      }
      return;
    }
    if (g.type !== "start") return;
    const w = i && o === null;
    i = !1;
    const { details: a } = g, l = a.url, m = (a.method || "GET").toUpperCase(), x = yt(a.headers), ee = {}, C = {};
    for (const [p, A] of Object.entries(x))
      st(p) ? C[p] = A : ee[p] = A;
    const I = Number(a.timeout || 0), T = String(a.responseType || "text").toLowerCase();
    if (b.log("[VOT EXT][background][xhr] start", {
      xhrSessionId: n,
      state: "in_flight",
      url: l,
      method: m,
      responseType: T,
      timeoutMs: I,
      headerCount: Object.keys(x).length,
      headerNames: Object.keys(x),
      forbiddenHeaderNames: Object.keys(C),
      body: S(a.data)
    }), w) {
      const p = {
        finalUrl: l,
        readyState: 4,
        status: 0,
        statusText: "",
        responseHeaders: "",
        response: null,
        responseText: "",
        error: "Aborted"
      };
      try {
        r({ type: "abort", state: "terminal", error: p });
      } catch {
      }
      return;
    }
    c = !1, o = new AbortController(), I > 0 && (s = setTimeout(() => {
      c = !0;
      try {
        o?.abort();
      } catch {
      }
    }, I));
    let F = "include";
    (a.anonymous || a.withCredentials === !1) && (F = "omit");
    try {
      let p;
      a.nocache ? p = "no-store" : a.revalidate && (p = "no-cache");
      const A = a.redirect === "error" || a.redirect === "manual" ? a.redirect : "follow", O = m !== "GET" && m !== "HEAD";
      try {
        await ft(l), await lt(l), await at(l, C);
      } catch (d) {
        console.warn(
          "[VOT Extension] Failed to apply DNR header rules; requests may break:",
          d
        );
      }
      let u = O ? qe(a.data) : void 0, v;
      const te = () => (v !== void 0 || (v = J(a.data)), v), re = pt(x, "content-type"), H = ht(re);
      if (b.log("[VOT EXT][background][xhr] body decoded", {
        xhrSessionId: n,
        url: l,
        method: m,
        contentType: re ?? null,
        isProtobufRequest: H,
        sourceBody: S(a.data),
        decodedBody: S(u)
      }), O && H && u == null) {
        const d = te();
        d && (u = d, b.warn(
          "[VOT EXT][background][xhr] protobuf body recovered from raw payload",
          {
            xhrSessionId: n,
            url: l,
            method: m,
            recoveredBody: S(u)
          }
        ));
      }
      if (O && typeof u == "string" && H) {
        if (mt(u)) {
          const d = te();
          d && (u = d, b.warn(
            "[VOT EXT][background][xhr] recovered protobuf body from object-like string fallback",
            {
              xhrSessionId: n,
              url: l,
              method: m,
              sourceBody: S(a.data),
              recoveredBody: S(d)
            }
          ));
        }
        if (typeof u == "string") {
          const d = gt(u);
          u = d ?? bt(u), b.log(
            "[VOT EXT][background][xhr] protobuf string converted to bytes",
            {
              xhrSessionId: n,
              url: l,
              method: m,
              strategy: d ? "base64" : "latin1",
              convertedBody: S(u)
            }
          );
        }
      }
      b.log("[VOT EXT][background][xhr] fetch dispatch", {
        xhrSessionId: n,
        url: l,
        method: m,
        credentials: F,
        redirect: A,
        cache: p ?? "default",
        body: S(u)
      });
      const V = {
        method: m,
        headers: ee,
        redirect: A,
        credentials: F,
        signal: o.signal
      };
      u !== void 0 && (V.body = u), p !== void 0 && (V.cache = p);
      const y = await fetch(l, V);
      b.log("[VOT EXT][background][xhr] fetch response received", {
        xhrSessionId: n,
        url: y.url || l,
        method: m,
        status: y.status,
        statusText: y.statusText,
        responseType: T,
        contentType: y.headers.get("content-type") || null,
        contentLength: y.headers.get("content-length") || null
      });
      const Be = dt(y.headers), ne = y.url || l, oe = y.headers.get("content-type") || "", ie = (d) => ({
        finalUrl: ne,
        readyState: d,
        status: y.status,
        statusText: y.statusText,
        responseHeaders: Be
      }), Ee = T === "arraybuffer" || T === "blob" || T === "stream";
      let B, E, N;
      if (Ee) {
        const d = Number(y.headers.get("content-length") || 0);
        if (!!y.body && (!Number.isFinite(d) || d > ot)) {
          let k = 0;
          const se = Number.isFinite(d) ? d : 0, Ae = y.body.getReader();
          for (; ; ) {
            const { done: Oe, value: P } = await Ae.read();
            if (Oe) break;
            P && (k += P.byteLength, r({
              type: "progress",
              state: "in_flight",
              progress: {
                ...ie(3),
                loaded: k,
                total: se,
                lengthComputable: se > 0,
                chunkB64: he(P)
              }
            }));
          }
          B = void 0;
        } else {
          const k = await y.arrayBuffer();
          k.byteLength > 0 && (N = je(k)), B = void 0;
        }
      } else if (T === "json") {
        E = await y.text();
        try {
          B = JSON.parse(E);
        } catch {
          B = null;
        }
      } else
        E = await y.text(), B = E;
      f(), b.log("[VOT EXT][background][xhr] terminal", {
        xhrSessionId: n,
        state: "terminal",
        kind: "load",
        url: ne,
        status: y.status,
        responseType: T,
        responseBody: S(B),
        responseTextLength: E?.length ?? 0,
        responseB64Length: N?.length ?? 0
      }), r({
        type: "load",
        state: "terminal",
        response: {
          ...ie(4),
          responseType: T,
          ...oe ? { contentType: oe } : {},
          ...N ? { responseB64: N } : {},
          response: B,
          ...typeof E == "string" ? { responseText: E } : {}
        }
      });
    } catch (p) {
      if (f(), i || c || p instanceof DOMException && p.name === "AbortError") {
        let u;
        c ? u = "timeout" : u = "abort";
        const v = de(
          l,
          u === "timeout" ? "Timeout" : "Aborted"
        );
        try {
          r({ type: u, state: "terminal", error: v });
        } catch {
        }
        b.warn("[VOT EXT][background][xhr] terminal", {
          xhrSessionId: n,
          state: "terminal",
          kind: u,
          url: l,
          method: m,
          responseType: T
        });
        return;
      }
      const O = de(l, Se(p));
      r({
        type: "error",
        state: "terminal",
        error: O
      }), b.error("[VOT EXT][background][xhr] terminal", {
        xhrSessionId: n,
        state: "terminal",
        kind: "error",
        url: l,
        method: m,
        responseType: T,
        error: O.error
      });
    }
  });
});
function wt(e) {
  return !e || typeof e != "object" ? !1 : e.type === "gm_notification";
}
function Tt(e) {
  const t = e && typeof e == "object" ? e : {}, r = Number(t.timeout ?? 0);
  return {
    title: t.title != null ? String(t.title) : "",
    text: t.text != null ? String(t.text) : "",
    silent: !!t.silent,
    timeout: Number.isFinite(r) && r > 0 ? r : 0
  };
}
function St(e) {
  const t = e.tab?.id, r = e.tab?.windowId, n = typeof t == "number" ? t : -1, o = typeof r == "number" ? r : -1, s = typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}:${Math.random().toString(36).slice(2)}`;
  return `vot:${n}:${o}:${s}`;
}
function Bt(e) {
  const t = typeof h?.runtime?.getBrowserInfo == "function", n = {
    type: "basic",
    iconUrl: h?.runtime?.getURL ? h.runtime.getURL("icons/icon-128.png") : "icons/icon-128.png",
    title: e.title || "VOT",
    message: e.text
  };
  return t || (n.silent = e.silent), n;
}
function pe(e, t) {
  if (typeof e == "function")
    try {
      e(t);
    } catch {
    }
}
h?.runtime?.onMessage?.addListener?.(
  (e, t, r) => {
    if (!wt(e)) return;
    const n = Tt(e.details), o = St(t), s = Bt(n);
    return (async () => {
      try {
        await Ye(o, s), n.timeout > 0 && setTimeout(() => {
          We(o);
        }, n.timeout), pe(r, { ok: !0 });
      } catch (i) {
        b.error(
          "[VOT EXT][background] Failed to create notification",
          i
        ), pe(r, {
          ok: !1,
          error: Se(i)
        });
      }
    })(), !0;
  }
);
h?.notifications?.onClicked?.addListener?.((e) => {
  if (!e.startsWith("vot:")) return;
  const t = e.split(":");
  if (t.length < 3) return;
  const r = Number(t[1]), n = Number(t[2]);
  Number.isFinite(n) && n >= 0 && Je(n, { focused: !0 }), Number.isFinite(r) && r >= 0 && Ke(r, { active: !0 });
});
export {
  St as createBridgeNotificationId,
  Bt as createBridgeNotificationOptions,
  wt as isGmNotificationMessage,
  Tt as normalizeGmNotificationDetails
};
