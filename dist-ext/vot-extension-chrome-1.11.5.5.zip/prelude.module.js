var e = {
	log: (...e) => {
		console.log("%c[VOT DEBUG]", "background: #3700ffff; color: #fff; padding: 5px;", ...e);
	},
	warn: (...e) => {
		console.warn("%c[VOT DEBUG]", "background: #e1ff00ff; color: #fff; padding: 5px;", ...e);
	},
	error: (...e) => {
		console.error("%c[VOT DEBUG]", "background: #F2452D; color: #fff; padding: 5px;", ...e);
	}
};
//#endregion
//#region src/utils/errors.ts
function t(e) {
	let t = /* @__PURE__ */ new WeakSet();
	try {
		return JSON.stringify(e, (e, n) => typeof n != "object" || !n ? n : t.has(n) ? "[Circular]" : (t.add(n), n)) ?? null;
	} catch {
		return null;
	}
}
function n(e) {
	let t = [
		e?.data?.message,
		e?.error?.message,
		e?.message
	];
	for (let e of t) if (typeof e == "string" && e) return e;
	return null;
}
function r(e, r) {
	let i = n(e);
	if (i) return i;
	let a = t(e);
	if (a && a !== "{}") return a;
	let o = e.constructor?.name;
	return o ? `[${o}]` : r;
}
function i(e, t) {
	return typeof e == "number" || typeof e == "boolean" || typeof e == "bigint" ? `${e}` : typeof e == "symbol" ? e.description ? `Symbol(${e.description})` : "Symbol" : typeof e == "function" ? e.name ? `[Function ${e.name}]` : "[Function]" : t;
}
function a(e, t = "Unknown error") {
	return e instanceof Error ? e.message || t : typeof e == "string" ? e || t : e == null ? t : typeof e == "object" ? r(e, t) : i(e, t);
}
typeof Uint8Array.prototype.toBase64 == "function" && Uint8Array.prototype.toBase64;
var o = Uint8Array.fromBase64, s = /[-_]/;
function ee(e) {
	let t = String(e).replaceAll(/\s+/g, ""), n = t.length % 4;
	if (n === 1) throw TypeError("Invalid base64 input.");
	return n === 0 ? t : t + "=".repeat(4 - n);
}
function c(e) {
	let t = ee(e), n = t.replaceAll("-", "+").replaceAll("_", "/");
	if (typeof o == "function") {
		let e = s.test(t);
		return o(e ? n : t, e ? { alphabet: "base64" } : void 0);
	}
	let r = globalThis.atob;
	if (typeof r != "function") throw TypeError("Base64 decoder is not available in this environment.");
	let i = r(n), a = new Uint8Array(i.length);
	for (let e = 0; e < i.length; e += 1) a[e] = i.charCodeAt(e);
	return a;
}
var l = 1e7, te = 12, ne = 2;
function u(e) {
	return typeof e == "object" && !!e;
}
function re(e) {
	return d(e) === "[object Object]";
}
function d(e) {
	try {
		return Object.prototype.toString.call(e);
	} catch {
		return null;
	}
}
function f(e) {
	return d(e) === "[object ArrayBuffer]";
}
function p(e) {
	try {
		let t = e?.constructor?.name;
		return typeof t == "string" ? t : null;
	} catch {
		return null;
	}
}
function m(e, t) {
	try {
		let n = e?.[t];
		return typeof n == "string" ? n : null;
	} catch {
		return null;
	}
}
function ie(e) {
	if (d(e) === "[object Blob]") return !0;
	if (!e || typeof e != "object") return !1;
	try {
		let t = e, n = typeof t.arrayBuffer == "function", r = typeof t.slice == "function", i = typeof t.size == "number", a = typeof t.type == "string";
		return (n || r) && i && a;
	} catch {
		return !1;
	}
}
function h(e) {
	if (typeof e != "number" || !Number.isFinite(e)) return null;
	let t = Math.trunc(e);
	return t < 0 || t > l ? null : t;
}
function g(e) {
	return typeof e != "number" || !Number.isFinite(e) ? null : Math.trunc(e) & 255;
}
function _(e) {
	let t = e.length;
	if (t > l) return null;
	let n = new Uint8Array(t);
	for (let r = 0; r < t; r += 1) {
		let t = g(e[r]);
		if (t === null) return null;
		n[r] = t;
	}
	return n;
}
function ae(e) {
	return new Uint8Array(e.buffer, e.byteOffset, e.byteLength);
}
function oe(e) {
	return ae(e).slice();
}
function se(e) {
	if (e === "") return null;
	let t = Number(e);
	return !Number.isFinite(t) || !Number.isInteger(t) || t < 0 ? null : t;
}
function ce(e) {
	if (!u(e)) return !1;
	let t = e;
	return t.__votExtBody === !0 && typeof t.b64 == "string";
}
function v(e, t = 0) {
	if (t > ne || !u(e)) return null;
	let n = e;
	if (f(e)) return new Uint8Array(e);
	try {
		if (ArrayBuffer.isView(e)) return oe(e);
	} catch {}
	return Array.isArray(e) ? _(e) : y(n) || b(n) || x(n, e, t) || le(n) || (re(e) ? ue(n) : null);
}
function y(e) {
	let t = [
		e.type === "Buffer" && Array.isArray(e.data) ? e.data : null,
		Array.isArray(e.data) ? e.data : null,
		Array.isArray(e.bytes) ? e.bytes : null
	];
	for (let e of t) {
		if (!e) continue;
		let t = _(e);
		if (t) return t;
	}
	return null;
}
function b(e) {
	let t = [e.b64, e.base64];
	for (let e of t) if (typeof e == "string") try {
		return c(e);
	} catch {}
	return null;
}
function x(e, t, n) {
	let r = h(e.byteLength), i = h(e.byteOffset ?? 0);
	if (r === null || i === null) return null;
	let a = e.buffer;
	if (f(a)) try {
		return new Uint8Array(a, i, r).slice();
	} catch {}
	if (!a || a === t) return null;
	let o = v(a, n + 1);
	if (!o || i > o.byteLength) return null;
	let s = Math.min(o.byteLength, i + r);
	return o.slice(i, s);
}
function le(e) {
	let t = h(e.length);
	if (t === null) return null;
	let n = e, r = new Uint8Array(t);
	for (let e = 0; e < t; e += 1) {
		let t = g(n[e]);
		if (t === null) return null;
		r[e] = t;
	}
	return r;
}
function ue(e) {
	let t = Object.keys(e);
	if (!t.length) return null;
	let n = Array(t.length), r = -1;
	for (let e = 0; e < t.length; e += 1) {
		let i = se(t[e]);
		if (i === null || i > l) return null;
		n[e] = i, i > r && (r = i);
	}
	let i = new Uint8Array(r + 1);
	for (let r = 0; r < t.length; r += 1) {
		let a = g(e[t[r]]);
		if (a === null) return null;
		i[n[r]] = a;
	}
	return i;
}
function S(e) {
	let t = e === null ? "null" : typeof e, n = d(e), r = p(e), i = de(e, t, n, r);
	if (i) return i;
	let a = fe(e, t, n, r);
	if (a) return a;
	let o = pe(e, t, n, r);
	if (o) return o;
	let s = v(e);
	if (s) return {
		kind: "coerced-bytes",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: s.byteLength
	};
	if (u(e)) {
		let i = Object.keys(e);
		return {
			kind: "object",
			jsType: t,
			tag: n,
			ctor: r,
			keyCount: i.length,
			keys: i.slice(0, te)
		};
	}
	return {
		kind: "primitive",
		jsType: t,
		tag: n,
		ctor: r
	};
}
function de(e, t, n, r) {
	return e == null ? {
		kind: "empty",
		jsType: t,
		tag: n,
		ctor: r
	} : typeof e == "string" ? {
		kind: "string",
		jsType: t,
		tag: n,
		ctor: r,
		textLength: e.length
	} : null;
}
function fe(e, t, n, r) {
	return ce(e) ? {
		kind: `serialized:${typeof e.kind == "string" && e.kind ? e.kind : "bytes"}`,
		jsType: t,
		tag: n,
		ctor: r,
		base64Length: e.b64.length,
		mime: m(e, "mime")
	} : null;
}
function pe(e, t, n, r) {
	if (f(e)) return {
		kind: "ArrayBuffer",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: e.byteLength
	};
	try {
		if (ArrayBuffer.isView(e)) return {
			kind: r ? `TypedArray:${r}` : "TypedArray",
			jsType: t,
			tag: n,
			ctor: r,
			byteLength: e.byteLength
		};
	} catch {}
	return ie(e) ? {
		kind: "BlobLike",
		jsType: t,
		tag: n,
		ctor: r,
		byteLength: typeof e.size == "number" ? Number(e.size) : -1,
		mime: m(e, "type")
	} : null;
}
//#endregion
//#region src/extension/constants.ts
var me = "__VOT_EXT_BRIDGE__", C = "VOT_EXT_REQ", he = "VOT_EXT_RES", w = "VOT_EXT_XHR_START", T = "VOT_EXT_XHR_ABORT", ge = "VOT_EXT_XHR_ACK", E = "VOT_EXT_XHR_EVENT", D = "VOT_EXT_NOTIFY", O = new Set([
	C,
	he,
	D,
	w,
	T,
	ge,
	E
]);
function k(e) {
	return !!(e && typeof e == "object" && e.__VOT_EXT_BRIDGE__ === !0 && typeof e.type == "string" && O.has(e.type));
}
//#endregion
//#region src/extension/bridgeTransport.ts
function A(e) {
	return {
		...e,
		[me]: !0
	};
}
//#endregion
//#region src/extension/prelude.ts
var j = "__VOT_EXT_PRELUDE_BOOTED__", M = 1e3, N = 15e3, P = typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}`;
function F(e) {
	return e && typeof e == "object" ? e : {};
}
function I(e) {
	if (e == null) return;
	let t = Number(e);
	return Number.isFinite(t) ? t : void 0;
}
function L(e) {
	globalThis.postMessage(A(e), "*");
}
function R(e) {
	let t = F(e);
	return {
		title: t.title == null ? void 0 : String(t.title),
		text: t.text == null ? void 0 : String(t.text),
		image: t.image == null ? void 0 : String(t.image),
		silent: !!t.silent,
		timeout: I(t.timeout),
		tag: t.tag == null ? void 0 : String(t.tag)
	};
}
var z = 0, B = /* @__PURE__ */ new Map();
function V() {
	return z += 1, `${P}_${z.toString(36)}`;
}
function H(t, n = {}) {
	let r = V();
	return new Promise((i, a) => {
		let o = globalThis.setTimeout(() => {
			B.delete(r), e.warn("[VOT EXT][prelude] GM API timeout", {
				requestId: r,
				action: t
			}), a(/* @__PURE__ */ Error(`VOT bridge timeout for ${t}`));
		}, N);
		e.log("[VOT EXT][prelude] GM API request", {
			requestId: r,
			action: t,
			payload: n
		}), B.set(r, {
			action: t,
			resolve: (e) => i(e),
			reject: a,
			timeoutId: o
		}), L({
			type: C,
			id: r,
			action: t,
			payload: n
		});
	});
}
var U = /* @__PURE__ */ new Map();
function W(e, t) {
	try {
		typeof e == "function" && e(t);
	} catch (e) {
		console.error("[VOT Extension] GM_xmlhttpRequest callback error", e);
	}
}
function G(e, t, n, r, i) {
	return (a) => {
		if (W(t[e], a), !n.isSettled) {
			if (n.isSettled = !0, e === "onload") {
				r(a);
				return;
			}
			i(a);
		}
	};
}
function K(e) {
	let t = U.get(e);
	return t ? (t.settled = !0, U.delete(e), t.timeoutId !== null && clearTimeout(t.timeoutId), t.callbacks) : null;
}
function q(t, n) {
	n.timeoutId !== null && (clearTimeout(n.timeoutId), n.timeoutId = null), !(n.settled || !n.acknowledged || !Number.isFinite(n.timeoutMs) || n.timeoutMs <= 0) && (n.timeoutId = globalThis.setTimeout(() => {
		let n = U.get(t);
		if (!n || n.settled) return;
		e.warn("[VOT EXT][prelude] GM_xmlhttpRequest timeout fallback fired", {
			requestId: t,
			timeoutMs: n.timeoutMs,
			state: "terminal",
			lastBridgeEventAt: n.lastBridgeEventAt || null
		});
		let r = K(t);
		if (r) {
			try {
				L({
					type: T,
					requestId: t
				});
			} catch {}
			W(r.ontimeout, {
				finalUrl: String(n.callbacks.url || ""),
				readyState: 4,
				status: 0,
				statusText: "",
				responseHeaders: "",
				response: null,
				responseText: "",
				error: "Timeout"
			});
		}
	}, n.timeoutMs + M));
}
function J(e) {
	return {
		method: e.method,
		url: e.url,
		headers: e.headers,
		data: S(e.data),
		timeout: e.timeout,
		responseType: e.responseType,
		anonymous: e.anonymous,
		withCredentials: e.withCredentials
	};
}
function _e(t) {
	return e.log("[VOT EXT][prelude] GM_xmlhttpRequest body passthrough", {
		url: t.url,
		method: t.method,
		body: S(t.data)
	}), {
		method: t.method,
		url: t.url,
		headers: t.headers,
		data: t.data,
		timeout: t.timeout,
		responseType: t.responseType,
		anonymous: t.anonymous,
		withCredentials: t.withCredentials
	};
}
function Y(e) {
	let t = F(e);
	return {
		status: t.status ?? null,
		statusText: t.statusText ?? null,
		readyState: t.readyState ?? null,
		finalUrl: t.finalUrl ?? null
	};
}
function ve(e, t) {
	return {
		finalUrl: String(e.url ?? ""),
		readyState: 4,
		status: 0,
		statusText: "",
		responseHeaders: "",
		response: null,
		responseText: "",
		error: t
	};
}
function X() {
	globalThis.GM_notification = (e) => {
		try {
			L({
				type: D,
				details: R(e)
			});
		} catch {}
	}, globalThis.GM_addStyle = (e) => {
		let t = document.createElement("style");
		return t.textContent = String(e ?? ""), (document.head || document.documentElement).appendChild(t), t;
	}, globalThis.GM_xmlhttpRequest = (t) => {
		let n = V(), r = F(t), i = Number(r.timeout ?? 0), o = {
			callbacks: r,
			timeoutId: null,
			timeoutMs: Number.isFinite(i) ? i : 0,
			acknowledged: !1,
			settled: !1,
			lastBridgeEventAt: 0
		};
		U.set(n, o);
		let s = !0;
		return e.log("[VOT EXT][prelude] GM_xmlhttpRequest", {
			requestId: n,
			state: "created",
			timeoutMs: o.timeoutMs,
			details: J(r)
		}), (() => {
			try {
				if (!s || !U.has(n)) return;
				let t = _e(r);
				e.log("[VOT EXT][prelude] GM_xmlhttpRequest post TYPE_XHR_START", {
					requestId: n,
					details: J(r)
				}), L({
					type: w,
					requestId: n,
					details: t
				});
			} catch (t) {
				if (!s || !U.has(n)) return;
				s = !1;
				let i = a(t);
				e.log("[VOT EXT][prelude] GM_xmlhttpRequest start error", {
					requestId: n,
					error: i
				}), W(K(n)?.onerror, ve(r, i));
			}
		})(), { abort: () => {
			s && (s = !1, e.warn("[VOT EXT][prelude] GM_xmlhttpRequest abort called", { requestId: n }), K(n), L({
				type: T,
				requestId: n
			}));
		} };
	};
	let t = (e) => {
		let t = F(e), n = null, r = new Promise((e, r) => {
			let i = { ...t }, a = { isSettled: !1 };
			i.onload = G("onload", t, a, e, r), i.onerror = G("onerror", t, a, e, r), i.ontimeout = G("ontimeout", t, a, e, r), i.onabort = G("onabort", t, a, e, r);
			let o = globalThis.GM_xmlhttpRequest(i);
			n = o && typeof o.abort == "function" ? o.abort.bind(o) : null;
		});
		return r.abort = () => {
			try {
				n?.();
			} catch {}
		}, r;
	};
	globalThis.GM = {
		getValue: (e, t) => H("gm_getValue", {
			key: e,
			def: t
		}),
		setValue: (e, t) => H("gm_setValue", {
			key: e,
			value: t
		}),
		deleteValue: (e) => H("gm_deleteValue", { key: e }),
		listValues: () => H("gm_listValues"),
		getValues: (e) => H("gm_getValues", { defaults: e }),
		notification: (e) => {
			L({
				type: D,
				details: R(e)
			});
		},
		xmlHttpRequest: (e) => t(e)
	}, globalThis.GM_info = {
		script: {
			name: "VOT Extension",
			version: "0.0.0"
		},
		scriptHandler: "VOT Extension",
		version: "0.0.0"
	};
}
function Z() {
	globalThis.addEventListener("message", (e) => {
		if (e.source !== globalThis.window) return;
		let t = e.data;
		k(t) && (ye(t) || be(t) || we(t));
	});
}
function ye(t) {
	if (t.type !== "VOT_EXT_RES") return !1;
	let n = String(t.id ?? ""), r = B.get(n);
	if (!r) return !0;
	if (B.delete(n), clearTimeout(r.timeoutId), t.ok) e.log("[VOT EXT][prelude] GM API response", {
		requestId: n,
		action: r.action,
		ok: !0,
		resultType: Array.isArray(t.result) ? "array" : typeof t.result
	}), r.resolve(t.result);
	else {
		let i = a(t.error ?? "Bridge error");
		e.warn("[VOT EXT][prelude] GM API response", {
			requestId: n,
			action: r.action,
			ok: !1,
			error: i
		}), r.reject(Error(i));
	}
	return !0;
}
function be(t) {
	if (t.type !== "VOT_EXT_XHR_ACK") return !1;
	let n = String(t.requestId ?? ""), r = U.get(n);
	return r ? (r.acknowledged = !0, r.lastBridgeEventAt = Date.now(), q(n, r), e.log("[VOT EXT][prelude] XHR acknowledged", {
		requestId: n,
		state: "acknowledged",
		timeoutMs: r.timeoutMs,
		payload: t.payload ?? null
	}), !0) : !0;
}
function xe(t, n, r) {
	e.log("[VOT EXT][prelude] XHR event", {
		requestId: t,
		state: n === "progress" ? "in_flight" : "terminal",
		kind: n,
		...Y(r.response ?? r.error ?? r.progress)
	});
}
function Se(t, n, r) {
	e.log("[VOT EXT][prelude] XHR terminal load", {
		requestId: t,
		state: "terminal",
		...Y(r.response)
	}), W(n.onload, r.response), K(t);
}
function Ce(t, n, r, i) {
	let a = i === "error" ? e.error : e.warn, o = {
		error: "onerror",
		timeout: "ontimeout",
		abort: "onabort"
	}[i];
	a(`[VOT EXT][prelude] XHR terminal ${i}`, {
		requestId: t,
		state: "terminal",
		...Y(r.error),
		error: r?.error?.error ?? null
	}), W(n[o], r.error), K(t);
}
function we(t) {
	if (t.type !== "VOT_EXT_XHR_EVENT") return;
	let n = String(t.requestId ?? ""), r = U.get(n);
	if (!r) return;
	let i = r.callbacks, a = F(t.payload), o = String(a.type ?? "");
	if (xe(n, o, a), o === "progress") {
		r.lastBridgeEventAt = Date.now(), q(n, r), W(i.onprogress, a.progress);
		return;
	}
	if (o === "load") {
		Se(n, i, a);
		return;
	}
	if (o === "error" || o === "timeout" || o === "abort") {
		Ce(n, i, a, o);
		return;
	}
	e.warn("[VOT EXT][prelude] unexpected XHR bridge event", {
		requestId: n,
		kind: o,
		payload: a
	});
}
async function Q() {
	X(), Z();
	try {
		let { manifest: e } = await H("handshake"), t = globalThis.GM_info;
		e?.name && (t.script.name = e.name), e?.version && (t.script.version = e.version, t.version = e.version);
	} catch {}
}
function $() {
	let t = globalThis;
	if (t[j]) {
		e.log("[VOT EXT][prelude] already initialized");
		return;
	}
	t[j] = !0, (async () => {
		try {
			await Q();
		} catch {}
	})();
}
$();
//#endregion
export { $ as bootstrapExtensionPrelude, Q as initializePrelude, X as installPageGmPolyfills, Z as wireMessageHandlers };
