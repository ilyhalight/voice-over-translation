// ==UserScript==
// @name         [VOT] - Test UI
// @description  Test ui
// @grant        GM_addStyle
// @grant        GM_deleteValue
// @grant        GM_listValues
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_xmlhttpRequest
// @require      https://cdn.jsdelivr.net/npm/animejs@3/lib/anime.min.js
// @require      https://gist.githubusercontent.com/ilyhalight/6eb5bb4dffc7ca9e3c57d6933e2452f3/raw/7ab38af2228d0bed13912e503bc8a9ee4b11828d/gm-addstyle-polyfill.js
// @match        *://toil.cc/*
// @namespace    vot-test-ui
// @version      1.0.0
// @icon         https://translate.yandex.ru/icons/favicon.ico
// @author       sodapng, mynovelhost, Toil, SashaXser, MrSoczekXD
// ==/UserScript==

/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/styles/main.scss":
/***/ (() => {

GM_addStyle(".vot-button{--vot-helper-theme:var(--vot-theme-rgb,var(--vot-primary-rgb,33,150,243));--vot-helper-ontheme:var(--vot-ontheme-rgb,var(--vot-onprimary-rgb,255,255,255));box-sizing:border-box;vertical-align:middle;text-align:center;text-overflow:ellipsis;min-width:64px;height:36px;color:rgb(var(--vot-helper-ontheme));background-color:rgb(var(--vot-helper-theme));font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system);cursor:pointer;outline:none;font-size:14px;font-weight:500;line-height:36px;transition:box-shadow .2s;display:inline-block;position:relative;box-shadow:0 3px 1px -2px #0003,0 2px 2px #00000024,0 1px 5px #0000001f;border:none!important;border-radius:4px!important;padding:0 16px!important}.vot-button[hidden]{display:none!important}.vot-button::-moz-focus-inner{border:none!important}.vot-button:before,.vot-button:after{content:\"\";opacity:0;position:absolute;top:0;bottom:0;left:0;right:0;border-radius:inherit!important}.vot-button:before{background-color:rgb(var(--vot-helper-ontheme));transition:opacity .2s}.vot-button:after{background:radial-gradient(circle,currentColor 1%,#0000 1%) 50%/10000% 10000% no-repeat;transition:opacity 1s,background-size .5s}.vot-button:hover{box-shadow:0 2px 4px -1px #0003,0 4px 5px #00000024,0 1px 10px #0000001f}.vot-button:hover:before{opacity:.08}.vot-button:active{box-shadow:0 5px 5px -3px #0003,0 8px 10px 1px #00000024,0 3px 14px 2px #0000001f}.vot-button:active:after{opacity:.32;background-size:100% 100%;transition:background-size}.vot-button[disabled=true]{background-color:rgba(var(--vot-onsurface-rgb,0,0,0),.12);color:rgba(var(--vot-onsurface-rgb,0,0,0),.38);box-shadow:none;cursor:initial}.vot-button[disabled=true]:before,.vot-button[disabled=true]:after{opacity:0}.vot-outlined-button{--vot-helper-theme:var(--vot-theme-rgb,var(--vot-primary-rgb,33,150,243));box-sizing:border-box;vertical-align:middle;text-align:center;text-overflow:ellipsis;min-width:64px;height:36px;color:rgb(var(--vot-helper-theme));font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system);cursor:pointer;background-color:#0000;outline:none;font-size:14px;font-weight:500;line-height:34px;display:inline-block;position:relative;border:solid 1px rgba(var(--vot-onsurface-rgb,0,0,0),.24)!important;border-radius:4px!important;margin:0!important;padding:0 16px!important}.vot-outlined-button[hidden]{display:none!important}.vot-outlined-button::-moz-focus-inner{border:none!important}.vot-outlined-button:before,.vot-outlined-button:after{content:\"\";opacity:0;position:absolute;top:0;bottom:0;left:0;right:0;border-radius:3px!important}.vot-outlined-button:before{background-color:rgb(var(--vot-helper-theme));transition:opacity .2s}.vot-outlined-button:after{background:radial-gradient(circle,currentColor 1%,#0000 1%) 50%/10000% 10000% no-repeat;transition:opacity 1s,background-size .5s}.vot-outlined-button:hover:before{opacity:.04}.vot-outlined-button:active:after{opacity:.16;background-size:100% 100%;transition:background-size}.vot-outlined-button[disabled=true]{color:rgba(var(--vot-onsurface-rgb,0,0,0),.38);cursor:initial;background-color:#0000}.vot-outlined-button[disabled=true]:before,.vot-outlined-button[disabled=true]:after{opacity:0}.vot-text-button{--vot-helper-theme:var(--vot-theme-rgb,var(--vot-primary-rgb,33,150,243));box-sizing:border-box;vertical-align:middle;text-align:center;text-overflow:ellipsis;min-width:64px;height:36px;color:rgb(var(--vot-helper-theme));font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system);cursor:pointer;background-color:#0000;outline:none;font-size:14px;font-weight:500;line-height:36px;display:inline-block;position:relative;border:none!important;border-radius:4px!important;margin:0!important;padding:0 8px!important}.vot-text-button[hidden]{display:none!important}.vot-text-button::-moz-focus-inner{border:none!important}.vot-text-button:before,.vot-text-button:after{content:\"\";opacity:0;position:absolute;top:0;bottom:0;left:0;right:0;border-radius:inherit!important}.vot-text-button:before{background-color:rgb(var(--vot-helper-theme));transition:opacity .2s}.vot-text-button:after{background:radial-gradient(circle,currentColor 1%,#0000 1%) 50%/10000% 10000% no-repeat;transition:opacity 1s,background-size .5s}.vot-text-button:hover:before{opacity:.04}.vot-text-button:active:after{opacity:.16;background-size:100% 100%;transition:background-size}.vot-text-button[disabled=true]{color:rgba(var(--vot-onsurface-rgb,0,0,0),.38);cursor:initial;background-color:#0000}.vot-text-button[disabled=true]:before,.vot-text-button[disabled=true]:after{opacity:0}.vot-icon-button{--vot-helper-onsurface:rgba(var(--vot-onsurface-rgb,0,0,0),.87);box-sizing:border-box;vertical-align:middle;text-align:center;text-overflow:ellipsis;width:36px;height:36px;fill:var(--vot-helper-onsurface);color:var(--vot-helper-onsurface);font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system);cursor:pointer;background-color:#0000;outline:none;font-size:14px;font-weight:500;line-height:36px;display:inline-block;position:relative;border:none!important;border-radius:50%!important;margin:0!important;padding:0!important}.vot-icon-button[hidden]{display:none!important}.vot-icon-button::-moz-focus-inner{border:none!important}.vot-icon-button:before,.vot-icon-button:after{content:\"\";opacity:0;position:absolute;top:0;bottom:0;left:0;right:0;border-radius:inherit!important}.vot-icon-button:before{background-color:var(--vot-helper-onsurface);transition:opacity .2s}.vot-icon-button:after{background:radial-gradient(circle,currentColor 1%,#0000 1%) 50%/10000% 10000% no-repeat;transition:opacity .3s,background-size .4s}.vot-icon-button:hover:before{opacity:.04}.vot-icon-button:active:after{opacity:.32;background-size:100% 100%;transition:background-size,opacity}.vot-icon-button[disabled=true]{color:rgba(var(--vot-onsurface-rgb,0,0,0),.38);fill:rgba(var(--vot-onsurface-rgb,0,0,0),.38);cursor:initial;background-color:#0000}.vot-icon-button[disabled=true]:before,.vot-icon-button[disabled=true]:after{opacity:0}.vot-textfield{display:inline-block;--vot-helper-theme:rgb(var(--vot-theme-rgb,var(--vot-primary-rgb,33,150,243)))!important;--vot-helper-safari1:rgba(var(--vot-onsurface-rgb,0,0,0),.38)!important;--vot-helper-safari2:rgba(var(--vot-onsurface-rgb,0,0,0),.6)!important;--vot-helper-safari3:rgba(var(--vot-onsurface-rgb,0,0,0),.87)!important;font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system)!important;text-align:start!important;padding-top:6px!important;font-size:16px!important;line-height:1.5!important;position:relative!important}.vot-textfield[hidden]{display:none!important}.vot-textfield>input,.vot-textfield>textarea{box-sizing:border-box!important;border-style:solid!important;border-width:1px!important;border-color:transparent var(--vot-helper-safari2)var(--vot-helper-safari2)!important;width:100%!important;height:inherit!important;color:rgba(var(--vot-onsurface-rgb,0,0,0),.87)!important;-webkit-text-fill-color:currentColor!important;font-family:inherit!important;font-size:inherit!important;line-height:inherit!important;caret-color:var(--vot-helper-theme)!important;background-color:#0000!important;border-radius:4px!important;margin:0!important;padding:15px 13px!important;transition:border .2s,box-shadow .2s!important;box-shadow:inset 1px 0 #0000,inset -1px 0 #0000,inset 0 -1px #0000!important}.vot-textfield>input:not(:focus):not(.vot-show-placeholer)::-moz-placeholder{color:#0000!important}.vot-textfield>textarea:not(:focus):not(.vot-show-placeholer)::-moz-placeholder{color:#0000!important}.vot-textfield>input:not(:focus):not(.vot-show-placeholer)::-moz-placeholder{color:#0000!important}.vot-textfield>textarea:not(:focus):not(.vot-show-placeholer)::-moz-placeholder{color:#0000!important}.vot-textfield>input:not(:focus):not(.vot-show-placeholer)::-webkit-input-placeholder{color:#0000!important}.vot-textfield>textarea:not(:focus):not(.vot-show-placeholer)::-webkit-input-placeholder{color:#0000!important}.vot-textfield>input:not(:focus):placeholder-shown,.vot-textfield>textarea:not(:focus):placeholder-shown{border-top-color:var(--vot-helper-safari2)!important}.vot-textfield>input+span,.vot-textfield>textarea+span{font-family:inherit;width:100%!important;max-height:100%!important;color:rgba(var(--vot-onsurface-rgb,0,0,0),.6)!important;cursor:text!important;pointer-events:none!important;font-size:75%!important;line-height:15px!important;transition:color .2s,font-size .2s,line-height .2s!important;display:flex!important;position:absolute!important;top:0!important;left:0!important}.vot-textfield>input:not(:focus):placeholder-shown+span,.vot-textfield>textarea:not(:focus):placeholder-shown+span{font-size:inherit!important;line-height:68px!important}.vot-textfield>input+span:before,.vot-textfield>input+span:after,.vot-textfield>textarea+span:before,.vot-textfield>textarea+span:after{content:\"\"!important;box-sizing:border-box!important;border-top:solid 1px var(--vot-helper-safari2)!important;pointer-events:none!important;min-width:10px!important;height:8px!important;margin-top:6px!important;transition:border .2s,box-shadow .2s!important;display:block!important;box-shadow:inset 0 1px #0000!important}.vot-textfield>input+span:before,.vot-textfield>textarea+span:before{border-left:1px solid #0000!important;border-radius:4px 0!important;margin-right:4px!important}.vot-textfield>input+span:after,.vot-textfield>textarea+span:after{border-right:1px solid #0000!important;border-radius:0 4px!important;flex-grow:1!important;margin-left:4px!important}.vot-textfield>input.vot-show-placeholer+span:before,.vot-textfield>textarea.vot-show-placeholer+span:before{margin-right:0!important}.vot-textfield>input.vot-show-placeholer+span:after,.vot-textfield>textarea.vot-show-placeholer+span:after{margin-left:0!important}.vot-textfield>input:not(:focus):placeholder-shown+span:before,.vot-textfield>input:not(:focus):placeholder-shown+span:after,.vot-textfield>textarea:not(:focus):placeholder-shown+span:before,.vot-textfield>textarea:not(:focus):placeholder-shown+span:after{border-top-color:#0000!important}.vot-textfield:hover>input:not(:disabled),.vot-textfield:hover>textarea:not(:disabled){border-color:transparent var(--vot-helper-safari3)var(--vot-helper-safari3)!important}.vot-textfield:hover>input:not(:disabled)+span:before,.vot-textfield:hover>input:not(:disabled)+span:after,.vot-textfield:hover>textarea:not(:disabled)+span:before,.vot-textfield:hover>textarea:not(:disabled)+span:after{border-top-color:var(--vot-helper-safari3)!important}.vot-textfield:hover>input:not(:disabled):not(:focus):placeholder-shown,.vot-textfield:hover>textarea:not(:disabled):not(:focus):placeholder-shown{border-color:var(--vot-helper-safari3)!important}.vot-textfield>input:focus,.vot-textfield>textarea:focus{border-color:transparent var(--vot-helper-theme)var(--vot-helper-theme)!important;box-shadow:inset 1px 0 var(--vot-helper-theme),inset -1px 0 var(--vot-helper-theme),inset 0 -1px var(--vot-helper-theme)!important;outline:none!important}.vot-textfield>input:focus+span,.vot-textfield>textarea:focus+span{color:var(--vot-helper-theme)!important}.vot-textfield>input:focus+span:before,.vot-textfield>input:focus+span:after,.vot-textfield>textarea:focus+span:before,.vot-textfield>textarea:focus+span:after{border-top-color:var(--vot-helper-theme)!important;box-shadow:inset 0 1px var(--vot-helper-theme)!important}.vot-textfield>input:disabled,.vot-textfield>input:disabled+span,.vot-textfield>textarea:disabled,.vot-textfield>textarea:disabled+span{border-color:transparent var(--vot-helper-safari1)var(--vot-helper-safari1)!important;color:rgba(var(--vot-onsurface-rgb,0,0,0),.38)!important;pointer-events:none!important}.vot-textfield>input:disabled+span:before,.vot-textfield>input:disabled+span:after,.vot-textfield>textarea:disabled+span:before,.vot-textfield>textarea:disabled+span:after,.vot-textfield>input:disabled:placeholder-shown,.vot-textfield>input:disabled:placeholder-shown+span,.vot-textfield>textarea:disabled:placeholder-shown,.vot-textfield>textarea:disabled:placeholder-shown+span{border-top-color:var(--vot-helper-safari1)!important}.vot-textfield>input:disabled:placeholder-shown+span:before,.vot-textfield>input:disabled:placeholder-shown+span:after,.vot-textfield>textarea:disabled:placeholder-shown+span:before,.vot-textfield>textarea:disabled:placeholder-shown+span:after{border-top-color:#0000!important}@media not all and (-webkit-min-device-pixel-ratio:.0000264583),not all and (min-resolution:.001dpcm){@supports ((-webkit-appearance:none)){.vot-textfield>input,.vot-textfield>input+span,.vot-textfield>textarea,.vot-textfield>textarea+span,.vot-textfield>input+span:before,.vot-textfield>input+span:after,.vot-textfield>textarea+span:before,.vot-textfield>textarea+span:after{transition-duration:.1s!important}}}.vot-checkbox{--vot-helper-theme:var(--vot-theme-rgb,var(--vot-primary-rgb,33,150,243));--vot-helper-ontheme:var(--vot-ontheme-rgb,var(--vot-onprimary-rgb,255,255,255));z-index:0;color:rgba(var(--vot-onsurface-rgb,0,0,0),.87);font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system);text-align:start;font-size:16px;line-height:1.5;display:inline-block;position:relative}.vot-checkbox-sub{padding-left:16px!important}.vot-checkbox[hidden]{display:none!important}.vot-checkbox>input{-webkit-appearance:none;appearance:none;z-index:10000;box-sizing:border-box;cursor:pointer;background:0 0;outline:none;width:18px;height:18px;transition:border-color .2s,background-color .2s;display:block;position:absolute;border:2px solid!important;border-color:rgba(var(--vot-onsurface-rgb,0,0,0),.6)!important;border-radius:2px!important;margin:3px 1px!important;padding:0!important}.vot-checkbox>input+span{box-sizing:border-box;width:inherit;cursor:pointer;font-family:inherit;font-weight:400;display:inline-block;position:relative;padding-left:30px!important}.vot-checkbox>input+span:before{content:\"\";background-color:rgb(var(--vot-onsurface-rgb,0,0,0));opacity:0;pointer-events:none;width:40px;height:40px;transition:opacity .3s,transform .2s;display:block;position:absolute;top:-8px;left:-10px;transform:scale(1);border-radius:50%!important}.vot-checkbox>input+span:after{content:\"\";z-index:10000;pointer-events:none;width:10px;height:5px;transition:border-color .2s;display:block;position:absolute;top:3px;left:1px;transform:translate(3px,4px)rotate(-45deg);box-sizing:content-box!important;border:0 solid #0000!important;border-width:0 0 2px 2px!important}.vot-checkbox>input:checked,.vot-checkbox>input:indeterminate{background-color:rgb(var(--vot-helper-theme));border-color:rgb(var(--vot-helper-theme))!important}.vot-checkbox>input:checked+span:before,.vot-checkbox>input:indeterminate+span:before{background-color:rgb(var(--vot-helper-theme))}.vot-checkbox>input:checked+span:after,.vot-checkbox>input:indeterminate+span:after{border-color:rgb(var(--vot-helper-ontheme,255,255,255))!important}.vot-checkbox>input:hover{box-shadow:none!important}.vot-checkbox>input:indeterminate+span:after{transform:translate(4px,3px);border-left-width:0!important}.vot-checkbox:hover>input+span:before{opacity:.04}.vot-checkbox:active>input,.vot-checkbox:active:hover>input:not(:disabled){border-color:rgb(var(--vot-helper-theme))!important}.vot-checkbox:active>input:checked{background-color:rgba(var(--vot-onsurface-rgb,0,0,0),.6);border-color:#0000!important}.vot-checkbox:active>input+span:before{opacity:1;transition:transform,opacity;transform:scale(0)}.vot-checkbox>input:disabled{cursor:initial;border-color:rgba(var(--vot-onsurface-rgb,0,0,0),.38)!important}.vot-checkbox>input:disabled:checked,.vot-checkbox>input:disabled:indeterminate{background-color:rgba(var(--vot-onsurface-rgb,0,0,0),.38);border-color:#0000!important}.vot-checkbox>input:disabled+span{color:rgba(var(--vot-onsurface-rgb,0,0,0),.38);cursor:initial}.vot-checkbox>input:disabled+span:before{opacity:0;transform:scale(0)}.vot-slider{display:inline-block;--vot-safari-helper1:rgba(var(--vot-primary-rgb,33,150,243),.04)!important;--vot-safari-helper2:rgba(var(--vot-primary-rgb,33,150,243),.12)!important;--vot-safari-helper3:rgba(var(--vot-primary-rgb,33,150,243),.16)!important;--vot-safari-helper4:rgba(var(--vot-primary-rgb,33,150,243),.24)!important;width:100%!important;color:rgba(var(--vot-onsurface-rgb,0,0,0),.87)!important;font-family:var(--vot-font,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system)!important;text-align:start!important;font-size:16px!important;line-height:1.5!important}.vot-slider[hidden]{display:none!important}.vot-slider>input{-webkit-appearance:none!important;appearance:none!important;cursor:pointer!important;background-color:#0000!important;border:none!important;width:100%!important;height:36px!important;margin:0 0 -36px!important;padding:0!important;display:block!important;position:relative!important;top:24px!important}.vot-slider>input:hover{box-shadow:none!important}.vot-slider>input:last-child{margin:0!important;position:static!important}.vot-slider>input:before{content:\"\"!important;width:calc(100%*var(--vot-progress,0))!important;background:rgb(var(--vot-primary-rgb,33,150,243))!important;height:2px!important;display:block!important;position:absolute!important;top:calc(50% - 1px)!important}.vot-slider>input:disabled{cursor:default!important;opacity:.38!important}.vot-slider>input:disabled+span{color:rgba(var(--vot-onsurface-rgb,0,0,0),.38)!important}.vot-slider>input:disabled::-webkit-slider-runnable-track{background-color:rgba(var(--vot-onsurface-rgb,0,0,0),.38)!important}.vot-slider>input:disabled::-moz-range-track{background-color:rgba(var(--vot-onsurface-rgb,0,0,0),.38)!important}.vot-slider>input:disabled::-ms-fill-lower{background-color:rgba(var(--vot-onsurface-rgb,0,0,0),.38)!important}.vot-slider>input:disabled::-ms-fill-upper{background-color:rgba(var(--vot-onsurface-rgb,0,0,0),.38)!important}.vot-slider>input:disabled::-moz-range-thumb{background-color:rgb(var(--vot-onsurface-rgb,0,0,0))!important;box-shadow:0 0 0 1px rgb(var(--vot-surface-rgb,255,255,255))!important;transform:scale(4)!important}.vot-slider>input:disabled::-ms-thumb{background-color:rgb(var(--vot-onsurface-rgb,0,0,0))!important;box-shadow:0 0 0 1px rgb(var(--vot-surface-rgb,255,255,255))!important;transform:scale(4)!important}.vot-slider>input:disabled::-webkit-slider-thumb{background-color:rgb(var(--vot-onsurface-rgb,0,0,0))!important;box-shadow:0 0 0 1px rgb(var(--vot-surface-rgb,255,255,255))!important;transform:scale(4)!important}.vot-slider>input:disabled::-ms-fill-upper{opacity:.38!important}.vot-slider>input:disabled::-moz-range-progress{background-color:rgba(var(--vot-onsurface-rgb,0,0,0),.87)!important}.vot-slider>input:disabled:-webkit-slider-thumb{color:rgb(var(--vot-surface-rgb,255,255,255))!important}.vot-slider>input:active::-webkit-slider-thumb{box-shadow:0 0 0 2px var(--vot-safari-helper4)!important}.vot-slider>input:active::-moz-range-thumb{box-shadow:0 0 0 2px rgba(var(--vot-primary-rgb,33,150,243),.24)!important}.vot-slider>input:active::-ms-thumb{box-shadow:0 0 0 2px rgba(var(--vot-primary-rgb,33,150,243),.24)!important}.vot-slider>input:focus{outline:none!important}.vot-slider>input::-webkit-slider-runnable-track{background-color:rgba(var(--vot-primary-rgb,33,150,243),.24)!important;border-radius:1px!important;width:100%!important;height:2px!important;margin:17px 0!important}.vot-slider>input::-moz-range-track{background-color:rgba(var(--vot-primary-rgb,33,150,243),.24)!important;border-radius:1px!important;width:100%!important;height:2px!important;margin:17px 0!important}.vot-slider>input::-ms-track{box-sizing:border-box!important;background-color:#0000!important;border:none!important;border-radius:1px!important;width:100%!important;height:2px!important;margin:17px 0!important;padding:0 17px!important}.vot-slider>input::-webkit-slider-thumb{-webkit-appearance:none!important;appearance:none!important;background-color:rgb(var(--vot-primary-rgb,33,150,243))!important;border:none!important;border-radius:50%!important;width:2px!important;height:2px!important;transition:box-shadow .2s!important;transform:scale(6)!important}.vot-slider>input::-moz-range-thumb{-webkit-appearance:none!important;appearance:none!important;background-color:rgb(var(--vot-primary-rgb,33,150,243))!important;border:none!important;border-radius:50%!important;width:2px!important;height:2px!important;transition:box-shadow .2s!important;transform:scale(6)!important}.vot-slider>input::-ms-thumb{-webkit-appearance:none!important;appearance:none!important;background-color:rgb(var(--vot-primary-rgb,33,150,243))!important;border:none!important;border-radius:50%!important;width:2px!important;height:2px!important;transition:box-shadow .2s!important;transform:scale(6)!important}.vot-slider>input::-webkit-slider-thumb{-webkit-appearance:none!important;margin:0!important}.vot-slider>input::-moz-range-thumb{-moz-appearance:none!important}.vot-slider>input::-ms-thumb{margin:0 17px!important}.vot-slider>input::-moz-range-progress{background-color:rgb(var(--vot-primary-rgb,33,150,243))!important;border-radius:1px!important;height:2px!important}.vot-slider>input::-ms-fill-lower{background-color:rgb(var(--vot-primary-rgb,33,150,243))!important;border-radius:1px!important;height:2px!important}.vot-slider>input::-ms-fill-upper{background-color:rgb(var(--vot-primary-rgb,33,150,243))!important;border-radius:1px!important;height:2px!important}.vot-slider>input::-moz-focus-outer{border:none!important}.vot-slider>span{margin-bottom:36px!important;display:inline-block!important}.vot-slider:hover>input::-webkit-slider-thumb{box-shadow:0 0 0 2px var(--vot-safari-helper1)!important}.vot-slider:hover>input::-ms-thumb{box-shadow:0 0 0 2px rgba(var(--vot-primary-rgb,33,150,243),.04)!important}.vot-slider:hover>input:hover::-moz-range-thumb{box-shadow:0 0 0 2px rgba(var(--vot-primary-rgb,33,150,243),.04)!important}.vot-select{font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system);text-align:start;color:var(--vot-helper-theme);fill:var(--vot-helper-theme);justify-content:space-between;align-items:center;font-size:14px;font-weight:400;line-height:1.5;display:flex;--vot-helper-theme-rgb:var(--vot-onsurface-rgb,0,0,0)!important;--vot-helper-theme:rgba(var(--vot-helper-theme-rgb),.87)!important;--vot-helper-safari1:rgba(var(--vot-onsurface-rgb,0,0,0),.6)!important;--vot-helper-safari2:rgba(var(--vot-onsurface-rgb,0,0,0),.87)!important}.vot-select[hidden]{display:none!important}.vot-select-label{font-family:inherit;font-size:16px}.vot-select-outer{cursor:pointer;justify-content:space-between;align-items:center;width:120px;max-width:120px;display:flex;border:1px solid var(--vot-helper-safari1)!important;border-radius:4px!important;padding:0 5px!important;transition:border .2s!important}.vot-select-outer:hover{border-color:var(--vot-helper-safari2)!important}.vot-select-title{text-overflow:ellipsis;white-space:nowrap;font-family:inherit;overflow:hidden}.vot-select-arrow-icon{justify-content:center;align-items:center;width:20px;height:32px;display:flex}.vot-select-content-list{flex-direction:column;display:flex}.vot-select-content-list .vot-select-content-item{cursor:pointer;border-radius:8px!important;padding:5px 10px!important}.vot-select-content-list .vot-select-content-item:not([inert]):hover{background-color:#2a2c31}.vot-select-content-list .vot-select-content-item[data-vot-selected=true]{color:rgb(var(--vot-primary-rgb,33,150,243));background-color:rgba(var(--vot-primary-rgb,33,150,243),.2)}.vot-select-content-list .vot-select-content-item[data-vot-selected=true]:hover{background-color:rgba(var(--vot-primary-rgb,33,150,243),.1)!important}.vot-select-content-list .vot-select-content-item[data-vot-disabled=true]{cursor:default}.vot-select-content-list .vot-select-content-item[hidden]{display:none!important}.vot-header{color:rgba(var(--vot-helper-onsurface-rgb),.87);font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system);text-align:start;font-weight:700;line-height:1.5}.vot-header[hidden]{display:none!important}.vot-header:not(:first-child){padding-top:8px}.vot-header-level-1{font-size:2em}.vot-header-level-2{font-size:1.5em}.vot-header-level-3{font-size:1.17em}.vot-header-level-4{font-size:1em}.vot-header-level-5{font-size:.83em}.vot-header-level-6{font-size:.67em}.vot-info{color:rgba(var(--vot-helper-onsurface-rgb),.87);font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system);text-align:start;-webkit-user-select:text;user-select:text;font-size:16px;line-height:1.5;display:flex}.vot-info[hidden]{display:none!important}.vot-info>:not(:first-child){color:rgba(var(--vot-helper-onsurface-rgb),.5);flex:1;margin-left:8px!important}.vot-details{color:rgba(var(--vot-helper-onsurface-rgb),.87);font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system);text-align:start;cursor:pointer;justify-content:space-between;align-items:center;font-size:16px;line-height:1.5;transition:background .5s;display:flex;border-radius:.5em!important;margin:0 -.5em!important;padding:.5em!important}.vot-details[hidden]{display:none!important}.vot-details-arrow-icon{width:20px;height:32px;fill:rgba(var(--vot-helper-onsurface-rgb),.87);justify-content:center;align-items:center;display:flex;transform:scale(1.25)rotate(-90deg)}.vot-details:hover{background:rgba(var(--vot-onsurface-rgb,0,0,0),.04)}.vot-lang-select{--vot-helper-theme-rgb:var(--vot-onsurface-rgb,0,0,0);--vot-helper-theme:rgba(var(--vot-helper-theme-rgb),.87);color:var(--vot-helper-theme);fill:var(--vot-helper-theme);justify-content:space-between;align-items:center;display:flex}.vot-lang-select[hidden]{display:none!important}.vot-lang-select-icon{justify-content:center;align-items:center;width:32px;height:32px;display:flex}.vot-segmented-button{--vot-helper-theme-rgb:var(--vot-onsurface-rgb,0,0,0);--vot-helper-theme:rgba(var(--vot-helper-theme-rgb),.87);-webkit-user-select:none;user-select:none;background:rgb(var(--vot-surface-rgb,255,255,255));max-width:100vw;height:32px;color:var(--vot-helper-theme);fill:var(--vot-helper-theme);font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system);cursor:default;z-index:2147483647;align-items:center;font-size:16px;line-height:1.5;transition:opacity .5s;display:flex;position:absolute;top:5rem;left:50%;overflow:hidden;transform:translate(-50%);border-radius:4px!important}.vot-segmented-button[hidden]{display:none!important}.vot-segmented-button *{box-sizing:border-box!important}.vot-segmented-button .vot-separator{background:rgba(var(--vot-helper-theme-rgb),.1);width:1px;height:50%}.vot-segmented-button .vot-separator[hidden]{display:none!important}.vot-segmented-button .vot-segment,.vot-segmented-button .vot-segment-only-icon{height:100%;color:inherit;background-color:#0000;justify-content:center;align-items:center;transition:background-color .1s ease-in-out;display:flex;position:relative;overflow:hidden;border:none!important;padding:0 8px!important}.vot-segmented-button .vot-segment[hidden],.vot-segmented-button [hidden].vot-segment-only-icon{display:none!important}.vot-segmented-button .vot-segment:before,.vot-segmented-button .vot-segment-only-icon:before,.vot-segmented-button .vot-segment:after,.vot-segmented-button .vot-segment-only-icon:after{content:\"\";opacity:0;position:absolute;top:0;bottom:0;left:0;right:0;border-radius:inherit!important}.vot-segmented-button .vot-segment:before,.vot-segmented-button .vot-segment-only-icon:before{background-color:rgb(var(--vot-helper-theme-rgb));transition:opacity .2s}.vot-segmented-button .vot-segment:after,.vot-segmented-button .vot-segment-only-icon:after{background:radial-gradient(circle,currentColor 1%,#0000 1%) 50%/10000% 10000% no-repeat;transition:opacity 1s,background-size .5s}.vot-segmented-button .vot-segment:hover:before,.vot-segmented-button .vot-segment-only-icon:hover:before{opacity:.04}.vot-segmented-button .vot-segment:active:after,.vot-segmented-button .vot-segment-only-icon:active:after{opacity:.16;background-size:100% 100%;transition:background-size}.vot-segmented-button .vot-segment-only-icon{min-width:32px;padding:0!important}.vot-segmented-button .vot-segment-label{white-space:nowrap;color:inherit;font-weight:400;margin-left:8px!important}.vot-segmented-button[data-status=success] .vot-translate-button{color:rgb(var(--vot-primary-rgb,33,150,243));fill:rgb(var(--vot-primary-rgb,33,150,243))}.vot-segmented-button[data-status=error] .vot-translate-button{color:#f28b82;fill:#f28b82}.vot-segmented-button[data-loading=true] #vot-loading-icon{display:block!important}.vot-segmented-button[data-loading=true] #vot-translate-icon{display:none!important}.vot-segmented-button[data-direction=column]{flex-direction:column;height:fit-content}.vot-segmented-button[data-direction=column] .vot-segment-label{display:none}.vot-segmented-button[data-direction=column]>.vot-segment-only-icon,.vot-segmented-button[data-direction=column]>.vot-segment{padding:8px!important}.vot-segmented-button[data-direction=column] .vot-separator{width:50%;height:1px}.vot-segmented-button[data-position=left]{top:12.5vh;left:50px}.vot-segmented-button[data-position=right]{top:12.5vh;left:auto;right:0}.vot-segmented-button svg{width:24px}.vot-tooltip{--vot-helper-theme-rgb:var(--vot-onsurface-rgb,0,0,0);--vot-helper-theme:rgba(var(--vot-helper-theme-rgb),.87);--vot-helper-ondialog:rgb(var(--vot-ondialog-rgb,37,38,40));-webkit-user-select:none;user-select:none;background:rgb(var(--vot-surface-rgb,255,255,255));color:var(--vot-helper-theme);fill:var(--vot-helper-theme);font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system);cursor:default;z-index:2147483647;opacity:0;align-items:center;width:max-content;max-width:calc(100vw - 10px);height:max-content;font-size:14px;line-height:1.5;transition:opacity .5s;display:flex;position:absolute;top:0;bottom:0;left:0;right:0;overflow:hidden;box-shadow:0 1px 3px #0000001f;border-radius:4px!important;padding:4px 8px!important}.vot-tooltip[hidden]{display:none!important}.vot-tooltip[data-trigger=click]{-webkit-user-select:text;user-select:text}.vot-tooltip *{box-sizing:border-box!important}.vot-menu{--vot-helper-surface-rgb:var(--vot-surface-rgb,255,255,255);--vot-helper-surface:rgb(var(--vot-helper-surface-rgb));--vot-helper-onsurface-rgb:var(--vot-onsurface-rgb,0,0,0);--vot-helper-onsurface:rgba(var(--vot-helper-onsurface-rgb),.87);-webkit-user-select:none;user-select:none;background-color:var(--vot-helper-surface);color:var(--vot-helper-onsurface);font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system);cursor:default;z-index:2147483647;visibility:visible;opacity:1;transform-origin:top;min-width:300px;font-size:16px;line-height:1.5;transition:opacity .3s,transform .1s;position:absolute;top:calc(5rem + 48px);left:50%;overflow:hidden;transform:translate(-50%)scale(1);border-radius:8px!important}.vot-menu *{box-sizing:border-box!important}.vot-menu[hidden]{pointer-events:none;visibility:hidden;opacity:0;transform:translate(-50%)scale(0);display:block!important}.vot-menu-content-wrapper{min-height:100px;max-height:calc(var(--vot-container-height,75vh) - (5rem + 32px + 16px)*2);flex-direction:column;display:flex;overflow:auto}.vot-menu-header-container{flex-shrink:0;align-items:flex-start;min-height:31px;display:flex}.vot-menu-header-container:empty{padding:0 0 16px!important}.vot-menu-header-container>.vot-icon-button{margin-inline-end:4px!important;margin-top:4px!important}.vot-menu-title-container{font-size:inherit;font-weight:inherit;text-align:start;outline:0;flex:1;display:flex;margin:0!important}.vot-menu-title{flex:1;font-size:16px;font-weight:400;line-height:1;padding:16px!important}.vot-menu-body-container{box-sizing:border-box;overscroll-behavior:contain;flex-direction:column;gap:8px;min-height:1.375rem;display:flex;overflow:auto;scrollbar-color:rgba(var(--vot-helper-onsurface-rgb),.1)var(--vot-helper-surface)!important;padding:0 16px!important}.vot-menu-body-container::-webkit-scrollbar{background:var(--vot-helper-surface)!important;width:12px!important;height:12px!important}.vot-menu-body-container::-webkit-scrollbar-track{background:var(--vot-helper-surface)!important;width:12px!important;height:12px!important}.vot-menu-body-container::-webkit-scrollbar-thumb{background:rgba(var(--vot-helper-onsurface-rgb),.1)!important;border:5px solid var(--vot-helper-surface)!important;-webkit-border-radius:1ex!important}.vot-menu-body-container::-webkit-scrollbar-thumb:hover{border:3px solid var(--vot-helper-surface)!important}.vot-menu-body-container::-webkit-scrollbar-corner{background:var(--vot-helper-surface)!important}.vot-menu-footer-container{flex-shrink:0;justify-content:flex-end;display:flex;padding:16px!important}.vot-menu-footer-container:empty{padding:16px 0 0!important}.vot-menu[data-position=left]{top:12.5vh;left:240px}.vot-menu[data-position=right]{top:12.5vh;left:auto;right:-80px}.vot-dialog{--vot-helper-surface-rgb:var(--vot-surface-rgb,255,255,255);--vot-helper-surface:rgb(var(--vot-helper-surface-rgb));--vot-helper-onsurface-rgb:var(--vot-onsurface-rgb,0,0,0);--vot-helper-onsurface:rgba(var(--vot-helper-onsurface-rgb),.87);max-width:initial;max-height:initial;width:min(var(--vot-dialog-width,512px),100%);top:50%;bottom:50%;background-color:var(--vot-helper-surface);height:fit-content;color:var(--vot-helper-onsurface);font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system);-webkit-user-select:none;user-select:none;visibility:visible;opacity:1;transform-origin:50%;border-radius:8px;font-size:16px;line-height:1.5;transition:opacity .3s,transform .1s;display:block;position:fixed;top:0;bottom:0;left:0;right:0;overflow-x:auto;overflow-y:hidden;transform:scale(1);box-shadow:0 0 16px #0000001f,0 16px 16px #0000003d;margin:auto!important;padding:0!important}[hidden]>.vot-dialog{pointer-events:none;opacity:0;transition:opacity .1s,transform .2s;transform:scale(.5)}.vot-dialog-container{visibility:visible;z-index:2147483647;position:absolute}.vot-dialog-container[hidden]{pointer-events:none;visibility:hidden;display:block!important}.vot-dialog-container *{box-sizing:border-box!important}.vot-dialog-backdrop{opacity:1;background-color:#0009;transition:opacity .3s;position:fixed;top:0;bottom:0;left:0;right:0}[hidden]>.vot-dialog-backdrop{pointer-events:none;opacity:0}.vot-dialog-content-wrapper{flex-direction:column;max-height:75vh;display:flex;overflow:auto}.vot-dialog-header-container{flex-shrink:0;align-items:flex-start;min-height:31px;display:flex}.vot-dialog-header-container:empty{padding:0 0 20px}.vot-dialog-header-container>.vot-icon-button{margin-inline-end:4px!important;margin-top:4px!important}.vot-dialog-title-container{font-size:inherit;font-weight:inherit;outline:0;flex:1;display:flex;margin:0!important}.vot-dialog-title{flex:1;font-size:115.385%;font-weight:700;line-height:1;padding:20px 20px 16px!important}.vot-dialog-body-container{box-sizing:border-box;overscroll-behavior:contain;flex-direction:column;gap:16px;min-height:1.375rem;display:flex;overflow:auto;scrollbar-color:rgba(var(--vot-helper-onsurface-rgb),.1)var(--vot-helper-surface)!important;padding:0 20px!important}.vot-dialog-body-container::-webkit-scrollbar{background:var(--vot-helper-surface)!important;width:12px!important;height:12px!important}.vot-dialog-body-container::-webkit-scrollbar-track{background:var(--vot-helper-surface)!important;width:12px!important;height:12px!important}.vot-dialog-body-container::-webkit-scrollbar-thumb{background:rgba(var(--vot-helper-onsurface-rgb),.1)!important;border:5px solid var(--vot-helper-surface)!important;-webkit-border-radius:1ex!important}.vot-dialog-body-container::-webkit-scrollbar-thumb:hover{border:3px solid var(--vot-helper-surface)!important}.vot-dialog-body-container::-webkit-scrollbar-corner{background:var(--vot-helper-surface)!important}.vot-dialog-footer-container{flex-shrink:0;justify-content:flex-end;display:flex;padding:16px!important}.vot-dialog-footer-container:empty{padding:20px 0 0!important}.vot-subtitles{--vot-subtitles-background:rgba(var(--vot-surface-rgb,46,47,52),var(--vot-subtitles-opacity,.8));background:var(--vot-subtitles-background,#2e2f34cc);width:max-content;max-width:100%;max-height:100%;color:var(--vot-subtitles-color,#e3e3e3);pointer-events:all;font-size:20px;font-family:var(--vot-font-family,\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system);box-sizing:border-box;-webkit-user-select:none;user-select:none;flex-wrap:wrap;gap:0 3px;line-height:normal;display:flex;position:relative;border-radius:.5em!important;padding:.5em!important}.vot-subtitles-widget{z-index:2147483647;pointer-events:none;justify-content:center;align-items:center;width:50%;min-height:20%;max-height:100%;display:flex;position:absolute;top:75%;left:25%}.vot-subtitles-info{flex-direction:column;gap:2px;display:flex;padding:6px!important}.vot-subtitles-info-service{color:var(--vot-subtitles-context-color,#86919b);margin-bottom:8px!important;font-size:10px!important;line-height:1!important}.vot-subtitles-info-header{color:var(--vot-subtitles-header-color,#fff);margin-bottom:6px!important;font-size:20px!important;font-weight:500!important;line-height:1!important}.vot-subtitles-info-context{color:var(--vot-subtitles-context-color,#86919b);font-size:12px!important;line-height:1.2!important}.vot-subtitles span{cursor:pointer;position:relative;font-size:inherit!important;font-family:inherit!important;line-height:normal!important}.vot-subtitles span.passed{color:var(--vot-subtitles-passed-color,#2196f3)}.vot-subtitles span:before{content:\"\";z-index:-1;width:100%;height:100%;position:absolute;top:2px;bottom:2px;left:-2px;right:-2px;border-radius:4px!important;padding:0 2px!important}.vot-subtitles span:hover:before{background:var(--vot-subtitles-hover-color,#ffffff8c)}.vot-subtitles span.selected:before{background:var(--vot-subtitles-passed-color,#2196f3)}#vot-subtitles-info.vot-subtitles-info *{-webkit-user-select:text!important;user-select:text!important}:root{--vot-font-family:\"Roboto\",\"Segoe UI\",BlinkMacSystemFont,system-ui,-apple-system;--vot-primary-rgb:139,180,245;--vot-onprimary-rgb:32,33,36;--vot-surface-rgb:32,33,36;--vot-onsurface-rgb:227,227,227;--vot-subtitles-color:rgb(var(--vot-onsurface-rgb,227,227,227));--vot-subtitles-passed-color:rgb(var(--vot-primary-rgb,33,150,243))}vot-block{font-family:inherit;display:block;visibility:visible!important}.vot-portal{display:inline}.vot-portal-local{z-index:2147483647;position:fixed;top:0;left:0}")

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
// This entry needs to be wrapped in an IIFE because it needs to be in strict mode.
(() => {
"use strict";

;// ./node_modules/lit-html/lit-html.js
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const n=globalThis,c=n.trustedTypes,h=c?c.createPolicy("lit-html",{createHTML:t=>t}):void 0,f="$lit$",v=`lit$${Math.random().toFixed(9).slice(2)}$`,m="?"+v,_=`<${m}>`,w=document,lt=()=>w.createComment(""),st=t=>null===t||"object"!=typeof t&&"function"!=typeof t,g=Array.isArray,$=t=>g(t)||"function"==typeof t?.[Symbol.iterator],x="[ \t\n\f\r]",T=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,E=/-->/g,k=/>/g,O=RegExp(`>|${x}(?:([^\\s"'>=/]+)(${x}*=${x}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),S=/'/g,j=/"/g,M=/^(?:script|style|textarea|title)$/i,P=t=>(i,...s)=>({_$litType$:t,strings:i,values:s}),ke=P(1),Oe=P(2),Se=P(3),R=Symbol.for("lit-noChange"),D=Symbol.for("lit-nothing"),V=new WeakMap,I=w.createTreeWalker(w,129);function N(t,i){if(!g(t)||!t.hasOwnProperty("raw"))throw Error("invalid template strings array");return void 0!==h?h.createHTML(i):i}const U=(t,i)=>{const s=t.length-1,e=[];let h,o=2===i?"<svg>":3===i?"<math>":"",n=T;for(let i=0;i<s;i++){const s=t[i];let r,l,c=-1,a=0;for(;a<s.length&&(n.lastIndex=a,l=n.exec(s),null!==l);)a=n.lastIndex,n===T?"!--"===l[1]?n=E:void 0!==l[1]?n=k:void 0!==l[2]?(M.test(l[2])&&(h=RegExp("</"+l[2],"g")),n=O):void 0!==l[3]&&(n=O):n===O?">"===l[0]?(n=h??T,c=-1):void 0===l[1]?c=-2:(c=n.lastIndex-l[2].length,r=l[1],n=void 0===l[3]?O:'"'===l[3]?j:S):n===j||n===S?n=O:n===E||n===k?n=T:(n=O,h=void 0);const u=n===O&&t[i+1].startsWith("/>")?" ":"";o+=n===T?s+_:c>=0?(e.push(r),s.slice(0,c)+f+s.slice(c)+v+u):s+v+(-2===c?i:u)}return[N(t,o+(t[s]||"<?>")+(2===i?"</svg>":3===i?"</math>":"")),e]};class B{constructor({strings:t,_$litType$:i},s){let e;this.parts=[];let h=0,o=0;const n=t.length-1,r=this.parts,[l,a]=U(t,i);if(this.el=B.createElement(l,s),I.currentNode=this.el.content,2===i||3===i){const t=this.el.content.firstChild;t.replaceWith(...t.childNodes)}for(;null!==(e=I.nextNode())&&r.length<n;){if(1===e.nodeType){if(e.hasAttributes())for(const t of e.getAttributeNames())if(t.endsWith(f)){const i=a[o++],s=e.getAttribute(t).split(v),n=/([.?@])?(.*)/.exec(i);r.push({type:1,index:h,name:n[2],strings:s,ctor:"."===n[1]?Y:"?"===n[1]?Z:"@"===n[1]?q:G}),e.removeAttribute(t)}else t.startsWith(v)&&(r.push({type:6,index:h}),e.removeAttribute(t));if(M.test(e.tagName)){const t=e.textContent.split(v),i=t.length-1;if(i>0){e.textContent=c?c.emptyScript:"";for(let s=0;s<i;s++)e.append(t[s],lt()),I.nextNode(),r.push({type:2,index:++h});e.append(t[i],lt())}}}else if(8===e.nodeType)if(e.data===m)r.push({type:2,index:h});else{let t=-1;for(;-1!==(t=e.data.indexOf(v,t+1));)r.push({type:7,index:h}),t+=v.length-1}h++}}static createElement(t,i){const s=w.createElement("template");return s.innerHTML=t,s}}function z(t,i,s=t,e){if(i===R)return i;let h=void 0!==e?s.o?.[e]:s.l;const o=st(i)?void 0:i._$litDirective$;return h?.constructor!==o&&(h?._$AO?.(!1),void 0===o?h=void 0:(h=new o(t),h._$AT(t,s,e)),void 0!==e?(s.o??=[])[e]=h:s.l=h),void 0!==h&&(i=z(t,h._$AS(t,i.values),h,e)),i}class F{constructor(t,i){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=i}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:i},parts:s}=this._$AD,e=(t?.creationScope??w).importNode(i,!0);I.currentNode=e;let h=I.nextNode(),o=0,n=0,r=s[0];for(;void 0!==r;){if(o===r.index){let i;2===r.type?i=new et(h,h.nextSibling,this,t):1===r.type?i=new r.ctor(h,r.name,r.strings,this,t):6===r.type&&(i=new K(h,this,t)),this._$AV.push(i),r=s[++n]}o!==r?.index&&(h=I.nextNode(),o++)}return I.currentNode=w,e}p(t){let i=0;for(const s of this._$AV)void 0!==s&&(void 0!==s.strings?(s._$AI(t,s,i),i+=s.strings.length-2):s._$AI(t[i])),i++}}class et{get _$AU(){return this._$AM?._$AU??this.v}constructor(t,i,s,e){this.type=2,this._$AH=D,this._$AN=void 0,this._$AA=t,this._$AB=i,this._$AM=s,this.options=e,this.v=e?.isConnected??!0}get parentNode(){let t=this._$AA.parentNode;const i=this._$AM;return void 0!==i&&11===t?.nodeType&&(t=i.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,i=this){t=z(this,t,i),st(t)?t===D||null==t||""===t?(this._$AH!==D&&this._$AR(),this._$AH=D):t!==this._$AH&&t!==R&&this._(t):void 0!==t._$litType$?this.$(t):void 0!==t.nodeType?this.T(t):$(t)?this.k(t):this._(t)}O(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.O(t))}_(t){this._$AH!==D&&st(this._$AH)?this._$AA.nextSibling.data=t:this.T(w.createTextNode(t)),this._$AH=t}$(t){const{values:i,_$litType$:s}=t,e="number"==typeof s?this._$AC(t):(void 0===s.el&&(s.el=B.createElement(N(s.h,s.h[0]),this.options)),s);if(this._$AH?._$AD===e)this._$AH.p(i);else{const t=new F(e,this),s=t.u(this.options);t.p(i),this.T(s),this._$AH=t}}_$AC(t){let i=V.get(t.strings);return void 0===i&&V.set(t.strings,i=new B(t)),i}k(t){g(this._$AH)||(this._$AH=[],this._$AR());const i=this._$AH;let s,e=0;for(const h of t)e===i.length?i.push(s=new et(this.O(lt()),this.O(lt()),this,this.options)):s=i[e],s._$AI(h),e++;e<i.length&&(this._$AR(s&&s._$AB.nextSibling,e),i.length=e)}_$AR(t=this._$AA.nextSibling,i){for(this._$AP?.(!1,!0,i);t&&t!==this._$AB;){const i=t.nextSibling;t.remove(),t=i}}setConnected(t){void 0===this._$AM&&(this.v=t,this._$AP?.(t))}}class G{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,i,s,e,h){this.type=1,this._$AH=D,this._$AN=void 0,this.element=t,this.name=i,this._$AM=e,this.options=h,s.length>2||""!==s[0]||""!==s[1]?(this._$AH=Array(s.length-1).fill(new String),this.strings=s):this._$AH=D}_$AI(t,i=this,s,e){const h=this.strings;let o=!1;if(void 0===h)t=z(this,t,i,0),o=!st(t)||t!==this._$AH&&t!==R,o&&(this._$AH=t);else{const e=t;let n,r;for(t=h[0],n=0;n<h.length-1;n++)r=z(this,e[s+n],i,n),r===R&&(r=this._$AH[n]),o||=!st(r)||r!==this._$AH[n],r===D?t=D:t!==D&&(t+=(r??"")+h[n+1]),this._$AH[n]=r}o&&!e&&this.j(t)}j(t){t===D?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}}class Y extends G{constructor(){super(...arguments),this.type=3}j(t){this.element[this.name]=t===D?void 0:t}}class Z extends G{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==D)}}class q extends G{constructor(t,i,s,e,h){super(t,i,s,e,h),this.type=5}_$AI(t,i=this){if((t=z(this,t,i,0)??D)===R)return;const s=this._$AH,e=t===D&&s!==D||t.capture!==s.capture||t.once!==s.once||t.passive!==s.passive,h=t!==D&&(s===D||e);e&&this.element.removeEventListener(this.name,this,s),h&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){"function"==typeof this._$AH?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t)}}class K{constructor(t,i,s){this.element=t,this.type=6,this._$AN=void 0,this._$AM=i,this.options=s}get _$AU(){return this._$AM._$AU}_$AI(t){z(this,t)}}const si={M:f,P:v,A:m,C:1,L:U,R:F,D:$,V:z,I:et,H:G,N:Z,U:q,B:Y,F:K},Re=n.litHtmlPolyfillSupport;Re?.(B,et),(n.litHtmlVersions??=[]).push("3.2.0");const Q=(t,i,s)=>{const e=s?.renderBefore??i;let h=e._$litPart$;if(void 0===h){const t=s?.renderBefore??null;e._$litPart$=h=new et(i.insertBefore(lt(),t),t,void 0,s??{})}return h._$AI(t),h};
//# sourceMappingURL=lit-html.js.map

// EXTERNAL MODULE: ./src/styles/main.scss
var main = __webpack_require__("./src/styles/main.scss");
;// ./src/localization/locales/en.json
const en_namespaceObject = /*#__PURE__*/JSON.parse('{"recommended":"recommended","translateVideo":"Translate video","disableTranslate":"Turn off","translationSettings":"Translation settings","subtitlesSettings":"Subtitles settings","about":"About extension","resetSettings":"Reset settings","videoBeingTranslated":"The video is being translated","videoLanguage":"Video language","translationLanguage":"Translation language","translationTake":"The translation will take","translationTakeMoreThanHour":"The translation will take more than an hour","translationTakeAboutMinute":"The translation will take about a minute","translationTakeFewMinutes":"The translation will take a few minutes","translationTakeApproximatelyMinutes":"The translation will take approximately {0} minutes","translationTakeApproximatelyMinute":"The translation will take approximately {0} minutes","requestTranslationFailed":"Failed to request video translation","audioNotReceived":"Audio link not received","audioFormatNotSupported":"The audio format is not supported","VOTAutoTranslate":"Translate on open","VOTDontTranslateYourLang":"Don\'t translate from my language","VOTVolume":"Video volume","VOTVolumeTranslation":"Translation Volume","VOTAutoSetVolume":"Reduce video volume to ","VOTShowVideoSlider":"Video volume slider","VOTSyncVolume":"Link translation and video volume","VOTDisableFromYourLang":"You have disabled the translation of the video in your language","VOTVideoIsTooLong":"Video is too long","VOTNoVideoIDFound":"No video ID found","VOTSubtitles":"Subtitles","VOTSubtitlesDisabled":"Disabled","VOTSubtitlesMaxLength":"Subtitles max length","VOTHighlightWords":"Highlight words","VOTTranslatedFrom":"translated from","VOTAutogenerated":"autogenerated","VOTSettings":"VOT Settings","VOTMenuLanguage":"Menu language","VOTAuthors":"Authors","VOTVersion":"Version","VOTLoader":"Loader","VOTBrowser":"Browser","VOTShowPiPButton":"Show PiP button","langs":{"auto":"Auto","af":"Afrikaans","ak":"Akan","sq":"Albanian","am":"Amharic","ar":"Arabic","hy":"Armenian","as":"Assamese","ay":"Aymara","az":"Azerbaijani","bn":"Bangla","eu":"Basque","be":"Belarusian","bho":"Bhojpuri","bs":"Bosnian","bg":"Bulgarian","my":"Burmese","ca":"Catalan","ceb":"Cebuano","zh":"Chinese","zh-Hans":"Chinese (Simplified)","zh-Hant":"Chinese (Traditional)","co":"Corsican","hr":"Croatian","cs":"Czech","da":"Danish","dv":"Divehi","nl":"Dutch","en":"English","eo":"Esperanto","et":"Estonian","ee":"Ewe","fil":"Filipino","fi":"Finnish","fr":"French","gl":"Galician","lg":"Ganda","ka":"Georgian","de":"German","el":"Greek","gn":"Guarani","gu":"Gujarati","ht":"Haitian Creole","ha":"Hausa","haw":"Hawaiian","iw":"Hebrew","hi":"Hindi","hmn":"Hmong","hu":"Hungarian","is":"Icelandic","ig":"Igbo","id":"Indonesian","ga":"Irish","it":"Italian","ja":"Japanese","jv":"Javanese","kn":"Kannada","kk":"Kazakh","km":"Khmer","rw":"Kinyarwanda","ko":"Korean","kri":"Krio","ku":"Kurdish","ky":"Kyrgyz","lo":"Lao","la":"Latin","lv":"Latvian","ln":"Lingala","lt":"Lithuanian","lb":"Luxembourgish","mk":"Macedonian","mg":"Malagasy","ms":"Malay","ml":"Malayalam","mt":"Maltese","mi":"Māori","mr":"Marathi","mn":"Mongolian","ne":"Nepali","nso":"Northern Sotho","no":"Norwegian","ny":"Nyanja","or":"Odia","om":"Oromo","ps":"Pashto","fa":"Persian","pl":"Polish","pt":"Portuguese","pa":"Punjabi","qu":"Quechua","ro":"Romanian","ru":"Russian","sm":"Samoan","sa":"Sanskrit","gd":"Scottish Gaelic","sr":"Serbian","sn":"Shona","sd":"Sindhi","si":"Sinhala","sk":"Slovak","sl":"Slovenian","so":"Somali","st":"Southern Sotho","es":"Spanish","su":"Sundanese","sw":"Swahili","sv":"Swedish","tg":"Tajik","ta":"Tamil","tt":"Tatar","te":"Telugu","th":"Thai","ti":"Tigrinya","ts":"Tsonga","tr":"Turkish","tk":"Turkmen","uk":"Ukrainian","ur":"Urdu","ug":"Uyghur","uz":"Uzbek","vi":"Vietnamese","cy":"Welsh","fy":"Western Frisian","xh":"Xhosa","yi":"Yiddish","yo":"Yoruba","zu":"Zulu"},"streamNoConnectionToServer":"There is no connection to the server","searchField":"Search...","VOTTranslateAPIErrors":"Translate errors from the API","VOTDetectService":"Language detection service","VOTProxyWorkerHost":"Enter the proxy worker address","VOTM3u8ProxyHost":"Enter the address of the m3u8 proxy worker","proxySettings":"Proxy Settings","translationTakeApproximatelyMinute2":"The translation will take approximately {0} minutes","VOTAudioBooster":"Extended translation volume increase","VOTSubtitlesDesign":"Subtitles design","VOTSubtitlesFontSize":"Font size of subtitles","VOTSubtitlesOpacity":"Transparency of the subtitle background","VOTPressNewHotkey":"Press the new hotkey...","VOTCreateTranslationHotkey":"Create Hotkey for Translation","VOTChangeHotkeyWithCurrent":"Change Hotkey (Current: {0})","VOTSubtitlesDownloadFormat":"The format for downloading subtitles","VOTDownloadWithName":"Download files with the video name","VOTUpdateLocaleFiles":"Update localization files","VOTLocaleHash":"Locale hash","VOTUpdatedAt":"Updated at","VOTNeedWebAudioAPI":"To enable this, you must have a Web Audio API","VOTMediaCSPEnabledOnSite":"Media CSP is enabled on this site","VOTOnlyBypassMediaCSP":"Use it only for bypassing Media CSP","VOTNewAudioPlayer":"Use the new audio player","VOTUseNewModel":"Use an experimental variation of Yandex voices for some videos","VOTTranslationErrorsService":"Error translation service","TranslationDelayed":"The translation is slightly delayed","VOTTranslationCompletedNotify":"The translation on the {0} has been completed!","VOTSendNotifyOnComplete":"Send a notification that the video has been translated","VOTBugReport":"Report a bug","VOTTranslateProxyDisabled":"Disabled","VOTTranslateProxyEnabled":"Enabled","VOTTranslateProxyEverything":"Proxy everything","VOTTranslateProxyStatus":"Proxying mode","VOTTranslatedBy":"Translated by {0}"}');
;// ./src/utils/debug.ts
/* harmony default export */ const debug = ({
    log: (...text) => {
        if (false) {}
        return console.log("%c[VOT DEBUG]", "background: #F2452D; color: #fff; padding: 5px;", ...text);
    },
});

;// ./src/config/config.js
// CONFIGURATION
const workerHost = "api.browser.yandex.ru";
/**
 * used for streaming
 */
const m3u8ProxyHost = "media-proxy.toil.cc/v1/proxy/m3u8";
const proxyWorkerHost = "vot-worker.toil.cc";
const votBackendUrl = "https://vot.toil.cc/v1";
const contentUrl =
  "https://raw.githubusercontent.com/ilyhalight/voice-over-translation";
const repositoryUrl = "https://github.com/ilyhalight/voice-over-translation";

/**
 * 0.0 - 1.0 (0% - 100%) - default volume of the video with the translation
 */
const defaultAutoVolume = 0.15;
const maxAudioVolume = 900;
/**
 * The number of repeated responses after which the message turns into "translation is delayed, please wait"
 */
const minLongWaitingCount = 5;
const defaultTranslationService = "yandexbrowser";
const defaultDetectService = "yandexbrowser";

const foswlyTranslateUrl = "https://translate.toil.cc/v2";
const detectRustServerUrl = "https://rust-server-531j.onrender.com/detect";

const proxyOnlyExtensions = (/* unused pure expression or super */ null && ([
  "FireMonkey",
  "Greasemonkey",
  "AdGuard",
  "OrangeMonkey",
  "Userscripts",
  "Other (Polyfill)",
]));



;// ./src/utils/storage.ts

async function convertData(data, option, oldValue, newValue, optionValue = undefined) {
    const optionVal = optionValue ?? data[option];
    if (optionVal !== oldValue) {
        return;
    }
    data[option] = newValue;
    await votStorage.set(option, newValue);
    console.log(`[VOT] Old ${option} converted to new ${newValue}`);
}
const votStorage = new (class {
    gmSupport;
    constructor() {
        this.gmSupport = typeof GM_getValue === "function";
        debug.log(`GM Storage Status: ${this.gmSupport}`);
    }
    syncGet(name, def = undefined) {
        if (this.gmSupport) {
            return GM_getValue(name, def);
        }
        const toNumber = typeof def === "number";
        let val = window.localStorage.getItem(name);
        const result = val ?? def;
        return toNumber ? Number(result) : result;
    }
    async get(name, def = undefined) {
        if (this.gmSupport) {
            return await GM_getValue(name, def);
        }
        return Promise.resolve(this.syncGet(name, def));
    }
    syncSet(name, value) {
        if (this.gmSupport) {
            return GM_setValue(name, value);
        }
        return window.localStorage.setItem(name, value);
    }
    async set(name, value) {
        if (this.gmSupport) {
            return await GM_setValue(name, value);
        }
        return Promise.resolve(this.syncSet(name, value));
    }
    syncDelete(name) {
        if (this.gmSupport) {
            return GM_deleteValue(name);
        }
        return window.localStorage.removeItem(name);
    }
    async delete(name) {
        if (this.gmSupport) {
            return await GM_deleteValue(name);
        }
        return Promise.resolve(this.syncDelete(name));
    }
    syncList() {
        if (this.gmSupport) {
            return GM_listValues();
        }
        return [
            "autoTranslate",
            "dontTranslateLanguage",
            "dontTranslateYourLang",
            "autoSetVolumeYandexStyle",
            "autoVolume",
            "buttonPos",
            "showVideoSlider",
            "syncVolume",
            "subtitlesMaxLength",
            "highlightWords",
            "responseLanguage",
            "defaultVolume",
            "audioProxy",
            "showPiPButton",
            "translateAPIErrors",
            "translationService",
            "detectService",
            "m3u8ProxyHost",
            "translateProxyEnabled",
            "hotkeyButton",
            "proxyWorkerHost",
            "audioBooster",
            "locale-version",
            "locale-lang",
            "locale-phrases",
        ];
    }
    async list() {
        if (this.gmSupport) {
            return await GM_listValues();
        }
        return Promise.resolve(this.syncList());
    }
})();

;// ./node_modules/@vot.js/shared/dist/data/consts.js
const availableLangs = (/* unused pure expression or super */ null && ([
    "auto",
    "ru",
    "en",
    "zh",
    "ko",
    "lt",
    "lv",
    "ar",
    "fr",
    "it",
    "es",
    "de",
    "ja",
]));
const availableTTS = ["ru", "en", "kk"];
const subtitlesFormats = (/* unused pure expression or super */ null && (["srt", "vtt", "json"]));


;// ./src/utils/utils.js





const userlang = navigator.language || navigator.userLanguage;
const MAX_SECS_FRACTION = 0.66;
const slavicLangs = [
  "uk",
  "be",
  "bg",
  "mk",
  "sr",
  "bs",
  "hr",
  "sl",
  "pl",
  "sk",
  "cs",
];
const lang = userlang?.substring(0, 2).toLowerCase() || "en";
const calculatedResLang = (() => {
  if (availableTTS.includes(lang)) {
    return lang;
  }

  if (slavicLangs.includes(lang)) {
    return "ru";
  }

  return "en";
})();

function secsToStrTime(secs) {
  let minutes = Math.floor(secs / 60);
  let seconds = Math.floor(secs % 60);
  const fraction = seconds / 60;
  if (fraction >= MAX_SECS_FRACTION) {
    // rounding to the next minute if it has already been more than N%
    // e.g. 100 -> 2 minutes
    minutes += 1;
    seconds = 0;
  }

  if (minutes >= 60) {
    return localizationProvider.get("translationTakeMoreThanHour");
  } else if (minutes === 1 || (minutes === 0 && seconds > 0)) {
    return localizationProvider.get("translationTakeAboutMinute");
  } else if (minutes !== 11 && minutes % 10 === 1) {
    return localizationProvider
      .get("translationTakeApproximatelyMinute2")
      .replace("{0}", minutes);
  } else if (
    ![12, 13, 14].includes(minutes) &&
    [2, 3, 4].includes(minutes % 10)
  ) {
    return localizationProvider
      .get("translationTakeApproximatelyMinute")
      .replace("{0}", minutes);
  }

  return localizationProvider
    .get("translationTakeApproximatelyMinutes")
    .replace("{0}", minutes);
}

function isPiPAvailable() {
  return (
    "pictureInPictureEnabled" in document && document.pictureInPictureEnabled
  );
}

function initHls() {
  return typeof Hls != "undefined" && Hls?.isSupported()
    ? new Hls({
        debug: true, // turn it on manually if necessary
        lowLatencyMode: true,
        backBufferLength: 90,
      })
    : undefined;
}

const textFilters = (() => {
  const patterns = [
    /(?:https?|www|\bhttp\s+)[^\s/]*?(?:\.\s*[a-z]{2,}|\/)[^\s]*/gi,
    /#[^\s#]+|Auto-generated\s+by\s+YouTube|Provided\s+to\s+YouTube\s+by|Released\s+on|PayPal?/gi,
    /0x[\da-f]{40}|[13][a-km-zA-HJ-NP-Z1-9]{25,34}|4[0-9AB][1-9A-HJ-NP-Za-km-z]{93}/g,
  ];

  return new RegExp(patterns.map((p) => p.source).join("|"), "gi");
})();

function cleanText(title, description) {
  return (title + " " + (description || ""))
    .replace(textFilters, "")
    .replace(/(?:[\s\u200B]+|\.{2,})/g, " ")
    .replace(/[^\p{L}\s]/gu, "")
    .replace(/\s+/g, " ")
    .substring(0, 450)
    .trim();
}
/**
 * Download binary file with entered filename
 *
 * @param {Blob} blob
 * @param {string} filename
 */
function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
/**
 * Remove all banned characters from filename
 *
 * @param {string} filename
 * @return {string}
 */
function clearFileName(filename) {
  if (filename.trim().length === 0) {
    // generate a new filename
    return new Date().toLocaleDateString("en-us").replaceAll("/", "-");
  }

  return filename.replace(/[\\/:*?"'<>|]/g, "");
}

async function GM_fetch(url, opts = {}) {
  const { timeout = 15000, ...fetchOptions } = opts;
  const controller = new AbortController();

  try {
    if (url.includes("api.browser.yandex.ru")) {
      throw new Error("Preventing yandex cors");
    }
    return await fetch(url, {
      signal: controller.signal,
      ...fetchOptions,
    });
  } catch (err) {
    // Если fetch завершился ошибкой, используем GM_xmlhttpRequest
    // https://greasyfork.org/ru/scripts/421384-gm-fetch/code
    debug.log("GM_fetch preventing CORS by GM_xmlhttpRequest", err.message);

    return new Promise((resolve, reject) => {
      GM_xmlhttpRequest({
        method: fetchOptions.method || "GET",
        url,
        responseType: "blob",
        data: fetchOptions.body,
        timeout,
        headers: fetchOptions.headers || {},
        onload: (resp) => {
          const headers = resp.responseHeaders
            .split(/\r?\n/)
            .reduce((acc, line) => {
              const [, key, value] = line.match(/^([\w-]+): (.+)$/) || [];
              if (key) {
                acc[key] = value;
              }
              return acc;
            }, {});

          const response = new Response(resp.response, {
            status: resp.status,
            headers: headers,
          });
          // Response have empty url by default
          // this need to get same response url as in classic fetch
          Object.defineProperty(response, "url", {
            value: resp.finalUrl ?? "",
          });

          resolve(response);
        },
        ontimeout: () => reject(new Error("Timeout")),
        onerror: (error) => reject(new Error(error)),
        onabort: () => reject(new Error("AbortError")),
      });
    });
  }
}

function getTimestamp() {
  return Math.floor(Date.now() / 1000);
}

function clamp(value, min = 0, max = 100) {
  return Math.min(Math.max(value, min), max);
}



;// ./src/localization/localizationProvider.js







const localeCacheTTL = 7200;
const localizationUrl = `${contentUrl}/${
   true ? "dev" : 0
}/src/localization`;

// TODO: add get from hashes.json or use DEFAULT_LOCALES
const availableLocales = (/* unused pure expression or super */ null && (AVAILABLE_LOCALES));

class LocalizationProvider {
  constructor() {
    this.gmValues = [
      "locale-phrases",
      "locale-lang",
      "locale-hash",
      "locale-updated-at",
      "locale-lang-override",
    ];
    this.lang = this.getLang();
    this.locale = {};
    this.setLocaleFromJsonString(votStorage.syncGet("locale-phrases", ""));
  }

  getLang() {
    const langOverride = votStorage.syncGet("locale-lang-override", "auto");
    return langOverride !== "auto" ? langOverride : lang;
  }

  reset() {
    for (const key of this.gmValues) {
      votStorage.syncDelete(key);
    }
  }

  async checkUpdates(force = false) {
    debug.log("Check locale updates...");
    try {
      const res = await GM_fetch(
        `${localizationUrl}/hashes.json${force ? `?timestamp=${getTimestamp()}` : ""}`,
      );
      if (!res.ok) throw res.status;
      const hashes = await res.json();
      return (await votStorage.get("locale-hash")) !== hashes[this.lang]
        ? hashes[this.lang]
        : false;
    } catch (err) {
      console.error(
        "[VOT] [localizationProvider] Failed to get locales hash:",
        err,
      );
      return false;
    }
  }

  async update(force = false) {
    const localeUpdatedAt = await votStorage.get("locale-updated-at", 0);
    if (
      !force &&
      localeUpdatedAt + localeCacheTTL > getTimestamp() &&
      (await votStorage.get("locale-lang")) === this.lang
    )
      return;

    const hash = await this.checkUpdates(force);
    await votStorage.set("locale-updated-at", getTimestamp());
    if (!hash) return;

    debug.log("Updating locale...");
    try {
      const res = await GM_fetch(
        `${localizationUrl}/locales/${this.lang}.json${force ? `?timestamp=${getTimestamp()}` : ""}`,
      );
      if (!res.ok) throw res.status;
      // We use it .text() in order for there to be a single logic for GM_Storage and localStorage
      const text = await res.text();
      await votStorage.set("locale-phrases", text);
      await votStorage.set("locale-hash", hash);
      await votStorage.set("locale-lang", this.lang);
      this.setLocaleFromJsonString(text);
    } catch (err) {
      console.error("[VOT] [localizationProvider] Failed to get locale:", err);
      this.setLocaleFromJsonString(await votStorage.get("locale-phrases", ""));
    }
  }

  setLocaleFromJsonString(json) {
    try {
      this.locale = JSON.parse(json) || {};
    } catch (err) {
      console.error("[VOT] [localizationProvider]", err);
      this.locale = {};
    }
  }

  getFromLocale(locale, key) {
    return (
      key.split(".").reduce((acc, k) => acc?.[k], locale) ??
      this.warnMissingKey(locale, key)
    );
  }

  warnMissingKey(locale, key) {
    console.warn(
      "[VOT] [localizationProvider] locale",
      locale,
      "doesn't contain key",
      key,
    );
    return undefined;
  }

  getDefault(key) {
    return this.getFromLocale(en_namespaceObject, key) ?? key;
  }

  get(key) {
    return this.getFromLocale(this.locale, key) ?? this.getDefault(key);
  }
}

const localizationProvider_localizationProvider = new LocalizationProvider();

;// ./src/ui.js




class UI {
  static undefinedPhrase = "#UNDEFINED";
  static arrowIconRaw = Oe`<svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
  >
    <path
      d="M12 14.975q-.2 0-.375-.062T11.3 14.7l-4.6-4.6q-.275-.275-.275-.7t.275-.7q.275-.275.7-.275t.7.275l3.9 3.9l3.9-3.9q.275-.275.7-.275t.7.275q.275.275.275.7t-.275.7l-4.6 4.6q-.15.15-.325.213t-.375.062Z"
    />
  </svg>`;
  static animeOpts = {
    easing: "linear",
    delay: (i) => i * 200,
  };

  /**
   * Auxiliary method for creating HTML elements
   *
   * @param {string} tag - Element tag
   * @param {string[]} classes - List of classes for element
   * @param {HTMLElement|string|null} content - Internal content (optional)
   * @return {HTMLElement} Created element
   */
  static createEl(tag, classes = [], content = null) {
    const el = document.createElement(tag);
    if (classes.length) el.classList.add(...classes);
    if (content !== null) el.append(content);
    return el;
  }

  /**
   * Create header element
   *
   * @param {HTMLElement|string} html - header content
   * @param {1|2|3|4|5|6} level - header level
   * @return {HTMLElement} HTML header element
   */
  static createHeader(html, level = 4) {
    const header = this.createEl("vot-block", [
      "vot-header",
      `vot-header-level-${level}`,
    ]);
    header.append(html);
    return header;
  }

  /**
   * Create information element
   *
   * @param {HTMLElement|string} labelHtml - label content
   * @param {HTMLElement|string} valueHtml - value content
   * @return {{
   *  container: HTMLElement,
   *  header: HTMLElement,
   *  value: HTMLElement
   * }} information elements
   */
  static createInformation(labelHtml, valueHtml) {
    const container = this.createEl("vot-block", ["vot-info"]);
    const header = this.createEl("vot-block");
    Q(labelHtml, header);
    const value = this.createEl("vot-block");
    Q(valueHtml, value);
    container.append(header, value);
    return { container, header, value };
  }

  /**
   * Create button
   *
   * @param {HTMLElement|string} html - button content
   * @return {HTMLElement} HTML button element
   */
  static createButton(html) {
    const button = this.createEl("vot-block", ["vot-button"]);
    button.append(html);
    return button;
  }

  /**
   * Create text button
   *
   * @param {HTMLElement|string} html - button content
   * @return {HTMLElement} HTML text button element
   */
  static createTextButton(html) {
    const button = this.createEl("vot-block", ["vot-text-button"]);
    button.append(html);
    return button;
  }

  /**
   * Create outlined button
   *
   * @param {HTMLElement|string} html - button content
   * @return {HTMLElement} HTML outlined button element
   */
  static createOutlinedButton(html) {
    const button = this.createEl("vot-block", ["vot-outlined-button"]);
    button.append(html);
    return button;
  }

  /**
   * Create icon button
   *
   * @param {TemplateResult} templateHtml - icon svg lit template
   * @return {HTMLElement} HTML icon button element
   */
  static createIconButton(templateHtml) {
    const button = this.createEl("vot-block", ["vot-icon-button"]);
    Q(templateHtml, button);
    return button;
  }

  /**
   * Create checkbox
   *
   * @param {string|HTMLElement} html - label content
   * @param {boolean} value - checkbox state
   * @return {{
   *  container: HTMLElement,
   *  input: HTMLInputElement,
   *  label: HTMLSpanElement
   * }} checkbox elements
   */
  static createCheckbox(html, value = false) {
    const container = this.createEl("label", ["vot-checkbox"]);
    const input = document.createElement("input");
    input.type = "checkbox";
    input.checked = Boolean(value);
    const label = this.createEl("span");
    label.append(html);
    container.append(input, label);
    return { container, input, label };
  }

  /**
   * Update slider value
   *
   * @param {HTMLInputElement} input - slider input element
   */
  static updateSlider(input) {
    const value = +input.value;
    const min = +input.min;
    const max = +input.max;
    const progress = (value - min) / (max - min);
    input.parentElement.setAttribute("style", `--vot-progress: ${progress}`);
  }

  /**
   * Create slider
   *
   * @param {string|HTMLElement} html - label content
   * @param {number} value - default value
   * @param {number} min - min value
   * @param {number} max - max value
   * @return {{
   *  container: HTMLElement,
   *  input: HTMLInputElement,
   *  label: HTMLSpanElement
   * }} slider elements
   */
  static createSlider(labelHtml, value = 50, min = 0, max = 100) {
    const container = this.createEl("vot-block", ["vot-slider"]);
    const input = document.createElement("input");
    input.type = "range";
    input.min = min;
    input.max = max;
    input.value = value;
    const label = this.createEl("span");
    Q(labelHtml, label);
    container.append(input, label);
    input.addEventListener("input", (e) => this.updateSlider(e.target));
    this.updateSlider(input);
    return { container, input, label };
  }

  /**
   * Create textfield
   *
   * @param {string|HTMLElement} html - label content
   * @param {string} value - default value
   * @param {string} placeholder - textfield placeholder
   * @param {boolean} multiline - multiline textfield
   * @return {{
   *  container: HTMLElement,
   *  input: HTMLInputElement,
   *  label: HTMLSpanElement
   * }} textfield elements
   */
  static createTextfield(
    html,
    value = "",
    placeholder = " ",
    multiline = false,
  ) {
    const container = this.createEl("vot-block", ["vot-textfield"]);
    const input = document.createElement(multiline ? "textarea" : "input");
    input.placeholder = placeholder;
    input.value = value;
    if (!html) input.classList.add("vot-show-placeholer");
    const label = this.createEl("span");
    label.append(html);
    container.append(input, label);
    return { container, input, label };
  }

  /**
   * Create dialog
   *
   * @param {string|HTMLElement} html - title content
   * @return {{
   *  container: HTMLElement,
   *  backdrop: HTMLElement,
   *  dialog: HTMLElement,
   *  contentWrapper: HTMLElement,
   *  headerContainer: HTMLElement,
   *  bodyContainer: HTMLElement,
   *  footerContainer: HTMLElement,
   *  titleContainer: HTMLElement,
   *  closeButton: HTMLElement,
   *  title: HTMLElement,
   * }} dialog elements
   */
  static createDialog(html) {
    const container = this.createEl("vot-block", ["vot-dialog-container"]);
    container.hidden = true;

    const backdrop = this.createEl("vot-block", ["vot-dialog-backdrop"]);
    const dialog = this.createEl("vot-block", ["vot-dialog"]);
    const contentWrapper = this.createEl("vot-block", [
      "vot-dialog-content-wrapper",
    ]);
    const headerContainer = this.createEl("vot-block", [
      "vot-dialog-header-container",
    ]);
    const bodyContainer = this.createEl("vot-block", [
      "vot-dialog-body-container",
    ]);
    const footerContainer = this.createEl("vot-block", [
      "vot-dialog-footer-container",
    ]);
    const titleContainer = this.createEl("vot-block", [
      "vot-dialog-title-container",
    ]);
    const closeButton = this.createIconButton(
      Oe`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="100%" viewBox="0 -960 960 960">
        <path d="M480-424 284-228q-11 11-28 11t-28-11q-11-11-11-28t11-28l196-196-196-196q-11-11-11-28t11-28q11-11 28-11t28 11l196 196 196-196q11-11 28-11t28 11q11 11 11 28t-11 28L536-480l196 196q11 11 11 28t-11 28q-11 11-28 11t-28-11L480-424Z"/>
      </svg>`,
    );
    closeButton.classList.add("vot-dialog-close-button");

    // Закрытие диалога по нажатию на фон или кнопку
    backdrop.onclick = closeButton.onclick = () => {
      container.hidden = true;
    };

    const title = this.createEl("vot-block", ["vot-dialog-title"]);
    title.append(html);

    container.append(backdrop, dialog);
    dialog.append(contentWrapper);
    contentWrapper.append(headerContainer, bodyContainer, footerContainer);
    headerContainer.append(titleContainer, closeButton);
    titleContainer.append(title);

    return {
      container,
      backdrop,
      dialog,
      contentWrapper,
      headerContainer,
      bodyContainer,
      footerContainer,
      titleContainer,
      closeButton,
      title,
    };
  }

  /**
   * Create VOTButton
   *
   * @param {string|HTMLElement} label - label content
   * @return {{
   *  container: HTMLElement,
   *  translateButton: HTMLElement,
   *  separator: HTMLElement,
   *  pipButton: HTMLElement,
   *  separator2: HTMLElement,
   *  menuButton: HTMLElement,
   *  label: HTMLSpanElement,
   * }} VOTButton elements
   */
  static createVOTButton(labelHtml) {
    const container = this.createEl("vot-block", ["vot-segmented-button"]);
    const translateButton = this.createEl("vot-block", [
      "vot-segment",
      "vot-translate-button",
    ]);
    Q(
      Oe`<svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
      >
        <path
          id="vot-translate-icon"
          fill-rule="evenodd"
          d="M15.778 18.95L14.903 21.375C14.8364 21.5583 14.7197 21.7083 14.553 21.825C14.3864 21.9417 14.203 22 14.003 22C13.6697 22 13.3989 21.8625 13.1905 21.5875C12.9822 21.3125 12.9447 21.0083 13.078 20.675L16.878 10.625C16.9614 10.4417 17.0864 10.2917 17.253 10.175C17.4197 10.0583 17.603 10 17.803 10H18.553C18.753 10 18.9364 10.0583 19.103 10.175C19.2697 10.2917 19.3947 10.4417 19.478 10.625L23.278 20.7C23.4114 21.0167 23.378 21.3125 23.178 21.5875C22.978 21.8625 22.7114 22 22.378 22C22.1614 22 21.9739 21.9375 21.8155 21.8125C21.6572 21.6875 21.5364 21.525 21.453 21.325L20.628 18.95H15.778ZM19.978 17.2H16.378L18.228 12.25L19.978 17.2Z"
        ></path>
        <path
          d="M9 14L4.7 18.3C4.51667 18.4833 4.28333 18.575 4 18.575C3.71667 18.575 3.48333 18.4833 3.3 18.3C3.11667 18.1167 3.025 17.8833 3.025 17.6C3.025 17.3167 3.11667 17.0833 3.3 16.9L7.65 12.55C7.01667 11.85 6.4625 11.125 5.9875 10.375C5.5125 9.625 5.1 8.83333 4.75 8H6.85C7.15 8.6 7.47083 9.14167 7.8125 9.625C8.15417 10.1083 8.56667 10.6167 9.05 11.15C9.78333 10.35 10.3917 9.52917 10.875 8.6875C11.3583 7.84583 11.7667 6.95 12.1 6H2C1.71667 6 1.47917 5.90417 1.2875 5.7125C1.09583 5.52083 1 5.28333 1 5C1 4.71667 1.09583 4.47917 1.2875 4.2875C1.47917 4.09583 1.71667 4 2 4H8V3C8 2.71667 8.09583 2.47917 8.2875 2.2875C8.47917 2.09583 8.71667 2 9 2C9.28333 2 9.52083 2.09583 9.7125 2.2875C9.90417 2.47917 10 2.71667 10 3V4H16C16.2833 4 16.5208 4.09583 16.7125 4.2875C16.9042 4.47917 17 4.71667 17 5C17 5.28333 16.9042 5.52083 16.7125 5.7125C16.5208 5.90417 16.2833 6 16 6H14.1C13.75 7.18333 13.275 8.33333 12.675 9.45C12.075 10.5667 11.3333 11.6167 10.45 12.6L12.85 15.05L12.1 17.1L9 14Z"
        ></path>
        <path
          id="vot-loading-icon"
          style="display:none"
          d="M19.8081 16.3697L18.5842 15.6633V13.0832C18.5842 12.9285 18.5228 12.7801 18.4134 12.6707C18.304 12.5613 18.1556 12.4998 18.0009 12.4998C17.8462 12.4998 17.6978 12.5613 17.5884 12.6707C17.479 12.7801 17.4176 12.9285 17.4176 13.0832V15.9998C17.4176 16.1022 17.4445 16.2028 17.4957 16.2915C17.5469 16.3802 17.6205 16.4538 17.7092 16.505L19.2247 17.38C19.2911 17.4189 19.3645 17.4443 19.4407 17.4547C19.5169 17.4652 19.5945 17.4604 19.6688 17.4407C19.7432 17.4211 19.813 17.3869 19.8741 17.3402C19.9352 17.2934 19.9864 17.2351 20.0249 17.1684C20.0634 17.1018 20.0883 17.0282 20.0982 16.952C20.1081 16.8757 20.1028 16.7982 20.0827 16.7239C20.0625 16.6497 20.0279 16.5802 19.9808 16.5194C19.9336 16.4586 19.8749 16.4077 19.8081 16.3697ZM18.0015 10C16.8478 10 15.6603 10.359 14.7011 11C13.7418 11.641 12.9415 12.4341 12.5 13.5C12.0585 14.5659 11.8852 16.0369 12.1103 17.1684C12.3353 18.3 12.8736 19.4942 13.6894 20.31C14.5053 21.1258 15.8684 21.7749 17 22C18.1316 22.2251 19.4341 21.9415 20.5 21.5C21.5659 21.0585 22.359 20.2573 23 19.298C23.641 18.3387 24.0015 17.1537 24.0015 16C23.9998 14.4534 23.5951 13.0936 22.5015 12C21.4079 10.9064 19.5481 10.0017 18.0015 10ZM18.0009 20.6665C17.0779 20.6665 16.1757 20.3928 15.4082 19.88C14.6408 19.3672 14.0427 18.6384 13.6894 17.7857C13.3362 16.933 13.2438 15.9947 13.4239 15.0894C13.604 14.1842 14.0484 13.3527 14.7011 12.7C15.3537 12.0474 16.1852 11.6029 17.0905 11.4228C17.9957 11.2428 18.934 11.3352 19.7867 11.6884C20.6395 12.0416 21.3683 12.6397 21.8811 13.4072C22.3939 14.1746 22.6676 15.0769 22.6676 15.9998C22.666 17.237 22.1738 18.4231 21.299 19.298C20.4242 20.1728 19.2381 20.665 18.0009 20.6665Z"
        ></path>
      </svg>`,
      translateButton,
    );

    const separator = this.createEl("vot-block", ["vot-separator"]);
    const pipButton = this.createEl("vot-block", ["vot-segment-only-icon"]);
    Q(
      Oe`<svg
        xmlns="http://www.w3.org/2000/svg"
        height="24"
        viewBox="0 -960 960 960"
        width="24"
      >
        <path
          d="M120-520q-17 0-28.5-11.5T80-560q0-17 11.5-28.5T120-600h104L80-743q-12-12-12-28.5T80-800q12-12 28.5-12t28.5 12l143 144v-104q0-17 11.5-28.5T320-800q17 0 28.5 11.5T360-760v200q0 17-11.5 28.5T320-520H120Zm40 360q-33 0-56.5-23.5T80-240v-160q0-17 11.5-28.5T120-440q17 0 28.5 11.5T160-400v160h280q17 0 28.5 11.5T480-200q0 17-11.5 28.5T440-160H160Zm680-280q-17 0-28.5-11.5T800-480v-240H480q-17 0-28.5-11.5T440-760q0-17 11.5-28.5T480-800h320q33 0 56.5 23.5T880-720v240q0 17-11.5 28.5T840-440ZM600-160q-17 0-28.5-11.5T560-200v-120q0-17 11.5-28.5T600-360h240q17 0 28.5 11.5T880-320v120q0 17-11.5 28.5T840-160H600Z"
        />
      </svg>`,
      pipButton,
    );

    const separator2 = this.createEl("vot-block", ["vot-separator"]);
    const menuButton = this.createEl("vot-block", ["vot-segment-only-icon"]);
    Q(
      Oe`<svg
        xmlns="http://www.w3.org/2000/svg"
        height="24"
        viewBox="0 -960 960 960"
        width="24"
      >
        <path
          d="M480-160q-33 0-56.5-23.5T400-240q0-33 23.5-56.5T480-320q33 0 56.5 23.5T560-240q0 33-23.5 56.5T480-160Zm0-240q-33 0-56.5-23.5T400-480q0-33 23.5-56.5T480-560q33 0 56.5 23.5T560-480q0 33-23.5 56.5T480-400Zm0-240q-33 0-56.5-23.5T400-720q0-33 23.5-56.5T480-800q33 0 56.5 23.5T560-720q0 33-23.5 56.5T480-640Z"
        />
      </svg>`,
      menuButton,
    );

    const label = this.createEl("span", ["vot-segment-label"]);
    label.append(labelHtml);
    container.append(
      translateButton,
      separator,
      pipButton,
      separator2,
      menuButton,
    );
    translateButton.append(label);
    return {
      container,
      translateButton,
      separator,
      pipButton,
      separator2,
      menuButton,
      label,
    };
  }

  /**
   * Create VOTMenu
   *
   * @param {string|HTMLElement} html - title content
   * @return {{
   *  container: HTMLElement,
   *  contentWrapper: HTMLElement,
   *  headerContainer: HTMLElement,
   *  bodyContainer: HTMLElement,
   *  footerContainer: HTMLElement,
   *  titleContainer: HTMLElement,
   *  title: HTMLSpanElement,
   * }} VOTMenu elements
   */
  static createVOTMenu(html) {
    const container = this.createEl("vot-block", ["vot-menu"]);
    container.hidden = true;
    const contentWrapper = this.createEl("vot-block", [
      "vot-menu-content-wrapper",
    ]);
    const headerContainer = this.createEl("vot-block", [
      "vot-menu-header-container",
    ]);
    const bodyContainer = this.createEl("vot-block", [
      "vot-menu-body-container",
    ]);
    const footerContainer = this.createEl("vot-block", [
      "vot-menu-footer-container",
    ]);
    const titleContainer = this.createEl("vot-block", [
      "vot-menu-title-container",
    ]);
    const title = this.createEl("vot-block", ["vot-menu-title"]);
    title.append(html);
    container.append(contentWrapper);
    contentWrapper.append(headerContainer, bodyContainer, footerContainer);
    headerContainer.append(titleContainer);
    titleContainer.append(title);
    return {
      container,
      contentWrapper,
      headerContainer,
      bodyContainer,
      footerContainer,
      titleContainer,
      title,
    };
  }

  /**
   * Create VOTSelectLabel
   *
   * @param {string} text - label text
   * @return {HTMLSpanElement} VOTSelectLabel element
   */
  static createVOTSelectLabel(text) {
    const label = this.createEl("span", ["vot-select-label"]);
    label.textContent = text;
    return label;
  }

  /**
   * Create VOTSelect - A customizable select component with search functionality
   * and support for single/multi-select modes.
   *
   * @param {string} selectTitle - Default title shown when no items are selected
   * @param {string} dialogTitle - Title displayed in the selection dialog
   * @param {{label: string, value: string, selected: boolean, disabled?: boolean}[]} items - Array of selectable items
   * @param {{
   *   onSelectCb?: function,      // Callback function triggered on item selection
   *   labelElement?: string,      // Optional label element to display above select
   *   multiSelect?: boolean       // Enable multiple item selection
   * }} options - Configuration options
   * @return {{
   *  container: HTMLElement,      // Main container element
   *  title: HTMLSpanElement,      // Title element showing selected items
   *  arrowIcon: HTMLElement,      // Dropdown arrow icon element
   *  labelElement: HTMLElement,   // Label element if provided
   *  setTitle: (newTitle: string) => void,          // Function to update select title
   *  setSelected: (val: string | string[]) => void, // Function to set selected items
   *  updateItems: (newItems: {label: string, value: string, selected: boolean}[]) => void, // Update available items
   *  selectedValues: Set<string>  // Set containing currently selected values
   * }} VOTSelect elements and control functions
   */
  static createVOTSelect(selectTitle, dialogTitle, items, options = {}) {
    const {
      onSelectCb = () => {},
      labelElement = "",
      multiSelect = false,
      dialogParent = document.documentElement,
    } = options;
    let selectedItems = [];
    let selectedValues = new Set(
      items.filter((i) => i.selected).map((i) => i.value),
    );

    const container = this.createEl("vot-block", ["vot-select"]);
    if (labelElement) container.append(labelElement);

    const outer = this.createEl("vot-block", ["vot-select-outer"]);
    const title = this.createEl("span", ["vot-select-title"]);
    const updateTitle = () => {
      if (multiSelect) {
        const selectedLabels = items
          .filter((i) => selectedValues.has(i.value))
          .map((i) => i.label)
          .join(", ");
        title.textContent = selectedLabels || selectTitle;
      } else {
        const selectedItem = items.find((i) => i.selected);
        title.textContent = selectedItem ? selectedItem.label : selectTitle;
      }
    };
    updateTitle();

    const arrowIcon = this.createEl("vot-block", ["vot-select-arrow-icon"]);
    Q(this.arrowIconRaw, arrowIcon);

    const updateSelectedState = () => {
      if (selectedItems.length > 0) {
        for (const item of selectedItems) {
          item.dataset.votSelected = selectedValues.has(item.dataset.votValue);
        }
      }
      updateTitle();
    };

    outer.append(title, arrowIcon);

    let isLoading = false;
    let dialogOpened = false;

    outer.onclick = async () => {
      if (isLoading || dialogOpened) return;
      try {
        isLoading = true;
        if (options.onBeforeOpen) await options.onBeforeOpen();

        const votSelectDialog = this.createDialog(dialogTitle);
        votSelectDialog.container.classList.add("vot-dialog-temp");
        votSelectDialog.container.hidden = false;
        dialogParent.appendChild(votSelectDialog.container);
        dialogOpened = true;

        const contentList = this.createEl("vot-block", [
          "vot-select-content-list",
        ]);

        for (const item of items) {
          const contentItem = this.createEl("vot-block", [
            "vot-select-content-item",
          ]);
          contentItem.textContent = item.label;
          contentItem.dataset.votSelected = item.selected;
          contentItem.dataset.votValue = item.value;
          if (item.disabled) contentItem.inert = true;

          contentItem.onclick = async (e) => {
            if (e.target.inert) return;
            if (multiSelect) {
              const value = item.value;
              if (selectedValues.has(value) && selectedValues.size > 1) {
                selectedValues.delete(value);
                item.selected = false;
              } else {
                selectedValues.add(value);
                item.selected = true;
              }
              contentItem.dataset.votSelected = selectedValues.has(value);
              updateSelectedState();
              await onSelectCb(e, Array.from(selectedValues));
            } else {
              const value = e.target.dataset.votValue;
              selectedValues = new Set([value]);
              for (const ci of contentList.childNodes) {
                ci.dataset.votSelected = ci.dataset.votValue === value;
              }
              for (const i of items) {
                i.selected = i.value === value;
              }
              updateTitle();
              await onSelectCb(e, value);
            }
          };
          contentList.appendChild(contentItem);
        }

        const votSearchLangTextfield = this.createTextfield(
          localizationProvider_localizationProvider.get("searchField"),
        );
        votSearchLangTextfield.input.oninput = (e) => {
          const searchText = e.target.value.toLowerCase();
          for (const ci of selectedItems) {
            ci.hidden = !ci.textContent.toLowerCase().includes(searchText);
          }
        };

        votSelectDialog.bodyContainer.append(
          votSearchLangTextfield.container,
          contentList,
        );
        selectedItems = contentList.childNodes;

        votSelectDialog.backdrop.onclick = votSelectDialog.closeButton.onclick =
          () => {
            votSelectDialog.container.remove();
            dialogOpened = false;
            selectedItems = [];
          };
      } finally {
        isLoading = false;
      }
    };

    container.append(outer);

    const setSelected = (val) => {
      if (multiSelect) {
        selectedValues = new Set(
          Array.isArray(val) ? val.map(String) : [String(val)],
        );
      } else {
        selectedValues = new Set([String(val)]);
      }
      for (const item of items) {
        item.selected = selectedValues.has(String(item.value));
      }
      updateSelectedState();
    };

    const updateItems = (newItems) => {
      items = newItems;
      selectedValues = new Set(
        items.filter((i) => i.selected).map((i) => i.value),
      );
      updateSelectedState();
    };

    return {
      container,
      title,
      arrowIcon,
      labelElement,
      setTitle: (t) => (selectTitle = t) && updateTitle(),
      setSelected,
      updateItems,
      selectedValues,
    };
  }

  /**
   * Create VOTLanguageSelect
   *
   * @param {object} options - language select options
   * @return {{ container: HTMLElement, fromSelect: object, icon: HTMLElement, toSelect: object }}
   */
  static createVOTLanguageSelect(options) {
    const {
      fromTitle = this.undefinedPhrase,
      fromDialogTitle = this.undefinedPhrase,
      fromItems = [],
      fromOnSelectCB = null,
      toTitle = this.undefinedPhrase,
      toDialogTitle = this.undefinedPhrase,
      toItems = [],
      toOnSelectCB = null,
    } = options;

    const container = this.createEl("vot-block", ["vot-lang-select"]);
    const fromSelect = this.createVOTSelect(
      fromTitle,
      fromDialogTitle,
      fromItems,
      {
        onSelectCb: fromOnSelectCB,
      },
    );
    const icon = this.createEl("vot-block", ["vot-lang-select-icon"]);
    Q(
      Oe`<svg
        xmlns="http://www.w3.org/2000/svg"
        height="24"
        viewBox="0 -960 960 960"
        width="24"
      >
        <path
          d="M647-440H200q-17 0-28.5-11.5T160-480q0-17 11.5-28.5T200-520h447L451-716q-12-12-11.5-28t12.5-28q12-11 28-11.5t28 11.5l264 264q6 6 8.5 13t2.5 15q0 8-2.5 15t-8.5 13L508-188q-11 11-27.5 11T452-188q-12-12-12-28.5t12-28.5l195-195Z"
        />
      </svg>`,
      icon,
    );
    const toSelect = this.createVOTSelect(toTitle, toDialogTitle, toItems, {
      onSelectCb: toOnSelectCB,
    });
    container.append(fromSelect.container, icon, toSelect.container);
    return { container, fromSelect, icon, toSelect };
  }

  /**
   * Create details element
   *
   * @param {HTMLElement|string} titleHtml - details title
   * @return {{
   *  container: HTMLElement,
   *  header: HTMLElement,
   *  arrowIcon: HTMLElement
   * }} details elements
   */
  static createDetails(titleHtml) {
    const container = this.createEl("vot-block", ["vot-details"]);
    const header = this.createEl("vot-block");
    header.append(titleHtml);
    const arrowIcon = this.createEl("vot-block", ["vot-details-arrow-icon"]);
    Q(this.arrowIconRaw, arrowIcon);
    container.append(header, arrowIcon);
    return { container, header, arrowIcon };
  }

  /**
   *
   * @export
   * @param {SVGElement} votLoader
   * @param {string} [primaryColor="139, 180, 245"]
   * @return {Function} Update animation function
   */
  static animateLoader(votLoader, primaryColor = "139, 180, 245") {
    const votLoaderHelper = votLoader.querySelector(".vot-loader-helper");
    const votLoaderMain = votLoader.querySelector(".vot-loader-main");
    anime
      .timeline({
        ...this.animeOpts,
        targets: [votLoaderHelper, votLoaderMain],
        duration: 250,
      })
      .add({
        "fill-opacity": 0,
        "stroke-width": 2,
        d: "M 12 1.5 C 17.799 1.5 22.5 6.201 22.5 12 C 22.5 17.799 17.799 22.5 12 22.5 C 6.201 22.5 1.5 17.799 1.5 12 C 1.5 6.201 6.201 1.5 12 1.5 Z",
        duration: 0,
      })
      .add(
        {
          targets: votLoaderHelper,
          stroke: `rgb(${primaryColor})`,
          "stroke-opacity": 0,
          duration: 0,
        },
        0,
      )
      .add(
        {
          targets: votLoaderMain,
          stroke: "#888888",
          "stroke-opacity": 0.25,
        },
        0,
      );

    const animation = anime
      .timeline({
        targets: votLoaderHelper,
        easing: "easeInOutSine",
        duration: 1000,
        autoplay: false,
      })
      .add({ strokeOpacity: 1, duration: 0 }, 0)
      .add({ strokeDashoffset: [anime.setDashoffset, 0] }, 0);

    return (percentage) =>
      animation.seek(animation.duration * (percentage / 100));
  }

  /**
   * After the bootloader animation
   *
   * @param {SVGElement} votLoader
   * @param {string} [primaryColor="139, 180, 245"]
   */
  static afterAnimateLoader(votLoader, primaryColor = "139, 180, 245") {
    const votLoaderHelper = votLoader.querySelector(".vot-loader-helper");
    const votLoaderMain = votLoader.querySelector(".vot-loader-main");
    anime
      .timeline({
        ...this.animeOpts,
        targets: votLoaderMain,
        duration: 600,
      })
      .add({
        d: "M 9.0596 14.8571 L 9.7667 15.5642 L 10.4738 14.8571 L 17.0071 8.3238 C 17.0457 8.2852 17.0937 8.25 17.2333 8.25 C 17.373 8.25 17.421 8.2852 17.4596 8.3238 C 17.4981 8.3624 17.5333 8.4104 17.5333 8.55 C 17.5333 8.6896 17.4981 8.7376 17.4596 8.7762 L 9.9929 16.2429 C 9.9011 16.3346 9.8397 16.35 9.7667 16.35 C 9.6937 16.35 9.6322 16.3346 9.5404 16.2429 L 6.0738 12.7762 C 6.0352 12.7376 6 12.6897 6 12.55 C 6 12.4103 6.0352 12.3624 6.0738 12.3238 C 6.1124 12.2852 6.1603 12.25 6.3 12.25 C 6.4397 12.25 6.4876 12.2852 6.5262 12.3238 L 9.0596 14.8571 Z",
        duration: 0,
      })
      .add({
        strokeDashoffset: [anime.setDashoffset, 0],
        stroke: `rgb(${primaryColor})`,
        "stroke-opacity": 1,
      });

    setTimeout(() => {
      anime
        .timeline({
          ...this.animeOpts,
          targets: votLoaderMain,
          duration: 600,
        })
        .add({
          d: "M12 15.575C11.8667 15.575 11.7417 15.5542 11.625 15.5125C11.5083 15.4708 11.4 15.4 11.3 15.3L7.7 11.7C7.5 11.5 7.40417 11.2667 7.4125 11C7.42083 10.7333 7.51667 10.5 7.7 10.3C7.9 10.1 8.1375 9.99583 8.4125 9.9875C8.6875 9.97917 8.925 10.075 9.125 10.275L11 12.15V5C11 4.71667 11.0958 4.47917 11.2875 4.2875C11.4792 4.09583 11.7167 4 12 4C12.2833 4 12.5208 4.09583 12.7125 4.2875C12.9042 4.47917 13 4.71667 13 5V12.15L14.875 10.275C15.075 10.075 15.3125 9.97917 15.5875 9.9875C15.8625 9.99583 16.1 10.1 16.3 10.3C16.4833 10.5 16.5792 10.7333 16.5875 11C16.5958 11.2667 16.5 11.5 16.3 11.7L12.7 15.3C12.6 15.4 12.4917 15.4708 12.375 15.5125C12.2583 15.5542 12.1333 15.575 12 15.575ZM6 20C5.45 20 4.97917 19.8042 4.5875 19.4125C4.19583 19.0208 4 18.55 4 18V16C4 15.7167 4.09583 15.4792 4.2875 15.2875C4.47917 15.0958 4.71667 15 5 15C5.28333 15 5.52083 15.0958 5.7125 15.2875C5.90417 15.4792 6 15.7167 6 16V18H18V16C18 15.7167 18.0958 15.4792 18.2875 15.2875C18.4792 15.0958 18.7167 15 19 15C19.2833 15 19.5208 15.0958 19.7125 15.2875C19.9042 15.4792 20 15.7167 20 16V18C20 18.55 19.8042 19.0208 19.4125 19.4125C19.0208 19.8042 18.55 20 18 20H6Z",
          duration: 100,
        })
        .add(
          {
            targets: votLoaderHelper,
            d: "",
            duration: 200,
          },
          0,
        )
        .add({
          targets: votLoaderMain,
          "stroke-width": "0",
          stroke: `rgba(${primaryColor}), 0)`,
          "fill-opacity": "1",
          "stroke-dasharray": "0",
          "stroke-dashoffset": "0",
          duration: 0,
        });
    }, 2000);
  }

  static createPortal(local = false) {
    return this.createEl("vot-block", [`vot-portal${local ? "-local" : ""}`]);
  }

  static createSubtitleInfo(word, desc, translationService) {
    const container = this.createEl("vot-block", ["vot-subtitles-info"]);
    container.id = "vot-subtitles-info";
    const translatedWith = this.createEl(
      "vot-block",
      ["vot-subtitles-info-service"],
      localizationProvider_localizationProvider
        .get("VOTTranslatedBy")
        .replace("{0}", translationService),
    );
    const header = this.createEl(
      "vot-block",
      ["vot-subtitles-info-header"],
      word,
    );
    const context = this.createEl(
      "vot-block",
      ["vot-subtitles-info-context"],
      desc,
    );

    container.append(translatedWith, header, context);

    return {
      container,
      translatedWith,
      header,
      context,
    };
  }
}

;// ./src/types/tooltip.ts
const positions = ["left", "top", "right", "bottom"];
const triggers = ["hover", "click"];

;// ./src/ui/tooltip.ts



class Tooltip {
    showed = false;
    target;
    anchor;
    content;
    position;
    trigger;
    parentElement;
    layoutRoot;
    offsetX;
    offsetY;
    hidden;
    autoLayout;
    pageWidth;
    pageHeight;
    globalOffsetX;
    globalOffsetY;
    maxWidth;
    backgroundColor;
    borderRadius;
    container;
    onResizeObserver;
    constructor({ target, anchor = undefined, content = "", position = "top", trigger = "hover", offset = 4, maxWidth = undefined, hidden = false, autoLayout = true, backgroundColor = undefined, borderRadius = undefined, parentElement = document.body, layoutRoot = document.documentElement, }) {
        if (!(target instanceof HTMLElement)) {
            throw new Error("target must be a valid HTMLElement");
        }
        this.target = target;
        this.anchor = anchor instanceof HTMLElement ? anchor : target;
        this.content = content;
        if (typeof offset === "number") {
            this.offsetY = this.offsetX = offset;
        }
        else {
            this.offsetX = offset.x;
            this.offsetY = offset.y;
        }
        this.hidden = hidden;
        this.autoLayout = autoLayout;
        this.trigger = Tooltip.validateTrigger(trigger) ? trigger : "hover";
        this.position = Tooltip.validatePos(position) ? position : "top";
        this.parentElement = parentElement;
        this.layoutRoot = layoutRoot;
        this.borderRadius = borderRadius;
        this.maxWidth = maxWidth;
        this.backgroundColor = backgroundColor;
        this.updatePageSize();
        this.init();
    }
    static validatePos(position) {
        return positions.includes(position);
    }
    static validateTrigger(trigger) {
        return triggers.includes(trigger);
    }
    setPosition(position) {
        this.position = Tooltip.validatePos(position) ? position : "top";
        this.updatePos();
        return this;
    }
    setContent(content) {
        this.content = content;
        this.destroy();
        return this;
    }
    onResize = () => {
        this.updatePageSize();
        this.updatePos();
    };
    onClick = () => {
        this.showed ? this.destroy() : this.create();
    };
    onHoverPointerDown = (e) => {
        if (e.pointerType === "mouse") {
            return;
        }
        this.create();
    };
    onHoverPointerUp = (e) => {
        if (e.pointerType === "mouse") {
            return;
        }
        this.destroy();
    };
    onMouseEnter = () => {
        this.create();
    };
    onMouseLeave = () => {
        this.destroy();
    };
    updatePageSize() {
        if (this.layoutRoot !== document.documentElement) {
            const { left, top } = this.parentElement.getBoundingClientRect();
            this.globalOffsetX = left;
            this.globalOffsetY = top;
        }
        else {
            this.globalOffsetX = 0;
            this.globalOffsetY = 0;
        }
        this.pageWidth = this.layoutRoot.clientWidth;
        this.pageHeight = this.layoutRoot.clientHeight;
        return this;
    }
    init() {
        this.onResizeObserver = new ResizeObserver(this.onResize);
        if (this.trigger === "click") {
            this.target.addEventListener("pointerdown", this.onClick);
            return this;
        }
        this.target.addEventListener("mouseenter", this.onMouseEnter);
        this.target.addEventListener("mouseleave", this.onMouseLeave);
        this.target.addEventListener("pointerdown", this.onHoverPointerDown);
        this.target.addEventListener("pointerup", this.onHoverPointerUp);
        return this;
    }
    release() {
        this.destroy();
        if (this.trigger === "click") {
            this.target.removeEventListener("pointerdown", this.onClick);
            return this;
        }
        this.target.removeEventListener("mouseenter", this.onMouseEnter);
        this.target.removeEventListener("mouseleave", this.onMouseLeave);
        this.target.removeEventListener("pointerdown", this.onHoverPointerDown);
        this.target.removeEventListener("pointerup", this.onHoverPointerUp);
        return this;
    }
    create() {
        this.showed = true;
        this.container = UI.createEl("vot-block", ["vot-tooltip"], this.content);
        this.container.setAttribute("role", "tooltip");
        this.container.dataset.trigger = this.trigger;
        this.container.dataset.position = this.position;
        this.parentElement.appendChild(this.container);
        this.updatePos();
        if (this.backgroundColor !== undefined) {
            this.container.style.backgroundColor = this.backgroundColor;
        }
        if (this.borderRadius !== undefined) {
            this.container.style.borderRadius = `${this.borderRadius}px`;
        }
        if (this.hidden) {
            this.container.hidden = true;
        }
        this.container.style.opacity = "1";
        this.onResizeObserver?.observe(this.layoutRoot);
        return this;
    }
    updatePos() {
        if (!this.container) {
            return this;
        }
        let { top, left } = this.calcPos(this.autoLayout);
        const maxWidth = this.maxWidth ??
            clamp(this.pageWidth - left - this.offsetX, 0, this.pageWidth);
        this.container.style.transform = `translate(${left}px, ${top}px)`;
        this.container.style.maxWidth = `${maxWidth}px`;
        return this;
    }
    calcPos(autoLayout = true) {
        if (!this.container) {
            return { top: 0, left: 0 };
        }
        const { left: anchorLeft, right: anchorRight, top: anchorTop, bottom: anchorBottom, width: widthTarget, height: heightTarget, } = this.anchor.getBoundingClientRect();
        const { width, height } = this.container.getBoundingClientRect();
        const left = anchorLeft - this.globalOffsetX;
        const right = anchorRight - this.globalOffsetX;
        const top = anchorTop - this.globalOffsetY;
        const bottom = anchorBottom - this.globalOffsetY;
        switch (this.position) {
            case "top": {
                const pTop = clamp(top - height - this.offsetY, 0, this.pageHeight);
                if (autoLayout && pTop + this.offsetY < height) {
                    this.position = "bottom";
                    return this.calcPos(false);
                }
                return {
                    top: pTop,
                    left: clamp(left - width / 2 + widthTarget / 2, 0, this.pageWidth),
                };
            }
            case "right": {
                const pLeft = clamp(right + this.offsetX, 0, this.pageWidth);
                if (autoLayout && pLeft + width > this.pageWidth) {
                    this.position = "left";
                    return this.calcPos(false);
                }
                return {
                    top: clamp(top + (heightTarget - height) / 2, 0, this.pageHeight),
                    left: pLeft,
                };
            }
            case "bottom": {
                const pTop = clamp(bottom + this.offsetY, 0, this.pageHeight);
                if (autoLayout && pTop + height > this.pageHeight) {
                    this.position = "top";
                    return this.calcPos(false);
                }
                return {
                    top: pTop,
                    left: clamp(left - width / 2 + widthTarget / 2, 0, this.pageWidth),
                };
            }
            case "left": {
                const pLeft = clamp(left - width - this.offsetX, 0, this.pageWidth);
                if (autoLayout && pLeft + width > left) {
                    this.position = "right";
                    return this.calcPos(false);
                }
                return {
                    top: clamp(top + (heightTarget - height) / 2, 0, this.pageHeight),
                    left: pLeft,
                };
            }
            default:
                return { top: 0, left: 0 };
        }
    }
    destroy(instant = false) {
        if (!this.container) {
            return this;
        }
        this.showed = false;
        this.onResizeObserver?.disconnect();
        if (instant) {
            this.container.remove();
            return this;
        }
        const container = this.container;
        container.style.opacity = "0";
        container.addEventListener("transitionend", () => {
            container?.remove();
        }, {
            once: true,
        });
        return this;
    }
}

;// ./tests/ui.js




class TestUI {
  initUI() {
    this.testDialog = UI.createDialog("Test");
    // Header
    this.h1 = UI.createHeader("H1 Lorem ipsum dolor", 1);
    this.h2 = UI.createHeader("H2 Lorem ipsum dolor", 2);
    this.h3 = UI.createHeader("H3 Lorem ipsum dolor", 3);
    this.h4 = UI.createHeader("H4 Lorem ipsum dolor", 4);
    this.h5 = UI.createHeader("H5 Lorem ipsum dolor", 5);
    this.h6 = UI.createHeader("H6 Lorem ipsum dolor", 6);
    this.testHTML = document.createElement("vot-block");
    this.testHTML.style = "padding: 4px; color: skyblue;";
    this.testHTML.textContent = "Lorem ipsum dolor";
    this.h3WithHTML = UI.createHeader(this.testHTML.cloneNode(true), 3);
    console.log(this.h3WithHTML.outerHTML);
    this.testDialog.bodyContainer.append(
      this.h1,
      this.h2,
      this.h3,
      this.h4,
      this.h5,
      this.h6,
      this.h3WithHTML,
    );

    // Information
    this.info = UI.createInformation(
      "Information Lorem ipsum dolor:",
      "Neque porro quisquam est qui",
    );
    this.infoWithHTML = UI.createInformation(
      this.testHTML.cloneNode(true),
      this.testHTML.cloneNode(true),
    );

    this.testDialog.bodyContainer.append(
      this.info.container,
      this.infoWithHTML.container,
    );

    // Button
    this.button = UI.createButton("Button Lorem ipsum dolor");
    this.buttonDisabled = UI.createButton("Button Disabled Lorem ipsum dolor");
    this.buttonDisabled.setAttribute("disabled", "true");
    this.buttonWithHTML = UI.createButton(this.testHTML.cloneNode(true));
    this.testDialog.bodyContainer.append(
      this.button,
      this.buttonDisabled,
      this.buttonWithHTML,
    );

    // TextButton
    this.textButton = UI.createTextButton("TextButton Lorem ipsum dolor");
    this.textButtonDisabled = UI.createTextButton(
      "TextButton Disabled Lorem ipsum dolor",
    );
    this.textButtonDisabled.setAttribute("disabled", "true");
    this.textButtonWithHTML = UI.createTextButton(
      this.testHTML.cloneNode(true),
    );
    this.testDialog.bodyContainer.append(
      this.textButton,
      this.textButtonDisabled,
      this.textButtonWithHTML,
    );

    // OutlinedButton
    this.outlinedButton = UI.createOutlinedButton(
      "OutlinedButton Lorem ipsum dolor",
    );
    this.outlinedButtonDisabled = UI.createOutlinedButton(
      "OutlinedButton Disabled Lorem ipsum dolor",
    );
    this.outlinedButtonDisabled.setAttribute("disabled", "true");
    this.outlinedButtonWithHTML = UI.createOutlinedButton(
      this.testHTML.cloneNode(true),
    );
    this.testDialog.bodyContainer.append(
      this.outlinedButton,
      this.outlinedButtonDisabled,
      this.outlinedButtonWithHTML,
    );

    const downloadIcon = Oe`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="100%" viewBox="0 0 24 24" class="vot-loader" id="vot-loader-download">
            <path class="vot-loader-main" d="M12 15.575C11.8667 15.575 11.7417 15.5542 11.625 15.5125C11.5083 15.4708 11.4 15.4 11.3 15.3L7.7 11.7C7.5 11.5 7.40417 11.2667 7.4125 11C7.42083 10.7333 7.51667 10.5 7.7 10.3C7.9 10.1 8.1375 9.99583 8.4125 9.9875C8.6875 9.97917 8.925 10.075 9.125 10.275L11 12.15V5C11 4.71667 11.0958 4.47917 11.2875 4.2875C11.4792 4.09583 11.7167 4 12 4C12.2833 4 12.5208 4.09583 12.7125 4.2875C12.9042 4.47917 13 4.71667 13 5V12.15L14.875 10.275C15.075 10.075 15.3125 9.97917 15.5875 9.9875C15.8625 9.99583 16.1 10.1 16.3 10.3C16.4833 10.5 16.5792 10.7333 16.5875 11C16.5958 11.2667 16.5 11.5 16.3 11.7L12.7 15.3C12.6 15.4 12.4917 15.4708 12.375 15.5125C12.2583 15.5542 12.1333 15.575 12 15.575ZM6 20C5.45 20 4.97917 19.8042 4.5875 19.4125C4.19583 19.0208 4 18.55 4 18V16C4 15.7167 4.09583 15.4792 4.2875 15.2875C4.47917 15.0958 4.71667 15 5 15C5.28333 15 5.52083 15.0958 5.7125 15.2875C5.90417 15.4792 6 15.7167 6 16V18H18V16C18 15.7167 18.0958 15.4792 18.2875 15.2875C18.4792 15.0958 18.7167 15 19 15C19.2833 15 19.5208 15.0958 19.7125 15.2875C19.9042 15.4792 20 15.7167 20 16V18C20 18.55 19.8042 19.0208 19.4125 19.4125C19.0208 19.8042 18.55 20 18 20H6Z"/>
            <path class="vot-loader-helper" d=""/>
         </svg>`;

    // IconButton
    this.iconButton = UI.createIconButton(downloadIcon);
    this.iconButtonWithProgress = UI.createIconButton(downloadIcon);
    this.iconButtonDisabled = UI.createIconButton(downloadIcon);
    this.iconButtonDisabled.setAttribute("disabled", "true");
    this.testDialog.bodyContainer.append(
      this.iconButton,
      this.iconButtonWithProgress,
      this.iconButtonDisabled,
    );

    // Checkbox
    this.checkbox = UI.createCheckbox("Checkbox Lorem ipsum dolor", true);
    this.checkboxDisabled = UI.createCheckbox(
      "Checkbox Disabled Lorem ipsum dolor",
      true,
    );
    this.checkboxDisabled.input.disabled = true;
    this.checkboxWithHTML = UI.createCheckbox(
      this.testHTML.cloneNode(true),
      false,
    );

    this.testDialog.bodyContainer.append(
      this.checkbox.container,
      this.checkboxDisabled.container,
      this.checkboxWithHTML.container,
    );

    // Slider
    this.slider = UI.createSlider("Slider Lorem ipsum dolor");
    this.sliderDisabled = UI.createSlider("Slider Disabled Lorem ipsum dolor");
    this.sliderDisabled.input.disabled = true;
    this.sliderWithHTML = UI.createSlider(
      this.testHTML.cloneNode(true),
      2,
      0,
      300,
    );

    this.testDialog.bodyContainer.append(
      this.slider.container,
      this.sliderDisabled.container,
      this.sliderWithHTML.container,
    );

    // Textfield
    this.textfield = UI.createTextfield(
      "Textfield Lorem ipsum dolor",
      "",
      "test",
    );
    this.textfieldWithoutLabel = UI.createTextfield("", "", "test");
    this.textfieldWithoutValue = UI.createTextfield(
      "Textfield Without Value",
      "",
      "",
    );
    this.textfieldDisabled = UI.createTextfield(
      "Textfield Disabled Lorem ipsum dolor",
      "",
      "",
    );
    this.textfieldDisabled.input.disabled = true;
    this.textfieldWithHTML = UI.createTextfield(
      this.testHTML.cloneNode(true),
      "lorem ipsum dolor",
      "lorem ipsum 1231",
      true,
    );

    this.testDialog.bodyContainer.append(
      this.textfield.container,
      this.textfieldWithoutLabel.container,
      this.textfieldWithoutValue.container,
      this.textfieldDisabled.container,
      this.textfieldWithHTML.container,
    );

    // VOTButton
    this.votButton = UI.createVOTButton("Translate");
    this.votButton.container.style.left = "20%";
    this.votButtonWithHTML = UI.createVOTButton(this.testHTML.cloneNode(true));
    this.votButtonWithHTML.container.style.marginTop = "100px";
    this.votButtonWithHTML.container.style.left = "20%";

    // tooltip
    // ! Now vot code doesn't have portal
    this.votPortal = UI.createPortal();
    document.documentElement.appendChild(this.votPortal);

    this.testTooltipContent = UI.createEl("p", [], "Use logical sides too 👍🏻");
    this.testTooltipBContent = this.testTooltipContent.cloneNode(true);
    this.testTooltipLContent = this.testTooltipContent.cloneNode(true);
    // TODO: max width
    this.testTooltipRContent = UI.createEl(
      "p",
      [],
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis ",
    );
    this.tooltipEl = new Tooltip({
      target: this.votButton.menuButton,
      content: this.testTooltipContent,
      position: "top",
      parentElement: this.votPortal,
    });
    this.tooltipBEl = new Tooltip({
      target: this.votButton.menuButton,
      content: this.testTooltipBContent,
      position: "bottom",
      parentElement: this.votPortal,
    });
    this.tooltipREl = new Tooltip({
      target: this.votButton.menuButton,
      content: this.testTooltipRContent,
      position: "right",
      parentElement: this.votPortal,
    });
    this.tooltipLEl = new Tooltip({
      target: this.votButton.container,
      content: this.testTooltipLContent,
      position: "left",
      trigger: "click",
      parentElement: this.votPortal,
    });

    // VOTMenu
    this.votMenu = UI.createVOTMenu("VOTMenu Lorem ipsum dolor");
    this.votMenu.container.hidden = false;
    this.votMenu.container.style.marginTop = "100px";
    this.votMenu.container.style.left = "20%";
    this.votMenuWithHTML = UI.createVOTMenu(this.testHTML.cloneNode(true));
    this.votMenuWithHTML.container.hidden = false;
    this.votMenuWithHTML.container.style.marginTop = "250px";
    this.votMenuWithHTML.container.style.left = "20%";

    // VOTSelectLabel
    this.votSelectLabel = UI.createVOTSelectLabel(
      "VOTSelectLabel Lorem ipsum dolor",
    );
    this.testDialog.bodyContainer.append(this.votSelectLabel);

    // VOTSelect
    this.votSelect = UI.createVOTSelect(
      "VOTSelect Lorem ipsum dolor",
      "VOTSelect Dialog Lorem ipsum dolor",
      [
        {
          label: "label Lorem ipsum dolor",
          value: "value Lorem ipsum dolor",
          selected: false,
        },
      ],
    );
    this.testDialog.bodyContainer.append(this.votSelect.container);

    this.testDialog.container.hidden = false;

    document.documentElement.append(
      this.testDialog.container,
      this.votButton.container,
      this.votButtonWithHTML.container,
      this.votMenu.container,
      this.votMenuWithHTML.container,
    );

    // test animation
    const primaryColor = getComputedStyle(
      this.iconButtonWithProgress,
    ).getPropertyValue("--vot-primary-rgb");
    const updateAnimation = UI.animateLoader(
      this.iconButtonWithProgress,
      primaryColor,
    );

    let percentage = 0;
    let timer = setInterval(() => {
      updateAnimation(Math.round(percentage));
      percentage++;
      if (percentage === 100) {
        clearInterval(timer);
        UI.afterAnimateLoader(this.iconButtonWithProgress, primaryColor);
      }
    }, 100);
  }
}

new TestUI().initUI();

})();

/******/ })()
;