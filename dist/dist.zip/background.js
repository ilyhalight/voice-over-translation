chrome.runtime.onInstalled.addListener(() => {
  chrome.scripting.registerContentScripts([
    {
      id: "userscript",
      matches: ["<all_urls>"],
      js: ["vot.user.js"],
      runAt: "document_end",
    },
  ]);
});
